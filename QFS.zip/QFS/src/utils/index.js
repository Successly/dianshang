function formatNumber (n) {
  const str = n.toString()
  return str[1] ? str : `0${str}`
}

export function formatTime (date) {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()

  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  const t1 = [year, month, day].map(formatNumber).join('/')
  const t2 = [hour, minute, second].map(formatNumber).join(':')

  return `${t1} ${t2}`
}
// 跳转
function goto (way, path, data) {
  data = data || ''

  if (data) {
    var str = '?'
    for (var k in data) {
      str += k + '=' + data[k] + '&'
    }
    var newstr = str.substr(0, str.lastIndexOf('&'))
  } else {
    newstr = ''
  }

  // 保留当前页面， 跳转到应用内的某个页面
  // 使用 wx.navigateBack  可以返回
  if (way === 'navigateTo') {
    wx.navigateTo({
      url: `/pages/${path}${newstr}`
    })
  } else if (way === 'switchTab') {
    // 跳转到带有tab的页面
    wx.switchTab({
      url: `/pages/${path}${newstr}`
    })
  } else if (way === 'redirectTo') {
    // 跳转到非tabBar的某个页面
    wx.redirectTo({
      url: `/pages/${path}${newstr}`
    })
  } else if (way === 'navigateBack') {
    // 关闭当前页面，返回上一页面或多级页面
    wx.navigateBack({
      delta: 1, // 返回的层技数
      url: `/pages/${path}${newstr}`
    })
  } else {
    //  关闭所有页面，打开到应用内的某个页面
    wx.reLaunch({
      delta: 1, // 返回的层技数
      url: `/pages/${path}${newstr}`
    })
  }
}
/**
 * 时间格式化
 */
export function formatDate (date, fmt) {
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
  }
  let o = {
    'M+': date.getMonth() + 1,
    'd+': date.getDate(),
    'h+': date.getHours(),
    'm+': date.getMinutes(),
    's+': date.getSeconds()
  }
  for (let k in o) {
    if (new RegExp(`(${k})`).test(fmt)) {
      let str = o[k] + ''
      fmt = fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? str : padLeftZero(str))
    }
  }
  return fmt
}

function padLeftZero (str) {
  return ('00' + str).substr(str.length)
}

export function datePlus (date, plusNum) {
  var t = date;
  var t_s = date.getTime();
  t.setTime(t_s + 1000 * 60 * 60 * 24 * plusNum);
  return t;
}

export function dateSubtract (date, subtractNum) {
  var t = date;
  var t_s = date.getTime();
  t.setTime(t_s - 1000 * 60 * 60 * 24 * subtractNum);
  return t;
}

export function formatDateToWeek (date) {
  var myddy = date.getDay();
  var weekday = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
  return weekday[myddy];
}
export default {
  formatNumber,
  formatTime,
  formatDate,
  goto
}
