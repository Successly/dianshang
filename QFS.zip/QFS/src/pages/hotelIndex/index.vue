<template>
  <div class="hotelIndex">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <div class="div-1">
        <i class="attention-btn" @click="click1(isAttention)" v-if="isAttentionFlag">{{isAttention == true ? '已关注' : '+关注'}}</i>
        <!--<img :src="data && data.images && data.images[0]" />-->
        <swiper
          v-if="data && data.banners"
          indicator-dots="true"
          indicator-color="#ffffff"
          indicator-active-color="#0878FF"
          autoplay="true"
          :interval="interval"
          :duration="duration"
        >
          <swiper-item v-for="(item,index) in data.banners" :key="index">
            <image :src="item.image" class="slide-image"/>
          </swiper-item>
        </swiper>
        <div class="div-1-1">
          <!-- <span class="span-1 day" :class="type === 'day' ? 'active' : ''" @click="clickDay">整日租赁1</span>
          <span class="span-2 hour" :class="type === 'hour' ? 'active' : ''" @click="clickHour">分时租赁1</span> -->
            <div class="div-wrap">
            <span class="" :class="type === 'day' ? 'active' : ''" @click="clickDay">整日租赁</span>
            <span class="ml" :class="type === 'hour' ? 'active' : ''" @click="clickHour">分时租赁</span>
            </div>
          <span class="span-3" v-if="type === 'day'">入住 <i>{{dayStart}}</i>{{dayWeek1}}</span>
          <span class="span-3" v-if="type === 'hour'">入住 <i>{{hourStart}}</i>{{hourWeek1}}</span>
          <span class="span-4" v-if="type === 'day'">离开 <i>{{dayEnd}}</i>{{dayWeek2}}</span>
          <span class="span-4" v-if="type === 'hour'">离开 <i>{{hourEnd}}</i>{{hourWeek2}}</span>
          <span class="span-5" @click="modTime">点击修改时间</span>
          <span class="a1" @click="modTime" v-if="type === 'day'">共{{dayTotal}} ></span>
          <span class="a1" @click="modTime" v-if="type === 'hour'">共{{hourTotal}} ></span>
          <p @click="gotoRoomList" class="a2">搜索客房</p>
          <timeSelect @onOkSelected="onOkSelected" v-if="tiemShow" :tiemShow="tiemShow"  :startTime="dayStart" :endTime="dayEnd"></timeSelect>
          <hourSelect @onOkSelected="onOkSelected" v-if="hourShow" :hourShow="hourShow" :startTime="hourStart" :endTime="hourEnd"></hourSelect>
        </div>
        <div class="div-1-2">
          <a class="a1" href="/pages/hotelMember/main">会员中心</a>
          <a class="a2" href="/pages/couponCenter/main">领券中心</a>
          <a class="a3" href="/pages/debit/main">储值优惠</a>
        </div>
        <div class="div-1-3">当前活动</div>
        <div class="div-1-4" v-if="data.promotionToday&&data.promotionToday[0].title&& data.promotionToday[0].detail">
          <span class="span-1">{{data && data.promotionToday && data.promotionToday[0].title}}：</span>
          <span class="span-2">{{data && data.promotionToday && data.promotionToday[0].detail}}</span>
          <a class="span-3" href="/pages/hotelMember/main">更享会员折扣 ></a>
        </div>
      </div>
      <div class="sp"></div>
      <div class="div-2">
        <h3>酒店特色</h3>
        <span v-for="(tip,ids) in data.features" :key="ids">
          {{ids + 1}}.{{tip}}
        </span>
        <!-- <span>1.酒店紧邻江宁大学城、文鼎广场，交通便利、购物消费快捷；</span>
        <span>2.向北500米，即可到达方山公园，休闲娱乐；</span>
        <span>3.同时住客还可享受无线网络、休闲随心阅读等特色服务。</span> -->
      </div>
      <div class="sp"></div>
      <div class="div-3">
        <h3>分时酒店联盟·{{data.name}}</h3>
        <div class="swiper-home">
          <scroll-view scroll-x="true" style="width: 100%">
            <div class="swiper-item" v-for="(item, index) in imgs" :key="index">
              <img :src="item">
            </div>
          </scroll-view>
        </div>
        <!-- <div v-for="img in imgs">
          <img v-bind:src="img.image" />
        </div> -->
      </div>
      <div class="impower-1" :class="box === 1 ? '' : 'displaynone'">
        <div class="impower-box">
          <div class="impower-logo"></div>
          <div class="impower-div1">欢迎来到分时酒店联盟</div>
          <div class="impower-div2">授权获取你的手机号</div>
          <div class="impower-div3">分时酒店联盟不会将你的信息提供给第三方仅用于酒店预定等个人信息展示</div>
          <div class="impower-div4">点击授权即表示已阅读并同意<a href="/pages/impower/main">《分时酒店联盟用户许可协议》</a></div>
          <button open-type="getPhoneNumber" @getphonenumber="getPhoneNumber">授权</button>
        </div>
      </div>
      <div class="impower-2" :class="box === 2 ? '' : 'displaynone'">
        <div class="sp"></div>
        <div class="impower-box">
          <div class="impower-div1">提示</div>
          <div class="impower-div2">小程序即将获取您的昵称公开信息</div>
          <div class="impower-div3">（昵称、头像等）</div>
          <button class="span-1" open-type="getUserInfo" @getuserinfo="bindgetuserinfo">确定</button>
        </div>
      </div>
    </scroll-view>
  </div>
</template>
<script>
import timeSelect from "../../components/timeSelect";
import hourSelect from "../../components/hourSelect";
export default {
  components: { timeSelect, hourSelect },
  data() {
    return {
      interval: 1500, //轮播图切换时间
      duration: 500, //轮播动画过度时间
      data1: {},
      data: {},
      imgs: [],
      tiemShow: false,
      hourShow: false,
      isAttention: false,
      type: 'hour',
      hourTotal: '3小时',
      hourTotal1: '3',
      dayTotal: '1整天',
      dayTotal1: '1',
      hourStart: '',
      hourStart1: '',
      dayStart: '',
      dayStart1: '',
      end: '',
      hourEnd: '',
      hourEnd1: '',
      dayEnd: '',
      dayEnd1: '',
      hourWeek1: '',
      dayWeek1: '',
      hourWeek2: '',
      dayWeek2: '',
      hourStartTime: '',
      hourEndTime: '',
      dayStartTime: '',
      dayEndTime: '',
      imgUrl: '',
      box: 0,
      dayFlag: true,
      hourFlag: true,
      isAttentionFlag:false
    };
  },
  methods: {
    onOkSelected(res) {
      this.tiemShow = false;
      this.hourShow = false;
      if (this.type === 'hour') {
        this.hourFlag = false
        this.hourStart = res.enter
        this.hourStart1 = res.enter1
        this.hourEnd = res.leave
        this.hourEnd1 = res.leave1
        this.hourTotal = res.total
        this.hourTotal1 = res.total1
        this.hourWeek1 = res.week1
        this.hourWeek2 = res.week2
        this.hourStartTime = res.enter1
        this.hourEndTime = res.leave1
        wx.setStorageSync('hourStart', this.hourStart)
        wx.setStorageSync('hourStart1', this.hourStart1)
        wx.setStorageSync('hourEnd', this.hourEnd)
        wx.setStorageSync('hourEnd1', this.hourEnd1)
        wx.setStorageSync('hourTotal', this.hourTotal)
        wx.setStorageSync('hourTotal1', this.hourTotal1)
        wx.setStorageSync('hourWeek1', this.hourWeek1)
        wx.setStorageSync('hourWeek2', this.hourWeek2)
        wx.setStorageSync('hourStartTime', this.hourStartTime)
        wx.setStorageSync('hourEndTime', this.hourEndTime)
      } else {
        this.dayFlag = false
        this.dayStart = res.enter+'12:00'
        this.dayStart1 = res.enter1
        this.dayEnd = res.leave+'12:00'
        this.dayEnd1 = res.leave1
        this.dayTotal = res.total
        this.dayTotal1 = res.total1
        this.dayWeek1 = res.week1
        this.dayWeek2 = res.week2
        this.dayStartTime = res.enter1
        this.dayEndTime = res.leave1
        wx.setStorageSync('dayStart', this.dayStart)
        wx.setStorageSync('dayStart1', this.dayStart1)
        wx.setStorageSync('dayEnd', this.dayEnd)
        wx.setStorageSync('dayEnd1', this.dayEnd1)
        wx.setStorageSync('dayTotal', this.dayTotal)
        wx.setStorageSync('dayTotal1', this.dayTotal1)
        wx.setStorageSync('dayWeek1', this.dayWeek1)
        wx.setStorageSync('dayWeek2', this.dayWeek2)
        wx.setStorageSync('dayStartTime', this.dayStartTime)
        wx.setStorageSync('dayEndTime', this.dayEndTime)
      }
    },
    setHourTime () {
      let today = new Date()
      let todayYear = today.getFullYear()
      let todayMonth = today.getMonth() + 1
      todayMonth = todayMonth < 10 ? '0' + todayMonth : todayMonth
      let todayWeek = today.getDay()
      let todayDay = today.getDate() < 10 ? '0' + today.getDate() : today.getDate()
      let todayHour = today.getHours()
      let todayMin = today.getMinutes()
      let tomorrow = new Date(new Date().getTime() + 24*60*60*1000)
      let tomorrowYear = tomorrow.getFullYear()
      let tomorrowMonth = tomorrow.getMonth() + 1
      tomorrowMonth = tomorrowMonth < 10 ? '0' + tomorrowMonth : tomorrowMonth
      let tomorrowWeek = tomorrow.getDay()
      let tomorrowDay = tomorrow.getDate() < 10 ? '0' + tomorrow.getDate() : tomorrow.getDate()
      let tomorrowHour = tomorrow.getHours()
      let tomorrowMin = tomorrow.getMinutes()
      let yesterday = new Date(new Date().getTime() - 24*60*60*1000)
      let yesterdayYear = yesterday.getFullYear()
      let yesterdayMonth = yesterday.getMonth() + 1
      yesterdayMonth = yesterdayMonth < 10 ? '0' + yesterdayMonth : yesterdayMonth
      let yesterdayWeek = yesterday.getDay()
      let yesterdayDay = yesterday.getDate() < 10 ? '0' + yesterday.getDay() : yesterday.getDate()
      let yesterdayHour = yesterday.getHours()
      let yesterdayMin = yesterday.getMinutes()
      let arr = ['日', '一', '二', '三', '四', '五', '六']
      if (todayHour < 12) {
        this.hourStart = todayMonth + '月' + todayDay + '日12:00'
        this.hourStart1 = todayYear + '-' + todayMonth + '-' + todayDay + ' 12:00:00'
        this.hourEnd = todayMonth + '月' + todayDay + '日15:00'
        this.hourEnd1 = todayYear + '-' + todayMonth + '-' + todayDay + ' 15:00:00'
        this.hourWeek1 = '周' + arr[todayWeek]
        this.hourWeek2 = '周' + arr[todayWeek]
        this.hourStartTime = todayYear + '-' + todayMonth + '-' + todayDay + ' 12:00:00'
        this.hourEndTime = todayYear + '-' + todayMonth + '-' + todayDay + ' 15:00:00'
      } else {
        this.hourStart = tomorrowMonth + '月' + tomorrowDay + '日12:00'
        this.hourStart1 = tomorrowYear + '-' + tomorrowMonth + '-' + tomorrowDay + ' 12:00:00'
        this.hourEnd = tomorrowMonth + '月' + tomorrowDay + '日15:00'
        this.hourEnd1 = tomorrowYear + '-' + tomorrowMonth + '-' + tomorrowDay + ' 15:00:00'
        this.hourWeek1 = '周' + arr[tomorrowWeek]
        this.hourWeek2 = '周' + arr[tomorrowWeek]
        this.hourStartTime = tomorrowYear + '-' + tomorrowMonth + '-' + tomorrowDay + ' 12:00:00'
        this.hourEndTime = tomorrowYear + '-' + tomorrowMonth + '-' + tomorrowDay + ' 15:00:00'
      }
      wx.setStorageSync('hourStart', this.hourStart)
      wx.setStorageSync('hourStart1', this.hourStart1)
      wx.setStorageSync('hourEnd', this.hourEnd)
      wx.setStorageSync('hourEnd1', this.hourEnd1)
      wx.setStorageSync('hourWeek1', this.hourWeek1)
      wx.setStorageSync('hourWeek2', this.hourWeek2)
      wx.setStorageSync('hourStartTime', this.hourStartTime)
      wx.setStorageSync('hourEndTime', this.hourEndTime)
      wx.setStorageSync('hourTotal', this.hourTotal)
      wx.setStorageSync('hourTotal1', this.hourTotal1)
    },
    setDayTime () {
      let today = new Date()
      let todayYear = today.getFullYear()
      let todayMonth = today.getMonth() + 1
      todayMonth = todayMonth < 10 ? '0' + todayMonth : todayMonth
      let todayWeek = today.getDay()
      let todayDay = today.getDate() < 10 ? '0' + today.getDate() : today.getDate()
      let todayHour = today.getHours()
      let todayMin = today.getMinutes()
      let tomorrow = new Date(new Date().getTime() + 24*60*60*1000)
      let tomorrowYear = tomorrow.getFullYear()
      let tomorrowMonth = tomorrow.getMonth() + 1
      tomorrowMonth = tomorrowMonth < 10 ? '0' + tomorrowMonth : tomorrowMonth
      let tomorrowWeek = tomorrow.getDay()
      let tomorrowDay = tomorrow.getDate() < 10 ? '0' + tomorrow.getDate() : tomorrow.getDate()
      let tomorrowHour = tomorrow.getHours()
      let tomorrowMin = tomorrow.getMinutes()
      let yesterday = new Date(new Date().getTime() - 24*60*60*1000)
      let yesterdayYear = yesterday.getFullYear()
      let yesterdayMonth = yesterday.getMonth() + 1
      yesterdayMonth = yesterdayMonth < 10 ? '0' + yesterdayMonth : yesterdayMonth
      let yesterdayWeek = yesterday.getDay()
      let yesterdayDay = yesterday.getDate() < 10 ? '0' + yesterday.getDay() : yesterday.getDate()
      let yesterdayHour = yesterday.getHours()
      let yesterdayMin = yesterday.getMinutes()
      let arr = ['日', '一', '二', '三', '四', '五', '六']
      if (todayHour < 6) {
        this.dayStart = yesterdayMonth + '月' + yesterdayDay + '日12:00'
        this.dayStart1 = yesterdayYear + '-' + yesterdayMonth + '-' + yesterdayDay
        this.dayEnd = todayMonth + '月' + todayDay + '日12:00'
        this.dayEnd1 = todayYear + '-' + todayMonth + '-' + todayDay
        this.dayWeek1 = '周' + arr[yesterdayWeek]
        this.dayWeek2 = '周' + arr[todayWeek]
        this.dayStartTime = yesterdayYear + '-' + yesterdayMonth + '-' + yesterdayDay
        this.dayEndTime = todayYear + '-' + todayMonth + '-' + todayDay
      } else {
        this.dayStart = todayMonth + '月' + todayDay + '日12:00'
        this.dayStart1 = todayYear + '-' + todayMonth + '-' + todayDay
        this.dayEnd = tomorrowMonth + '月' + tomorrowDay + '日12:00'
        this.dayEnd1 = tomorrowYear + '-' + tomorrowMonth + '-' + tomorrowDay
        this.dayWeek1 = '周' + arr[todayWeek]
        this.dayWeek2 = '周' + arr[tomorrowWeek]
        this.dayStartTime = todayYear + '-' + todayMonth + '-' + todayDay
        this.dayEndTime = tomorrowYear + '-' + tomorrowMonth + '-' + tomorrowDay
      }
      wx.setStorageSync('dayStart', this.dayStart)
      wx.setStorageSync('dayStart1', this.dayStart1)
      wx.setStorageSync('dayEnd', this.dayEnd)
      wx.setStorageSync('dayEnd1', this.dayEnd1)
      wx.setStorageSync('dayWeek1', this.dayWeek1)
      wx.setStorageSync('dayWeek2', this.dayWeek2)
      wx.setStorageSync('dayStartTime', this.dayStartTime)
      wx.setStorageSync('dayEndTime', this.dayEndTime)
      wx.setStorageSync('dayTotal', this.dayTotal)
      wx.setStorageSync('dayTotal1', this.dayTotal1)
    },
    gotoRoomList(){
      let _that = this;
      let time = _that.type == 'day'? _that.dayTotal : _that.hourTotal;
      wx.navigateTo({
        url: '/pages/roomList/main?type='+ _that.type + '&time='+time
      })
    },
    clickBox1 () {
      this.box = 0
    },
    clickBox2 () {
      this.box = 0
    },
    loginFn () {
      const me = this
      if (!wx.getStorageSync('phone')) {
        this.box = 1
      } else {
        wx.getSetting({
          success (res) {
            console.log(res.authSetting)
            if (res.authSetting['scope.userInfo']) {
              me.getData()
              me.getData1()
              me.getData2()
            } else {
              me.box = 2
            }
          }
        })
      }
      wx.login({
        success (res) {
          wx.request({
            url: me.globalData.globalUrl + '/register/getOpenId',
            data: {code: res.code},
            header: {
              'content-type': 'application/json'
            },
            success (response) {
              wx.setStorageSync('openid', response.data.data)
            },
            fail (res) {
              console.log(res)
            }
          })
        }
      })
    },
    bindgetuserinfo () {
      const me = this
      wx.getUserInfo({
        success (res) {
          const userInfo = res.userInfo
          wx.request({
            url: me.globalData.globalUrl + '/register/mAddOrUpdate',
            method: 'POST',
            data: {
              openId: wx.getStorageSync('openid'),
              name: userInfo.nickName,
              avatar: userInfo.avatarUrl,
              sex: userInfo.gender,
              province: userInfo.province,
              city: userInfo.city,
              mobile: wx.getStorageSync('phone')
            },
            success (response) {
              if (response.data.data) {
                me.box = 0
                wx.setStorageSync('memberId', response.data.data)
                me.getData()
                me.getData1()
                me.getData2()
              } else {
                me.box = 2
              }
            },
            fail (res) {
              console.log(res)
            }
          })
        }
      })
    },
    getPhoneNumber (e) {
      const me = this
      wx.login({
        success (res) {
          wx.request({
            url: me.globalData.globalUrl + '/register/getPhoneNumber',
            data: {
              encryptedData: e.mp.detail.encryptedData,
              code: res.code,
              iv: e.mp.detail.iv
            },
            header: {
              'content-type': 'application/json'
            },
            success (response) {
              if (response.data.data) {
                me.box = 0
                wx.setStorageSync('phone', response.data.data.phoneNumber)
                wx.getSetting({
                  success (res) {
                    console.log(res.authSetting)
                    if (res.authSetting['scope.userInfo']) {
                      me.getData()
                      me.getData1()
                    } else {
                      me.box = 2
                    }
                  }
                })
              } else {
                me.box = 1
              }
            },
            fail (res) {
              console.log(res)
            }
          })
        }
      })
    },
    clickHour () {
      if (this.type !== 'hour') {
        this.type = 'hour'
        if (this.hourFlag) {
          this.setHourTime()
        }
      }
    },
    clickDay () {
      if (this.type !== 'day') {
        this.type = 'day'
        if (this.dayFlag) {
          this.setDayTime()
        }
      }
    },
    toCenter() {
      wx.switchTab({
        url: "/pages/userCenter/main"
      });
    },
    modTime() {
      if (this.type === 'day') {
        this.tiemShow = true
        this.hourShow = false
      } else {
        this.timeShow = false
        this.hourShow = true
      }
    },
    getData() {
      const me = this;
      wx.request({
        url: this.globalData.globalUrl + `/hotel/hotels/${wx.getStorageSync('hotelId')}`,
        header: {
          "content-type": "application/json",
          memberId: wx.getStorageSync('memberId')
        },
        success(res) {
          console.log("/hotel/hotels/");
          console.log(res);
          me.data = res.data.data;
          me.imgs=res.data.data.images;
          wx.setStorage({
            key:"hotelBackgroundImg",
            data:res.data.data.images[0]
          })
        }
      });
    },
    getData1() {
      const me = this;
      console.log(this.globalData.globalUrl + `/member/${wx.getStorageSync('memberId')}/hotel/${wx.getStorageSync('hotelId')}`)
      wx.request({
        url: this.globalData.globalUrl + `/member/${wx.getStorageSync('memberId')}/hotel/${wx.getStorageSync('hotelId')}`,
        data: {
          id: wx.getStorageSync('hotelId')
        },
        header: {
          "content-type": "application/json",
          memberId: wx.getStorageSync('memberId')
        },
        success(res) {
//          me.data1 = res.data.data.hotels;
        }
      });
    },
    getData2() {
      const me = this;
      wx.request({
        url: this.globalData.globalUrl + "/banner/list",
        data: {
          hotelId: wx.getStorageSync('hotelId')
        },
        header: {
          "content-type": "application/json",
          memberId: wx.getStorageSync('memberId')
        },
        success(res) {
          // me.imgs = res.data.data;
        }
      });

      wx.request({
        url:'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wxe6dbe1a9d35901a6&secret=03530e48f49999fc290960e2811ecabf',
        success: function (res) {
          wx.request({
             url:'https://api.weixin.qq.com/wxa/getwxacode?access_token=' + res.data.access_token,
            method: "POST",
            data: {
              path: '/pages/hotelIndex/main?hotelId=1'
            },
            responseType:'arraybuffer',
            success: function (res) {
              me.imgUrl=wx.arrayBufferToBase64(res.data)
              console.log(res.data)   // 二维码
            },
            fail: function (res) {
              console.log('fail')
            }
          })
        },
        fail: function (res) {
          console.log('fail')
        }
      })


    },
    click1(flag) {
      wx.showLoading({
        title:  flag ? '正在取消关注...' : '正在关注...',
      })
      const me = this
      let tempUrl = me.isAttention ? '/member/follow/cancel' : "/member/follow/hotel";
      wx.request({
        url: this.globalData.globalUrl+ tempUrl,
        method: "POST",
        data: {
          hotelId: wx.getStorageSync('hotelId')
        },
        header: {
          "content-type": "application/json",
          memberId: wx.getStorageSync('memberId')
        },
        success(res) {
          console.log(res);
          if(res.data.code === 0){
            me.isAttention = !me.isAttention;
          }
        },
        fail(error){
          wx.hideLoading()
          wx.showToast({
            title: flag ? '取消失败，请稍后再试' : '关注失败，请稍后再试',
            icon: 'none',
            duration: 2000
          })
        },
        complete(){
          wx.hideLoading()
        }
      });
    },
    getStatus() {
      const me = this;
       wx.request({
          url: this.globalData.globalUrl + '/member/info',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success: function (res) {

              if(res.data.data){
                  me.isAttention  = res.data.data.isFollow== 0 ? false:true;
              }
          }
        });
    }
  },
  onLoad(item) {
    this.bindgetuserinfo ();
    console.log(item)
    if (item && item.hotelId) {
      let hotelId = decodeURIComponent(item.hotelId)
      wx.setStorageSync('hotelId', hotelId)
    }
    this.loginFn()
    this.setHourTime()
    this.setDayTime()
  },
  onShow () {
    console.log('onShow', this)
    this.isAttentionFlag=true;
    this.getStatus()
    this.dayStart = wx.getStorageSync('dayStart')
    this.dayStart1 = wx.getStorageSync('dayStart1')
    this.dayEnd = wx.getStorageSync('dayEnd')
    this.dayEnd1 = wx.getStorageSync('dayEnd1')
    this.dayTotal = wx.getStorageSync('dayTotal')
    this.dayTotal1 = wx.getStorageSync('dayTotal1')
    this.dayWeek1 = wx.getStorageSync('dayWeek1')
    this.dayWeek2 = wx.getStorageSync('dayWeek2')
    this.dayStartTime = wx.getStorageSync('dayStartTime')
    this.dayEndTime = wx.getStorageSync('dayEndTime')
    this.hourStart = wx.getStorageSync('hourStart')
    this.hourStart1 = wx.getStorageSync('hourStart1')
    this.hourEnd = wx.getStorageSync('hourEnd')
    this.hourEnd1 = wx.getStorageSync('hourEnd1')
    this.hourWeek1 = wx.getStorageSync('hourWeek1')
    this.hourWeek2 = wx.getStorageSync('hourWeek2')
    this.hourStartTime = wx.getStorageSync('hourStartTime')
    this.hourEndTime = wx.getStorageSync('hourEndTime')
    this.hourTotal = wx.getStorageSync('hourTotal')
    this.hourTotal1 = wx.getStorageSync('hourTotal1')
  }
};
</script>
<style scoped lang="less">
.displaynone {
  display: none;
}
.hotelIndex {
  background: #fff;
}
.sp {
  width: 100%;
  height: 20rpx;
  background: #f6f6f6;
}
.slide-image {
  width: 750rpx;
}
.div-1 {
  position: relative;
  width: 100%;
  height: 1090rpx;
  img {
    width: 100%;
    height: 423rpx;
  }
  .attention-btn {
    width: 120rpx;
    height: 50rpx;
    background: #000000;
    border-radius: 5rpx;
    color: #ffffff;
    font-size: 24rpx;
    line-height: 50rpx;
    text-align: center;
    opacity: 0.7;
    position: absolute;
    right: 30rpx;
    top: 35rpx;
    z-index: 1;
  }
  .div-1-1 {
    position: absolute;
    top: 305rpx;
    left: 30rpx;
    width: 690rpx;
    height: 360rpx;
    border-radius: 20rpx;
    z-index: 1;
    background: #fff;
    box-shadow: 0 0 40rpx #e5e5e5;
    .div-wrap {
      line-height: 80rpx;
      padding: 10rpx 30rpx;
      font-size: 28rpx;
      span {
        // width: 200rpx;
        display: inline-block;
      }
      .ml {
        margin-left: 30rpx;
      }
    }
    .span-1,
    .span-2 {
      position: absolute;
      top: 10rpx;
      width: 140rpx;
      height: 80rpx;
      line-height: 80rpx;
      font-size: 28rpx;
      color: #333;
      cursor: pointer;
    }
    .active {
      position: relative;
      font-weight: bold;
      font-size: 45rpx;
    }
    .active::after {
      // display: flex;
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0;
      border-bottom: 8rpx solid #35abfe;
      transform: scaleX(0.3);
      content: "";
    }
    .span-1 {
      left: 30rpx;
    }
    .day {
      width: 240rpx !important;
    }
    .hour {
      width: 240rpx !important;
    }
    .span-1 .span-2 {
      left: 220rpx;
    }
    .span-2.active {
      // left: 170rpx;
      width: 240rpx;
      font-size: 40rpx;
    }
    .span-3 {
      position: absolute;
      top: 104rpx;
      left: 30rpx;
      width: 400rpx;
      height: 48rpx;
      line-height: 48rpx;
      font-size: 32rpx;
      color: #999;
      i {
        display: inline-block;
        margin: 0 20rpx;
        color: #333;
      }
    }
    .span-4 {
      position: absolute;
      top: 152rpx;
      left: 30rpx;
      width: 400rpx;
      height: 48rpx;
      line-height: 48rpx;
      font-size: 32rpx;
      color: #999;
      i {
        display: inline-block;
        margin: 0 20rpx;
        color: #333;
      }
    }
    // .gochange-box {
    //   height: ;
    // }
    .span-5 {
      position: absolute;
      top: 164rpx;
      right: 0;
      width: 174rpx;
      height: 24rpx;
      line-height: 24rpx;
      font-size: 20rpx;
      color: #999;
    }
    .a1 {
      position: absolute;
      top: 130rpx;
      right: 0;
      width: 174rpx;
      height: 30rpx;
      line-height: 30rpx;
      font-size: 28rpx;
      color: #35abfe;
    }
    .a2 {
      position: absolute;
      bottom: 38rpx;
      left: 30rpx;
      width: 628rpx;
      height: 80rpx;
      border-radius: 16rpx;
      line-height: 80rpx;
      text-align: center;
      background: #35abfe;
      color: #fff;
      border-radius: 16rox;
      font-size: 34rpx;
    }
  }
  .div-1-2 {
    > a {
      box-sizing: border-box;
      position: absolute;
      top: 716rpx;
      width: 210rpx;
      padding: 80rpx 0 12rpx 0;
      height: 132rpx;
      line-height: 30rpx;
      text-align: center;
      border-radius: 8rpx;
      background: #fff;
      font-size: 24rpx;
      color: #666;
      box-shadow: 0 0 40rpx #e5e5e5;
    }
    .a1 {
      left: 30rpx;
      background: url("http://img.rainfn.com/qfs_p_0306_member-member.png")
        center 20rpx no-repeat;
      background-size: 60rpx 43rpx;
    }
    .a2 {
      left: 270rpx;
      background: url("http://img.rainfn.com/qfs_p_0306_index-icon1.png") center
        23rpx no-repeat;
      background-size: 60rpx 43rpx;
    }
    .a3 {
      left: 510rpx;
      background: url("http://img.rainfn.com/qfs_p_0306_icon-pig.png") center
        20rpx no-repeat;
      background-size: 60rpx 43rpx;
    }
  }
  .div-1-3 {
    position: absolute;
    bottom: 162rpx;
    left: 30rpx;
    padding-left: 54rpx;
    width: 400rpx;
    height: 40rpx;
    line-height: 40rpx;
    font-size: 34rpx;
    font-weight: 700;
    color: #333;
    background: url("http://img.rainfn.com/qfs_p_0306_index-icon2.png") 0 0
      no-repeat;
    background-size: 35rpx 40rpx;
  }
  .div-1-4 {
    font-size: 28rpx;
    color: #666;
    .span-1 {
      position: absolute;
      bottom: 104rpx;
      left: 50rpx;
      padding-left: 45rpx;
      width: 174rpx;
      height: 36rpx;
      line-height: 36rpx;
      background: url("http://img.rainfn.com/qfs_p_0306_index-icon3.png") 0 0
        no-repeat;
      background-size: 35rpx 35rpx;
    }
    .span-2 {
      position: absolute;
      bottom: 104rpx;
      left: 235rpx;
      width: 450rpx;
      height: 32rpx;
      line-height: 32rpx;
    }
    .span-3 {
      position: absolute;
      bottom: 64rpx;
      left: 235rpx;
      width: 450rpx;
      height: 32rpx;
      line-height: 32rpx;
    }
  }
}
.div-2 {
  box-sizing: border-box;
  padding-top: 36rpx;
  width: 100%;
  h3 {
    padding-left: 50rpx;
    margin: 0 0 20rpx 30rpx;
    width: 500rpx;
    height: 38rpx;
    line-height: 38rpx;
    color: #333;
    font-weight: 700;
    font-size: 34rpx;
    background: url("http://img.rainfn.com/qfs_p_0306_index-icon4.png") 0 0
      no-repeat;
    background-size: 38rpx 38rpx;
  }
  span {
    display: block;
    margin-left: 50rpx;
    width: 670rpx;
    line-height: 46rpx;
    font-size: 28rpx;
    color: #666;
  }
}
.div-3 {
  width: 100%;
  height: 396rpx;
  h3 {
    margin-left: 30rpx;
    width: 500rpx;
    height: 110rpx;
    line-height: 110rpx;
    font-size: 34rpx;
    font-weight: bold;
    color: #333;
  }
  > div {
    width: 100%;
    height: 235rpx;
  }
}
swiper {
  height: 424rpx;
}
.swiper-home {
  width: 100%;
  height: 225px;
  box-sizing: border-box;
  display: flex;
  white-space: nowrap;
  .swiper-item {
    width: 400rpx;
    height: 225rpx;
    border-radius: 10rpx;
    display: inline-block;
    margin: 0rpx 15rpx;
  }
  img {
    max-width: 100%;
    max-height: 100%;
  }
}
.impower-1 {
  position: fixed;
  top: 0;
  width: 100%;
  height: 100%;
  background: #fff;
  z-index: 1;
  .impower-box {
    position: absolute;
    top: 50%;
    margin-top: -350rpx;
    width: 100%;
    height: 700rpx;
    .impower-logo {
      position: absolute;
      top: 0;
      width: 100%;
      height: 150rpx;
      background: url("../../../static/images/impower-logo.png") center 0
        no-repeat;
      background-size: 150rpx 150rpx;
    }
    .impower-div1 {
      position: absolute;
      top: 175rpx;
      width: 100%;
      height: 54rpx;
      line-height: 54rpx;
      text-align: center;
      font-size: 36rpx;
      color: #333;
    }
    .impower-div2 {
      position: absolute;
      top: 230rpx;
      width: 100%;
      height: 54rpx;
      line-height: 54rpx;
      text-align: center;
      font-size: 36rpx;
      color: #333;
    }
    .impower-div3 {
      position: absolute;
      top: 320rpx;
      left: 125rpx;
      width: 500rpx;
      height: 80rpx;
      line-height: 40rpx;
      text-align: center;
      font-size: 26rpx;
      color: #999;
    }
    .impower-div4 {
      position: absolute;
      top: 590rpx;
      width: 100%;
      height: 30rpx;
      line-height: 30rpx;
      text-align: center;
      font-size: 22rpx;
      color: #999;
      a {
        display: inline-block;
        color: #3ebbff;
        font-size: 22rpx;
      }
    }
    button {
      position: absolute;
      left: 125rpx;
      top: 470rpx;
      width: 500rpx;
      height: 80rpx;
      line-height: 80rpx;
      background: #3ebbff;
      color: #fff;
      border-radius: 40rpx;
      font-size: 36rpx;
    }
  }
}
.impower-2 {
  position: fixed;
  top: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  .sp {
    position: absolute;
    width: 100%;
    height: 100%;
    z-index: 1;
    background: #f6f6f6;
    opacity: 0.7;
  }
  .impower-box {
    position: absolute;
    top: 50%;
    left: 50%;
    margin-top: -175rpx;
    margin-left: -300rpx;
    width: 600rpx;
    height: 350rpx;
    border-radius: 20rpx;
    z-index: 2;
    background: #fff;
    .impower-div1 {
      position: absolute;
      top: 30rpx;
      width: 100%;
      height: 60rpx;
      line-height: 60rpx;
      text-align: center;
      font-size: 36rpx;
      color: #333;
      font-weight: 500;
    }
    .impower-div2 {
      position: absolute;
      width: 100%;
      top: 110rpx;
      height: 40rpx;
      line-height: 40rpx;
      text-align: center;
      font-size: 32rpx;
      color: #666;
    }
    .impower-div3 {
      position: absolute;
      top: 165rpx;
      width: 100%;
      height: 40rpx;
      line-height: 40rpx;
      text-align: center;
      font-size: 32rpx;
      color: #666;
    }
    button {
      position: absolute;
      width: 100%;
      bottom: 0;
      height: 100rpx;
      line-height: 100rpx;
      font-size: 36rpx;
      text-align: center;
      color: #1aad19;
      border: none;
      background: #fff;
      border-top: 1px solid #e1e1e1;
      border-bottom-left-radius: 20rpx;
      border-bottom-right-radius: 20rpx;
    }
    button::after {
      border: none;
    }
  }
}
</style>
