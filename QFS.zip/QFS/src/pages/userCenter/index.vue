<template>
  <div class="userCenter">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <section class="section-1">
        <img :src="info.avatar" />
        <p class="user-name">{{info.name}}</p>
        <p class="user-level" v-if="info.mobile">{{info.mobile}}</p>
        <div class="user-card" v-if="info.gradeName">我的会员卡<a href="/pages/hotelMember/main">会员详情></a></div>
        <div class="user-card user-card-1" v-else>即刻开启会员生活<a href="" @click="toMember">限时免费开通></a></div>
        <div class="user-info">
          <div class="info-1" v-if="info.gradeName">
            <span class="info-span1">{{info.balance}}<b>元</b></span>
            <span class="info-span2">储蓄卡</span>
            <span class="info-span3">限时充值{{storedValue.cardDetail.length > 0 ? storedValue.cardDetail[0].money : ''}}送{{storedValue.cardDetail.length > 0 ? storedValue.cardDetail[0].giveMoney : 0}}</span>
          </div>
          <div class="info-1 info-1-1" v-else>开通即送优惠券</div>
          <div class="sp"></div>
          <div class="info-2" v-if="info.gradeName">
            <span class="info-span1">{{info.growthValue}}<b>值</b></span>
            <span class="info-span2">成长值</span>
            <span class="info-span3"></span>
          </div>
          <div class="info-2 info-2-1" v-else>最高享受{{maxDiscountOfGrade}}折</div>
          <div class="sp"></div>
          <div class="info-3" v-if="info.gradeName">
            <span class="info-span1">{{info.discount}}<b>折</b></span>
            <span class="info-span2">折扣权益</span>
            <span class="info-span3" v-if="maxDiscountOfGrade">最高享{{maxDiscountOfGrade}}折</span>
          </div>
          <div class="info-3 info-3-1" v-else>专属权益</div>
          <div class="my-order">
            <h3>我的订单</h3>
            <div>
              <a href="/pages/orderList/main?tab=1"><img src="http://img.rainfn.com/qfs_p_0306_user-icon1.png" /><span>待支付</span><i v-if="stayPay">{{stayPay}}</i></a>
              <a href="/pages/orderList/main?tab=2"><img src="http://img.rainfn.com/qfs_p_0306_user-icon2.png" /><span>待入住</span><i v-if="stayCheck">{{stayCheck}}</i></a>
              <a href="/pages/orderList/main?tab=3"><img src="http://img.rainfn.com/qfs_p_0306_user-icon3.png" /><span>退款/售后</span><i v-if="refund">{{refund}}</i></a>
              <a href="/pages/orderList/main?tab=0" ><img src="http://img.rainfn.com/qfs_p_0306_user-icon4.png" /><span>全部订单</span></a>
            </div>
          </div>
        </div>
      </section>
      <section class="section-2">
        <div class="gray-div">
          <div>
            <a href="/pages/coupon/main"><img src="http://img.rainfn.com/qfs_p_0306_user-icon5.png" /><span>优惠券</span></a>
            <a @click="gotoPhone(hotelIphone)"><img src="http://img.rainfn.com/qfs_p_0306_user-icon6-2.png" /><span>联系酒店</span></a>
          </div>
        </div>
      </section>
      <section class="section-3" style="display: none">
        <a><img src="http://img.rainfn.com/qfs_p_0306_card-1-1.png" /><span>首页</span></a>
        <a><img src="http://img.rainfn.com/qfs_p_0306_card-3-1.png" /><span>我的</span></a>
      </section>
    </scroll-view>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        info: {},
        hotelIphone:'',
        maxGiveMoneyOfCard: {},
        maxDiscountOfGrade: '',
        stayPay:0,
        stayCheck:0,
        refund:0,
        storedValue:""
      }
    },
    methods: {
      getHotel () {
        const me = this
        wx.request({
          url: this.globalData.globalUrl + `/hotel/hotels/${wx.getStorageSync('hotelId')}`,
          success (res) {
             me.hotelIphone = res.data.data.phone;
            // me.maxGiveMoneyOfCard = res.data.data.maxGiveMoneyOfCard;
            me.maxDiscountOfGrade = res.data.data.maxDiscountOfGrade;
            console.log("maxDiscountOfGrade",me.maxDiscountOfGrade)
          }
        })
      },
      getStoredValue(){
        const me = this;
         wx.request({
          url: this.globalData.globalUrl + '/card/detail',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            me.storedValue = res.data.data;
          }
        })
      },
      getData () {
        const me = this;
        wx.request({
          url: this.globalData.globalUrl + '/member/info',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success: function (res) {
            me.info =res.data.data? res.data.data:"";

          }
        })
        wx.request({
          url: this.globalData.globalUrl + '/roomOrder/orderCount',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            if (res.data.data) {
               me.stayPay=res.data.data.stayPay;
               me.stayCheck=res.data.data.stayCheck;
               me.refund=res.data.data.refund;
            }
          }
        })
      },
      gotoPhone (phonenum) {
           let me=this;
        if(phonenum){
          wx.makePhoneCall({
            phoneNumber: phonenum,
            success: function () {
              console.log('拨打电话成功')
            },
            fail: function () {
              console.log('拨打电话失败')
            }
          })
        }else{
          wx.showToast({
            title: '获取手机号失败，请刷新页面后重试',
            icon: 'eror',
            duration: 1500
          })
        }

      },
      toMember () {
         wx.navigateTo({
          url: '/pages/hotelMember/main'
        });
        // wx.request({
        //   url: this.globalData.globalUrl + '/member/open',
        //   data: {
        //     hotelId: wx.getStorageSync('hotelId')
        //   },
        //   header: {
        //     'content-type': 'application/json',
        //     'memberId': wx.getStorageSync('memberId')
        //   },
        //   success (res) {}
        // })
      }
    },
    mounted () {
    },
    created () {
      this.getData();
      this.getHotel();
    },
    onLoad(){
      this.getData();
      this.getHotel();
      this.getStoredValue();
    },
    onShow(){
      this.getData ();
      this.getHotel();
      this.getStoredValue();
    }
  }
</script>
<style scoped lang="less">
  section {
    background: #fff;
  }
  .section-1 {
    width: 100%;
    height: 800rpx;
    background: #fff url('http://img.rainfn.com/qfs_p_0306_user-bg.png') 0 -100rpx no-repeat;
    background-size: 750rpx 620rpx;
    text-align: center;
    >img {
      margin:34rpx auto 0 auto;
      width:120rpx;
      height:120rpx;
      border-radius:30rpx;
      box-shadow:0 4rpx 6rpx #aaa;
    }
  }

  .user-name {
    width: 100%;
    height: 45rpx;
    line-height: 45rpx;
    text-align: center;
    font-size: 32rpx;
    color: #fff;
  }
  .user-level {
    margin: 0 auto 15rpx auto;
    text-align: center;
    width: 148rpx;
    height: 33rpx;
    font-size: 24rpx;
    font-weight: 400;
    color: #fff;
    line-height: 33rpx;
  }
  .user-card {
    position:relative;
    box-sizing: border-box;
    padding-left: 20rpx;
    margin: 0 auto;
    width: 690rpx;
    height: 70rpx;
    line-height: 70rpx;
    font-size:26rpx;
    text-align:left;
    background: #fff;
    border-radius: 10rpx;
    a {
      position: absolute;
      top: 20rpx;
      right: 20rpx;
      width: 250rpx;
      line-height: 26rpx;
      text-align: right;
      color: #999;
    }
  }
  .user-card-1 {
    color: #3EBBFF;
    a {
      color: #3EBBFF;
    }
  }

  .user-info {
    margin: 8rpx auto 60rpx auto;
    width: 690rpx;
    height: 200rpx;
    background: #fff;
    border-radius: 10rpx;
    box-shadow : 0 8rpx 10rpx #f1f1f1;
    >div {
      float: left;
    }
    .sp {
      margin-top: 40rpx;
      width: 1px;
      height: 100rpx;
      background: #f1f1f1;
    }
    .info-1, .info-2, .info-3 {
      box-sizing: border-box;
      width: 225rpx;
      height: 100%;
    }
    .info-1-1 {
      background: url('../../../static/images/user-no-1.png') center 50rpx no-repeat;
      background-size: 64rpx 50rpx;
    }
    .info-2-1 {
      background: url('../../../static/images/user-no-2.png') center 52rpx no-repeat;
      background-size: 56rpx 56rpx;
    }
    .info-3-1 {
      background: url('../../../static/images/user-no-3.png') center 54rpx no-repeat;
      background-size: 60rpx 44rpx;
    }
    .info-1-1, .info-2-1, .info-3-1 {
      padding-top: 120rpx;
      line-height: 34rpx;
      color: #865F3C;
      font-size: 24rpx;
    }
  }

  .info-span1, .info-span2, .info-span3, .gray-div {
    display: block;
    width: 100%;
    height: 44rpx;
    line-height: 44rpx;
    text-align: center;
  }
  .info-span1 {
    margin-top: 30rpx;
    font-size: 48rpx;
    height: 67rpx!important;
    line-height: 67rpx!important;
    color: #35abfe;
    font-weight: 500;
    b {
      display: inline-block;
      font-size: 20rpx;
      height: 28rpx;
      line-height: 28rpx;
    }
  }

  .info-span2 {
    font-size: 28rpx;
    height: 40rpx!important;
    line-height: 40rpx!important;
    margin-bottom:8rpx;
  }
  .info-span3 {
    font-size: 20rpx;
    color: #e07376;
    height: 20rpx!important;
    line-height: 20rpx!important;
  }

  .my-order, .gray-div {
    width: 690rpx;
    height: 180rpx;
  }
  .my-order a, .gray-div a {
    position: relative;
    float: left;
    width: 25%;
    height: 140rpx;
  }
  .my-order {
    margin-top: 60rpx;
    height: 200rpx!important;
    h3 {
      width: 100%;
      height: 32rpx;
      line-height: 32rpx;
      text-align: left;
      font-size: 30rpx;
      font-weight: 600;
      color:#333;
    }

    a i {
      position: absolute;
      top: 20rpx;
      right: 50%;
      margin-right: -40rpx;
      width: 30rpx;
      height: 30rpx;
      line-height: 30rpx;
      font-size: 24rpx;
      border-radius: 15rpx;
      background: #ee4d53;
      color: #fff;
    }
    a img {
      margin: 40rpx auto 10rpx auto;
      width: 50rpx;
      height: 50rpx;
    }
    a span {
      display: block;
      width: 100%;
      height: 33rpx;
      line-height: 33rpx;
      font-size: 24rpx;
    }
  }

  .gray-div a img {
    margin: 50rpx auto 16rpx auto;
    width: 50rpx;
    height: 40rpx;
  }
  .gray-div a span {
    display: block;
    width: 100%;
    height: 33rpx;
    line-height: 33rpx;
    font-size: 24rpx;
  }
  .section-2 {
    margin-top: 20rpx;
  }
  .section-2 .gray-div {
    margin-left: 30rpx;
  }
  .section-3 {
    position: fixed;
    bottom: 0;
    width: 100%;
    height: 100rpx;
    border-top: 1px solid #f1f1f1;
    a {
      float: left;
      width: 50%;
      height: 100%;
      text-align: center;
      img {
        margin-top: 15rpx;
        width: 39rpx;
        height: 37rpx;
      }
      span {
        display: block;
        font-size: 24rpx;
        color: #999;
      }
    }
  }

</style>
