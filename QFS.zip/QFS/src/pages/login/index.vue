<template>
  <div class="login">
    <scroll-view scroll-y style="height:calc(100vh)" scroll-top="0">
      <div class="login-1" :class="box === 1 ? '' : 'displaynone'">
        <div class="sp"></div>
        <div class="login-box">
          <h3>趣分时 申请获得</h3>
          <div class="div-1">您的手机号码</div>
          <div class="div-2">
            <span class="span1">13012345678</span>
            <span class="span2">微信绑定号码</span>
          </div>
          <div class="div-3" @click="clickFn1">使用其他手机号码</div>
          <button class="button1">拒绝</button>
          <button class="button2" @click="clickFn2">允许</button>
        </div>
      </div>
      <div class="login-2">
        <div class="sp"></div>
        <div class="login-box">
          <div class="div-1">微信手机号授权</div>
          <div class="div-2">趣分时</div>
          <div class="div-3">申请获取您的微信绑定手机号</div>
          <div class="div-4">
            <span class="span-1">取消</span>
            <!--<button class="span-1" open-type="getUserInfo" @getuserinfo="bindgetuserinfo">确认授权</button>-->
            <!--<button class="span-1" open-type="getPhoneNumber" bindgetphonenumber="getPhoneNumber">确认授权</button>-->
            <button open-type="getPhoneNumber" @getphonenumber="getPhoneNumber">确认授权</button>

          </div>
        </div>
      </div>
      <div class="login-3" :class="box === 3 ? '' : 'displaynone'">
        <div class="sp"></div>
        <div class="login-box">
          <div class="div-1">其他手机号码登录</div>
          <div class="div-2">
            <input v-model="mobile" placeholder="请输入手机号" />
            <span @click="getCode">获取验证码</span>
          </div>
          <div class="div-3">
            <input v-model="code" placeholder="请输入短信验证码" />
          </div>
          <button @click="clickFn3">登录</button>
        </div>
      </div>
    </scroll-view>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        box: 1,
        mobile: '',
        code: ''
      }
    },
    mounted () {
      const me = this
      wx.login({
        success (res) {
          wx.request({
            url: me.globalData.globalUrl + '/register/getOpenId',
            data: {code: res.code},
            header: {
              'content-type': 'application/json'
            },
            success (response) {
              wx.setStorageSync('openid', response.data.data)
            },
            fail (res) {
              console.log(res)
            }
          })
        }
      })
    },
    methods: {
      getPhoneNumber (e) {
        const me = this
        wx.login({
          success (res) {
            wx.request({
              url: me.globalData.globalUrl + '/register/getPhoneNumber',
              data: {
                encryptedData: e.mp.detail.encryptedData,
                code: res.code,
                iv: e.mp.detail.iv
              },
              header: {
                'content-type': 'application/json'
              },
              success (response) {
                console.log('请求获取openid:' + response.data.data)
              },
              fail (res) {
                console.log(res)
              }
            })
          }
        })
      },
      bindgetuserinfo (e) {
        console.log(e)
        wx.setStorageSync('userInfo', e.mp.detail.userInfo)
        const me = this
        wx.login({
          success (res) {
            wx.request({
              url: me.globalData.globalUrl + '/register/getPhoneNumber',
              data: {
                encryptedData: e.mp.detail.encryptedData,
                code: res.code,
                iv: e.mp.detail.iv
              },
              header: {
                'content-type': 'application/json',
                'memberId': wx.getStorageSync('memberId')
              },
              success (response) {
                console.log('请求获取openid:' + response.data.data)
              },
              fail (res) {
                console.log(res)
              }
            })
          }
        })
      },
      clickFn1 () {
        this.box = 3
      },
      clickFn2 () {
        wx.request({
          url: this.globalData.globalUrl + '/register/mAddOrUpdate',
          method: 'POST',
          data: {
            openId: wx.getStorageSync('openid'),
            name: wx.getStorageSync('userInfo').nickName,
            avatar: wx.getStorageSync('userInfo').avatarUrl,
            sex: wx.getStorageSync('userInfo').gender,
            province: wx.getStorageSync('userInfo').province,
            city: wx.getStorageSync('userInfo').city,
            mobile: 13012345678
          },
          success (response) {
            console.log('请求获取openid:' + response.data.data)
          },
          fail (res) {
            console.log(res)
          }
        })
      },
      clickFn3 () {
        const me = this
        wx.request({
          url: this.globalData.globalUrl + '/register/sendCode',
          data: {
            mobile: this.mobile,
            code: this.code
          },
          method: 'POST',
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (response) {
            console.log('请求获取openid:' + response.data.data)
            wx.request({
              url: me.globalData.globalUrl + '/register/mAddOrUpdate',
              method: 'POST',
              data: {
                openId: wx.getStorageSync('openid'),
                name: wx.getStorageSync('userInfo').nickName,
                avatar: wx.getStorageSync('userInfo').avatarUrl,
                sex: wx.getStorageSync('userInfo').gender,
                province: wx.getStorageSync('userInfo').province,
                city: wx.getStorageSync('userInfo').city,
                mobile: me.mobile
              },
              success (response) {
                console.log('请求获取openid:' + response.data.data)
              },
              fail (res) {
                console.log(res)
              }
            })
          },
          fail (res) {
            console.log(res)
          }
        })
      },
      getCode () {
        wx.request({
          url: this.globalData.globalUrl + '/register/sendSms',
          data: {
            mobile: this.mobile
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (response) {},
          fail (res) {
            console.log(res)
          }
        })
      }
    }
  }
</script>
<style scoped lang="less">
  .displaynone {
    display: none;
  }
  .login-1 {
    position: fixed;
    width: 100%;
    height: 100%;
    z-index: 1;
    .sp {
      width: 100%;
      height: 100%;
      background: #000;
      z-index: 2;
      opacity: .6;
    }
    .login-box {
      position: absolute;
      bottom: 0;
      width: 100%;
      height: 700rpx;
      background: #fff;
    }
  }
  .login-2 {
    position: fixed;
    width: 100%;
    height: 100%;
    z-index: 1;
    .sp {
      width: 100%;
      height: 100%;
      z-index: 2;
      background: #000;
      opacity: .6;
    }
    .login-box {
      box-sizing: border-box;
      position: absolute;
      top: 50%;
      left: 50%;
      margin-top: -300rpx;
      margin-left: -300rpx;
      width: 600rpx;
      height: 600rpx;
      background: #fff;
      font-size: 28rpx;
      .div-1 {
        width: 100%;
        height: 100rpx;
        line-height: 100rpx;
        text-align: center;
        color: #666;
        border-bottom: 1px solid #f1f1f1;
        box-sizing: border-box;
        font-size: 28rpx;
      }
      .div-2 {
        margin: 0 auto;
        width: 500rpx;
        height: 240rpx;
        text-align: center;
        color: #666;
        border-bottom: 1px solid #f1f1f1;
        box-sizing: border-box;
        font-size: 28rpx;
        background: url('../../../static/images/qfs-icon.png') center center no-repeat;
        background-size: 100rpx 100rpx;
      }
      .div-3 {
        width: 100%;
        height: 160rpx;
        color: #999;
        box-sizing: border-box;
        font-size: 28rpx;
        text-align: center;
      }
      .div-4 {
        width: 100%;
        height: 100rpx;
        border-top: 1px solid #f1f1f1;
        box-sizing: border-box;
        font-size: 28rpx;
        .span-1 {
          float: left;
          display: block;
          width: 50%;
          height: 100rpx;
          line-height: 100rpx;
          text-align: center;
          color: #999;
          border-right: 1px solid #f1f1f1;
          box-sizing: border-box;
          font-size: 28rpx;
        }
        button {
          float: left;
          width: 50%;
          height: 96rpx;
          line-height: 100rpx;
          text-align: center;
          color: #666;
          background: #fff;
        }
        button::after{
          border: none;
        }
      }
    }
  }
  .login-3 {
    position: fixed;
    width: 100%;
    height: 100%;
    z-index: 1;
    .sp {
      width: 100%;
      height: 100%;
      z-index: 2;
      background: #000;
      opacity: .6;
    }
    .login-box {
      position: absolute;
      top: 50%;
      left: 50%;
      margin-top: -250rpx;
      margin-left: -300rpx;
      width: 600rpx;
      height: 500rpx;
      background: #fff;
    }
  }
</style>
