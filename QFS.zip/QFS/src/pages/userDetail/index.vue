<template>
  <div class="userDetail">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <section class="section-top">
        <img src="http://img.rainfn.com/qfs_p_0306_userDetail-top.png" />
      </section>
      <section class="section-1">
        <div class="shuoming">酒店会员是趣分时联合酒店共同推出的服务，旨在为用户提供更完善、更全面且更优惠的服务；此会员权益、服务均为专属酒店提供，不可跨酒店使用。</div>
      </section>
      <section class="section-2">
        <h3 class="hy-title">酒店会员基本描述</h3>
        <div>
          <p>会员分为白银会员、黄金会员、白金会员、钻石会员、至尊会员5个等级；</p>
          <p>等级由“成长值”决定，成长值主要与消费金额和日常任务相关，亦可以通过购买储值卡快速获取；</p>
          <p>成长值越高，等级越高，对应可享受的权益也更多、更优惠；</p>
          <p>趣分时亦将联合酒店持续丰富等级权益。</p>
        </div>
      </section>
      <section class="section-3">
        <h3>会员成长值公式</h3>
        <div>会员成长值 = 消费成长值 + 任务成长值</div>
      </section>
      <section class="section-4">
        <h3>升级宝典</h3>
        <div>
          <p>1、会员本人通过在酒店小程序产生以下消费项目</p>
          <div class="user-table">
            <div class="user-tr">
              <div>消费项目</div>
              <div>加权项</div>
            </div>
            <div class="user-tr">
              <div>预订酒店</div>
              <div>1元=1成长值</div>
            </div>
            <div class="user-tr">
              <div>购买储值卡</div>
              <div>500元/1000元储值</div>
            </div>
          </div>
          <p>2、会员本人完成以下任务， 获取成长值</p>
          <div class="user-panel user-panel1">
            <i></i>
            <span class="title">关注酒店</span>
            <span class="des">50成长值，仅限-次</span>
            <a href="" @click="backIndex"></a>
          </div>
          <div class="user-panel user-panel2">
            <i></i>
            <span class="title">更多任务</span>
            <span class="des">签到、反馈、分享</span>
            <div>敬请期待</div>
          </div>
        </div>
      </section>
      <section class="section-5">
        <h3>成长值发放规则</h3>
        <div>
          <p>预订酒店获取的成长值将在办理离店后次日发放</p>
          <p>购买储值卡获取的成长值将在购买后立即发放</p>
          <p>参加任务成功后立即发放成长值</p>
        </div>
      </section>
      <section class="section-6">
        <h3>权益说明</h3>
        <div>会员可为本人预订或他人代订酒店，享受预订对应折扣趣分时酒店会员权益仅适用于您选择的酒店，同属于酒店会员，不可跨店使用</div>
      </section>
      <section class="section-bottom">
        <img src="http://img.rainfn.com/qfs_p_0306_userDetail-bottom.png" />
      </section>
    </scroll-view>
  </div>
</template>
<script>
  export default {
    data () {
      return {}
    },
    methods: {
      backIndex () {
        const url = '/pages/hotelIndex/main'
        wx.switchTab({url})
      }
    }
  }
</script>
<style scoped lang="less">
  section {
    padding: 50rpx 40rpx 50rpx 30rpx;
    margin-top: 20rpx;
    background: #fff;
    h3 {
      margin-bottom: 30rpx;
      font-size: 32rpx;
      color: #db9f50;
    }
    >div {
      font-size: 26rpx;
      color: #535353;
    }
  }
  .section-top, .section-bottom {
    padding: 0;
    margin: 0;
  }
  .section-top img {
    width: 100%;
    height: 196rpx;
  }
  .section-bottom img {
    width: 100%;
    height: 81rpx;
  }
  .section-1 {
    margin: 0;
  }
  .shuoming {
    font-size: 28rpx!important;
    line-height: 40rpx;
  }
  .section-2 {
    .hy-title {
      font-size: 32rpx!important;
      color: #db9f50;
      height: 45rpx!important;
      line-height: 45rpx!important;
      margin-bottom: 20rpx!important;
    }
    p {
      line-height: 40rpx;
      font-size: 28rpx;
      margin-bottom: 20rpx;
    }
  }
  .section-3 div {
    padding-left: 43rpx;
    background: url('http://img.rainfn.com/qfs_p_0306_userDetail-icon.png') 0 center no-repeat;
    background-size: 36rpx;
  }
  .user-table {
    display: table;
    margin: 15rpx auto 25rpx auto;
    width: 95%;
    border-collapse: collapse;
    .user-tr {
      display:table-row;
      > div {
        padding: 20rpx 0;
        display:table-cell;
        vertical-align:middle;
        text-align: center;
        border: 1px solid #e2e2e2;
      }
    }
  }

  .user-panel {
    position: relative;
    width: 100%;
    height: 120rpx;
    box-shadow: 0 0 20rpx #c1c1c1;
    border-radius: 6rpx;
    i {
      position: absolute;
      top: 15rpx;
      left: 15rpx;
      width: 90rpx;
      height: 90rpx;
    }
    .title {
      position: absolute;
      top: 25rpx;
      left: 120rpx;
      width: 300rpx;
      height: 30rpx;
      line-height: 30rpx;
      color: #333;
    }
    .des {
      position: absolute;
      top: 70rpx;
      left: 120rpx;
      width: 300rpx;
      height: 30rpx;
      line-height: 30rpx;
    }
  }
  .user-panel1 {
    margin: 30rpx 0;
    i {
      background: url('http://img.rainfn.com/qfs_p_0306_userDetail-fav.png') 0 0 no-repeat;
      background-size: 90rpx;
    }

    a {
      position: absolute;
      top: 30rpx;
      right: 35rpx;
      width: 100rpx;
      height: 50rpx;
      background: url('http://img.rainfn.com/qfs_p_0306_userDetail-go.png') 0 0 no-repeat;
      background-size: 100rpx 50rpx;
    }
  }

  .user-panel2 {
    i {
      background: url('http://img.rainfn.com/qfs_p_0306_userDetail-more.png') 0 0 no-repeat;
      background-size: 90rpx;
    }
    div {
      position: absolute;
      top: 45rpx;
      right: 25rpx;
      width: 120rpx;
      height: 32rpx;
      line-height: 32rpx;
      color: #ccc;
    }
  }


</style>
