<template>
  <div class="container">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <h3>{{result.hotelName}}</h3>
      <div class="div1">
        <span class="span1">余额：</span>
        <span class="span2">¥</span>
        <span class="span3">{{result.balance}}</span>
      </div>
      <div class="sp"></div>
      <h3 class="p2">消费详情</h3>
      <dl class="header">
        <dd>
          <div class="header-left">已完成订单</div>
          <div class="header-right">
            <span>储蓄卡</span>
            <span>抵扣金额（元）</span>
          </div>
        </dd>
      </dl>
      <dl class="lists">
        <dd v-for="(val, idx) in result.consumeDetail" :key="idx" class="">
          <div class="lists-left">
            <span class="span1">{{result.hotelName}}</span>
            <span class="span2">床型：{{val.roomTypeName}}</span>
            <span class="span3">支付时间：{{val.createTime}}</span>
            <span class="span4">入住时间：{{val.startTime}}</span>
            <span class="span5">离开时间：{{val.endTime}}</span>
          </div>
          <div class="lists-right">{{val.cardDeduction}}</div>
        </dd>
      </dl>
    </scroll-view>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        result: {
          hotelName: '',
          balance: 2900.00,
          consumeDetail: [
            {
              roomTypeName: '大床房',
              cardDeduction: '308',
              createTime: '2018.12.30 12:00',
              startTime: '2019.01.01 14:00',
              endTime: '2019.0102 11:00'
            }
          ]
        }
      }
    },
    methods: {
      getData () {
        const me = this
        wx.request({
          url: this.globalData.globalUrl + '/card/detail',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success: function (res) {
            me.result = res.data.data
            for (let i = 0; i < me.result.consumeDetail.length; i++) {
              me.result.consumeDetail[i].createTime = me.result.consumeDetail[i].createTime.substr(0, 16).replace(/T/, ' ')
              me.result.consumeDetail[i].startTime = me.result.consumeDetail[i].startTime.substr(0, 16).replace(/T/, ' ')
              me.result.consumeDetail[i].endTime = me.result.consumeDetail[i].endTime.substr(0, 16).replace(/T/, ' ')
            }
          }
        })
      }
    },
    created () {
      this.getData()
    }
  }
</script>
<style scoped lang="less">
  .container {
    padding: 0;
    width: 100%;
    height: 100vh;
    background: #fff;
    font-size: 24rpx;
  }
  h3 {
    padding-left: 60rpx;
    margin-top: 30rpx;
    width: 100%;
    height: 80rpx;
    line-height: 80rpx;
    font-size: 38rpx;
    color: #333;
  }
  .div1 {
    padding-left: 60rpx;
    margin-bottom: 20rpx;
    width: 100%;
    height: 90rpx;
     span {
      float: left;
      display: block;
      color: #db8327;
      height: 90rpx;
      line-height: 90rpx;
    }
    .span1 {
      width: 90rpx;
      font-size: 30rpx;
    }
    .span2 {
      width: 30rpx;
      font-size: 24rpx;
    }
    .span3 {
      width: 300rpx;
      font-size: 46rpx;
    }
  }


  .sp {
    width: 100%;
    height: 20rpx;
    background: #f6f6f6;
  }
  dd {
    box-sizing: border-box;
    padding: 45rpx 60rpx 0 60rpx;
    margin: 0 auto;
  }
  .header dd div {
    float: left;
    height: 100rpx;
    border: 1px solid #a0a0a0;
    box-sizing: border-box;
    text-align: center;
    font-size: 26rpx;
    color: #333;
  }
  .header-left {
    line-height: 100rpx;
  }
  .header-right {
    padding-top: 14rpx;
  }
  .header-right span {
    display: block;
    width: 100%;
    height: 36rpx;
    line-height: 36rpx;
  }
  .lists dd div {
    float: left;
    height: 300rpx;
    border: 1px solid #a0a0a0;
    border-top-width: 0;
    box-sizing: border-box;
  }
  dd .lists-left, .header-left {
    width: 70%;
    border-right-width: 0 !important;
  }
  dd .lists-right, .header-right {
    width: 30%;
  }
  .lists-left span {
    display: block;
    box-sizing: border-box;
    padding-left: 12rpx;
    width: 100%;
    height: 40rpx;
    line-height: 40rpx;
    font-size: 26rpx;
  }
  .lists-left .span1 {
    margin-top: 46rpx;
  }
  .lists-right {
    line-height: 300rpx;
    text-align: center;
  }
</style>
