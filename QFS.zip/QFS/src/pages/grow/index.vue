<template>
  <div class="grow">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <section class="section-1">
        <div class="level" v-if="info.gradeName">{{info.gradeName}}</div>
        <div class="name">{{hotelName}}</div>
        <div class="grow-value"  v-if="info.growthValue||info.growthValue==0">成长值 {{info.growthValue}}</div>
        <i class="icon-1" :class="cls1"></i>
        <i class="icon-2" :class="cls2"></i>
      </section>
      <section class="section-2" v-if="memberData && memberData.length > 0">
        <ul>
          <li v-for="(item,index) in memberData" :key="index">
            <span class="span1">{{item.createTime}}</span>
            <span class="span2">{{item.detail}}</span>
            <span class="span3">+{{item.value}}</span>
          </li>
        </ul>
      </section>
      <sectiion class="section-3" v-if="!memberData || memberData.length == 0">
        <div>
          <div></div>
          <p>暂无明细</p>
          <p>开通酒店会员即享专属等级成长及折扣权益</p>
        </div>
      </sectiion>
    </scroll-view>
  </div>
</template>

<script>
  import {formatTime} from '../../utils'
  export default {
    data () {
      return {
        info: '',
        memberData: [],
        cls1: '',
        cls2: '',
        hotelName:''

      }
    },
    filters: {
      formatDate(time){
        if(!time){
          return '';
        }
        let rTime = time.slice(0,10);
        return rTime;
        /*let date = new Date(time);
        return formatTime(date, 'yyyy-MM-dd');*/
      },
    },
    methods: {
      getData () {
        const me = this
        wx.request({
          url: this.globalData.globalUrl + '/member/info',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success: function (res) {
            me.info =res.data.data? res.data.data:"";
            me.cls1 = 'icon-1-' + res.data.data.grade
            me.cls2 = 'icon-2-' + res.data.data.grade
          }
        })
        wx.request({
          url: this.globalData.globalUrl + '/member/belong/growthValueDetail',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            if (res.data.code == 0) {
              me.memberData = res.data.data
              me.memberData.forEach(function(item,index){
                item.createTime = item.createTime.slice(0,10);
              })
            } else {
              wx.showToast({
                title: '网络故障，请稍后再试',
                icon: 'none',
                duration: 2000,
                success: function() {
                  wx.navigateBack({
                    delta: 1
                  })
                }
              })
            }

          },
          fail(){
            wx.showToast({
              title: '网络故障，请稍后再试',
              icon: 'none',
              duration: 2000,
              success: function(){
                wx.navigateBack({
                  delta: 1
                })
              }
            })
          }
        })
      }
    },
    created () {
      this.getData();
    },
    onShow(){
      this.memberData=[];
       this.getData();
       if(wx.getStorageSync('hotelname')){
          this.hotelName=wx.getStorageSync('hotelname');
       }
    }
  }
</script>
<style scoped lang="less">
  section {
    background: #fff;
  }
  .section-1 {
    position: relative;
    margin-bottom: 20rpx;
    width: 100%;
    height: 260rpx;
    color: #262626;
    .level {
      position: absolute;
      top: 60rpx;
      left: 30rpx;
      width: 200rpx;
      height: 60rpx;
      line-height: 60rpx;
      font-size: 48rpx;
    }
    .icon-1 {
      position: absolute;
      display: inline-block;
      top: 80rpx;
      left: 230rpx;
      width: 60rpx;
      height: 30rpx;
    }
    .icon-1-1 {
      background: url('http://img.rainfn.com/qfs_p_0306_grow-level1.png') 0 0 no-repeat;
      background-size: 60rpx 30rpx;
    }
    .icon-1-2 {
      background: url('http://img.rainfn.com/qfs_p_0306_grow-level2.png') 0 0 no-repeat;
      background-size: 60rpx 30rpx;
    }
    .icon-1-3 {
      background: url('http://img.rainfn.com/qfs_p_0306_grow-level3.png') 0 0 no-repeat;
      background-size: 60rpx 30rpx;
    }
    .icon-1-4 {
      background: url('http://img.rainfn.com/qfs_p_0306_grow-level4.png') 0 0 no-repeat;
      background-size: 60rpx 30rpx;
    }
    .icon-1-5 {
      background: url('http://img.rainfn.com/qfs_p_0306_grow-level5.png') 0 0 no-repeat;
      background-size: 60rpx 30rpx;
    }
    .name {
      position: absolute;
      top: 120rpx;
      left: 30rpx;
      width: 100%;
      height: 50rpx;
      line-height: 50rpx;
      font-size: 38rpx;
    }
    .grow-value {
      position: absolute;
      top: 190rpx;
      left: 30rpx;
      padding-left: 42rpx;
      width: 100%;
      height: 38rpx;
      line-height: 38rpx;
      font-size: 26rpx;
      background: url("http://img.rainfn.com/qfs_p_0306_userDetail-icon.png") 0 0 no-repeat;
      background-size: 36rpx 37rpx;
    }
    .icon-2 {
      position: absolute;
      top: 60rpx;
      right: 30rpx;
      width: 83rpx;
      height: 94rpx;
    }
    .icon-2-1 {
      background: url('http://img.rainfn.com/qfs_p_0306_badge5.png') 0 0 no-repeat;
      background-size: 83rpx 94rpx;
    }
    .icon-2-2 {
      background: url('http://img.rainfn.com/qfs_p_0306_badge4.png') 0 0 no-repeat;
      background-size: 83rpx 94rpx;
    }
    .icon-2-3 {
      background: url('http://img.rainfn.com/qfs_p_0306_badge2.png') 0 0 no-repeat;
      background-size: 83rpx 94rpx;
    }
    .icon-2-4 {
      background: url('http://img.rainfn.com/qfs_p_0306_badge3.png') 0 0 no-repeat;
      background-size: 83rpx 94rpx;
    }
    .icon-2-5 {
      background: url('http://img.rainfn.com/qfs_p_0306_badge1.png') 0 0 no-repeat;
      background-size: 83rpx 94rpx;
    }

  }


  .section-2 {
    width: 100%;
    li {
      width: 100%;
      height: 80rpx;
      border-bottom: 1px solid #f1f1f1;
      .span1 {
        float: left;
        display: block;
        margin-left: 30rpx;
        width: 220rpx;
        height: 80rpx;
        line-height: 80rpx;
      }
      .span2 {
        float: left;
        display: block;
        width: 350rpx;
        height: 80rpx;
        line-height: 80rpx;
      }
      .span3 {
        float: right;
        display: block;
        margin-right: 30rpx;
        width: 100rpx;
        height: 80rpx;
        line-height: 80rpx;
        text-align: right;
      }
    }
  }

  .section-3 >div {
    height: 100%;
    background: #fff;
  }
  .section-3 >div >div {
    margin-bottom: 40rpx;
    width: 100%;
    height: 500rpx;
    background: url('http://img.rainfn.com/qfs_p_0306_grow-no.png') center bottom no-repeat;
    background-size: 218rpx 234rpx;
  }
  .section-3 p {
    width: 100%;
    height: 60rpx;
    line-height: 60rpx;
    text-align: center;
    font-size: 26rpx;
    color: #999;
  }

</style>
