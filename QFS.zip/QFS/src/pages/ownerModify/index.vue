<template>
  <div class="ownerModify">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <section class="section-1">
        <div class="div-1"></div>
        <div class="name">
          <span class="span1">姓名</span>
          <input class="span2" v-model="name" placeholder="请填写入住人姓名" placeholder-class="right" placeholder-style="text-align:right" />
        </div>
        <div class="phone">
          <span class="span1">手机号码</span>
          <input class="span2" v-model="mobile" placeholder="请填写入住人手机号码" placeholder-class="right" placeholder-style="text-align:right" maxlength="11"/>
        </div>
        <div class="div-1"></div>
        <div class="owner-app">
          <button class="button1" @click="click1">删除</button>
          <button class="button2" @click="click2">确定修改</button>
          <p class="p1">入住人的身份信息只用于必要的身份审核</p>
          <p class="p2">请务必确保真实有效，我们将会为您严格保密</p>
        </div>
      </section>
      <section class="section-2" :class="{displaynone : isShow}" >
        <div class="div-1"></div>
        <div class="div-2">
          <div class="div-top">确定要删除此入住人吗？</div>
          <div class="div-bottom">
            <span class="span1" @click="cancel">取消</span>
            <span class="span2" @click="delFn">删除</span>
          </div>
        </div>
      </section>
    </scroll-view>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        name: '',
        mobile: '',
        id: '',
        isShow: true
      }
    },
    methods: {
      click1 () {
        this.isShow = false
      },
      click2 () {
        var myreg = /^(((13[0-9])|(14[5-7])|(15[0-9])|(17[0-9])|(18[0-9]))+\d{8})$/
        if (!myreg.test(this.mobile)) {
          wx.showToast({
            title: '请输入正确的手机号',
            icon: 'none',
            duration: 2000
          })
        } else {
          const me = this
          wx.request({
            url: this.globalData.globalUrl + '/check/update',
            method: 'POST',
            data: {
              id: this.id,
              memberId: wx.getStorageSync('memberId'),
              name: this.name,
              mobile: this.mobile
            },
            header: {
              'content-type': 'application/json',
              'memberId': wx.getStorageSync('memberId')
            },
            success (res) {
              const url = '/pages/owner/main?item=' + JSON.stringify({name: me.name, mobile: me.mobile, id: me.id})
              wx.navigateBack({delta:1});
            }
          })
        }
      },
      cancel () {
        this.isShow = true;
      },
      delFn () {
        const me = this
        wx.request({
          url: this.globalData.globalUrl + '/check/delete',
          data: {
            id: this.id,
            memberId: wx.getStorageSync('memberId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            me.isShow = false
            const url = '/pages/owner/main'
            // wx.navigateTo({url});
            wx.navigateBack({delta:1});
          }
        })
      }

    },
    onLoad (item) {
      this.isShow=true;
      if (item.item) {
        const o = JSON.parse(item.item)
        this.name = o.name
        this.mobile = o.mobile
        this.id = o.id
      }
    }

  }
</script>
<style scoped lang="less">
  .displaynone {
    display: none;
  }
  .section-1 {
    height: 100%;
    background: #fff;
    font-size: 26rpx;
    .div-1 {
      width: 100%;
      height: 20rpx;
      background: #f6f6f6;
    }
  }

  .name, .phone {
    width: 100%;
    height: 100rpx;
  }
  .name {
    border-bottom: 1px solid #f7f7f7;
  }
  .section-1 {
    .span1, .span2 {
      display: inline-block;
      box-sizing: border-box;
      width: 50%;
      height: 100%;
      line-height: 100rpx;
    }
    .span1 {
      float: left;
      padding-left: 25rpx;
      text-align: left;
    }
    .span2 {
      padding-right: 25px;
      text-align: right;
    }
  }

  .owner-app {
    position: relative;
    padding-top: 140rpx;
    .button1 {
      position: absolute;
      top: 40rpx;
      right: 30rpx;
      width: 140rpx;
      height: 60rpx;
      line-height: 60rpx;
      text-align: center;
      border: 1px solid #878787;
      border-radius: 6rpx;
    }
    .button2 {
      width: 90%;
      height: 90rpx;
      line-height: 90rpx;
      text-align: center;
      background: #35abfe;
      border-radius: 16rpx;
      color: #fff;
      font-size: 34rpx;
    }
    p {
      width: 100%;
      height: 40rpx;
      line-height: 40rpx;
      text-align: center;
      font-size: 24rpx;
      color: #878787
    }
    .p1 {
      margin-top: 30rpx;
    }
  }

  .section-2 {
    position: fixed;
    top: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
    .div-1 {
      position: absolute;
      width: 100%;
      height: 100%;
      background: #000;
      opacity: .4;
    }
    .div-2 {
      position: absolute;
      top: 50%;
      left: 50%;
      margin-top: -150rpx;
      margin-left: -300rpx;
      width: 600rpx;
      height: 300rpx;
      background: #fff;
      z-index: 2;
      border-radius: 16rpx;
    }
    .div-top {
      box-sizing: border-box;
      width: 100%;
      height: 200rpx;
      line-height: 200rpx;
      text-align: center;
      font-size: 34rpx;
      border-bottom: 1px solid #c1c1c1;
    }
    .div-bottom {
      width: 100%;
      height: 100rpx;
      span {
        display: inline-block;
        box-sizing: border-box;
        width: 50%;
        height: 100rpx;
        line-height: 100rpx;
        text-align: center;
        font-size: 34rpx;
      }
      .span1 {
        border-right: 1px solid #c1c1c1;
      }
      .span2 {
        color: #d31c27;
      }
    }

  }

</style>
