<template>
  <div class="interestDetail">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <section>
        <div class="div-1"></div>
        <div class="div-2">
          <span class="span1">会员等级</span>
          <span class="span2">等级特权</span>
        </div>
        <div class="div-3"></div>

        <div class="div-4 clearfix" v-for="(item,index) in hotelGrades" :key=index>
          <div class="div-4-left" style=" height: 100%;">
            <span class="span1"   :class=" 'span'+index+0"></span>
            <span class="span2">{{item.name}}</span>
          </div>
          <div class="div-4-right" >
             <span class="span1">订单{{item.discount}}折优惠</span>
            <span class="span2" v-if="item.hotelGradeRquity.delayQuitRoomHour">延时退房至:{{item.hotelGradeRquity.delayQuitRoomHour}}:00</span>
             <!-- <span class="span3" >{{item.hotelGradeRquity.rquitys}}</span> -->


            <span v-for="(item1,index1) in item.hotelGradeRquity.rquitys" :key=index1>
              <span class="span3">{{rquitys[item1]}}</span>
            </span>
          </div>
         <div class="div-5"></div>
        </div>
      </section>
    </scroll-view>
  </div>
</template>
<script>
export default {
  data() {
    return {
      info: "",
      hotelGrades: [],
      hoteCards: [],
      rquitys: {
        freeDeposit: "免押金",
        freeFindRoom: "免查房",
        upgradeGift: "升级大礼包",
        delayQuitRoom: ""
      }
    };
  },
  methods: {
    hotelMemberGrades() {
      let me = this;
      let hotelId = wx.getStorageSync("hotelId");
      wx.request({
        url: this.globalData.globalUrl + `/hotel/grade/${hotelId}`,
        header: {
          "content-type": "application/json"
        },
        success(res) {
          //会员
          me.hotelGrades = [];
          let hotelGrades = res.data.data.hotelGrades;
          if (hotelGrades) {
            for (var i = hotelGrades.length - 1; i >= 0; i--) {
              if (hotelGrades[i].hotelGradeRquity.rquitys) {
                let rquitys = hotelGrades[i].hotelGradeRquity.rquitys;
                hotelGrades[i].hotelGradeRquity.rquitys = rquitys.filter(
                  element => {
                    return element != "delayQuitRoom";
                  }
                );
              }
              me.hotelGrades.push(hotelGrades[i]);
            }
          }

          me.hoteCards = res.data.data.hoteCards;
        }
      });
    }
  },
  onLoad() {},
  onShow() {
    this.hotelGrades = [];
    this.hotelMemberGrades();
  }
};
</script>
<style scoped lang="less">
.clearfix:after {
  content: ""; //设置内容为空
  height: 0; //高度为0
  line-height: 0; //行高为0
  display: block; //将文本转为块级元素
  visibility: hidden; //将元素隐藏
  clear: both//清除浮动;
}
section {
  background: #fff;
}
.div-1 {
  width: 100%;
  height: 196rpx;
  background: url("http://img.rainfn.com/qfs_p_0306_interest-bg.png") 0 0
    no-repeat;
  background-size: 750rpx 196rpx;
}
// .div-13 {
//   width: 100%;
//   height: 81rpx;
//   background: url("http://img.rainfn.com/qfs_p_0306_userDetail-bottom.png") 0 0
//     no-repeat;
//   background-size: 750rpx 81rpx;
// }
.div-2 {
  margin-top: 50rpx;
  width: 100%;
  height: 85rpx;
  span {
    display: block;
    float: left;
    width: 50%;
    height: 85rpx;
    line-height: 85rpx;
    font-size: 30rpx;
    color: #db8327;
  }
  .span1 {
    text-align: center;
  }
  .span2 {
    box-sizing: border-box;
    padding-left: 30rpx;
  }
}

.div-3 {
  margin: 0 auto;
  margin-top: 10rpx;
  width: 690rpx;
  height: 10rpx;
  background: #f6f6f6;
}
.div-4 {
  position: relative;
  width: 100%;
}
.div-4 .div-4-left,
.div-4 .div-4-right {
  float: left;
  width: 50%;
  height: 100%;
}
.div-4 .div-4-right {
  margin-left: 50%;
}
.div-4-left span {
  // display: inline-block;
}
.div-4 .div-4-left .span1 {
  width: 42rpx;
  height: 47rpx;
  background-size: 42rpx 47rpx;
  position: absolute;
  top: 50%;
  left: 10%;
}
.div-4 .div-4-left .span00 {
  background: url("http://img.rainfn.com/qfs_p_0306_badge1.png") center center
    no-repeat;
  background-size: 42rpx 47rpx;
}
.div-4 .div-4-left .span10 {
  background: url("http://img.rainfn.com/qfs_p_0306_badge2.png") center center
    no-repeat;
  background-size: 42rpx 47rpx;
}
.div-4 .div-4-left .span20 {
  background: url("http://img.rainfn.com/qfs_p_0306_badge3.png") center center
    no-repeat;
  background-size: 42rpx 47rpx;
}
.div-4 .div-4-left .span30 {
  background: url("http://img.rainfn.com/qfs_p_0306_badge4.png") center center
    no-repeat;
  background-size: 42rpx 47rpx;
}
.div-4 .div-4-left .span40 {
  background: url("http://img.rainfn.com/qfs_p_0306_badge5.png") center center
    no-repeat;
  background-size: 42rpx 47rpx;
}
.div-4 .div-4-left .span2 {
  position: absolute;
  font-size: 26rpx;
  top: 50%;
  left: 18%;
  color: #666;
}
.div-4-right {
  box-sizing: 10rpx;
  padding-top: 10rpx;
  span {
    display: block;
    box-sizing: border-box;
    padding-left: 30rpx;
    width: 100%;
    height: 60rpx;
    line-height: 60rpx;
    font-size: 26rpx;
    color: #666;
  }
}
.div-5 {
  position: absolute;
  left: 6%;
  bottom: -10rpx;
  width: 690rpx;
  height: 10rpx;
  background: #f6f6f6;
}
// .div-4 .div-left .span2 {
// }

// .div-4 .div-left .span1 {
//   background: url("http://img.rainfn.com/qfs_p_0306_badge1.png") right center
//     no-repeat;
//   background-size: 42rpx 47rpx;
// }
// .div-6 .div-left .span1 {
//   background: url("http://img.rainfn.com/qfs_p_0306_badge2.png") right center
//     no-repeat;
//   background-size: 42rpx 47rpx;
// }
// .div-8 .div-left .span1 {
//   background: url("http://img.rainfn.com/qfs_p_0306_badge3.png") right center
//     no-repeat;
//   background-size: 42rpx 47rpx;
// }
// .div-10 .div-left .span1 {
//   background: url("http://img.rainfn.com/qfs_p_0306_badge4.png") right center
//     no-repeat;
//   background-size: 42rpx 47rpx;
// }
// .div-12 .div-left .span1 {
//   background: url("http://img.rainfn.com/qfs_p_0306_badge5.png") right center
//     no-repeat;
//   background-size: 42rpx 47rpx;
// }
</style>
