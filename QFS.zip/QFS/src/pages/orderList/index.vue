<template>
  <div class="orderList">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0" @scrolltolower='getMoreOrders'>
      <section>
        <div class="tabs">
          <span v-for="(item,index) in titles" :key="index" :index="index" class="span-1"
                :class="activeIndex === index ? 'active' : ''" @click="goSelect(item,index)">{{item.title}}</span>
          <!-- <span class="span-1 active">全部</span>
          <span class="span-2">待支付</span>
          <span class="span-3">待入住</span>
          <span class="span-4">退款/售后</span> -->
        </div>
        <div class="sp"></div>
        <div v-if="activeIndex === 0">
          <div class="list-item" v-for="(item,index) in orders" :key="index" @click="details()" :index="index">

            <img :src="item.image"/>
            <span class="span-1">{{item.type == 0 ? "分时租赁" : "整日租赁"}}</span>
            <span class="span-2" :class="item.color" v-if="item.status!=0?true:false">{{item.statusName}}</span>
            <span class="span-2" :class="item.color" v-else>{{item.statusName}}<span
              class="countDown">{{item.djs}}</span></span>
            <span class="span-3">{{item.hotelName}}</span>
            <span class="span-4">房型：{{item.roomName}}</span>
            <span class="span-5">{{item.startTime}} - {{item.endTime}}</span>
            <span class="span-6"><b>¥</b>{{item.payAmount/100}}</span>
            <a href="" class="a2" @click="closeOrder(item)" v-show="item.status==0? true : false">取消支付</a>
            <a href="" class="a1" @click="gotoPay(item)" v-show="item.status==0? true : false">继续支付</a>
            <a href="" class="a1" @click="backIndex"
               v-show="item.status==6 || item.status==7 ||item.status==3? true : false">再次入住</a>
            <a v-if="item.status === 1 || item.status==7" href="" class="a2" @click="refundOrder(item)">申请退款</a>
            <!--<a v-if="item.status == 2" href="" class="a2">立即反馈</a>-->
            <div class="line"></div>
          </div>
        </div>
        <div v-if="activeIndex === 1">
          <div class="list-item" v-for="(item,index) in ordersPay" :key="index" :index="index" @click="details()"
               v-show="item.djs=='0'?false:true">
            <img :src="item.image"/>
            <span class="span-1">{{item.type == 0 ? "分时租赁" : "整日租赁"}}</span>
            <span class="span-2" :class="item.color">{{item.statusName}}<span
              class="countDown">{{item.djs}}</span></span>
            <span class="span-3">{{item.hotelName}}</span>
            <span class="span-4">房型：{{item.roomName}}</span>
            <span class="span-5">{{item.startTime}} - {{item.endTime}}</span>
            <span class="span-6"><b>¥</b>{{item.payAmount/100}}</span>
            <a href="" class="a1" @click="gotoPay(item)">继续支付</a>
            <a href="" class="a2" @click="closeOrder(item)">取消支付</a>
            <!-- <a href="" class="a2">立即反馈</a> -->
            <div class="line"></div>
          </div>
        </div>
        <div v-if="activeIndex === 2">
          <div class="list-item" v-for="(item,index) in orderStay" :key="index" @click="details()" :index="index">
            <img :src="item.image"/>
            <span class="span-1">{{item.type == 0 ? "分时租赁" : "整日租赁"}}</span>
            <span class="span-2" :class="item.color">{{item.statusName}}</span>
            <span class="span-3">{{item.hotelName}}</span>
            <span class="span-4">房型：{{item.roomName}}</span>
            <span class="span-5">{{item.startTime}} - {{item.endTime}}</span>
            <span class="span-6"><b>¥</b>{{item.payAmount/100}}</span>
            <a href="" class="a1" @click="backIndex">再次入住</a>
            <a href="" class="a2" @click="refundOrder(item)">申请退款</a>
            <!-- <a href="" class="a2">立即反馈</a> -->
            <div class="line"></div>
          </div>
        </div>
        <div v-if="activeIndex === 3">
          <div class="list-item" v-for="(item,index) in orderRefund" :key="index" @click="details()" :index="index">
            <img :src="item.image"/>
            <span class="span-1">{{item.type == 0 ? "分时租赁" : "整日租赁"}}</span>
            <span class="span-2" :class="item.color">{{item.statusName}}</span>
            <span class="span-3">{{item.hotelName}}</span>
            <span class="span-4">房型：{{item.roomName}}</span>
            <span class="span-5">{{item.startTime}} - {{item.endTime}}</span>
            <span class="span-6"><b>¥</b>{{item.payAmount/100}}</span>
            <a href="" class="a1" @click="backIndex">再次入住</a>
            <!-- <a href="" class="a2">立即反馈</a> -->
            <div class="line"></div>
          </div>
        </div>
        <div v-if="noMore" class="noMore">没有更多订单了</div>
        <div class="loading" v-if="loadingFlag">
          <image src="../../../static/images/loading.gif" class="loadingImg" style="height: 100rpx; width: 100rpx;"
                 mode="widthFix"></image>
        </div>
        <div v-if="noOrder" class="noOrder">您还没有相关订单呀～</div>
      </section>
    </scroll-view>
  </div>
</template>
<script>
  import { formatDate } from "../../utils/index";

  export default {
    data() {
      return {
        noOrder: false,
        timer: "",//定时器
        pageSize: 8,//单个页面数据容量
        pageNum: 1,//当前页码
        loadingFlag: false,
        loadMoreFlag: true, //是否可以下拉加载更多
        noMore: false,
        ordersPub: [],
        titles: [
          {
            num: -1,
            title: "全部"
          },
          {
            num: 0,
            title: "待支付"
          },
          {
            num: 1,
            title: "待入住"
          },
          {
            num: 4,
            title: "退款/售后"
          }
        ],
        activeIndex: 0,
        orders: [],
        status: "",
        statusList: [
          {
            id: 0,
            name: "待支付",
            color: "redText"
          },
          {
            id: 1,
            name: "待入住",
            color: "redText"
          },
          {
            id: 2,
            name: "待反馈",
            color: "blueText"
          },
          {
            id: 3,
            name: "已取消",
            color: "blueText"
          },
          {
            id: 4,
            name: "退款中",
            color: "redText"
          },
          {
            id: 5,
            name: "已退款",
            color: "grayText"
          },
          {
            id: 6,
            name: "已完成",
            color: "blueText"
          },
          {
            id: 7,
            name: "待入住",
            color: "redText"
          }
        ],
        ordersPay: [],
        orderStay: [],
        orderRefund: []
      };
    },
    methods: {
      getMoreOrders() {
        console.log("loadingMore...");
        let that = this;
        if (that.loadMoreFlag) {
          that.pageNum++;
          this.getData(that.activeIndex, that.pageNum);
        } else {
          return;
        }

      },
      formateTimes(dataList) {
        dataList.forEach(function(item, index) {
          item.startTime = formatDate(new Date(item.startTime), "yyyy-MM-dd hh:mm:ss");
          item.endTime = formatDate(new Date(item.endTime), "yyyy-MM-dd hh:mm:ss");
        });
      },
      changeStatus(orderCode, status) {
        const me = this;
        wx.request({
          url: me.globalData.globalUrl + "/roomOrder/update",
          data: {
            id: orderCode,
            status: status
          },
          success(res) {
            console.log(res);
          }
        });
      },
      DateFormat(date) {
        let newDate = new Date(date);
        var y = newDate.getFullYear();
        var m = newDate.getMonth() + 1;
        m = m < 10 ? "0" + m : m;
        var d = newDate.getDate();
        d = d < 10 ? "0" + d : d;
        var h = newDate.getHours();
        h = h < 10 ? "0" + h : h;
        var minute = newDate.getMinutes();
        minute = minute < 10 ? "0" + minute : minute;
        return y + "." + m + "." + d + " " + h + ":" + minute;
      },
      backIndex() {
        wx.navigateTo({
          url: "/pages/roomList/main?type=hour"
        });
      },
      getData(activeIndex, currPage) {
        let that = this;
        that.noOrder = false;
        that.loadingFlag = true;
        that.loadMoreFlag = false; //请求数据期间不允许再次请求
        if (activeIndex === 0) {
          that.status = "";
        } else if (activeIndex === 1) {
          that.status = 0;
        } else if (activeIndex === 2) {
          that.status = [1, 7];
        } else {
          that.status = [4, 5];
        }
        wx.request({
          url: that.globalData.globalUrl + "/roomOrder/list",
          data: {
            hotelId: wx.getStorageSync("hotelId"),
            //            hotelId: 1,
            status: that.status.toString(),
            pageNum: currPage || 1,
            pageSize: this.pageSize

          },
          header: {
            "content-type": "application/json",
            memberId: wx.getStorageSync("memberId")
          },
          success(res) {
            if (!res.data.data.list) {
              ///更改相关标记状态
              that.loadingFlag = false;
              that.loadMoreFlag = false;
              that.noMore = true;
              return false;
            }
            if (res.data.data.list && res.data.data.list.length > 0) {
              that.formateTimes(res.data.data.list);
            }
            // let orders = res.data.data.list ? res.data.data.list.slice(0) : [];
            if (activeIndex == 2) {

              that.orderStay = that.orderStay.concat(res.data.data.list ? res.data.data.list : []);

            } else if (activeIndex == 3) {
              that.orderRefund = that.orderRefund.concat(res.data.data.list ? res.data.data.list : []);

            }
            that.ordersPub = that.ordersPub.concat(res.data.data.list ? res.data.data.list : []);
            if (that.ordersPub.length <= 0) {
              that.noOrder = true;
            }


            console.log("activeIndex", activeIndex);


            // 处理状态
            that.ordersPub.forEach(function(item01,index01){
              that.statusList.forEach(function(item02,index02){
                if(item01.status == item02.id){
                  item01.statusName = item02.name;
                  item01.color = item02.color ;
                }
              })

            })

            that.timer = setInterval(function() {
              if (that.ordersPub.length > 0) {
                that.ordersPub.forEach(function(item, index) {
                  if (item.status == 0) {
                    let deadLine = new Date(item.createTime).getTime() + 60 * 1000 * 10;
                    let djs = deadLine - new Date().getTime();
                    if (djs > 0) {
                      item.djs = formatDate(new Date(djs), "mm:ss");
                    } else {
                      that.changeStatus(item.id, 3);
                    }
                  }
                });
              }

              if (activeIndex == 0) {
                that.orders = that.ordersPub;

              } else if (activeIndex == 1) {
                that.ordersPay = that.ordersPub;
              }
            }, 1000);

            ///更改相关标记状态
            setInterval(function(){
              //过度渲染时间
              that.loadingFlag = false;
              if (!res.data.data.list) {
                that.loadMoreFlag = false; //没有数据不允许重复请求
              } else if (res.data.data.list && res.data.data.list.length < that.pageSize) {
                that.loadMoreFlag = false;//加载完所有数据后也不允许重复提交请求
                that.noMore = true;
              } else {
                that.loadMoreFlag = true;
                that.noMore = false;
              }
            },800)



          }
          ,
          fail(error) {
            let that = this;
            that.loadingFlag = false;
            wx.showToast({
              title: "网络故障，请稍后再试",
              icon: "none",
              duration: 1500
            });
          }
        })
        ;
      },
      goSelect(item, index) {
        let that = this;
        // console.log(item, index)
        that.ordersPay = [];
        that.orderStay = [];
        that.orderRefund = [];
        that.orders = [];
        that.ordersPub = [];
        that.activeIndex = index;
        that.pageNum = 1;
        that.getData(that.activeIndex);
      },
      gotoPay(item) {
        const me = this;
        wx.request({
          url: me.globalData.globalUrl + "/roomOrder/wxPay",
          data: {
            openId: wx.getStorageSync("openid"),
            orderCode: item.orderCode,
            payAmount: item.payAmount / 100
          },
          header: {
            "content-type": "application/json",
            memberId: wx.getStorageSync("memberId")
          },
          success(res) {
            wx.requestPayment({
              timeStamp: res.data.data.timeStamp,
              nonceStr: res.data.data.nonceStr,
              package: res.data.data.package,
              signType: "MD5",
              paySign: res.data.data.paySign,
              success: function(res) {
                wx.showToast({
                  title: "支付成功",
                  icon: "success",
                  duration: 3000
                });
                var url = "/pages/paymentSuccess/main";
                wx.navigateTo({ url });
              },
              fail: function(res) {
                console.log("支付失败");
                var url = "/pages/paymentFailed/main?item=orderAccounts";
                wx.navigateTo({ url });
              }
            });
          }
        });
      },
      closeOrder(item) {
        const me = this;
        wx.request({
          url: me.globalData.globalUrl + "/roomOrder/cancel",
          data: {
            orderCode: item.orderCode
          },
          header: {
            "content-type": "application/json",
            memberId: wx.getStorageSync("memberId")
          },
          success(res) {
            if (res.data.message == "取消成功") {
              me.getData(wx.getStorageSync("orderActiveIndex"));
            }
          }
        });
      },
      refundOrder(item) {
        const me = this;
        wx.request({
          url: me.globalData.globalUrl + "/roomOrder/refund",
          method: "POST",
          data: {
            orderCode: item.orderCode
          },
          header: {
            "content-type": "application/json",
            memberId: wx.getStorageSync("memberId")
          },
          success(res) {
            if (res.data.code === 0) {
              wx.showToast({
                title: "退款处理中",
                icon: "success",
                duration: 3000
              });
            } else if (res.data.code === 1) {
              wx.showToast({
                title: res.data.message,
                icon: "none",
                duration: 3000
              });
            } else {
              wx.showToast({
                title: "系统异常",
                icon: "none",
                duration: 3000
              });
            }
            console.log(res);
          }
        });
      },
      //详情
      details() {
        wx.navigateTo({
          url: `/pages/orderdetails/main`
        });
      }
    },
    mounted() {
      let tab = this.$root.$mp.query.tab ? this.$root.$mp.query.tab : 0;
      this.activeIndex = parseInt(tab);
      // console.log(tab)
      wx.setStorageSync("orderActiveIndex", this.activeIndex);
      this.getData(this.activeIndex);
    },
    onShow() {
      this.orders = [];
      let that = this;
      let orders = [];

    },
    onHide() {
      let that = this;
      clearInterval(that.timer);
    }
  };
</script>
<style scoped lang="less">
  .orderList {
    background: #fff;
  }

  .loading {
    height: 150 rpx;
    display: flex;
    width: 100%;
    align-items: center;
    justify-content: center;
  }

  .loadingImg {
    flex: none;
  }

  .noMore {
    font-size: 32 rpx;
    color: #999;
    width: 100%;
    height: 60 rpx;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .orderList {
    background: #fff;
  }
  .tabs {
    width: 100%;
    height: 100rpx;
    background: #fff;
    span {
      float: left;
      box-sizing: border-box;
      // padding: 0 20rpx;
      height: 70rpx;
      line-height: 70rpx;
      font-size: 32rpx;
      text-align: center;
      color: #333;
      font-weight: 600;
    }
    .span-1 {
      width: 24%;
    }
    // .span-2 {
    //   width: 23%;
    // }
    // .span-3 {
    //   width: 23%;
    // }
    // .span-4 {
    //   width: 35%;
    // }
    .span-1.active {
      background: url("http://img.rainfn.com/qfs_p_0306_coupon-active.png") center
      bottom no-repeat;
      background-size: 60rpx 10rpx;
    }
    .span-2.active {
      background: url("http://img.rainfn.com/qfs_p_0306_coupon-active.png") center
      bottom no-repeat;
      background-size: 110rpx 10rpx;
    }
    .span-3.active {
      background: url("http://img.rainfn.com/qfs_p_0306_coupon-active.png") center
      bottom no-repeat;
      background-size: 110rpx 10rpx;
    }
    .span-4.active {
      background: url("http://img.rainfn.com/qfs_p_0306_coupon-active.png") center
      bottom no-repeat;
      background-size: 170rpx 10rpx;
    }
  }
  .blueText {
    color: #3ebbff !important;
  }
  .redText {
    color: #e87777 !important;
  }
  .grayText {
    color: #666666 !important;
  }
  .sp {
    width: 100%;
    height: 20rpx;
    background: #f6f6f6;
  }
  .list-item {
    position: relative;
    width: 100%;
    height: 320rpx;
    > span,
    > a,
    > img {
      position: absolute;
    }
    .line {
      width: 100%;
      height: 20rpx;
      background: #f6f6f6;
      position: absolute;
      bottom: 0;
    }
    > img {
      top: 76rpx;
      left: 30rpx;
      width: 200rpx;
      height: 127rpx;
      border-radius: 8rpx;
    }
    .span-1 {
      top: 28rpx;
      left: 30rpx;
      width: 200rpx;
      height: 30rpx;
      line-height: 30rpx;
      font-size: 30rpx;
      color: #666;
    }
    .span-2 {
      top: 28rpx;
      right: 30rpx;
      width: 300rpx;
      height: 30rpx;
      line-height: 30rpx;
      font-size: 30rpx;
      text-align: right;
      color: #e06064;
    }
    .countDown {
      margin-left: 10rpx;
    }
    .span-3 {
      top: 84rpx;
      left: 260rpx;
      width: 450rpx;
      height: 28rpx;
      line-height: 28rpx;
      font-size: 28rpx;
      color: #666;
    }
    .span-4 {
      top: 128rpx;
      left: 260rpx;
      width: 450rpx;
      height: 24rpx;
      line-height: 24rpx;
      font-size: 24rpx;
      color: #666;
    }
    .span-5 {
      top: 178rpx;
      left: 260rpx;
      width: 450rpx;
      height: 20rpx;
      line-height: 22rpx;
      font-size: 22rpx;
      color: #666;
    }
    .span-6 {
      top: 232rpx;
      left: 30rpx;
      width: 250rpx;
      height: 36rpx;
      line-height: 36rpx;
      font-size: 36rpx;
      color: #e06064;
    }
    .span-6 b {
      display: inline-block;
      margin-right: 6rpx;
      font-size: 20rpx;
    }
    .a1 {
      bottom: 40rpx;
      right: 30rpx;
      width: 150rpx;
      height: 60rpx;
      line-height: 60rpx;
      border-radius: 30rpx;
      text-align: center;
      font-size: 26rpx;
      color: #fff;
      background: linear-gradient(to right, #52c8ff, #25aeff);
    }
    .a2 {
      bottom: 40rpx;
      right: 210rpx;
      width: 150rpx;
      height: 60rpx;
      line-height: 60rpx;
      border-radius: 30rpx;
      text-align: center;
      font-size: 26rpx;
      color: #fff;
      background: linear-gradient(to right, #52c8ff, #25aeff);
    }
  }
  .noOrder {
    box-sizing: border-box;
    margin-top: 300rpx;
    padding-top: 234rpx;
    width: 100%;
    height: 274rpx;
    line-height: 70rpx;
    text-align: center;
    background: #fff url("http://img.rainfn.com/qfs_p_0306_grow-no.png") center 0
    no-repeat;
    background-size: 218rpx 234rpx;
    font-size: 28rpx;
    color: #999;
  }
</style>
