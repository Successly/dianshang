<template>
  <div class="index">
    <div class="banner"><img :src="img"></div>
    <div class="hotel-item" v-for="(val,index) in data"  @click="goHome(val.id, val.name)" :key="index">
      <span class="hotel-name">{{val.name}}</span>
      <span class="hotel-add">{{val.address.city + val.address.district + val.address.addressDetail}}</span>

      <span class="hotel-level" :class="val.myStatus&&val.myStatus.level?'hotel-level'+val.myStatus.level:''"></span>
      <!-- //ddd -->
      <span :class="balanceFlag? hotel-saving:''"></span>
      <a class="hotel-go" href="" >进入酒店</a>
    </div>
    <div class="impower-1" :class="box === 1 ? '' : 'displaynone'">
      <div class="impower-box">
        <div class="impower-logo"></div>
        <div class="impower-div1">欢迎来到分时酒店联盟</div>
        <div class="impower-div2">授权获取你的手机号</div>
        <div class="impower-div3">分时酒店联盟不会将你的信息提供给第三方仅用于酒店预定等个人信息展示</div>
        <div class="impower-div4">点击授权即表示已阅读并同意<a href="/pages/impower/main">《分时酒店联盟用户许可协议》</a></div>
        <button open-type="getPhoneNumber" @getphonenumber="getPhoneNumber">授权</button>
      </div>
    </div>
    <div class="impower-2" :class="box === 2 ? '' : 'displaynone'">
      <div class="sp"></div>
      <div class="impower-box">
        <div class="impower-div1">提示</div>
        <div class="impower-div2">小程序即将获取您的昵称公开信息</div>
        <div class="impower-div3">（昵称、头像等）</div>
        <button class="span-1" open-type="getUserInfo" @getuserinfo="bindgetuserinfo">确定</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      data: [],
      img: '',
      box: 0,
      balanceFlag:'',
      hotelLevel:''  //酒店会员图标
    }
  },
  mounted () {
    // this.goHome(35,'xxxxx')
  },
  methods: {
    balance(){
      let me = this;
        wx.request({
          url: this.globalData.globalUrl + '/card/detail',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success: function (res) {
            me.balanceFlag = res.data.data.balance;
          }
        })
    },
    goHome (id, name) {
      wx.setStorageSync('hotelId', id)
      wx.setStorageSync('hotelname', name)
      const url = '/pages/hotelIndex/main?hotelId=' + id
      wx.switchTab({url})
    },
    clickBox1 () {
      this.box = 0
    },
    clickBox2 () {
      this.box = 0
    },
    loginFn () {
      const me = this
      if (!wx.getStorageSync('phone')) {
        this.box = 1
      } else {
        wx.getSetting({
          success (res) {
            console.log(res.authSetting)
            if (res.authSetting['scope.userInfo']) {
              me.getData()
              me.getData1()
            } else {
              me.box = 2
            }
          }
        })
      }
      wx.login({
        success (res) {
          wx.request({
            url: me.globalData.globalUrl + '/register/getOpenId',
            data: {code: res.code},
            header: {
              'content-type': 'application/json'
            },
            success (response) {
               wx.setStorageSync('openid', response.data.data)
            },
            fail (res) {
              console.log(res)
            }
          })
        }
      })
    },
    getData () {
      const me = this
      wx.request({
        url: this.globalData.globalUrl + '/hotel/hotels/home',
        header: {
          'content-type': 'application/json',
          'memberId': wx.getStorageSync('memberId')
        },
        success (res) {
          me.data = res.data.data.hotels;

        }
      })
    },
    getData1 () {
      const me = this
      wx.request({
        url: this.globalData.globalUrl + '/banner/list',
        data: {
          hotelId: 0
        },
        header: {
          'content-type': 'application/json',
          'memberId': wx.getStorageSync('memberId')
        },
        success (res) {
          me.img = res.data.data[0] ? res.data.data[0].image : ''
        }
      })
    },
    bindgetuserinfo () {
      const me = this
      wx.getUserInfo({
        success (res) {
          const userInfo = res.userInfo
          wx.request({
            url: me.globalData.globalUrl + '/register/mAddOrUpdate',
            method: 'POST',
            data: {
              openId: wx.getStorageSync('openid'),
              name: userInfo.nickName,
              avatar: userInfo.avatarUrl,
              sex: userInfo.gender,
              province: userInfo.province,
              city: userInfo.city,
              mobile: wx.getStorageSync('phone')
            },
            success (response) {
              if (response.data.data) {
                me.box = 0
                wx.setStorageSync('memberId', response.data.data)
//                wx.setStorageSync('memberId', 1)
                me.getData()
                me.getData1()
              } else {
                me.box = 2
              }
            },
            fail (res) {
              console.log(res)
            }
          })
        }
      })
    },
    getPhoneNumber (e) {
      const me = this
      wx.login({
        success (res) {
          wx.request({
            url: me.globalData.globalUrl + '/register/getPhoneNumber',
            data: {
              encryptedData: e.mp.detail.encryptedData,
              code: res.code,
              iv: e.mp.detail.iv
            },
            header: {
              'content-type': 'application/json'
            },
            success (response) {
              if (response.data.data) {
                me.box = 0
                wx.setStorageSync('phone', response.data.data.phoneNumber)
                wx.getSetting({
                  success (res) {
                    console.log(res.authSetting)
                    if (res.authSetting['scope.userInfo']) {
                      me.getData()
                      me.getData1()
                    } else {
                      me.box = 2
                    }
                  }
                })
              } else {
                me.box = 1
              }
            },
            fail (res) {
              console.log(res)
            }
          })
        }
      })
    }

  },
  created () {
    this.loginFn();
    this.balance();
    this.getData();
  },
  onShow(){
    this.balance();
    this.getData();
  }
}
</script>

<style scoped lang="less">
  .displaynone {
    display: none;
  }
  .banner {
    width: 100%;
    height: 400rpx;
    img {
      width: 100%;
      height: 400rpx;
    }
  }
  .hotel-item {
    position: relative;
    margin: 50rpx 15rpx 0 15rpx;
    width: 690prx;
    height: 230rpx;
    background: url('http://img.rainfn.com/qfs_bg_index-20190317.png') 0 0 no-repeat;
    background-size: 720rpx 230rpx;
  }
  .hotel-name {
    position:absolute;
    top:45rpx;
    left:30rpx;
    width:450rpx;
    height:50rpx;
    line-height:50rpx;
    font-size:32rpx;
    color:#fff;
  }
  .hotel-add {
    position: absolute;
    top: 90rpx;
    left: 30rpx;
    padding-left: 30rpx;
    width: 500rpx;
    height: 40rpx;
    line-height: 40rpx;
    font-size: 24rpx;
    color: #fff;
    background: url('http://img.rainfn.com/qfs_p_0306_hotel-site.png') 0 6rpx no-repeat;
    background-size: 20rpx 25rpx;
  }
  .hotel-level {
    position:absolute;
    top:0;
    right:40rpx;
    width:83rpx;
    height:112rpx;
  }

  // 1-白银
  // 2-黄金
  // 3-白金
  // 4-钻石
  // 5-至尊
  .hotel-level5 {
    background: url('http://img.rainfn.com/qfs_p_0306_badge1.png') 0 14rpx no-repeat;
    background-size: 100%;
  }
  .hotel-level4 {
    background: url('http://img.rainfn.com/qfs_p_0306_badge2.png') 0 14rpx no-repeat;
    background-size: 100%;
  }
  .hotel-level3 {
    background: url('http://img.rainfn.com/qfs_p_0306_badge3.png') 0 14rpx no-repeat;
    background-size: 100%;
  }
  .hotel-level2 {
    background: url('http://img.rainfn.com/qfs_p_0306_badge4.png') 0 14rpx no-repeat;
    background-size: 100%;
  }
  .hotel-level1 {
    background: url('http://img.rainfn.com/qfs_p_0306_badge5.png') 0 14rpx no-repeat;
    background-size: 100%;
  }
  .hotel-saving {
    position: absolute;
    top:  -16rpx;
    left: 30rpx;
    width: 127rpx;
    height: 46rpx;
    background: url('http://img.rainfn.com/qfs_p_0306_saving.png') 0 0 no-repeat;
    background-size: 127rpx 46rpx;
  }
  .hotel-go {
    position: absolute;
    display: block;
    right: 30rpx;
    bottom: 50rpx;
    padding-right: 40rpx;
    width: 200rpx;
    height: 26rpx;
    line-height: 26rpx;
    color: #fff;
    background: url('http://img.rainfn.com/qfs_p_0306_hotel-go.png') right 1rpx no-repeat;
    background-size: 30rpx 24rpx;
    text-align: right;
    font-size: 26rpx;
  }
  .impower-1 {
    position: fixed;
    top: 0;
    width: 100%;
    height: 100%;
    background: #fff;
    .impower-box {
      position: absolute;
      top: 50%;
      margin-top: -350rpx;
      width: 100%;
      height: 700rpx;
      .impower-logo {
        position: absolute;
        top: 0;
        width: 100%;
        height: 150rpx;
        background: url('../../../static/images/impower-logo.png') center 0 no-repeat;
        background-size: 150rpx 150rpx;
      }
      .impower-div1 {
        position: absolute;
        top: 175rpx;
        width: 100%;
        height: 54rpx;
        line-height: 54rpx;
        text-align: center;
        font-size: 36rpx;
        color: #333;
      }
      .impower-div2 {
        position: absolute;
        top: 230rpx;
        width: 100%;
        height: 54rpx;
        line-height: 54rpx;
        text-align: center;
        font-size: 36rpx;
        color: #333;
      }
      .impower-div3 {
        position: absolute;
        top: 320rpx;
        left: 125rpx;
        width: 500rpx;
        height: 80rpx;
        line-height: 40rpx;
        text-align: center;
        font-size: 26rpx;
        color: #999;
      }
      .impower-div4 {
        position: absolute;
        top: 590rpx;
        width: 100%;
        height: 30rpx;
        line-height: 30rpx;
        text-align: center;
        font-size: 22rpx;
        color: #999;
        a {
          display: inline-block;
          color: #3ebbff;
          font-size: 22rpx;
        }
      }
      button {
        position: absolute;
        left: 125rpx;
        top: 470rpx;
        width: 500rpx;
        height: 80rpx;
        line-height: 80rpx;
        background: #3ebbff;
        color: #fff;
        border-radius: 40rpx;
        font-size: 36rpx;
      }
    }
  }
  .impower-2 {
    position: fixed;
    top: 0;
    width: 100%;
    height: 100%;
    .sp {
      position: absolute;
      width: 100%;
      height: 100%;
      z-index: 1;
      background: #000;
      opacity: .7;
    }
    .impower-box {
      position: absolute;
      top: 50%;
      left: 50%;
      margin-top: -175rpx;
      margin-left: -300rpx;
      width: 600rpx;
      height: 350rpx;
      border-radius: 20rpx;
      z-index: 2;
      background: #fff;
      .impower-div1 {
        position: absolute;
        top: 30rpx;
        width: 100%;
        height: 60rpx;
        line-height: 60rpx;
        text-align: center;
        font-size: 36rpx;
        color: #333;
        font-weight: 500;
      }
      .impower-div2 {
        position: absolute;
        width: 100%;
        top: 110rpx;
        height: 40rpx;
        line-height: 40rpx;
        text-align: center;
        font-size: 32rpx;
        color: #666;
      }
      .impower-div3 {
        position: absolute;
        top: 165rpx;
        width: 100%;
        height: 40rpx;
        line-height: 40rpx;
        text-align: center;
        font-size: 32rpx;
        color: #666;
      }
      button {
        position: absolute;
        width: 100%;
        bottom: 0;
        height: 100rpx;
        line-height: 100rpx;
        font-size: 36rpx;
        text-align: center;
        color: #1aad19;
        border: none;
        background: #fff;
        border-top: 1px solid #e1e1e1;
        border-bottom-left-radius: 20rpx;
        border-bottom-right-radius: 20rpx;
      }
      button::after{
        border: none;
      }
    }
  }
</style>
