<template>
  <div class="ownerAdd">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <form @submit.prevent="submit">
        <div class="div-1"></div>
        <div class="name">
          <span class="span1">姓名</span>
          <input class="name" v-model="input1" placeholder="请填写入住人姓名" placeholder-class="right" placeholder-style="text-align:right" />
        </div>
        <div class="phone">
          <span class="span1">手机号码 </span>
          <input class="mobile" v-model="input2" placeholder="请填写入住人联系方式" placeholder-class="right" placeholder-style="text-align:right" maxlength="11"/>
        </div>
        <div class="div-1"></div>
        <div class="owner-app">
          <button class="button2" @click="click2">提交保存</button>
          <p class="p1">入住人的身份信息只用于必要的身份审核</p>
          <p class="p2">请务必确保真实有效，我们将会为您严格保密</p>
        </div>
      </form>
    </scroll-view>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        input1: '',
        input2: ''
      }
    },
    methods: {
      click2 () {
        var myreg = /^(((13[0-9])|(14[5-7])|(15[0-9])|(17[0-9])|(18[0-9]))+\d{8})$/
        if (!myreg.test(this.input2)) {
          wx.showToast({
            title: '请输入正确的手机号',
            icon: 'none',
            duration: 2000
          })
        } else {
          wx.request({
            url: this.globalData.globalUrl + '/check/add',
            method: 'POST',
            data: {
              memberId: wx.getStorageSync('memberId'),
              name: this.input1,
              mobile: this.input2
            },
            header: {
              'content-type': 'application/json',
              'memberId': wx.getStorageSync('memberId')
            },
            success (res) {
              if(res.data.message=="success"){
                    const url = '/pages/owner/main';
                     wx.navigateBack({delta: 1});
              }

            }
          })
        }
      }
    },
    onLoad(){
      this.input1="",
      this.input2=""
    }
  }
</script>
<style scoped lang="less">
  .ownerAdd {
    background: #fff;
  }
  form {
    height: 100%;
    font-size: 26rpx;
  }
  .div-1 {
    width: 100%;
    height: 20rpx;
    background: #f6f6f6;
  }
  .name, .phone {
    width: 100%;
    height: 100rpx;
  }
  .name {
    border-bottom: 1px solid #f7f7f7;
  }
  .span1, input {
    float: left;
    display: inline-block;
    box-sizing: border-box;
    height: 100%;
    line-height: 100rpx;
    text-align: right;
  }
  .span1 {
    width: 40%;
  }
  input {
    width: 60%;
    padding-right: 30rpx;
  }

  .span1 {
    padding-left: 25rpx;
    text-align: left;
  }
  .owner-app {
    position: relative;
    padding-top: 140rpx;
    .button1 {
      position: absolute;
      top: 40rpx;
      right: 30rpx;
      width: 140rpx;
      height: 60rpx;
      line-height: 60rpx;
      text-align: center;
      border: 1px solid #878787;
      border-radius: 6rpx;
    }
    .button2 {
      width: 90%;
      height: 90rpx;
      line-height: 90rpx;
      text-align: center;
      background: #35abfe;
      border-radius: 16rpx;
      color: #fff;
      font-size: 34rpx;
    }
    p {
      width: 100%;
      height: 40rpx;
      line-height: 40rpx;
      text-align: center;
      font-size: 24rpx;
      color: #878787
    }
    .p1 {
      margin-top: 30rpx;
    }
  }

</style>
