<template>
  <div class="couponCenter">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <section class="section-1">
        <div v-if="isShow">
          <div v-for="item in lists" v-bind:key="item.id">
            <div v-if="item.status === 0" class="coupon-common coupon-box" :class="item.couponClass">
              <span class="span1">¥</span>
              <span class="span2">{{item.money}}</span>
              <span class="span3">{{item.barriers}}</span>
              <span class="span4">{{item.name}}</span>

              <span v-if="item.startTime&&item.startTime!=0" class="span5">有效期 {{item.startTime}}至{{item.endTime}}</span>
              <span v-else class="span5">有效期{{item.expireDay}}天</span>

              <span class="span6">{{item.limit}}</span>
              <div class="div-des">
                <span class="button1" @click="click1(index)">使用范围</span>
              </div>
              <span :class="item.isReceived==1 ? 'img-draw':''"></span>
              <span v-if="item.isReceived == 0" class="button2" @click="click2(item.id,item.limitFlag)">立即领取</span>
            </div>
            <div class="coupon-des" :class="item.showTip == true ? '' : 'displaynone'">
              <div><span>可用整日租赁类型：{{item.wholeDays}}</span></div>
              <div><span>可用分时租赁类型：{{item.timeSharings}}</span></div>
            </div>
          </div>
        </div>
        <div v-else="!show" class="noCoupon">暂无优惠券</div>
      </section>
    </scroll-view>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        hotelname: '',
        lists: [],
        isShow: false,
        vipFlag: false //是否是会员
      }
    },
    methods: {
      getData () {
        const me = this
        wx.request({
          url: this.globalData.globalUrl + '/coupon/list',
          data: {
            hotelId: wx.getStorageSync('hotelId'),
            type:1
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            me.lists = res.data.data.list;
            console.log("'/coupon/list'");
            console.log(me.lists);

            for (let i = 0; i < me.lists.length; i++) {
              if (me.lists[i].status === 0) {
                me.isShow = true
              }
              let str = 'coupon';
              if (me.lists[i].limit === null) {
                str += '-common'
                me.lists[i].limit = '所有用户均可领取'
                me.lists[i].limitFlag = false;
              } else  {
                str += '-member'
                me.lists[i].limit = '限会员用户领取';
                me.lists[i].limitFlag = true;
              }
              if (me.lists[i].isReceived == 1) {
                str += '-draw'
              }
              me.lists[i].couponClass = str;
           
              if (parseInt(me.lists[i].barriers) === -1) {
                me.lists[i].barriers = '无门槛'
              } else {
                me.lists[i].barriers = '满' + me.lists[i].barriers + '可用'
              }
              me.lists[i].startTime = me.lists[i].startTime ? me.lists[i].startTime.substr(0, 10) : 0
              me.lists[i].endTime = me.lists[i].endTime ? me.lists[i].endTime.substr(0, 10) : 0
              me.lists[i].showTip = false
            }
            
          }
        })
        this.isMember();
      },
      isMember(){
        const me = this
        wx.request({
          url: this.globalData.globalUrl + '/member/info',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            if (res.data.data) {
              me.vipFlag = res.data.data.isMember==0?false:true;

            }
          }
        });
      },
      click1 (index) {
        let o = this.lists[index]
        o.showTip = !o.showTip
        this.$set(this.lists, index, o)
      },
      click2 (couponId,limitFlag) {

        let _that = this;
        if(!_that.vipFlag && limitFlag){
          wx.showModal({
            title: '提示',
            cancelText: '稍后再去',
            confirmText: '立即前往',
            content: '成为会员即可领取该优惠券',
            success(res) {
              if (res.confirm) {
                wx.navigateTo({
                  url: '/pages/hotelMember/main'
                })
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          });
        }else{
          wx.showLoading({
            title: '正在领取',
          });
          wx.request({
            url: this.globalData.globalUrl + '/coupon/member/received/'+couponId,
            header: {
              'content-type': 'application/json',
              'memberId': wx.getStorageSync('memberId')
            },
            success (res) {
              wx.hideLoading();
              wx.showToast({
                title: '领取成功',
                icon: 'success',
                duration: 1500
              })
              console.log(res)
              _that.getData();
            },
            fail (error){
              wx.hideLoading();
              wx.showToast({
                title: '领取失败,请刷新后重试',
                icon: 'none',
                duration: 1500
              })
            }
          })
        }

      }

    },
    created () {
      this.getData()
    },
    onLoad () {
      this.isMember();
       this.getData();
      if (wx.getStorageSync('hotelname')) {
        this.hotelname = wx.getStorageSync('hotelname')
      }
    },
    onShow(){
      let _that = this;
      this.getData();
      wx.request({
        url: this.globalData.globalUrl + '/member/info',
        header: {
          'content-type': 'application/json',
          'memberId': wx.getStorageSync('memberId')
        },
        data: {
          hotelId: wx.getStorageSync('hotelId')
        },
        success (res) {
          if (res.data.data) {
            _that.vipFlag = res.data.data.isMember==0?false:true;

          }
        }
      })
    }
  }
</script>
<style scoped lang="less">
  .displaynone {
    display: none;
  }
  .couponCenter {
    background: #fff;
  }
  .coupon-box {
    position: relative;
    margin: 0 auto;
    width: 700rpx;
    height: 220rpx;
    >span {
      position: absolute;
      display: inline-block;
    }
    .span1 {
      top: 90rpx;
      left: 20rpx;
      width: 20rpx;
      height: 24rpx;
      line-height: 24rpx;
      font-size: 24rpx;
      color: #fff;
    }
    .span2 {
      top: 40rpx;
      left: 45rpx;
      width: 120rpx;
      height: 74rpx;
      line-height: 74rpx;
      font-size: 74rpx;
      color: #fff;
    }
    .span3 {
      top: 140rpx;
      left: 40rpx;
      width: 130rpx;
      height: 22rpx;
      line-height: 22rpx;
      font-size: 22rpx;
      color: #fff;
    }
    .span4 {
      top: 26rpx;
      left: 195rpx;
      width: 480rpx;
      height: 26rpx;
      line-height: 26rpx;
      font-size: 26rpx;
      color: #666;

    }
    .span5 {
      top: 75rpx;
      left: 195rpx;
      width: 480rpx;
      height: 24rpx;
      line-height: 24rpx;
      font-size: 24rpx;
      color: #666;
    }
    .span6 {
      top: 116rpx;
      left: 195rpx;
      width: 480rpx;
      height: 24rpx;
      line-height: 24rpx;
      font-size: 24rpx;
      color: #666;
    }
    .div-des {
      position: absolute;
      top: 150rpx;
      left: 195rpx;
      width: 300rpx;
      height: 50rpx;
      border-top: 1px solid #f1f1f1;
    }
  }

  .div-des .button1 {
    width: 110rpx;
    height: 50rpx;
    line-height: 50rpx;
    font-size: 22rpx;
    color: #666;
    background: url('http://img.rainfn.com/qfs_p_0306_down.png') 90rpx center no-repeat;
    background-size: 20rpx 12rpx;
  }
  .coupon-box .button2 {
    position: absolute;
    bottom: 10rpx;
    right: 26rpx;
    padding-right: 20rpx;
    width: 140rpx;
    height: 50rpx;
    line-height: 50rpx;
    font-size: 26rpx;
    color: #f9001b;
    text-align: right;
    background: url('http://img.rainfn.com/qfs_p_0306_right.png') right center no-repeat;
    background-size: 12rpx 20rpx;
  }
  .coupon-des {
    box-sizing: border-box;
    padding: 10rpx 14rpx;
    margin: 0 0 25rpx 205rpx;
    width: 510rpx;
    height: 85rpx;
    background:#fff;
    border-radius:10rpx;
    span {
      display: block;
      width: 400rpx;
      height: 28rpx;
      line-height: 28rpx;
      font-size: 20rpx;
      color: #666;
    }
  }

  .coupon-common {
    background: url('http://img.rainfn.com/qfs_p_0306_coupon-bg-common.png') 0 0 no-repeat;
    background-size: 700rpx 220rpx;
  }
  .coupon-member {
    background: url('http://img.rainfn.com/qfs_p_0306_coupon-bg-member.png') 0 0 no-repeat;
    background-size: 700rpx 220rpx;
  }
  .coupon-common-draw {
    background: url('http://img.rainfn.com/qfs_p_0306_coupon-bg-common-draw.png') 0 0 no-repeat;
    background-size: 700rpx 220rpx;
  }
  .coupon-member-draw {
    background: url('http://img.rainfn.com/qfs_p_0306_coupon-bg-member-draw.png') 0 0 no-repeat;
    background-size: 700rpx 220rpx;
  }
  .img-draw {
    position: absolute;
    bottom: 20rpx;
    right: 20rpx;
    width: 140rpx;
    height: 140rpx;
    background: url('http://img.rainfn.com/qfs_p_0306_icon-draw.png') 0 0 no-repeat;
    background-size: 140rpx 140rpx;
  }
  .noCoupon {
    box-sizing: border-box;
    margin-top: 300rpx;
    padding-top: 400rpx;
    width: 100%;
    height: 430rpx;
    line-height: 30rpx;
    text-align: center;
    background: #fff url('../../../static/images/noCoupon.png') center 0 no-repeat;
    background-size: 400rpx 400rpx;
    font-size: 28rpx;
    color: #999;
  }
</style>
