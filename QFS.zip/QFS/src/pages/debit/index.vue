<template>
  <div class="debit">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <section class="section-1">
        <div class="name">{{hotelName}}</div>
        <div class="balance">余额: ¥ <b>{{balance}}</b></div>
        <a href="/pages/debitDetail/main">储值及消费详情 ></a>
      </section>
      <section class="section-2">
        <div class="balance-500" v-for="(item,index) in data" :key="index">
          <div class="title">
            储值卡{{item.money}}元  |  <span>价值{{item.money + item.giveMoney}}元</span>
          </div>
          <div class="content">
            <div class="content-name">酒店储值卡{{item.money}}元</div>
            <div class="content-value">限时活动 储值{{item.money}}元即送{{item.giveMoney}}元</div>
            <hr/>
            <div class="content-tip tip1">储值即送酒店会员+400成长值,下单再获成长值</div>
            <div class="content-tip">预定客房直接抵扣 | 无满额限制 | 永久有效</div>
          </div>
          <div class="card-footer">
            <span>{{item.money}}元</span>
            <span class="before-num">{{item.money + item.giveMoney}}元</span>
            <span class="go-add" @click="toDebit(item.id)">立即储值 ></span>
          </div>
        </div>
        <div class="balance-1000"></div>
      </section>
    </scroll-view>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        data: {},
        balance: '',
        hotelName:''
      }
    },
    methods: {
      getData () {
        const me = this
        wx.request({
          url: this.globalData.globalUrl + '/hotel/card/list',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success: function (res) {
            me.data = res.data.data.list;
          
          }
        })
        wx.request({
          url: this.globalData.globalUrl + '/card/detail',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success: function (res) {
            me.balance = res.data.data.balance;
          }
        })
      },
      toDebit (id) {
        wx.request({
          url: this.globalData.globalUrl + '/card/order/create',
          method: 'POST',
          data: {
            cardId: id
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success: function (res) {
            if (res.data.data.data) {
              wx.requestPayment({
                timeStamp: res.data.data.data.timeStamp,
                nonceStr: res.data.data.data.nonceStr,
                package: res.data.data.data.package,
                signType: 'MD5',
                paySign: res.data.data.data.paySign,
                success: function (res) {
                  wx.showToast({
                    title: '支付成功',
                    icon: 'success',
                    duration: 3000
                  })
                  var url = '/pages/paymentSuccess/main'
                  wx.navigateTo({ url})
                },
                'fail': function (res) {
                  // console.log('支付失败')
                  // var url = '/pages/paymentFailed/main?item=debit'
                  // wx.navigateTo({ url})
                  wx.showToast({
                    title: '支付失败',
                    icon: 'none',
                    duration: 2000
                  })
                }
              })
            } else {
              wx.showToast({
                title: '储值失败',
                icon: 'none',
                duration: 2000
              })
            }
          }
        })
      }
    },
    onShow () {
      this.getData();
      if(wx.getStorageSync('hotelname')){
        this.hotelName=wx.getStorageSync('hotelname');
      }
    }
  }
</script>
<style scoped lang="less">
  section {
    background: #fff;
  }
  .section-1 {
    position: relative;
    margin-bottom: 20rpx;
    width: 100%;
    height: 240rpx;
    color: #262626;
    .name {
      position: absolute;
      top: 60rpx;
      left: 30rpx;
      width: 100%;
      height: 50rpx;
      line-height: 50rpx;
      font-size: 38rpx;
    }
    .balance {
      position: absolute;
      top: 150rpx;
      left: 30rpx;
      width: 450rpx;
      height: 50rpx;
      font-size: 28rpx;
      vertical-align: bottom;
      color: #db8327;
    }
    .balance b {
      display: inline-block;
      font-size: 48rpx;
    }
    a {
      position: absolute;
      top: 165rpx;
      right: 30rpx;
      width: 220rpx;
      height: 28rpx;
      line-height: 28rpx;
      text-align: right;
      font-size: 24rpx;
      color: #999;
    }
  }

  .section-2 {
    padding-top: 50rpx;
    width: 100%;
    .balance-500 {
      background: url('../../../static/images/card-bg.png') 0 0 no-repeat;
      background-size: 100%;
      margin: 0 auto 48rpx auto;
      width: 690rpx;
      height: 400rpx;
      box-shadow:0px 5px 20px 0px rgba(0,0,0,0.2);
      border-radius:20px;
      >div {
        margin-left:30rpx;
      }
      .title {
        font-size: 28rpx;
        height: 65rpx;
        color: #666666;
        line-height:65rpx;
        font-weight:400;
        span {
          color: #999999;
        }
      }
      .content {
        color: #FFFFFF;
        height:250rpx;
        .content-name {
          height: 56rpx;
          font-size: 40rpx;
          line-height: 56rpx;
          font-weight:500;
          padding-top:14rpx;
        }
        .content-value {
          height:45rpx;
          font-size:32rpx;
          font-weight:600;
          line-height:45rpx;
          margin-bottom:17rpx;
        }
        hr {
          width: 550rpx;
          opacity: 0.8;
          border-bottom: 1rpx solid #FFFFFF;
          margin-bottom:26rpx;
        }
        .content-tip {
          height: 33rpx;
          font-size: 24rpx;
          font-weight: 400;
          line-height: 33rpx;
        }
        .tip1 {
          margin-bottom:7rpx;
        }
      }
      .card-footer {
        height: 85rpx;
        line-height: 85rpx;
        position: relative;
        span {
          font-size: 28rpx;
          color: #D38F38;
          font-weight: 400;
        }
        .before-num {
          margin-left: 14rpx;
          color: #999999;
          text-decoration:line-through;
        }
        .go-add {
          font-size: 32rpx;
          position: absolute;
          right: 30rpx;
        }
      }
    }
    // .balance-1000 {
    //   background: url('../../../static/images/card2-bg.png') 0 0 no-repeat;
    //   background-size: 100%;
    // }
  }
</style>
