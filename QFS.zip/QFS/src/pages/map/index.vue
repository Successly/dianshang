<template>
  <div class="map-content">
    <map
      id="map"
      longitude="73.324520"
      latitude="83.099994"
      scale="14"
      :controls="controls"
      bindcontroltap="controltap"
      :markers="markers"
      bindmarkertap="markertap"
      :polyline="polyline"
      bindregionchange="regionchange"
      show-location
      style="width: 100%; height: 100vh;">
    </map>
  </div>
</template>
<script>
export default {
  data () {
    return {
      markers: [{
        iconPath: '/resources/others.png',
        id: 0,
        latitude: 73.099994,
        longitude: 63.324520,
        width: 50,
        height: 50
      }],
      polyline: [{
        points: [{
          longitude: 113.3245211,
          latitude: 23.10229
        }, {
          longitude: 113.324520,
          latitude: 23.21229
        }],
        color: '#FF0000DD',
        width: 2,
        dottedLine: true
      }],
      controls: [{
        id: 1,
        iconPath: '/resources/location.png',
        position: {
          left: 0,
          top: 300 - 50,
          width: 50,
          height: 50
        },
        clickable: true
      }],
      geoInfo:{
          lng: 0,
          lat: 0
      }
      
    }
  },
  methods: {
    regionchange(e) {
      console.log(e.type)
    },
    markertap(e) {
      console.log(e.markerId)
    },
    controltap(e) {
      console.log(e.controlId)
    }
  },
  mounted () {
    console.log(this.$root.$mp.query)
    // var mid = this.$root.$mp.query
    // const me = this
    // me.lat = mid.lat
    // me.lng = mid.lng
    // me.markers[0].latitude = mid.lat
    if(wx.getStorageSync('longitude')){
       this.geoInfo.lng=wx.getStorageSync('longitude')
    }
    if(wx.getStorageSync('latitude')){
       this.geoInfo.lat=wx.getStorageSync('latitude')
    }
    console.log("geoInfo");
    console.log(this.geoInfo);
    
  }
}
</script>

<style scoped lang="less">
.map-content {
  height: 100%;
  width: 100%;
}
</style>
