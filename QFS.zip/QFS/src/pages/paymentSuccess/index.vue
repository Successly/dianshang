<template>
  <div class="paymentSuccess">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <section>
        <div class="pay-icon">
          <img src="http://img.rainfn.com/qfs_p_0306_paySuccess.png" />
        </div>
        <p class="p1">支付成功</p>
        <p class="p2">您已完成支付，感谢您的选择</p>
        <a class="a1" href="" @click="backTo">返回首页</a>
        <a class="a2" href="/pages/orderList/main">查看订单</a>
      </section>
    </scroll-view>
  </div>
</template>
<script>
  export default {
    data () {
      return {}
    },
    methods: {
      backTo () {
        const url = '/pages/hotelIndex/main'
        wx.switchTab({url})
      }
    }
  }
</script>
<style scoped lang="less">
  section {
    height: 100%;
    background: #fff;
  }
  .pay-icon {
    padding-top: 120rpx;
    width: 100%;
    height: 300rpx;
    img {
      display: block;
      margin: 0 auto;
      width: 150rpx;
      height: 150rpx;
      border-radius: 75rpx;
    }
  }

  p {
    width: 100%;
    height: 50rpx;
    line-height: 50rpx;
    color: #222;
    text-align: center;
  }
  .p1 {
    font-size: 36rpx;
  }
  .p2 {
    margin-bottom: 20rpx;
    font-size: 28rpx;
  }
  a {
    display: block;
    margin: 50rpx auto;
    width: 90%;
    height: 90rpx;
    line-height: 90rpx;
    text-align: center;
    border-radius: 16rpx;
  }
  .a1 {
    background: #35abfe;
    color: #fff;
  }
  .a2 {
    border: 1px solid #35abfe;
    color: #35abfe;
  }
</style>
