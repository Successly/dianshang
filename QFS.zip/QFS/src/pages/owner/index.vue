<template>
  <div class="owner">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <section>
        <div class="div-1"></div>
        <a class="owner-add"  @click="addOwner()">+ 添加入住人</a>
        <ul>
          <li v-for="(item, index) in items" :key="index">
            <i :class="{active: item.cls}" @click="selectFn(item, index)"></i>
            <span class="name">{{item.name}}</span>
            <span class="phone">手机号：{{item.mobile}}</span>
            <div class="edit" @click="click1(item)">编辑</div>
          </li>
        </ul>
        <button class="button2" v-show="items.length" @click="click2">确定</button>
      </section>
    </scroll-view>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        items: []
      }
    },
    methods: {
      addOwner(){
        wx.navigateTo({
          url: '/pages/ownerAdd/main'
        })
      },
      getData () {
        const me = this;

        wx.request({
          url: this.globalData.globalUrl + '/check/list',
          data: {
            memberId: wx.getStorageSync('memberId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            if (res.data.data) {
              for (let i = 0; i < res.data.data.length; i++) {
                res.data.data[i].cls = false
              }
              me.items = res.data.data
            }
          }
        })
      },
      selectFn (item, index) {
        console.log(this)
        if (item.cls) {
          this.items[index].cls = false
        } else {
          this.items[index].cls = true
        }
      },
      //编辑
      click1 (item) {
        const url = '/pages/ownerModify/main?item=' + JSON.stringify(item)
        wx.navigateTo({url})
      },
      //确定
      click2 () {
        const arr = []
        for (var i = 0; i < this.items.length; i++) {
          if (this.items[i].cls) {
            arr.push(this.items[i])
          }
        }
        if (arr.length > 1) {
          wx.showToast({
            title: '只能选择一个用户',
            icon: 'none',
            duration: 2000
          });
        } else if (arr.length === 0) {
          wx.showToast({
            title: '请选择用户',
            icon: 'none',
            duration: 2000
          });
        } else if (arr.length === 1) {
          wx.setStorageSync('owner', JSON.stringify(arr))
          wx.navigateBack({
            delta: 1
          })
          /*const url = '/pages/orderAccounts/main'
          wx.navigateTo({url})*/
        }

      }
    },
    created () {
    },
    onLoad (item) {
      if (item.item) {
        const o = JSON.parse(item.item)
        this.name = o.name
        this.mobile = o.mobile
        this.id = o.id
      }
      this.getData();
    },
    onShow(){
      this.getData();
    }
  }
</script>
<style scoped lang="less">
  section {
    padding-top: 50rpx;
    height: 100%;
    background: #fff;
    font-size: 26rpx;
  }
  .div-1 {
    width: 100%;
    height: 20rpx;
    background: #f6f6f6;
  }
  .owner-add {
    display: block;
    margin: 0rpx auto;
    width: 90%;
    height: 90rpx;
    line-height: 90rpx;
    text-align: center;
    font-size: 36rpx;
    color: #35abfe;
    border: 1px solid #35abfe;
    border-radius: 16rpx;
  }
  ul {
    margin-top: 50rpx;
    border-top: 1px solid #f5f5f5;
  }
  li {
    position: relative;
    width: 100%;
    height: 120rpx;
    border-bottom: 1px solid #f5f5f5;
  }
  i {
    position: absolute;
    top: 20rpx;
    left: 30rpx;
    width: 40rpx;
    height: 40rpx;
    background: url('http://img.rainfn.com/qfs_p_0306_select-no.png');
    background-size:contain;
  }
  i.active {
    background: url('http://img.rainfn.com/qfs_p_0306_select-yes.png');
    background-size:contain;
  }
  .name, .phone {
    position: absolute;
    left: 100rpx;
    width: 300rpx;
    height: 30rpx;
    line-height: 30rpx;
  }
  .name {
    top: 25rpx;
    color: #333;
  }
  .phone {
    top: 60rpx;
    color: #666;
  }
  .edit {
    position: absolute;
    right: 30rpx;
    top: 45rpx;
    width: 60rpx;
    height: 30rpx;
    line-height: 30rpx;
    color: #999;
  }
  .button2 {
    width: 90%;
    height: 90rpx;
    line-height: 90rpx;
    text-align: center;
    background: #35abfe;
    border-radius: 16rpx;
    color: #fff;
    font-size: 34rpx;
  }
</style>
