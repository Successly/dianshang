<template>
  <div class="orderAccounts">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <section class="section-1">
        <img :src="hotelBackgroundImg"/>
        <span class="span1">{{hotelname}}</span>
        <span class="span2">房型：{{roomName}}</span>
        <span class="span3">{{address.city}} {{address.district}} {{address.addressDetail}}</span>
      </section>
      <section class="section-2">
        <span class="span1">入住时间</span>
        <span class="span2">{{enter}}</span>
        <span class="span3">离开时间</span>
        <span class="span4">{{leave}}</span>
        <span class="span5">共{{total}}</span>
      </section>
      <section class="section-3">
        <div class="div1">
          <span class="span1">房间数</span>
          <span class="span2">1间</span>
        </div>
        <div class="div2">
          <span class="span1">入住人</span>
          <input placeholder="每间填写1位入住人姓名" v-model="owner.name"/>
          <a href="/pages/owner/main"></a>
        </div>
        <div class="div3">
          <span class="span1">联系手机</span>
          <input placeholder="用于接收通知短信" v-model="owner.mobile" maxlength="11"/>
        </div>
      </section>
      <section class="section-4">
        <div class="div1">费用信息</div>
        <div class="div2">
          <span class="span1">房费</span>
          <span class="span2">{{orderMoneyNum.roomFee/100}}元</span>
        </div>
      </section>
      <section class="section-5">
        <div class="div1">
          优惠信息<span v-if="CouponList"></span>
        </div>
        <div class="div2">
          <span>优惠券</span>
          <a href="" @click="toCoupon()">-{{orderMoneyNum.couponAmount/100}}元 ></a>
        </div>
      </section>
      <section class="section-6">
        <div class="div1">
          <span>酒店会员</span>
          <a href="/pages/hotelMember/main">会员详情 ></a>
        </div>
        <div class="div2">
          <span class="span1">会员折扣</span>
          <span class="span2" v-if="orderMoneyNum.memberDiscount!=0">{{orderMoneyNum.memberDiscount}}折</span>
          <span class="span2" v-else>无</span>
        </div>
      </section>
      <section class="section-7">
        <div>合计：{{orderMoneyNum.total/100}}元</div>
      </section>
      <section class="section-8">
        <div class="div1">
          <span class="span1">储值卡</span>
          <span class="span2 card" v-if="cardMoneyMax.money&&cardMoneyMax.giveMoney?true:false">满{{cardMoneyMax.money}}送{{cardMoneyMax.giveMoney}}</span>
          <a href="/pages/debit/main">储值详情 ></a>
        </div>
        <div class="div2">
          <span class="span1">储值卡抵扣</span>
          <span class="span2" v-if="orderMoneyNum.cardDeduction!=0">{{orderMoneyNum.cardDeduction/100}}元</span>
          <span class="span2" v-else>无</span>
        </div>
      </section>
      <section class="section-9">
        <div class="div1">本单可享</div>
        <div class="div2" v-if="backCouponFlag">
          <span class="span1">消费后返</span>
          <span class="span2" >入住后返<span v-for="(item, index) in backCouponArr" :key="index">{{item.money}}元<span v-if="index!=backCouponArr.length-1">,</span></span>优惠券</span>
        </div>
        <div class="div3" v-if="memberData.isMember">
          <span class="span1">会员权益</span>
          <span class="span2">{{memberData.gradeName}}入住{{equity}}</span>
        </div>
        <div class="div4">
          <span class="span1"></span>
          <span class="span2">离店后可获会员成长值，详见酒店会员中心</span>
        </div>
      </section>
      <section class="section-10">
        <div class="div1">退款规则</div>
        <div class="div2">{{refundRules}}</div>
      </section>
      <section class="section-11">
        <div class="money">
          <span class="span1">¥</span>
          <span class="span2">{{orderMoneyNum.payAmount /100}}</span>
          <span class="span3">已省{{orderMoneyNum.provinceAmount/100}}元</span>
        </div>
        <div class="payment" @click="payment">微信支付</div>
      </section>
    </scroll-view>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        status: 0,
        owner: {
          name: '',
          id: '',
          mobile: ''
        },
        cardDeduction: 0,
        duration: '',
        endTime: '',
        memberDiscount: '',
        provinceAmount: '',
        roomFee: '',
        roomId: '',
        roomNumber: '',
        roomTypeId: '',
        startTime: '',
        orderType: '',
        enter: '',
        leave: '',
        total: '',
        savemoney: 0,
        couponAmount: 0,
        couponId: 0,
        hotelname:'',
        CouponList:'',
        backCouponFlag:'',
        backCouponArr:[],
        refundRules:'',
        cardMoneyMax:{},
        address:[],
        roomType:'',
        hotelBackgroundImg:'',
        orderMoneyNum:[],
        roomRemain:'',
        memberData:'',
        equity:'',
        roomName:''

      }
    },
    methods: {
      toCoupon () {
        var url = '/pages/couponOrder/main?startTime=' + this.startTime + '&endTime=' + this.endTime + '&roomFee=' + this.roomFee
        wx.navigateTo({ url})
      },
      memberInfo(){
         const me = this
        //会员权益
        wx.request({
          url: this.globalData.globalUrl + '/member/info',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            me.memberData = res.data.data;

            if(me.memberData.equity&&me.memberData.equity.length!=0){
                   let equityArr = me.memberData.equity;
                   let str='';
                   equityArr.forEach(item=>{
                      str+=item.name;
                   });
               me.equity=str;
            }


          }
        })
      },
      //页面的金额
      moneyNum(){
         const me = this;
         const params={
            hotelId: wx.getStorageSync('hotelId'),
            startTime: this.startTime,
            endTime: this.endTime,
            duration: this.duration,
            type: this.orderType,
            roomNumber: this.roomNumber,
            mobile: this.owner.mobile,
            roomFee: Number(this.roomFee),
            couponAmount: String(this.couponAmount),
            memberDiscount: this.memberDiscount,
            cardDeduction: this.cardDeduction,
            provinceAmount: Number(this.provinceAmount),
            payAmount: (this.savemoney - this.cardDeduction) || 1,
            roomId: this.roomId,
            roomTypeId: this.roomTypeId,
            couponId: this.couponId
          };
        wx.request({
          url: this.globalData.globalUrl + '/roomOrder/roomFee',
          method: 'POST',
          data:params,
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            if(res.data){
                me.orderMoneyNum = res.data.data;
                console.log(me.orderMoneyNum);
            }
          }
        })
      },
      //退款规则
      refundRule(){
        const me = this
        wx.request({
          url: this.globalData.globalUrl + '/roomOrder/refund/rule',
          data: {
            hotelId: wx.getStorageSync('hotelId'),
            startTime:wx.getStorageSync('startTime'),
            // memberId: 1,
            type:wx.getStorageSync('orderType')
          },
          success (res) {
            if(res.data){
                me.refundRules=res.data.message;
            }
          }
        })
      },
      // 储值卡
      cardList(){
        const me =this;
        wx.request({
          url: this.globalData.globalUrl + '/hotel/card/list',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success: function (res) {
            let cardGiveMoneyMax=0;
            me.data = res.data.data.list;
            me.data.forEach(item => {
              if(item.giveMoney>=cardGiveMoneyMax){
                  me.cardMoneyMax.giveMoney=item.giveMoney;
                  me.cardMoneyMax.money =item.money;
              }
            });
          }
        })
      },
      queryGetCouponList(){
        const me = this
        wx.request({
          url: this.globalData.globalUrl + '/coupon/member/receivedList',
          data: {
            hotelId: wx.getStorageSync('hotelId'),
            // memberId: 1,
            status: 0
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            if (res.data.data.list) {
              me.CouponList = res.data.data.list.length;
            }
          }
        })
      },
      queryCouponList(){
           const me = this
        wx.request({
          url: this.globalData.globalUrl + '/coupon/list',
          data: {
            hotelId: wx.getStorageSync('hotelId'),
            type:3
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            if(res.data.data.list){
              me.backCouponFlag=res.data.data.list.length===0?false:true;
              me.backCouponArr=res.data.data.list;
            }
          }
        })
      },
      payment () {
        if (!this.owner.name) {
          wx.showToast({
            title: '请输入入住人姓名',
            icon: 'none',
            duration: 2000
          })
          return
        }
        var myreg = /^(((13[0-9])|(14[5-7])|(15[0-9])|(17[0-9])|(18[0-9]))+\d{8})$/
        if (!this.owner.mobile) {
          wx.showToast({
            title: '请输入入住人手机号码',
            icon: 'none',
            duration: 2000
          })
          return
        } else if (!myreg.test(this.owner.mobile)) {
          wx.showToast({
            title: '请输入正确的手机号',
            icon: 'none',
            duration: 2000
          })
          return
        }
        const me = this;
        const params={
            hotelId: wx.getStorageSync('hotelId'),
            startTime: this.startTime,
            endTime: this.endTime,
            duration: this.duration,
            type: this.orderType,
            roomNumber: this.roomNumber,
            mobile: this.owner.mobile,
            roomFee: Number(this.roomFee),
            couponAmount: String(this.couponAmount),
            memberDiscount: this.memberDiscount,
            cardDeduction: this.cardDeduction,
            provinceAmount: Number(this.provinceAmount),
            payAmount: (this.savemoney - this.cardDeduction) || 1,
            roomId: this.roomId,
            roomTypeId: this.roomTypeId,
            couponId: this.couponId,
            name:this.owner.name
          };
        wx.request({
          url: this.globalData.globalUrl + '/roomOrder/add',
          method: 'POST',
          data: params,
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            if (res.data.data && res.data.data.orderCode) {
              wx.request({
                url: me.globalData.globalUrl + '/roomOrder/wxPay',
                data: {
                  openId: wx.getStorageSync('openid'),
                  orderCode: res.data.data.orderCode,
                  payAmount: ((me.savemoney - me.cardDeduction) || 1) / 100
                },
                header: {
                  'content-type': 'application/json',
                  'memberId': wx.getStorageSync('memberId')
                },
                success (res) {
                  wx.requestPayment({
                    timeStamp: res.data.data.timeStamp,
                    nonceStr: res.data.data.nonceStr,
                    package: res.data.data.package,
                    signType: 'MD5',
                    paySign: res.data.data.paySign,
                    success: function (res) {
                      wx.showToast({
                        title: '支付成功',
                        icon: 'success',
                        duration: 3000
                      })
                      var url = '/pages/userCenter/main'
                      wx.navigateTo({ url})
                    },
                    'fail': function (res) {
                      console.log('支付失败')
                      var url = '/pages/paymentFailed/main?item=orderAccounts'
                      wx.navigateTo({ url})
                    }
                  })
                }
              })
            } else {
              wx.showToast({
                title: '提交失败',
                icon: 'none',
                duration: 3000
              })

            }
          }
        })
      },
      getData () {}
    },
    created () {
      this.getData();
      this.refundRule();
    },
    onLoad(){
      this.owner= {name: '',id: '',mobile: '' };
    },
    onShow () {
      let a1 = wx.getStorageSync('enter');
      this.CouponList=0;
      this.queryGetCouponList();
      this.queryCouponList();
      this.cardList();
      this.memberInfo();
      let a2 = wx.getStorageSync('enter')
      this.hotelname=wx.getStorageSync('hotelname')?wx.getStorageSync("hotelname"):"";
      if (wx.getStorageSync('hotelBackgroundImg')) {
              this.hotelBackgroundImg = wx.getStorageSync('hotelBackgroundImg');
      }
      if (wx.getStorageSync('roomType')) {
              this.roomType = wx.getStorageSync('roomType');
      }
      if (wx.getStorageSync('address')) {
        this.address = wx.getStorageSync('address');
      }
      if (wx.getStorageSync('couponId')) {
        this.couponId = wx.getStorageSync('couponId')
      }
      if (wx.getStorageSync('owner')) {
        var o = JSON.parse(wx.getStorageSync('owner'))[0]
        this.owner = o
      }
      if (wx.getStorageSync('couponAmount')) {
        this.couponAmount = Number(wx.getStorageSync('couponAmount'))
      }
      if (wx.getStorageSync('cardDeduction')) {
        this.cardDeduction = wx.getStorageSync('cardDeduction')
      }
      if (wx.getStorageSync('duration')) {
        this.duration = wx.getStorageSync('duration')
      }
      if (wx.getStorageSync('endTime')) {
        this.endTime = wx.getStorageSync('endTime')
      }
      if (wx.getStorageSync('memberDiscount')) {
        this.memberDiscount = Number(wx.getStorageSync('memberDiscount'))
      }
      if (wx.getStorageSync('provinceAmount')) {
        this.provinceAmount = wx.getStorageSync('provinceAmount')
      }
      if (wx.getStorageSync('roomFee')) {
        this.roomFee = wx.getStorageSync('roomFee')
      }
      if (wx.getStorageSync('roomId')) {
        this.roomId = wx.getStorageSync('roomId')
      }
      if (wx.getStorageSync('roomNumber')) {
        this.roomNumber = wx.getStorageSync('roomNumber')
      }
      if (wx.getStorageSync('roomTypeId')) {
        this.roomTypeId = wx.getStorageSync('roomTypeId')
      }
      if (wx.getStorageSync('startTime')) {
        this.startTime = wx.getStorageSync('startTime')
      }
      if (wx.getStorageSync('orderType')) {
        this.orderType = wx.getStorageSync('orderType')
      }
      if (wx.getStorageSync('enter')) {
        this.enter = wx.getStorageSync('enter')
      }
      if (wx.getStorageSync('leave')) {
        this.leave = wx.getStorageSync('leave')
      }
      if (wx.getStorageSync('total')) {
        this.total = wx.getStorageSync('total')
      }
       if (wx.getStorageSync('roomRemain')) {
        this.roomRemain = wx.getStorageSync('roomRemain')
      }
       if (wx.getStorageSync('roomName')) {
        this.roomName = wx.getStorageSync('roomName')
      }
      this.savemoney = (this.roomFee - 100 * this.couponAmount) * this.memberDiscount / 100
      if (this.cardDeduction >= this.savemoney) {
        this.cardDeduction = (this.savemoney -1) > 0 ? (this.savemoney -1) : 0
      }
      this.provinceAmount = this.roomFee - this.savemoney;
     this.moneyNum();
    }
  }
</script>
<style scoped lang="less">
  section {
    margin-top: 20rpx;
    width: 100%;
    background: #fff;
    font-size: 32rpx;
    .div1, .div2 {
      box-sizing: border-box;
      padding: 0 30rpx;
      width: 100%;
      height: 90rpx;
    }
    span, a {
      display: inline-block;
    }
  }

  .section-4, .section-5, section-6, .section-8 {
    width: 100%;
    height: 180rpx;
  }
  .section-1 {
    position: relative;
    width: 100%;
    height: 190rpx;
    img {
      position: absolute;
      top: 30rpx;
      left: 30rpx;
      width: 200rpx;
      height: 127rpx;
      border-radius: 16rpx;
    }
    span {
      height: 40rpx;
      line-height: 40rpx;
    }
    .span1 {
      position: absolute;
      top: 30rpx;
      left: 260rpx;
      width: 450rpx;
      color: #333;
    }
    .span2 {
      position: absolute;
      top: 80rpx;
      left: 260rpx;
      width: 450rpx;
      color: #666;
    }
    .span3 {
      position: absolute;
      top: 125rpx;
      left: 260rpx;
      width: 450rpx;
      color: #666;
    }
  }

  .section-2 {
    position: relative;
    width: 100%;
    height: 160rpx;
    .span1 {
      position: absolute;
      top: 30rpx;
      left: 30rpx;
      width: 150rpx;
      color: #666;
    }
    .span2 {
      position: absolute;
      top: 30rpx;
      left: 180rpx;
      width: 400rpx;
      color: #333;
    }
    .span3 {
      position: absolute;
      top: 80rpx;
      left: 30rpx;
      width: 150rpx;
      color: #666;
    }
    .span4 {
      position: absolute;
      top: 80rpx;
      left: 180rpx;
      width: 400rpx;
      color: #333;
    }
    .span5 {
      position: absolute;
      top: 55rpx;
      right: 30rpx;
      width: 150rpx;
      text-align: right;
      color: #666;
    }
  }

  .section-3 {
    width: 100%;
    height: 275rpx;
    .div1 {
      border-bottom: 1px solid #f5f5f5;
    }
    span {
      height: 90rpx;
      line-height: 90rpx;
    }
    .span1 {
      float: left;
      width: 170rpx;
      color: #333;
    }
    .span2 {
      float: left;
      width: 450rpx;
      color: #666;
    }
    .div2 {
      border-bottom: 1px solid #f5f5f5;
      a {
        float: left;
        margin-left: 35rpx;
        width: 50rpx;
        height: 90rpx;
        background: url('http://img.rainfn.com/qfs_p_0306_people.png') 0 center no-repeat;
        background-size: 30rpx 32rpx;
      }
    }

    input {
      float: left;
      margin-top: 16rpx;
      width: 420rpx;
      height: 60rpx;
    }
    .div3 .span1 {
      margin-left: 30rpx;
    }
  }

  .section-4 .div1 {
    line-height: 90rpx;
    color: #333;
    border-bottom: 1px solid #f5f5f5;
    span {
      height: 90rpx;
      line-height: 90rpx;
    }
    .div2 .span1 {
      float: left;
      width: 170rpx;
      color: #666;
    }
    .div2 .span2 {
      float: right;
      width: 200rpx;
      color: #666;
      text-align: right;
    }
  }

  .section-5 {
    .div1 {
      position: relative;
      width: 100%;
      line-height: 90rpx;
      border-bottom: 1px solid #f5f5f5;
      span {
        position: absolute;
        top: 30rpx;
        left: 170rpx;
        background: url('http://img.rainfn.com/qfs_p_0306_most-discount.png') 0 0 no-repeat;
        background-size: 100rpx 30rpx;
        width:100rpx;
        height:100%;
      }
    }

    .div2 span {
      float: left;
      color: #666;
      height: 90rpx;
      line-height: 90rpx;
    }
    .div2 a {
      float: right;
      height: 90rpx;
      line-height: 90rpx;
      text-decoration: none;
      color: #666;
    }
  }

  .section-6 {
    span, a {
      width: 200rpx;
      height: 90rpx;
      line-height: 90rpx;
    }
    a{
      color: #666;
    }
    .div1 {
      border-bottom: 1px solid #f5f5f5;
      span {
        float: left;
      }
      a {
        float: right;
        text-align: right;
      }
    }

    .div2 .span2 {
      float: right;
      text-align: right;
      color: #666;
    }
  }


  .section-7 {
    height: 90rpx;
    line-height: 90rpx;
    div {
      padding-right: 30rpx;
      text-align: right;
      color: #e06064;
    }
  }
  .section-8 {
    .div1 {
      position: relative;
      .span1 {
        float: left;
        width: 100rpx;
        height: 90rpxx;
        line-height: 90rpx;
        color: #333;
      }
      .span2 {
        position: absolute;
        top: 30rpx;
        left: 130rpx;
        width: 190rpx;
        height: 35rpx;
        // background: url('http://img.rainfn.com/qfs_p_0306_discount-1000-300.png') 0 0 no-repeat;
        background-size: 190rpx 35rpx;
        background: #e87777;
        border-radius: 12rpx;
        color: #fff;
        font-size: 25rpx;
        text-align:center;
      }
      a {
        float: right;
        width: 200rpx;
        height: 90rpx;
        line-height: 90rpx;
        color: #666;
        text-align: right;
      }
    }

    .div2 .span1 {
      float: left;
      width: 200rpx;
      height: 90rpx;
      line-height: 90rpx;
    }
    .div2 .span2 {
      float: right;
      width: 200rpx;
      height: 90rpx;
      line-height: 90rpx;
      text-align: right;
      color: #666;
    }
  }


  .section-9 {
    .div1 {
      width: 100%;
      height: 90rpx;
      line-height: 90rpx;
      color: #333;
    }
    .div2, .div3, .div4 {
      box-sizing: border-box;
      padding: 0 30rpx;
      width: 100%;
      height: 60rpx;
      line-height: 60rpx;
      color: #666;
    }
    .div2 .span1, .div3 .span1, .div3 .span1 {
      float: left;
      width: 150rpx;
      height: 60rpx;
      line-height: 60rpx;
    }
    .div2 .span2, .div3 .span2, .div4 .span2, {
      float: left;
      width: 540rpx;
      height: 60rpx;
      line-height: 60rpx;
      font-size: 26rpx;
    }
  }

  .section-10 {
    margin-bottom: 120rpx;
    .div1 {
      width: 100%;
      color: #333;
    }
    .div2 {
      width: 100%;
      color: #666;
    }
  }

  .section-11 {
    position: fixed;
    bottom: 0;
    height: 120rpx;
    .money {
      position: absolute;
      top: 50rpx;
      left: 30rpx;
      color: #e06064;
      .span1 {
        display: inline-block;
        font-size: 24rpx;
      }
      .span2 {
        margin-left: 2rpx;
        font-size: 38rpx;
      }
      .span3 {
        padding: 0rpx 4rpx;
        margin-left: 6rpx;
        border: 1px solid #e06064;
        border-radius: 8rpx;
        font-size: 20rpx;
      }
    }
    .payment {
      position: absolute;
      top: 20rpx;
      right: 20rpx;
      width: 235rpx;
      height: 80rpx;
      line-height: 80rpx;
      text-align: center;
      background: #35abfe;
      color: #fff;
    }
  }

</style>
