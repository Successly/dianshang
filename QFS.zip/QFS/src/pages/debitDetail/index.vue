<template>
  <div class="debitDetail">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <section class="section-1">
        <div class="name">{{result.hotelName}}</div>
        <div class="balance">余额: ¥ <b>{{balance}}</b></div>
      </section>
      <section class="section-2">
        <div class="tip-name">
          <h3 v-for="(tip,index) in tips" :key="index" @click="show(index)">{{tip.name}}</h3>
        </div>
        <div class="debitDetail-table" v-if="activeIndex == 0">
          <div class="debitDetail-tr">
            <div></div>
            <div>储蓄金额<br/>（元）</div>
            <div>消费金额<br/>（元）</div>
          </div>
          <div class="debitDetail-tr">
            <div class="out">
              <em class="tr">汇总</em>
              <em class="lb">时间</em>
            </div>
            <div>{{total1}}</div>
            <div>{{total2}}</div>
          </div>
          <div class="debitDetail-tr" v-for="item in cardDetail">
            <div>{{item.createTime}}</div>
            <div>储值：{{item.money}}【赠送{{item.giveMoney}}】</div>
            <div>{{item.payAmount}}</div>
          </div>
        </div>
      </section>
      <div class="xiaofei"  v-if="activeIndex == 1">
        <dl class="header">
          <dd>
            <div class="header-left">已完成订单</div>
            <div class="header-right">
              <span>储蓄卡</span>
              <span>抵扣金额（元）</span>
            </div>
          </dd>
        </dl>
        <dl class="lists">
          <dd v-for="(val, idx) in result.consumeDetail" :key="idx" class="">
            <div class="lists-left">
              <span class="span1">{{result.hotelName}}</span>
              <span class="span2">床型：{{val.roomTypeName}}</span>
              <span class="span3">支付时间：{{val.createTime}}</span>
              <span class="span4">入住时间：{{val.startTime}}</span>
              <span class="span5">离开时间：{{val.endTime}}</span>
            </div>
            <div class="lists-right">{{val.cardDeduction}}</div>
          </dd>
        </dl>
      </div>
    </scroll-view>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        balance: '',
        total1: '',
        total2: '',
        cardDetail: [],
        result: {
          hotelName: '',
          balance: 2900.00,
          consumeDetail: [
            {
              roomTypeName: '大床房',
              cardDeduction: '308',
              createTime: '2018.12.30 12:00',
              startTime: '2019.01.01 14:00',
              endTime: '2019.0102 11:00'
            }
          ]
        },
        tips: [
          {
            name: '储值详情'
          },
          {
            name: '消费详情'
          }
        ],
        activeIndex: 0
      }
    },
    methods: {
      getData () {
        const me = this
        wx.request({
          url: this.globalData.globalUrl + '/card/detail',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success: function (res) {
            me.balance = res.data.data.balance
            me.cardDetail = res.data.data.cardDetail
            me.result = res.data.data
            me.total1 = 0
            me.total2 = 0
            for (let i = 0; i < me.cardDetail.length; i++) {
              me.cardDetail[i].createTime = me.cardDetail[i].createTime.substr(0, 10)
              me.total1 += Number(me.cardDetail[i].money)
              me.total2 += Number(me.cardDetail[i].payAmount)
            }
            for (let i = 0; i < me.result.consumeDetail.length; i++) {
              me.result.consumeDetail[i].createTime = me.result.consumeDetail[i].createTime.substr(0, 16).replace(/T/, ' ')
              me.result.consumeDetail[i].startTime = me.result.consumeDetail[i].startTime.substr(0, 16).replace(/T/, ' ')
              me.result.consumeDetail[i].endTime = me.result.consumeDetail[i].endTime.substr(0, 16).replace(/T/, ' ')
            }
          }
        })
      },
      show (index) {
        this.activeIndex = index
      }
    },
    created () {
      this.getData()
    },
    onshow(){
       this.getData ();
    }
  }
</script>
<style scoped lang="less">
  section {
    background: #fff;
  }
  .section-1 {
    position: relative;
    margin-bottom: 20rpx;
    width: 100%;
    height: 240rpx;
    color: #262626;
    .name {
      position: absolute;
      top: 60rpx;
      left: 30rpx;
      width: 100%;
      height: 50rpx;
      line-height: 50rpx;
      font-size: 38rpx;
    }
    .balance {
      position: absolute;
      top: 150rpx;
      left: 30rpx;
      width: 450rpx;
      height: 50rpx;
      font-size: 28rpx;
      vertical-align: bottom;
      color: #db8327;
    }
    .balance b {
      display: inline-block;
      font-size: 48rpx;
    }
  }

  .section-2 {
    padding: 40rpx 30rpx;
    h3 {
      width: 160rpx;
      height: 40rpx;
      line-height: 40rpx;
      font-size: 38rpx;
      margin-bottom: 40rpx;
      margin-right: 10rpx;
    }
  }
  .tip-name {
    display: flex;
    flex-direction: row;
  }
  .debitDetail {
    background: #fff;
  }
  .debitDetail-table {
    display: table;
    margin: 15rpx auto 25rpx auto;
    width: 100%;
    border-collapse: collapse;
    font-size: 26rpx;
    .debitDetail-tr {
      display:table-row;
      > div {
        padding: 20rpx 0;
        display:table-cell;
        vertical-align:middle;
        text-align: center;
        border: 1px solid #e2e2e2;
      }
    }
  }
  .out {
    position: relative;
    width: 200rpx;
    height: 77rpx;
  }
  .out:before {
    content: "";
    position: absolute;
    width: 1px;
    height: 235rpx;
    top: 0;
    left: 0;
    background-color: #e2e2e2;
    display: block;
    transform: rotate(-60deg);
    transform-origin: top;
    -ms-transform: rotate(-60deg);
    -ms-transform-origin: top;
  }
  .tr{
    position: absolute;
    top: 10rpx;
    right: 10rpx;
  }
  .lb{
    position: absolute;
    bottom: 10rpx;
    left: 10rpx;
  }
  /*.title3 {*/
    /*position: absolute;*/
    /*top: 30px;*/
    /*left: 0px;*/
  /*}*/
  dd {
    box-sizing: border-box;
    padding: 0rpx 60rpx 0 60rpx;
    margin: 0 auto;
  }
  .header dd div {
    float: left;
    height: 100rpx;
    border: 1px solid #a0a0a0;
    box-sizing: border-box;
    text-align: center;
    font-size: 26rpx;
    color: #333;
  }
  .header-left {
    line-height: 100rpx;
  }
  .header-right {
    padding-top: 14rpx;
  }
  .header-right span {
    display: block;
    width: 100%;
    height: 36rpx;
    line-height: 36rpx;
  }
  .lists dd div {
    float: left;
    height: 300rpx;
    border: 1px solid #a0a0a0;
    border-top-width: 0;
    box-sizing: border-box;
  }
  dd .lists-left, .header-left {
    width: 70%;
    border-right-width: 0 !important;
  }
  dd .lists-right, .header-right {
    width: 30%;
  }
  .lists-left span {
    display: block;
    box-sizing: border-box;
    padding-left: 12rpx;
    width: 100%;
    height: 40rpx;
    line-height: 40rpx;
    font-size: 26rpx;
  }
  .lists-left .span1 {
    margin-top: 46rpx;
  }
  .lists-right {
    line-height: 300rpx;
    text-align: center;
  }
</style>
