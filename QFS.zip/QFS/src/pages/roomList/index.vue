<template>
  <div class="roomList">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <div class="div-1">
        <h3>{{hotelData.name}}</h3>
        <div @click="goMap(hotelData.address)">
          <span class="span-1">{{hotelData.address.city}} {{hotelData.address.district}} ></span>
          <span class="span-2">{{hotelData.address.addressDetail}}</span>
        </div>
        <a href="" @click="gotoPhone(hotelData.phone)">联系酒店</a>
      </div>
      <div class="sp"></div>
      <div class="div-2">
        <a class="a1" href="/pages/hotelMember/main"></a>
        <a class="a2" href="/pages/debit/main"></a>
        <div>
          <span v-for="item in hotelData.promotionToday" class="span-1">{{item.title + '：' + item.detail}}</span>
          <block v-if="hotelData.maxGiveMoneyOfCard">
            <span  v-for="(value, key) in hotelData.maxGiveMoneyOfCard" class="span-1">酒店储值：储值{{key}}元送{{value}}元，更享会员折扣权益</span>
          </block>

        </div>
      </div>
      <div class="sp"></div>
      <div class="div-3">
        <h3>领券中心</h3>
        <a class="a1" href="/pages/couponCenter/main">领取 ></a>
        <a :class="item.class" href="javascript:void(0);" v-for="item in backCouponArr"><span>{{item.desc}}</span></a>
      </div>
      <div class="sp"></div>
      <div v-if="defaultSearchType == 'hour'" class="div-4">
        <div class="div-title">
          <span class="span-1"></span>
          <span class="span-2"><b>入住</b>{{hourData.enter}}</span>
          <span class="span-3"><b>离开</b>{{hourData.leave}}</span>
          <span class="span-4">点击修改时间</span>
          <a href="" @click="modHour">共{{hourData.total}} ></a>
          <hourSelect @onOkSelected="onOkSelected" v-if="hourShow" :hourShow="hourShow" :startTime="hourData.enter" :endTime="hourData.leave"></hourSelect>
        </div>
        <div class="houseWrap">
          <div class="houseBlock" v-for="(item,index) in memberData.hourRooms" :index="index" :key="index" v-if="index < count1">
            <div class="infoBlock">
              <div class="leftBlock">
                  <image :src="item.images[0]" mode="aspectFill" @click="showDetail(index, 'hour')"/>
              </div>
              <div class="rightBlock">
                <div class="houseName" @click="showDetail(index, 'hour')">{{item.name}} ></div>
                <div class="houseDesc">{{item.summary[0]}} {{item.summary[1]}} {{item.summary[2]}} </div>
                <div class="remain" v-if="item.remain>=0">剩余{{item.remain}}间</div>
                <div class="buyBlock">
                  <div class="moneyBlock">
                    <div class="realPrice"><i>¥</i>{{item.realPrice / 100}}</div>
                    <div class="savedPrice">已省{{item.savedPrice/100}}元</div>
                  </div>
                  <a v-if="item.remain == 0 || !item.remain" class="btnFull" href="">满房</a>
                  <a v-else class="btnOrder" href="" @click="gotoPay(item, '0')">立即预定</a>
                </div>
              </div>
            </div>
            <div class="labelsBlock">
              <!--<span class="label" v-if="hotelData.maxDiscountOfGrade">会员{{hotelData.maxDiscountOfGrade}}折</span>-->
              <block v-if="item.promotions">
                <span class="label" v-for="(item01, index01) in item.promotions">{{item01}}</span>
              </block>
            </div>
          </div>
           <div class="item-more" v-if="memberData.hourRooms && memberData.hourRooms.length > count1" @click="hourMore(1)">查看剩余房型</div>
        </div>
      </div>
      <div v-if="defaultSearchType == 'day'" class="div-5">
        <div class="div-title">
          <span class="span-1"></span>
          <span class="span-2"><b>入住</b>{{dayData.enter}}</span>
          <span class="span-3"><b>离开</b>{{dayData.leave}}</span>
          <span class="span-4">点击修改时间</span>
          <a href="" @click="modTime">共{{dayData.total}} ></a>
          <timeSelect @onOkSelected="onOkSelected" v-if="tiemShow" :tiemShow="tiemShow"  :startTime="dayData.enter" :endTime="dayData.leave"></timeSelect>
        </div>
        <div class="houseWrap">
          <div class="houseBlock" v-for="(item,index) in memberData.dayRooms" :index="index" :key="key" v-if="index < count1">
            <div class="infoBlock">
              <div class="leftBlock">
                <image :src="item.images[0]" mode="aspectFill" @click="showDetail(index, 'hour')"/>
              </div>
              <div class="rightBlock">
                <div class="houseName" @click="showDetail(index, 'hour')">{{item.name}} ></div>
                <div class="houseDesc">{{item.summary[0]}} {{item.summary[1]}} {{item.summary[2]}} </div>
                <div class="remain" v-if="item.remain>=0">剩余{{item.remain}}间</div>
                <div class="buyBlock">
                  <div class="moneyBlock">
                    <div class="realPrice"><i>¥</i>{{item.realPrice / 100}}</div>
                    <div class="savedPrice">已省{{item.savedPrice/100}}元</div>
                  </div>
                  <a v-if="item.remain == 0 || !item.remain" class="btnFull" href="">满房</a>
                  <a v-else class="btnOrder" href="" @click="gotoPay(item, '1')">立即预定</a>
                </div>
              </div>
            </div>
            <div class="labelsBlock">
              <!--<span class="label" v-if="hotelData.maxDiscountOfGrade">会员{{hotelData.maxDiscountOfGrade}}折</span>-->
              <block v-if="item.promotions">
                <span class="label" v-for="(item01, index01) in item.promotions">{{item01}}</span>
              </block>
            </div>
          </div>
          <div class="item-more" v-if="memberData.hourRooms && memberData.hourRooms.length > count1" @click="hourMore(1)">查看剩余房型</div>
        </div>
     <!--   <div class="div-items">
          <div class="item" v-for="(item,index) in memberData.dayRooms" :index="index" :key="key" v-if="index < count1">
            <span class="span-1">{{item.summary[0]}} {{item.summary[1]}} {{item.summary[2]}}</span>
            <span class="span-1-1">{{item.summary[3]}}</span>
            <span class="span-2" v-if="item.remain>=0" :class="item.summary.length>3 ? 'span-2-2' : ''">剩余{{item.remain}}间</span>
            <span class="span-3"><i>¥</i>{{item.realPrice / 100}}</span>
            <span class="span-4">已省{{item.savedPrice/100}}元</span>
            <div>
              <span v-if="item.promotions[0]">{{item.promotions[0]}}</span>
              <span v-if="item.promotions[1]">{{item.promotions[1]}}</span>
            </div>
            <a class="a1" href="" @click="showDetail(index, 'day')">
              <image :src="item.images[0]"/>
            </a>
            <a class="a2" href="" @click="showDetail(index, 'day')">{{item.name}} ></a>
            <a v-if="item.remain == 0" class="a3 a3-no" href="">满房</a>
            <a class="a3" href="" @click="gotoPay(item, '1')">立即预定</a>
            <div class="item-sp"></div>
          </div>
          <div class="item-more" v-if="memberData.dayRooms && memberData.dayRooms.length > count1" @click="dayMore(1)">查看剩余房型</div>
        </div>-->
      </div>
      <div class="sp"></div>

      <div v-if="defaultSearchType == 'day'" class="div-4">
        <div class="div-title">
          <span class="span-1"></span>
          <span class="span-2"><b>入住</b>{{hourData.enter}}</span>
          <span class="span-3"><b>离开</b>{{hourData.leave}}</span>
          <span class="span-4">点击修改时间</span>
          <a href="" @click="modHour">共{{hourData.total}} ></a>
          <hourSelect @onOkSelected="onOkSelected" v-if="hourShow" :hourShow="hourShow" :startTime="hourData.enter" :endTime="hourData.leave"></hourSelect>
        </div>
        <div class="houseWrap">
          <div class="houseBlock" v-for="(item,index) in memberData.hourRooms" :index="index" :key="key" v-if="index < count1">
            <div class="infoBlock">
              <div class="leftBlock">
                <image :src="item.images[0]" mode="aspectFill" @click="showDetail(index, 'hour')"/>
              </div>
              <div class="rightBlock">
                <div class="houseName" @click="showDetail(index, 'hour')">{{item.name}} ></div>
                <div class="houseDesc">{{item.summary[0]}} {{item.summary[1]}} {{item.summary[2]}} </div>
                <div class="remain" v-if="item.remain>=0">剩余{{item.remain}}间</div>
                <div class="buyBlock">
                  <div class="moneyBlock">
                    <div class="realPrice"><i>¥</i>{{item.realPrice / 100}}</div>
                    <div class="savedPrice">已省{{item.savedPrice/100}}元</div>
                  </div>
                  <a v-if="item.remain == 0 || !item.remain" class="btnFull" href="">满房</a>
                  <a v-else class="btnOrder" href="" @click="gotoPay(item, '0')">立即预定</a>
                </div>
              </div>
            </div>
            <div class="labelsBlock">
              <!--<span class="label" v-if="hotelData.maxDiscountOfGrade">会员{{hotelData.maxDiscountOfGrade}}折</span>-->
              <block v-if="item.promotions">
                <span class="label" v-for="(item01, index01) in item.promotions">{{item01}}</span>
              </block>
            </div>
          </div>
          <div class="item-more" v-if="memberData.hourRooms && memberData.hourRooms.length > count1" @click="hourMore(1)">查看剩余房型</div>
        </div>
      </div>
      <div v-if="defaultSearchType == 'hour'" class="div-5">
        <div class="div-title">
          <span class="span-1"></span>
          <span class="span-2"><b>入住</b>{{dayData.enter}}</span>
          <span class="span-3"><b>离开</b>{{dayData.leave}}</span>
          <span class="span-4">点击修改时间</span>
          <a href="" @click="modTime">共{{dayData.total}} ></a>
          <timeSelect @onOkSelected="onOkSelected" v-if="tiemShow" :tiemShow="tiemShow"  :startTime="dayData.enter" :endTime="dayData.leave"></timeSelect>
        </div>
        <div class="houseWrap">
          <div class="houseBlock" v-for="(item,index) in memberData.dayRooms" :index="index" :key="key" v-if="index < count1">
            <div class="infoBlock">
              <div class="leftBlock">
                <image :src="item.images[0]" mode="aspectFill" @click="showDetail(index, 'hour')"/>
              </div>
              <div class="rightBlock">
                <div class="houseName" @click="showDetail(index, 'hour')">{{item.name}} ></div>
                <div class="houseDesc">{{item.summary[0]}} {{item.summary[1]}} {{item.summary[2]}} </div>
                <div class="remain" v-if="item.remain>=0">剩余{{item.remain}}间</div>
                <div class="buyBlock">
                  <div class="moneyBlock">
                    <div class="realPrice"><i>¥</i>{{item.realPrice / 100}}</div>
                    <div class="savedPrice">已省{{item.savedPrice/100}}元</div>
                  </div>
                  <a v-if="item.remain == 0 || !item.remain" class="btnFull" href="">满房</a>
                  <a v-else class="btnOrder" href="" @click="gotoPay(item, '1')">立即预定</a>
                </div>
              </div>
            </div>
            <div class="labelsBlock">
              <!--<span class="label" v-if="hotelData.maxDiscountOfGrade">会员{{hotelData.maxDiscountOfGrade}}折</span>-->
              <block v-if="item.promotions">
                <span class="label" v-for="(item01, index01) in item.promotions">{{item01}}</span>
              </block>
            </div>
          </div>
          <div class="item-more" v-if="memberData.hourRooms && memberData.hourRooms.length > count1" @click="hourMore(1)">查看剩余房型</div>
        </div>
        <!--   <div class="div-items">
             <div class="item" v-for="(item,index) in memberData.dayRooms" :index="index" :key="key" v-if="index < count1">
               <span class="span-1">{{item.summary[0]}} {{item.summary[1]}} {{item.summary[2]}}</span>
               <span class="span-1-1">{{item.summary[3]}}</span>
               <span class="span-2" v-if="item.remain>=0" :class="item.summary.length>3 ? 'span-2-2' : ''">剩余{{item.remain}}间</span>
               <span class="span-3"><i>¥</i>{{item.realPrice / 100}}</span>
               <span class="span-4">已省{{item.savedPrice/100}}元</span>
               <div>
                 <span v-if="item.promotions[0]">{{item.promotions[0]}}</span>
                 <span v-if="item.promotions[1]">{{item.promotions[1]}}</span>
               </div>
               <a class="a1" href="" @click="showDetail(index, 'day')">
                 <image :src="item.images[0]"/>
               </a>
               <a class="a2" href="" @click="showDetail(index, 'day')">{{item.name}} ></a>
               <a v-if="item.remain == 0" class="a3 a3-no" href="">满房</a>
               <a class="a3" href="" @click="gotoPay(item, '1')">立即预定</a>
               <div class="item-sp"></div>
             </div>
             <div class="item-more" v-if="memberData.dayRooms && memberData.dayRooms.length > count1" @click="dayMore(1)">查看剩余房型</div>
           </div>-->
      </div>
      <div class="sp"></div>
      <div class="note">
        <h3>入住须知</h3>
        <div v-if="hotelData.knowledges">
          宠物：{{hotelData.knowledges[0]}}<br/>
          外宾：{{hotelData.knowledges[1]}}<br/>
          膳食：{{hotelData.knowledges[2]}}<br/>
          停车：{{hotelData.knowledges[3]}}

        </div>
      </div>
      <div class="room-detail" v-if="isShow">
        <div class="bg" @click="closeDetail"></div>
        <div class="detail-content">
          <div class="title">{{detailData.name}}</div>
          <a href="" class="close" @click="closeDetail">X</a>
          <div class="imgs">
             <swiper
                v-if="detailData && detailData.images"
                indicator-dots="true"
                indicator-color="#ffffff"
                indicator-active-color="#0878FF"
                autoplay="false"

                :duration="duration"
              >
              <swiper-item v-for="(item,index) in detailData.images" :key="index">
                <image :src="item" class="slide-image"/>
              </swiper-item>
            </swiper>
          </div>
          <div class="infos">
            <span class="span-1"><b>面积</b>{{detailData.summary[0]}}</span>
            <span class="span-2"><b>餐食</b>{{detailData.breakfast}}</span>
            <span class="span-3" ><b>窗户</b>{{detailData.windowCount >0 ? '有':'无'}}</span>
            <span class="span-4" v-if="detailData.allowSmoking==0?true:''"><b>吸烟</b>禁止吸烟</span>
            <span class="span-4" v-else><b>吸烟</b>允许吸烟</span>
            <span class="span-5"><b>可住</b>{{detailData.bedCount}}人</span>
            <span class="span-6"><b>床型</b>{{detailData.summary[1]}}</span>
            <span class="span-7" v-if="detailData.indieToilet==0?true:''"><b>卫浴</b>有独立卫生间</span>
            <span class="span-7" v-else><b>卫浴</b>无独立卫生间</span>
            <span class="span-8"><b>宽带</b>{{detailData.wifi}}</span>
            <span class="span-9">
              <b>客房设施</b>
              <b class="b1">{{detailData.utilities}}</b>
            </span>
          </div>
          <div class="detail-sp"></div>
          <div class="price">
            <b>¥</b>
            <span class="span-1">{{detailData.realPrice / 100}}</span>
            <span class="span-2">已省{{detailData.savedPrice/100}}元</span>
            <a class="apply" href="" @click="gotoPay(detailData, detailType)">微信支付</a>
          </div>
        </div>
      </div>
    </scroll-view>
  </div>
</template>
<script>
import timeSelect from "../../components/timeSelect";
import hourSelect from "../../components/hourSelect";
export default {
  components: { timeSelect, hourSelect },
  data() {
    return {
      interval: 1500, //轮播图切换时间
      duration: 500, //轮播动画过度时间
      hotelData: {
        name: "",
        address: "",
        address: {
          city: "",
          district: "",
          addressDetail: ""
        },
        phone: "",
        promotionToday: []
      },
      memberData: {
        dayRooms: "",
        hourRooms: ""
      },
      defaultSearchType: "day", //酒店首页的查询方式，默认整租
      count1: 5,
      count2: 1,
      warning: "",
      isShow: false,
      tiemShow: false,
      hourShow: false,
      detailData: {
        images: [],
        summary: [],
        realPrice: 0,
        savedPrice: 0
      },
      detailType: "0",
      //        type: '',
      dayData: {
        enter: "",
        leave: "",
        week1: "",
        week2: "",
        enter1: "",
        leave1: "",
        total1: "",
        total: "0整日"
      },
      hourData: {
        enter: "",
        leave: "",
        week1: "",
        week2: "",
        enter1: "",
        leave1: "",
        total1: "",
        total: "0小时"
      },
      backCouponArr: [],
      knowledges: ""
    };
  },
  methods: {
    queryCouponList() {
      const me = this;
      wx.request({
        url: this.globalData.globalUrl + "/coupon/list",
        data: {
          hotelId: wx.getStorageSync("hotelId"),
          type: 1
        },
        header: {
          "content-type": "application/json",
          memberId: wx.getStorageSync("memberId")
        },
        success(res) {
          if (res.data.data.list) {
            let backCouponArr = res.data.data.list;
            let maxLength = backCouponArr.length > 3 ? 3 : backCouponArr.length;
            //暂时取前三个数据
            for (let i = 0; i < maxLength; i++) {
              if (backCouponArr[i].barriers == -1) {
                me.backCouponArr.push({
                  class: "a" + (i + 2),
                  desc: "无门槛" + backCouponArr[i].money
                });
              } else {
                me.backCouponArr.push({
                  class: "a" + (i + 2),
                  desc:
                    "满" +
                    backCouponArr[i].barriers +
                    "减" +
                    backCouponArr[i].money
                });
              }
            }
          }
        }
      });
    },
    toCenter() {
      wx.switchTab({
        // url: "/pages/userCenter/main"
        // url:"/pages/hotelMember/main"
      });
    },
    modTime() {
      this.defaultSearchType = "day";
      this.tiemShow = true;
      this.hourShow = false;
    },
    modHour() {
      this.defaultSearchType = "hour";
      this.timeShow = false;
      this.hourShow = true;
    },
    onOkSelected(res) {
      this.tiemShow = false;
      this.hourShow = false;
      if (this.defaultSearchType === "day") {
        this.dayData = res;
        wx.setStorageSync("dayStart", res.enter + "12:00");
        wx.setStorageSync("dayStart1", res.enter1);
        wx.setStorageSync("dayEnd", res.leave + "12:00");
        wx.setStorageSync("dayEnd1", res.leave1);
        wx.setStorageSync("dayTotal", res.total);
        wx.setStorageSync("dayTotal1", res.total1);
        wx.setStorageSync("dayWeek1", res.week1);
        wx.setStorageSync("dayWeek2", res.week2);
        wx.setStorageSync("dayStartTime", res.enter1);
        wx.setStorageSync("dayEndTime", res.leave1);
      } else {
        this.hourData = res;
        console.log(res);
        wx.setStorageSync("hourStart", res.enter);
        wx.setStorageSync("hourStart1", res.enter1);
        wx.setStorageSync("hourEnd", res.leave);
        wx.setStorageSync("hourEnd1", res.leave1);
        wx.setStorageSync("hourTotal", res.total);
        wx.setStorageSync("hourTotal1", res.total1);
        wx.setStorageSync("hourWeek1", res.week1);
        wx.setStorageSync("hourWeek2", res.week2);
      }
      console.log("timeRes",res);
      const me = this;
      /*let duration = this.defaultSearchType === "day" ? wx.getStorageSync("dayTotal") : wx.getStorageSync("hourTotal");
      duration = duration.slice(0,-2)*1;*/
      wx.request({
        url: this.globalData.globalUrl + "/hotel/rooms",
        data: {
          hotelId: wx.getStorageSync("hotelId"),
          type: this.defaultSearchType,
          dayStartTime: wx.getStorageSync("dayStartTime"),
          dayEndTime: wx.getStorageSync("dayEndTime"),
          dayDuration:wx.getStorageSync("dayTotal1"),
          hourDuration: wx.getStorageSync("hourTotal1"),
          dayStart: res.enter1.split(" ")[0],
          dayEnd:
            this.defaultSearchType === "day" ? res.leave1.split(" ")[0] : res.leave1.split(" ")[0],
          hourStart:
            this.defaultSearchType === "hour"
              ? res.enter1.split(" ")[1].split(":")[0]
              : wx.getStorageSync("hourStartTime").split(" ")[1].split(":")[0],
          hourEnd:
            this.defaultSearchType === "hour"
              ? res.leave1.split(" ")[1].split(":")[0]
              : wx.getStorageSync("hourStartTime").split(" ")[1].split(":")[0],
        },
        header: {
          "content-type": "application/json",
          memberId: wx.getStorageSync("memberId")
        },
        success(res) {
          
          me.memberData = res.data.data;
        }
      });
    },
    closeDetail() {
      this.isShow = false;
    },
    showDetail(index, type) {
      this.isShow = true;
      if (type === "hour") {
        this.detailData = this.memberData.hourRooms[index];
        this.detailType = "0";
      } else {
        this.detailData = this.memberData.dayRooms[index];
        this.detailType = "1";
      }
    },
    getHotel() {
      const me = this;
      wx.request({
        url:
          this.globalData.globalUrl +
          `/hotel/hotels/${wx.getStorageSync("hotelId")}`,
        success(res) {
          me.hotelData = res.data.data;
          if (res.data.data && res.data.data.name) {
            wx.setStorageSync("hotelname", res.data.data.name);
            wx.setStorageSync("address", res.data.data.address);
          }
        }
      });
    },
    getData() {
      const me = this;
      /* let duration = this.defaultSearchType === "day" ? wx.getStorageSync("dayTotal") : wx.getStorageSync("hourTotal");
      duration = duration.slice(0,-2)*1;
      console.log("duration",duration)*/
      console.log("defaultSearchType");
      console.log(me.defaultSearchType);
      console.log("dayStart",wx.getStorageSync("dayStart"));
      wx.request({
        url: this.globalData.globalUrl + "/hotel/rooms",
        data: {
          hotelId: wx.getStorageSync("hotelId"),
          type: this.defaultSearchType,
          dayStartTime: wx.getStorageSync("dayStartTime"),
          dayEndTime: wx.getStorageSync("dayEndTime"),
          dayDuration:wx.getStorageSync("dayTotal1"),
          hourDuration: wx.getStorageSync("hourTotal1"),
          /*  duration:duration,*/
          dayStart:
            this.defaultSearchType === "day"
              ? wx.getStorageSync("dayStartTime")
              : wx.getStorageSync("hourStartTime").split(" ")[0],
          dayEnd:
            this.defaultSearchType === "day"
              ? wx.getStorageSync("dayEndTime")
              : wx.getStorageSync("hourEndTime").split(" ")[0],
          hourStart:
            this.defaultSearchType === "hour"
              ? wx
                  .getStorageSync("hourStartTime")
                  .split(" ")[1]
                  .split(":")[0]
              : wx
                .getStorageSync("hourStartTime")
                .split(" ")[1]
                .split(":")[0],
          hourEnd:
            this.defaultSearchType === "hour"
              ? wx
                  .getStorageSync("hourEndTime")
                  .split(" ")[1]
                  .split(":")[0]
              : wx
                .getStorageSync("hourEndTime")
                .split(" ")[1]
                .split(":")[0]
        },
        header: {
          "content-type": "application/json",
          memberId: wx.getStorageSync("memberId")
        },
        success(res) {
          me.memberData = res.data.data;
        }
      });
      wx.request({
        url:
          this.globalData.globalUrl +
          `/setup/setups/collect/${"checking.in.warning"}`,
        header: {
          "content-type": "application/json",
          memberId: wx.getStorageSync("memberId")
        },
        success(res) {
          me.warning = res.data;
        }
      });
    },
    gotoPhone(phonenum) {
      wx.makePhoneCall({
        phoneNumber: phonenum,
        success: function() {
          console.log("拨打电话成功");
        },
        fail: function() {
          console.log("拨打电话失败");
        }
      });
    },
    goMap(address) {
      console.log("address", address);
      let latitude = address.lat;
      let longitude = address.lng;
      wx.openLocation({
        latitude,
        longitude,
        scale: 18,
        name:
          address.province +
          address.city +
          address.district +
          address.addressDetail
      });
    },
    gotoPay(item, type) {
      let hotelId = wx.getStorageSync("hotelId");

      //        let type = this.defaultSearchType === 'day' ? 1 : 0
      let startTime = "";
      let endTime = "";
      let duration = "";
      let enter = "";
      let leave = "";
      let total = "";
      if (type === "1") {
        startTime = this.dayData.enter1;
        endTime = this.dayData.leave1;
        duration = this.dayData.total1;
        enter = this.dayData.enter1;
        leave = this.dayData.leave1;
        total = this.dayData.total1;
      } else {
        startTime = this.hourData.enter1;
        endTime = this.hourData.leave1;
        duration = this.hourData.total1;
        enter = this.hourData.enter1;
        leave = this.hourData.leave1;
        total = this.hourData.total1;
      }
      /*wx.setStorageSync("enter", item.name);
      wx.setStorageSync("leave", item.name);
      wx.setStorageSync("total", item.name);*/
      let roomNumber = 1;
      let roomFee = item.realPrice;
      let memberDiscount = item.memberDiscount;
      //        let memberDiscount = 85
      let cardDeduction = item.cardDeduction;
      //        let cardDeduction = 0
      let provinceAmount = item.remain;
      let roomId = item.id;
      let roomTypeId = item.type;
      //        let roomTypeId = 1
      //房型
      wx.setStorageSync("orderType", type);
      wx.setStorageSync("roomNumber", roomNumber);
      wx.setStorageSync("roomFee", roomFee);
      wx.setStorageSync("memberDiscount", memberDiscount);
      wx.setStorageSync("cardDeduction", cardDeduction);
      wx.setStorageSync("provinceAmount", provinceAmount);
      wx.setStorageSync("roomId", roomId);
      wx.setStorageSync("roomTypeId", roomTypeId);
      wx.setStorageSync("enter", enter);
      wx.setStorageSync("leave", leave);
      wx.setStorageSync("total", total);
      wx.setStorageSync("startTime", startTime);
      wx.setStorageSync("endTime", endTime);
      wx.setStorageSync("duration", duration);
       wx.setStorageSync("roomName", item.name);
      //房间剩余数
      wx.setStorageSync("roomRemain", item.remain);
      //房型map
      // 1大床房、2标准间、3家庭房、4浴缸房、5影院房等
      let roomTypeMap = {
        "1": "大床房",
        "2": "标准间",
        "3": "家庭房",
        "4": "浴缸房",
        "5": "影院房"
      };
      wx.setStorageSync("roomType", roomTypeMap[roomTypeId]);
      const url = "/pages/orderAccounts/main";
      wx.navigateTo({
        url: url
      });
    },
    hourMore(count) {
      this["count" + count] = 10000;
      //        this.count1 = 10000
    },
    dayMore(count) {
      this["count" + count] = 10000;
      //        this.count2 = 10000
    }
  },
  created() {
    this.queryCouponList();
  },
  onLoad(option) {
    let _that = this;
    _that.defaultSearchType = option.type;
    this.dayData = {
      enter: wx.getStorageSync("dayStart"),
      leave: wx.getStorageSync("dayEnd"),
      week1: wx.getStorageSync("dayWeek1"),
      week2: wx.getStorageSync("dayWeek2"),
      enter1: wx.getStorageSync("dayStart1"),
      leave1: wx.getStorageSync("dayEnd1"),
      total1: wx.getStorageSync("dayTotal1"),
      total: wx.getStorageSync("dayTotal")
    };
    this.hourData = {
      enter: wx.getStorageSync("hourStart"),
      leave: wx.getStorageSync("hourEnd"),
      week1: wx.getStorageSync("hourWeek1"),
      week2: wx.getStorageSync("hourWeek2"),
      enter1: wx.getStorageSync("hourStart1"),
      leave1: wx.getStorageSync("hourEnd1"),
      total1: wx.getStorageSync("hourTotal1"),
      total: wx.getStorageSync("hourTotal")
    };
    this.getHotel();
    this.getData();
    this.queryCouponList();
  },
  onShow() {
    // this.memberData = {
    //   dayRooms: "",
    //   hourRooms: ""
    // };
    this.getData();
  },
  onHide() {
    let that = this;
    that.timeShow = false;
    that.hourShow = false;
  },
  onUnload() {
    let that = this;
    that.timeShow = false;
    that.hourShow = false;
  }
};
</script>
<style scoped lang="less">
.roomList {
  background: #fff;
}
.sp {
  width: 100%;
  height: 20rpx;
  background: #f6f6f6;
}
.div-1 {
  position: relative;
  width: 100%;
  height: 210rpx;
  font-size: 24rpx;
  h3 {
    position: absolute;
    top: 50rpx;
    left: 30rpx;
    width: 500rpx;
    height: 36rpx;
    line-height: 36rpx;
    font-size: 36rpx;
    color: #333;
  }
  > div {
    position: absolute;
    top: 114rpx;
    left: 30rpx;
    padding-left: 60rpx;
    height: 70rpx;
    width: 400rpx;
    display: flex;
    flex-direction: column;
    background: url("http://img.rainfn.com/qfs_p_0306_room-site.png") 10rpx
      center no-repeat;
    background-size: 29rpx 35rpx;
    background-color: #eeeeee;
    border-radius: 10rpx;
    padding: 8rpx 10rpx;
    span {
      color: #999999;
      display: block;
      margin-left: 40rpx;
      width: 360rpx;
      line-height: 30rpx;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }
  }
  > a {
    position: absolute;
    top: 114rpx;
    right: 40rpx;
    width: 150rpx;
    height: 70rpx;
    display: flex;
    align-items: center;
    line-height: 30rpx;
    vertical-align: middle;
    justify-content: flex-end;
    color: #999999;
    text-align: right;
    background: url("http://img.rainfn.com/qfs_p_0306_user-icon6-1.png") 10rpx
      center no-repeat;
    background-size: 32rpx 28rpx;
    background-color: #eeeeee;
    border-radius: 10rpx;
    padding: 8rpx 30rpx 8rpx 10rpx;
  }
}
.div-2 {
  position: relative;
  width: 100%;
  height: 307rpx;
  > a {
    position: absolute;
    top: 40rpx;
    width: 330rpx;
    height: 120rpx;
    border-radius: 8rpx;
  }
  .a1 {
    left: 30rpx;
    background: url("http://img.rainfn.com/qfs_p_0306_room-big-1.png") 0 0
      no-repeat;
    background-size: 330rpx 120rpx;
  }
  .a2 {
    right: 30rpx;
    background: url("http://img.rainfn.com/qfs_p_0306_room-big-2.png") 0 0
      no-repeat;
    background-size: 330rpx 120rpx;
  }
  > div {
    position: absolute;
    bottom: 40rpx;
    left: 30rpx;
    padding-left: 80rpx;
    width: 700rpx;
    height: 76rpx;
    background: url("http://img.rainfn.com/qfs_p_0306_room-icon.png") 0 center
      no-repeat;
    background-size: 65rpx 80rpx;
    span {
      display: block;
      width: 100%;
      height: 38rpx;
      line-height: 38rpx;
      font-size: 22rpx;
      color: #999;
    }
  }
}
.div-3 {
  position: relative;
  width: 100%;
  height: 210rpx;
  h3 {
    position: absolute;
    top: 48rpx;
    left: 30rpx;
    width: 400rpx;
    height: 34rpx;
    line-height: 34rpx;
    color: #333;
  }
  a {
    position: absolute;
  }
  .a1 {
    top: 54rpx;
    right: 30rpx;
    width: 200rpx;
    height: 24rpx;
    line-height: 24rpx;
    text-align: right;
    color: #999;
    font-size: 24rpx;
  }
  .a2,
  .a3,
  .a4 {
    box-sizing: border-box;
    top: 110rpx;
    padding-left: 60rpx;
    width: 210rpx;
    height: 60rpx;
    line-height: 60rpx;
    font-size: 28rpx;
    color: #fff;
    background: url("http://img.rainfn.com/qfs_p_0306_room-coupon.png") 0 0
      no-repeat;
    background-size: 210rpx 60rpx;
  }
  .a2 {
    left: 30rpx;
  }
  .a3 {
    left: 270rpx;
  }
  .a4 {
    left: 510rpx;
  }
}
.div-4 {
  box-sizing: border-box;
  padding-top: 40rpx;
  .div-title .span-1 {
    background: url("http://img.rainfn.com/qfs_p_0306_room-hour.png") center
      center no-repeat;
    background-size: 80rpx 80rpx;
  }
}
.div-5 {
  box-sizing: border-box;
  padding-top: 40rpx;
  .div-title .span-1 {
    background: url("http://img.rainfn.com/qfs_p_0306_room-day.png") center
      center no-repeat;
    background-size: 80rpx 80rpx;
  }
}
.div-title {
  position: relative;
  margin: 0 auto;
  width: 690rpx;
  height: 130rpx;
  border-radius: 8rpx;
  box-shadow: 0 0 16rpx #f1f1f1;
  .span-1 {
    position: absolute;
    top: 25rpx;
    width: 130rpx;
    height: 80rpx;
    border-right: 1px solid #999;
  }
  .span-2,
  .span-3 {
    position: absolute;
    left: 180rpx;
    width: 350rpx;
    height: 30rpx;
    line-height: 30rpx;
    font-size: 30rpx;
    color: #666;
    b {
      display: inline-block;
      color: #999;
    }
  }
  .span-2 {
    top: 28rpx;
  }
  .span-3 {
    top: 73rpx;
  }
  .span-4 {
    position: absolute;
    bottom: 35rpx;
    right: 28rpx;
    width: 140rpx;
    height: 24rpx;
    line-height: 24rpx;
    color: #999;
    font-size: 20rpx;
  }
  > a {
    position: absolute;
    bottom: 64rpx;
    right: 28rpx;
    width: 160rpx;
    height: 30rpx;
    text-align: right;
    line-height: 30rpx;
    font-size: 30rpx;
    color: #35abfe;
  }
}

.div-items {
  .item {
    position: relative;
    margin: 0 auto;
    width: 690rpx;
    height: 316rpx;
    > span,
    > div,
    .a1,
    .a2,
    .a3 {
      position: absolute;
    }
    .item-sp {
      margin: 0 auto !important;
      width: 690rpx !important;
      height: 10rpx !important;
      background: #f1f1f1 !important;
      position: absolute !important;
      bottom: -12rpx !important;
      left: 0rpx !important;
    }
    .a1 {
      top: 30rpx;
      left: 30rpx;
      width: 314rpx;
      height: 200rpx;
      border-radius: 8rpx;
      image {
        width: 314rpx;
        height: 200rpx;
        border-radius: 8rpx;
      }
    }
    .a2 {
      top: 38rpx;
      left: 374rpx;
      width: 350rpx;
      height: 32rpx;
      line-height: 32rpx;
      font-size: 32rpx;
      color: #333;
    }
    .a3 {
      bottom: 84rpx;
      right: 30rpx;
      width: 130rpx;
      height: 50rpx;
      line-height: 50rpx;
      text-align: center;
      font-size: 24rpx;
      color: #fff;
      background: #49bfef;
      border-radius: 25rpx;
    }
    .a3-no {
      background: #c1c1c1;
    }
    .span-1 {
      top: 80rpx;
      left: 374rpx;
      width: 320rpx;
      height: 24rpx;
      line-height: 24rpx;
      font-size: 24rpx;
      color: #999;
    }
    .span-1-1 {
      top: 105rpx;
      left: 374rpx;
      width: 320rpx;
      height: 24rpx;
      line-height: 24rpx;
      font-size: 24rpx;
      color: #999;
    }
    .span-2 {
      top: 113rpx;
      left: 374rpx;
      width: 300rpx;
      height: 24rpx;
      line-height: 24rpx;
      font-size: 24rpx;
      color: #49bfef;
    }
    .span-2-2 {
      top: 131rpx;
      left: 374rpx;
      width: 300rpx;
      height: 24rpx;
      line-height: 24rpx;
      font-size: 24rpx;
      color: #49bfef;
    }
    .span-3 {
      top: 158rpx;
      left: 374rpx;
      width: 200rpx;
      height: 34rpx;
      line-height: 34rpx;
      color: #f02b35;
      i {
        display: inline-block;
        font-size: 20rpx;
      }
    }
    .span-4 {
      top: 200rpx;
      left: 374rpx;
      width: 200rpx;
      height: 22rpx;
      line-height: 22rpx;
      font-size: 22rpx;
      color: #f02b35;
    }
    > div {
      position: absolute;
      bottom: 30rpx;
      left: 30rpx;
      width: 600rpx;
      height: 36rpx;
      span {
        float: left;
        display: inline-block;
        padding: 0 10rpx;
        margin-right: 10rpx;
        height: 36rpx;
        line-height: 36rpx;
        font-size: 24rpx;
        color: #49bfef;
        border: 1px solid #49bfef;
        border-radius: 4rpx;
      }
    }
  }
  .item-more {
    margin: 0 auto 30rpx auto;
    width: 200rpx;
    height: 100rpx;
    line-height: 100rpx;
    font-size: 26rpx;
    background: url("http://img.rainfn.com/qfs_p_0306_down.png") right center
      no-repeat;
    background-size: 21rpx 12rpx;
  }
}
.note {
  margin: 0 auto;
  width: 690rpx;
  font-size: 26rpx;
  color: #666;
  padding-bottom: 60rpx;
  h3 {
    margin: 30rpx 0 20rpx 0;
    height: 44rpx;
    line-height: 44rpx;
    font-size: 32rpx;
    color: #333;
  }
}
.room-detail {
  position: fixed;
  top: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  .bg {
    width: 100%;
    height: 100%;
    background: #000;
    opacity: 0.6;
    z-index: 2;
  }
  .detail-content {
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 1000rpx;
    background: #fff;
    z-index: 2;
    border-top-left-radius: 16rpx;
    border-top-right-radius: 16rpx;
    .close {
      display: block;
      position: absolute;
      top: 20rpx;
      right: 20rpx;
      font-size: 30rpx;
      color: #666;
    }
    .title {
      box-sizing: border-box;
      padding: 0 30rpx;
      width: 100%;
      height: 80rpx;
      line-height: 80rpx;
      font-size: 30rpx;
      color: #000;
    }
    .imgs {
      width: 100%;
      height: 400rpx;
      image {
        width: 100%;
        height: 100%;
      }
    }
    .infos {
      position: relative;
      width: 100%;
      height: 390rpx;
      span {
        position: absolute;
        font-size: 26rpx;
        width: 300rpx;
        height: 26rpx;
        line-height: 26rpx;
        color: #999;
        b {
          display: inline-block;
          margin-right: 20rpx;
          color: #666;
        }
      }
      .span-1 {
        top: 47rpx;
        left: 30rpx;
      }
      .span-2 {
        top: 108rpx;
        left: 30rpx;
      }
      .span-3 {
        top: 164rpx;
        left: 30rpx;
      }
      .span-4 {
        top: 223rpx;
        left: 30rpx;
      }
      .span-5 {
        top: 47rpx;
        left: 376rpx;
      }
      .span-6 {
        top: 108rpx;
        left: 376rpx;
      }
      .span-7 {
        top: 164rpx;
        left: 376rpx;
      }
      .span-8 {
        top: 223rpx;
        left: 376rpx;
      }
      .span-9 {
        top: 286rpx;
        left: 30rpx;
        width: 690rpx;
        b {
          float: left;
        }
        .b1 {
          width: 500rpx;
          color: #999;
          line-height: 30rpx;
        }
      }
    }
    .detail-sp {
      width: 100%;
      height: 20rpx;
      background-image: linear-gradient(to bottom, #fff, #f1f1f1);
    }
    .price {
      position: relative;
      width: 100%;
      height: 120rpx;
      b {
        position: absolute;
        bottom: 30rpx;
        left: 30rpx;
        width: 24rpx;
        height: 24rpx;
        line-height: 24rpx;
        font-size: 24rpx;
        color: #e06064;
      }
      .span-1 {
        position: absolute;
        bottom: 30rpx;
        left: 54rpx;
        width: 180rpx;
        height: 38rpx;
        line-height: 38rpx;
        font-size: 38rpx;
        color: #e06064;
      }
      .span-2 {
        position: absolute;
        bottom: 30rpx;
        left: 234rpx;
        padding: 0 6rpx;
        height: 26rpx;
        line-height: 26rpx;
        font-size: 20rpx;
        border: 1px solid #e06064;
        color: #e06064;
        border-radius: 4rpx;
      }
      a {
        position: absolute;
        top: 20rpx;
        right: 30rpx;
        width: 336rpx;
        height: 80rpx;
        line-height: 80rpx;
        text-align: center;
        background: #35abfe;
        color: #fff;
        font-size: 38rpx;
        border-radius: 8rpx;
      }
    }
  }
}
.item-more {
  margin: 0 auto 30rpx auto;
  width: 200rpx;
  height: 100rpx;
  line-height: 100rpx;
  font-size: 26rpx;
  background: url("http://img.rainfn.com/qfs_p_0306_down.png") right center
    no-repeat;
  background-size: 21rpx 12rpx;
}
.houseWrap {
  .houseBlock {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    .infoBlock {
      width: 690rpx;
      flex: none;
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      .leftBlock {
        flex: none;
        width: 314rpx;
        image {
          width: 314rpx;
          height: 200rpx;
          border-radius: 8rpx;
        }
      }
      .rightBlock {
        flex: 1;
        margin-left: 20rpx;
        display: flex;
        justify-content: space-between;
        flex-direction: column;
        .houseName {
          line-height: 32rpx;
          font-size: 32rpx;
          color: #333;
        }
        .houseDesc {
          line-height: 24rpx;
          font-size: 24rpx;
          color: #999;
          margin: 12rpx 0;
        }
        .remain {
          line-height: 24rpx;
          font-size: 24rpx;
          color: #49bfef;
        }
        .buyBlock {
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          .moneyBlock {
            display: flex;
            flex-direction: column;
            .realPrice {
              line-height: 34rpx;
              color: #f02b35;
              i {
                display: inline-block;
                font-size: 20rpx;
              }
            }
            .savedPrice {
              line-height: 22rpx;
              font-size: 22rpx;
              color: #f02b35;
            }
          }
          .btnFull {
            width: 130rpx;
            height: 50rpx;
            line-height: 50rpx;
            text-align: center;
            font-size: 24rpx;
            color: #fff;
            background: #c1c1c1;
            border-radius: 25rpx;
          }
          .btnOrder {
            width: 130rpx;
            height: 50rpx;
            line-height: 50rpx;
            text-align: center;
            font-size: 24rpx;
            color: #fff;
            background: #49bfef;
            border-radius: 25rpx;
          }
        }
      }
    }
  }
  .labelsBlock {
    width: 690rpx;
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    align-items: center;
    min-height: 60rpx;
    flex-wrap: wrap;
    margin-bottom: 20rpx;
    .label {
      height: 36rpx;
      font-size: 24rpx;
      color: #49bfef;
      border: 2rpx solid #49bfef;
      border-radius: 4rpx;
      padding: 0 6rpx;
      margin-right: 10rpx;
    }
  }
}
</style>
