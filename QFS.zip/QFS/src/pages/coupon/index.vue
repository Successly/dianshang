<template>
  <div class="couponCenter">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <section class="section">
        <div class="tabs">
          <span v-for="(item,index) in titles" :key="index" :index="index" class="span1" :class="activeIndex === index ? 'active' : ''" @click="goSelect(index)">{{item.title}}</span>
        </div>
        <div class="canUse" v-if="activeIndex === 0">
          <div class="card-box" v-for="(card,index) in cards" :key="index" :index="index">
            <div class="coupon-common coupon-box">
              <span class="span1">¥</span>
              <span class="span2">{{card.money}}</span>
              <span class="span3" v-if="card.barriers==-1?true :false">无门槛</span>
              <span class="span3" v-if="card.barriers>0?true :false">满{{card.barriers}}可用</span>
              <span class="span4">{{hotelname}}</span>
              <span class="span5" v-if="card.startTime&&card.startTime!=0" >有效期 {{card.startTime}}至{{card.endTime}}</span>
               <span v-else-if="card.expireDay" class="span5">有效期{{card.expireDay}}天</span>
              <span class="span6">所有用户均可领取</span>
              <div class="div-des">
                <a class="a1" href="" @click="showRange(index)">使用范围</a>
              </div>
            </div>
            <div class="coupon-des" :class="card.showTip == true ? '' : 'displaynone'">
                <span>可用整日租赁类型：
                  <label v-for="(room,inx) in card.wholeDayList" :key="inx">{{room.name}} </label>
                </span>
              <span>可用分时租赁类型：
                  <label v-for="(fenroom,idx) in card.timeSharingList" :key="idx">{{fenroom.name}} </label>
                </span>
            </div>
          </div>
        </div>
        <div class="canUse" v-if="activeIndex === 1">
          <div class="card-box" v-for="(card,index) in cards" :key="index" :index="index">
            <div class="coupon-common-used coupon-box">
              <span class="span1">¥</span>
              <span class="span2">{{card.money}}</span>
              <span class="span3" v-if="card.barriers==-1?true :false">无门槛</span>
              <span class="span3" v-if="card.barriers>0?true :false">满{{card.barriers}}可用</span>
              <span class="span4">{{hotelname}}</span>
              <span class="span5" v-if="card.startTime&&card.startTime!=0" >有效期 {{card.startTime}}至{{card.endTime}}</span>
               <span v-else-if="card.expireDay" class="span5">有效期{{card.expireDay}}天</span>
              <span class="span6">所有用户均可领取</span>
              <div class="div-des">
                <a class="a1" href="" @click="showRange(index)">使用范围</a>
              </div>
              <span class="img-used"></span>
            </div>
            <div class="coupon-des" :class="card.showTip == true ? '' : 'displaynone'">
                <span>可用整日租赁类型：
                  <label v-for="(room,inx) in card.wholeDayList" :key="inx">{{room.name}} </label>
                </span>
              <span>可用分时租赁类型：
                  <label v-for="(fenroom,idx) in card.timeSharingList" :key="idx">{{fenroom.name}} </label>
                </span>
            </div>
          </div>
        </div>
        <div class="canUse" v-if="activeIndex === 2">
          <div class="card-box" v-for="(card,index) in cards" :key="index" :index="index">
            <div class="coupon-member-expired coupon-box">
              <span class="span1">¥</span>
              <span class="span2">{{card.money}}</span>
              <span class="span3" v-if="card.barriers==-1?true :false">无门槛</span>
              <span class="span3" v-if="card.barriers>0?true :false">满{{card.barriers}}可用</span>
              <span class="span4">{{hotelname}}</span>
             <span class="span5" v-if="card.startTime&&card.startTime!=0" >有效期 {{card.startTime}}至{{card.endTime}}</span>
               <span v-else-if="card.expireDay" class="span5">有效期{{card.expireDay}}天</span>
              <span class="span6">所有用户均可领取</span>
              <div class="div-des">
                <a class="a1" href="" @click="showRange(index)">使用范围</a>
              </div>
              <span class="img-expired"></span>
            </div>
            <div class="coupon-des" :class="card.showTip == true ? '' : 'displaynone'">
                <span>可用整日租赁类型：
                  <label v-for="(room,inx) in card.wholeDayList" :key="inx">{{room.name}} </label>
                </span>
              <span>可用分时租赁类型：
                  <label v-for="(fenroom,idx) in card.timeSharingList" :key="idx">{{fenroom.name}} </label>
                </span>
            </div>
          </div>
        </div>
      </section>
    </scroll-view>
  </div>
</template>
<script>
export default {
  data() {
    return {
      hotelname: "",
      status: 0,
      cards: {},
      titles: [
        {
          title: "可使用"
        },
        {
          title: "已使用"
        },
        {
          title: "已过期"
        }
      ],
      activeIndex: 0
    };
  },
  methods: {
    DateFormat(date) {
      let newDate = new Date(date);
      var y = newDate.getFullYear();
      var m = newDate.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = newDate.getDate();
      d = d < 10 ? "0" + d : d;
      return y + "." + m + "." + d;
    },
    getData(status) {
      const me = this;
      me.cards = [];
      wx.request({
        url: this.globalData.globalUrl + "/coupon/member/receivedList",
        data: {
          hotelId: wx.getStorageSync("hotelId"),
          // memberId: 1,
          status: status
        },
        header: {
          "content-type": "application/json",
          memberId: wx.getStorageSync("memberId")
        },
        success(res) {
          if (res.data.data.list && res.data.data.list.length != 0) {
            me.cards = res.data.data.list;

            // 处理时间
            for (let i = 0; i < me.cards.length; i++) {
              if (me.cards[i].startTime && me.cards[i].endTime) {
                me.cards[i].startTime = me.DateFormat(me.cards[i].startTime);
                me.cards[i].endTime = me.DateFormat(me.cards[i].endTime);
              }
              me.cards[i].showTip = false;
            }
          } else {
            wx.showToast({
              title: "没有优惠券",
              icon: "none",
              duration: 2000
            });
            // console.log()
          }
        }
      });
    },
    goSelect(index) {
      const me = this;
      console.log(index);
      me.activeIndex = index;
      me.getData(me.activeIndex);
    },
    showRange(index) {
      let o = this.cards[index];
      o.showTip = !o.showTip;
      this.$set(this.cards, index, o);
    }
  },
  onShow() {
    this.cards = [];
    this.getData(this.activeIndex);
  },
  created() {
    this.getData(this.activeIndex);
  },
  onLoad() {
    if (wx.getStorageSync("hotelname")) {
      this.hotelname = wx.getStorageSync("hotelname");
    }
  }
};
</script>
<style scoped lang="less">
.displaynone {
  display: none;
}
.coupon-box {
  position: relative;
  margin: 0 auto;
  width: 700rpx;
  height: 220rpx;
  > span {
    position: absolute;
    display: inline-block;
  }
  .span1 {
    top: 90rpx;
    left: 20rpx;
    width: 20rpx;
    height: 24rpx;
    line-height: 24rpx;
    font-size: 24rpx;
    color: #fff;
  }
  .span2 {
    top: 40rpx;
    left: 45rpx;
    width: 120rpx;
    height: 74rpx;
    line-height: 74rpx;
    font-size: 74rpx;
    color: #fff;
  }
  .span3 {
    top: 140rpx;
    left: 40rpx;
    width: 130rpx;
    height: 22rpx;
    line-height: 22rpx;
    font-size: 22rpx;
    color: #fff;
  }
  .span4 {
    top: 26rpx;
    left: 195rpx;
    width: 480rpx;
    height: 26rpx;
    line-height: 26rpx;
    font-size: 26rpx;
    color: #666;
  }
  .span5 {
    top: 75rpx;
    left: 195rpx;
    width: 480rpx;
    height: 24rpx;
    line-height: 24rpx;
    font-size: 24rpx;
    color: #666;
  }
  .span6 {
    top: 116rpx;
    left: 195rpx;
    width: 480rpx;
    height: 24rpx;
    line-height: 24rpx;
    font-size: 24rpx;
    color: #666;
  }
  .div-des {
    position: absolute;
    top: 150rpx;
    left: 195rpx;
    width: 300rpx;
    height: 50rpx;
    border-top: 1px solid #f1f1f1;
  }
}

.div-des .a1 {
  width: 110rpx;
  height: 50rpx;
  line-height: 50rpx;
  font-size: 22rpx;
  color: #666;
  background: url("http://img.rainfn.com/qfs_p_0306_down.png") 90rpx center
    no-repeat;
  background-size: 20rpx 12rpx;
}
.coupon-des {
  box-sizing: border-box;
  position: relative;
  padding: 10rpx 14rpx;
  margin: -10rpx 0 0 208rpx;
  width: 510rpx;
  height: 85rpx;
  background: #fff;
  border-radius: 10rpx;
  span {
    display: block;
    width: 400rpx;
    height: 28rpx;
    line-height: 28rpx;
    font-size: 20rpx;
    color: #666;
  }
}

.coupon-common {
  background: url("http://img.rainfn.com/qfs_p_0306_coupon-bg-common.png") 0 0
    no-repeat;
  background-size: 700rpx 220rpx;
}
.coupon-member {
  background: url("http://img.rainfn.com/qfs_p_0306_coupon-bg-member.png") 0 0
    no-repeat;
  background-size: 700rpx 220rpx;
}
.coupon-common-used {
  opacity: 0.6;
  background: url("http://img.rainfn.com/qfs_p_0306_coupon-bg-common.png") 0 0
    no-repeat;
  background-size: 700rpx 220rpx;
}
.coupon-member-used {
  opacity: 0.6;
  background: url("http://img.rainfn.com/qfs_p_0306_coupon-bg-member.png") 0 0
    no-repeat;
  background-size: 700rpx 220rpx;
}
.coupon-des-used {
  opacity: 0.6;
}
.coupon-common-expired {
  background: url("http://img.rainfn.com/qfs_p_0306_coupon-bg-common-draw.png")
    0 0 no-repeat;
  background-size: 700rpx 220rpx;
}
.coupon-member-expired {
  background: url("http://img.rainfn.com/qfs_p_0306_coupon-bg-member-draw.png")
    0 0 no-repeat;
  background-size: 700rpx 220rpx;
}
.img-used {
  position: absolute;
  bottom: 20rpx;
  right: 20rpx;
  width: 140rpx;
  height: 140rpx;
  background: url("http://img.rainfn.com/qfs_p_0306_icon-used.png") 0 0
    no-repeat;
  background-size: 140rpx 140rpx;
}
.img-expired {
  position: absolute;
  bottom: 20rpx;
  right: 20rpx;
  width: 140rpx;
  height: 140rpx;
  background: url("http://img.rainfn.com/qfs_p_0306_icon-expired.png") 0 0
    no-repeat;
  background-size: 140rpx 140rpx;
}
.tabs {
  width: 100%;
  height: 100rpx;
  background: #fff;
  span {
    float: left;
    box-sizing: border-box;
    padding: 0 50rpx;
    width: 33.33%;
    height: 70rpx;
    line-height: 70rpx;
    font-size: 32rpx;
    font-weight: 600;
    text-align: center;
    color: #333;
  }
  span.active {
    background: url("http://img.rainfn.com/qfs_p_0306_coupon-active.png") center
      bottom no-repeat;
    background-size: 60rpx 10rpx;
  }
}
</style>
