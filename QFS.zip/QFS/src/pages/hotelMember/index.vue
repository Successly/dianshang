<template>
  <div class="hotelMember">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <div class="member-yes" v-if=" memberData != null&&memberData.isMember!=0">
        <div class="div-1">{{memberData.gradeName}}
          <image class="grade-tip" :src="srcUrl[memberData.grade - 1].url"/>
        </div>
        <div class="div-2">{{storedValue.hotelName}}</div>
        <div class="div-3">成长值 {{memberData.growthValue}}</div>
        <a href="/pages/userDetail/main">会员详情 ></a>
      </div>
      <div class="member-no" v-else>
        <div class="div-1">{{storedValue.hotelName}}</div>
        <div class="div-2">酒店专属会员</div>
        <div class="div-3">
          <p>开通即享红包和折扣</p>
          <div>
            <span class="span-1">5元入会红包</span>
            <span class="span-2">最高享受7折</span>
            <span class="span-3">专属权益</span>
          </div>
          <button @click="goMember">限时免费 立即开启</button>
        </div>
        <a href="/pages/userDetail/main">会员详情 ></a>
      </div>
      <div class="go-member" :class="memberFlag ? '' : 'displaynone'">
        <div>
          <p>恭喜升级为LV.1会员</p>
          <button @click="close1"></button>
        </div>
        <span></span>
      </div>
      <div class="sp"></div>
      <div class="info-1">
        <a class="a1" href="/pages/debit/main">储值卡详情</a>
        <a class="a2" href="/pages/grow/main">成长值明细</a>
        <span v-if="storedValue.cardDetail&&storedValue.cardDetail.length>0">限时储值{{storedValue.cardDetail.length > 0 ? storedValue.cardDetail[0].money : ''}}送{{storedValue.cardDetail.length > 0 ? storedValue.cardDetail[0].giveMoney : 0}}</span>
      </div>
      <div class="sp"></div>
      <div class="info-2">
        <swiper class="swiper" :current="memberData.grade ? (memberData.grade - 1) : 0">
          <block v-for="(item, index) in movies" :index="index" :key="index">
            <swiper-item>
              <image :src="item.url" class="slide-image" mode="aspectFill"/>
              <div class="count" v-if="item.discount">{{item.discount}}</div>
              <div class="count" v-else>未开放</div>
            </swiper-item>
          </block>
        </swiper>
      </div>
      <div class="sp"></div>
      <div class="info-3">
        <div class="div-1">
          <span>更多权益</span>
          <a href="/pages/interestDetail/main">权益详情 ></a>
        </div>
        <div class="div-2">
          <span class="span-1">专属勋章</span>
          <span class="span-2">会员优惠券</span>
          <span class="span-3">免押金</span>
          <span class="span-4">延时退房</span>
        </div>
      </div>
      <div class="sp"></div>
      <div class="info-4">
        <h3>会员做任务，加速成长值</h3>
        <div class="div-1">
          <span class="span-1">预定酒店</span>
          <span class="span-2">1元=1成长值</span>
          <a href="" @click="toHotel"></a>
        </div>
        <div class="div-2">
          <span class="span-1">储值</span>
          <span class="span-2">储值送现金，还可拿积分</span>
          <a href="/pages/debit/main"></a>
        </div>
        <div class="div-3">
          <span class="span-1">关注酒店</span>
          <span class="span-2">50成长值，仅限一次</span>
          <a href="" @click="toHotel" v-if="!memberData.isFollow"></a>
          <span v-else class="span-3">已经完成</span>
        </div>
        <div class="div-4">
          <span class="span-1">更多任务</span>
          <span class="span-2">前端反馈分享</span>
          <span class="span-3">敬请期待</span>
        </div>
      </div>
    </scroll-view>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        srcUrl: [
          {
            url: 'http://img.rainfn.com/qfs_p_0306_grow-level1.png'
          },
          {
            url: 'http://img.rainfn.com/qfs_p_0306_grow-level2.png'
          },
          {
            url: 'http://img.rainfn.com/qfs_p_0306_grow-level3.png'
          },
          {
            url: 'http://img.rainfn.com/qfs_p_0306_grow-level4.png'
          },
          {
            url: 'http://img.rainfn.com/qfs_p_0306_grow-level5.png'
          }
        ],
        movies: [
          {
            url: 'http://img.rainfn.com/qfs_p_0306_member-card-1.png'
          },
          {
            url: 'http://img.rainfn.com/qfs_p_0306_member-card-2.png'
          },
          {
            url: 'http://img.rainfn.com/qfs_p_0306_member-card-3.png'
          },
          {
            url: 'http://img.rainfn.com/qfs_p_0306_member-card-4.png'
          },
          {
            url: 'http://img.rainfn.com/qfs_p_0306_member-card-5.png'
          }
        ],
        storedValue: {
          hotelName: '',
          cardDetail: []
        },
        memberData: {
          gradeName: '',
          grade: 1,
          growthValue: 0,
          discount: 95
        },
        memberFlag: false,
        getCardDiscounted:[]
      }
    },
    methods: {
      toHotel () {
        const url = '/pages/hotelIndex/main'
        wx.switchTab({url})
      },
      //酒店的对应的会员折扣
      getDiscounted(){
        let me = this;
         wx.request({
          url: this.globalData.globalUrl + '/hotel/grade/info',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          success (res) {
            me.getCardDiscounted = res.data.data;
            for(let i=0;i<me.movies.length;i++){
              me.movies[i].name=me.getCardDiscounted[i].name;
              me.movies[i].discount=me.getCardDiscounted[i].discount;

            }
          }
        })
      },
      getStoredValue () {
        const me = this
        wx.request({
          url: this.globalData.globalUrl + '/card/detail',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            me.storedValue = res.data.data;
          }
        })
      },
      getData () {
        const me = this
        //自己是否是会员
        wx.request({
          url: this.globalData.globalUrl + '/member/info',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            res.data.data.isMember==0?false:true;
            me.memberData = res.data.data;
          }
        })
      },
      goMember () {
        const me = this
        wx.showLoading({
          title: '正在开通...',
        })
        wx.request({
          url: this.globalData.globalUrl + '/member/open',
          data: {
            hotelId: wx.getStorageSync('hotelId')
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {

            me.memberFlag = res.data.message === 'success'?true : false;
            me.getData()
            wx.hideLoading()
          },
          fail(error){
            wx.hideLoading()
            wx.showToast({
              title: '开通失败，请稍后再试',
              icon: 'none',
              duration: 2000
            })
          },
          complete(){
            wx.hideLoading()
          }
        })
      },
      close1 () {
        this.memberFlag = false
      }
    },
    created () {
      this.getData();
      this.getStoredValue();
      this.getDiscounted();
    },
    onLoad(item) {
      this.getData();
      this.getDiscounted();
      this.getStoredValue();
    },
    onShow(){
        this.getData();
        this.getStoredValue();
    }
  }
</script>
<style scoped lang="less">
  .displaynone {
    display: none;
  }
  .hotelMember {
    background: #fff;
  }
  .member-yes {
    position: relative;
    width: 100%;
    height: 220rpx;
    .div-1 {
      position: absolute;
      top: 30rpx;
      left: 30rpx;
      width: 500rpx;
      height: 48rpx;
      vertical-align: bottom;
      .grade-tip {
        display: inline-block;
        margin-left: 10rpx;
        width: 60rpx;
        height: 30rpx;
        // background: url('http://img.rainfn.com/qfs_p_0306_grow-level2.png') 0 0 no-repeat;
        // background-size: 60rpx 30rpx;
      }
    }
    .div-2 {
      position: absolute;
      top: 80rpx;
      left: 30rpx;
      width: 600rpx;
      height: 60rpx;
      line-height: 60rpx;
      font-size: 38rpx;
    }
    .div-3 {
      position: absolute;
      padding-left: 40rpx;
      bottom: 30rpx;
      left: 30rpx;
      width: 300rpx;
      height: 32rpx;
      line-height: 32rpx;
      font-size: 26rpx;
      background: url('http://img.rainfn.com/qfs_p_0306_userDetail-icon.png') 0 0 no-repeat;
      background-size: 32rpx 32rpx;
    }
    a {
      position: absolute;
      bottom: 30rpx;
      right: 30rpx;
      width: 200rpx;
      height: 22rpx;
      line-height: 22rpx;
      text-align: right;
      color: #999;
      font-size: 22rpx;
    }
  }


  .member-no {
    position: relative;
    width: 100%;
    height: 630rpx;
    background: url('http://img.rainfn.com/qfs_p_0306_member-no-bg.png') 0 0 no-repeat;
    background-size: 750rpx 493rpx;
    .div-1 {
      position: absolute;
      top: 50rpx;
      left: 30rpx;
      width: 600rpx;
      height: 50rpx;
      line-height: 50rpx;
      font-size: 36rpx;
      color: #f1ca81;
    }
    .div-2 {
      position: absolute;
      top: 100rpx;
      left: 30rpx;
      padding-left: 35rpx;
      width: 300rpx;
      height: 40rpx;
      line-height: 40rpx;
      font-size: 24rpx;
      color: #f1ca81;
      background: url('http://img.rainfn.com/qfs_p_0306_member-member.png') 0 center no-repeat;
      background-size: 32rpx 22rpx;
    }

    >a {
      position: absolute;
      top: 110rpx;
      right: 30rpx;
      width: 200rpx;
      height: 24rpx;
      line-height: 24rpx;
      text-align: right;
      color: #f1ca81;
      font-size: 24rpx;
    }

    .div-3 {
      position: absolute;
      top: 170rpx;
      left: 31rpx;
      width: 688rpx;
      height: 400rpx;
      background: #fff;
      border-radius: 16rpx;
      box-shadow: 0 8rpx 10rpx #f1f1f1;
      >p {
        position: absolute;
        top: 48rpx;
        left: 0;
        width: 100%;
        height: 34rpx;
        line-height: 34rpx;
        text-align: center;
        font-size: 34rpx;
        color: #724d2e;
      }
      >div {
        position: absolute;
        top: 130rpx;
        width: 100%;
        height: 90rpx;
        span {
          float: left;
          display: block;
          padding-top: 66rpx;
          width: 33.33%;
          height: 90rpx;
          text-align: center;
          font-size: 24rpx;
          color: #f1ca81;
        }
        .span-1 {
          background: url('http://img.rainfn.com/qfs_p_0306_member-icon2.png') center 0 no-repeat;
          background-size: 60rpx 50rpx;
        }
        .span-2 {
          background: url('http://img.rainfn.com/qfs_p_0306_member-no-icon2.png') center 0 no-repeat;
          background-size: 55rpx 55rpx;
        }
        .span-3 {
          background: url('http://img.rainfn.com/qfs_p_0306_member-member.png') center 0 no-repeat;
          background-size: 60rpx 43rpx;
        }
      }

      button {
        position: absolute;
        bottom: 50rpx;
        left: 44rpx;
        width: 600rpx;
        height: 80rpx;
        line-height: 80rpx;
        text-align: center;
        font-size: 30rpx;
        color: #fff;
        background-image: linear-gradient(to right , #f1dd98, #c27221);
        border-radius: 16rpx;
      }
    }
  }


  .sp {
    width: 100%;
    height: 20rpx;
    background: #f6f6f6;
  }
  .info-1 {
    position: relative;
    width: 100%;
    height: 180rpx;
    a {
      box-sizing: border-box;
      position: absolute;
      padding-left: 80rpx;
      top: 37rpx;
      width: 260rpx;
      height: 60rpx;
      line-height: 60rpx;
      border: 1px solid #c37524;
      color: #c37524;
      border-radius: 10rpx;
      font-size: 26rpx;
    }
    .a1 {
      left: 73rpx;
      background: url('http://img.rainfn.com/qfs_p_0306_icon-pig.png') 30rpx center no-repeat;
      background-size: 38rpx 31rpx;
    }
    .a2 {
      right: 73rpx;
      background: url('http://img.rainfn.com/qfs_p_0306_userDetail-icon.png') 30rpx center no-repeat;
      background-size: 36rpx 37rpx;
    }
    span {
      position: absolute;
      top: 110rpx;
      left: 40rpx;
      width: 500rpx;
      height: 32rpx;
      line-height: 32rpx;
      font-size: 20rpx;
      color: #c37524;
    }
  }

  .info-2 {
    /*box-sizing: border-box;*/
    /*padding: 10%;*/
    width: 100%;
    height: 420rpx;
    swiper {
      height: 100%;
    }

    swiper-item {
      padding: 10% !important;
      width: 80% !important;
      height: 80% !important;
      .count {
        position:relative;
        top:-130rpx;
        right:-180rpx;
        font-size:60rpx;
        color:#fff;
        width: 80rpx;
      }
    }
    image {
      width: 600rpx;
      height: 300rpx;
    }
  }

  .info-3 {
    box-sizing: border-box;
    padding-top: 50rpx;
    width: 100%;
    height: 300rpx;
    .div-1 {
      position: relative;
      width: 100%;
      height: 60rpx;
      span {
        position: absolute;
        top: 0;
        left: 30rpx;
        width: 200rpx;
        height: 60rpx;
        line-height: 60rpx;
        font-size: 32rpx;
        color: #000;
      }
      a {
        position: absolute;
        top: 0;
        right: 28rpx;
        box-sizing: border-box;
        padding-right: 20rpx;
        width: 200rpx;
        height: 60rpx;
        line-height: 60rpx;
        font-size: 22rpx;
        color: #999;
        text-align: right;
      }
    }

    .div-2 {
      position: relative;
      margin: 0 auto;
      width: 700rpx;
      height: 130rpx;
      span {
        float: left;
        box-sizing: border-box;
        padding-top: 100rpx;
        width: 175rpx;
        height: 130rpx;
        font-size: 28rpx;
        color: #999;
        text-align: center;
      }
      .span-1 {
        background: url('http://img.rainfn.com/qfs_p_0306_member-icon1.png') center 24rpx no-repeat;
        background-size: 60rpx 60rpx;
      }
      .span-2 {
        background: url('http://img.rainfn.com/qfs_p_0306_member-icon2.png') center 24rpx no-repeat;
        background-size: 60rpx 50rpx;
      }
      .span-3 {
        background: url('http://img.rainfn.com/qfs_p_0306_member-icon3.png') center 24rpx no-repeat;
        background-size: 60rpx 60rpx;
      }
      .span-4 {
        background: url('http://img.rainfn.com/qfs_p_0306_menber-icon4.png') center 24rpx no-repeat;
        background-size: 60rpx 60rpx;
      }
    }
  }

  .info-4 {
    box-sizing: border-box;
    padding-top: 10rpx;
    width: 100%;
    height: 750rpx;
    background: #fff;
    border-radius: 10rpx;
    h3 {
      box-sizing: border-box;
      padding-left: 30rpx;
      width: 100%;
      height: 100rpx;
      line-height: 100rpx;
      font-size: 34rpx;
      color: #000;
    }
    >div {
      position: relative;
      margin: 15rpx auto;
      width: 690rpx;
      height: 120rpx;
      box-shadow: 0 0 16rpx #f1f1f1;
      .span-1, .span-2 {
        position: absolute;
        width: 400rpx;
        height: 40rpx;
        line-height: 40rpx;
        font-size: 26rpx;
      }
      .span-1 {
        top: 18rpx;
        left: 120rpx;
        color: #333;
      }
      .span-2 {
        top: 60rpx;
        left: 120rpx;
        color: #999;
      }
      .span-3 {
        position: absolute;
        top: 45rpx;
        right: 25rpx;
        width: 120rpx;
        height: 30rpx;
        line-height: 30rpx;
        text-align: right;
        font-size: 26rpx;
        color: #999;
        opacity: .6;
      }
      >a {
        position: absolute;
        top: 35rpx;
        right: 30rpx;
        width: 100rpx;
        height: 50rpx;
        background: url('http://img.rainfn.com/qfs_p_0306_userDetail-go.png') 0 0 no-repeat;
        background-size: 100rpx 50rpx;
      }
    }

    .div-1 {
      background: url('http://img.rainfn.com/qfs_p_0306_member-book.png') 15rpx 15rpx no-repeat;
      background-size: 90rpx 90rpx;
    }
    .div-2 {
      background: url('http://img.rainfn.com/qfs_p_0306_member-saving.png') 15rpx 15rpx no-repeat;
      background-size: 90rpx 90rpx;
    }
    .div-3 {
      background: url('http://img.rainfn.com/qfs_p_0306_userDetail-fav.png') 15rpx 15rpx no-repeat;
      background-size: 90rpx 90rpx;
    }
    .div-4 {
      background: url('http://img.rainfn.com/qfs_p_0306_userDetail-more.png') 15rpx 15rpx no-repeat;
      background-size: 90rpx 90rpx;
    }
  }

  .go-member {
    position: fixed;
    top: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
    >div {
      position: absolute;
      top: 50%;
      left: 0;
      margin-top: -300rpx;
      width: 100%;
      height: 600rpx;
      background: url('http://img.rainfn.com/qfs_p_0306_go-level1.png') center 0 no-repeat;
      background-size: 370rpx 370rpx;
      z-index: 2;
    }
    p {
      position: absolute;
      top: 400rpx;
      left: 0;
      width: 100%;
      height: 30rpx;
      line-height: 30rpx;
      text-align: center;
      font-size: 30rpx;
      color: #fff;
    }
    button {
      position: absolute;
      bottom: 0;
      left: 50%;
      margin-left: -25rpx;
      width: 50rpx;
      height: 50rpx;
      background: url('http://img.rainfn.com/qfs_p_0306_member-close.png') 0 0 no-repeat;
      background-size: 50rpx 50rpx;
    }
     >span {
      position: absolute;
      width: 100%;
      height: 100%;
      background: #000;
      opacity: .7;
    }
  }

</style>
