<template>
  <div class="userCenter">
    <scroll-view scroll-y style="height:calc(100vh);" scroll-top="0">
      <section class="section-1">
        <img src="http://img.rainfn.com/qfs_p_0306_user.png" />
        <p class="user-name">HY</p>
        <p class="user-level">黄金会员</p>
        <div class="user-card">我的会员卡<a href="">会员详情></a></div>
        <div class="user-info">
          <div class="info-1">
            <span class="info-span1">1250<b>元</b></span>
            <span class="info-span2">储蓄卡</span>
            <span class="info-span3">限时充值500送100</span>
          </div>
          <div class="sp"></div>
          <div class="info-2">
            <span class="info-span1">1450<b>值</b></span>
            <span class="info-span2">成长值</span>
            <span class="info-span3"></span>
          </div>
          <div class="sp"></div>
          <div class="info-3">
            <span class="info-span1">85<b>折</b></span>
            <span class="info-span2">折扣权益</span>
            <span class="info-span3">最高享75折</span>
          </div>
          <div class="my-order">
            <h3>我的订单</h3>
            <div>
              <a><img src="" /><span>待支付</span><i>1</i></a>
              <a><img src="" /><span>待入住</span></a>
              <a><img src="" /><span>退款/售后</span></a>
              <a><img src="" /><span>全部订单</span></a>
            </div>
          </div>
        </div>
      </section>
      <section class="section-2">
        <div class="gray-div">
          <div>
            <a><img src="" /><span>优惠券</span></a>
            <a><img src="" /><span>联系酒店</span></a>
          </div>
        </div>
      </section>
      <section class="section-3">
        <a><img src="" /><span>首页</span></a>
        <a><img src="" /><span>商城</span></a>
        <a><img src="" /><span>我的</span></a>
      </section>
    </scroll-view>
  </div>
</template>
<script>
  export default {
    data () {
      return {}
    },
    methods: {
      getData () {
        const me = this
        wx.request({
          url: this.globalData.globalUrl + '/member/rooms',
          data: {
            hotelId: 1,
            type: 'day',
            dayStart: '',
            dayEnd: '',
            hourStart: '',
            hourEnd: ''
          },
          header: {
            'content-type': 'application/json',
            'memberId': wx.getStorageSync('memberId')
          },
          success (res) {
            me.memberData = res.data.data
          }
        })
      }
    },
    created () {
      this.getData()
    }
  }
</script>
<style scoped lang="less">
  section {
    background: #fff;
  }
  .section-1 {
    width: 100%;
    height: 900px;
    background: url('http://img.rainfn.com/qfs_p_0306_user-bg.png') 0 -100rpx no-repeat;
    background-size: 750rpx 620rpx;
    >img {
      margin: 40rpx auto 0 auto;
      width: 120rpx;
      height: 120rpx;
    }
  }

  .user-name {
    width: 100%;
    height: 50rpx;
    line-height: 50rpx;
    text-align: center;
    font-size: 24rpx;
    color: #fff;
  }
  .user-level {
    margin-bottom: 10rpx;
    width: 130rpx;
    height: 36rpx;
    line-height: 36rpx;
    text-align: center;
    background: #fff;
    border-radius: 4rpx;
    color: #47beef;
  }
  .user-card {
    margin: 0 auto;
    width: 690rpx;
    height: 70rpx;
  }
  .user-info {
    margin: 8rpx auto 60rpx auto;
    width: 690rpx;
    height: 200rpx;
  }
  .my-order {
    width: 690rpx;
    height: 180rpx;
  }
  .section-2 {
    margin-top: 20rpx;
  }
  .section-2 .gray-div {

  }
  .section-3 {
    position: fixed;
    bottom: 0;
    width: 100%;
    height: 100rpx;
    border-top: 1px solid #f1f1f1;
    a {
      width: 33.33%;
      height: 100%;
    img {
      width: 39rpx;
      height: 37rpx;
    }
    span {
      font-size: 24rpx;
      color: #999;
    }
  }

  }

</style>
