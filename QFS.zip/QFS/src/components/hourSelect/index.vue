<template>
  <div class="calendar-container">
    <div class="calendar-show">
      <div class="item">
        <div class="time-title">入住时间</div>
        <div class="time-show">{{start}}</div>
      </div>
      <div>
        <div class="long-box">{{total}}</div>
      </div>
      <div  class="item">
        <div class="time-title">离开时间</div>
        <div class="time-show">{{end}}</div>
      </div>
    </div>
    <div class="calendar-body">
      <div class="calendar-body-item">
        <div v-for="(items, index) in availableMonths" :key="index">
          <div class="calendar-header-wrap">
            <div class="calendar-header-text">{{ items.date }}
            </div>
          </div>
          <div class="calendar-day-list">
            <div class="calendar-day-item" v-for="(item, k) in items.arr"
                 :class="item.selected && item.hour && item.selected.cls" :key="k" @click="onPressDay">
              <div class="calendar-day-text item-1">{{ item.hour }}</div>
              <div v-if="!!item.selected" class="calendar-day-text desc-text">{{ item.selected.label }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="tip-wrap" v-if="!hasLeaveDate">
      <div>请选择离店日期</div>
    </div>
    <div class="button-box">
      <div class="cancel" @click="clearFn">清空时间</div>
      <div class="submit" @click="saveFn">保存</div>
    </div>
  </div>
</template>
<script>
import moment from "moment";

const FORMAT_TYPE = "YYYY-MM-DD";
const ENTER_WORD = "入店";
const LEAVE_WORD = "离店";
const WEEKS_CH = ["日", "一", "二", "三", "四", "五", "六"];
const HOUR_CH = [
  "00:00",
  "01:00",
  "02:00",
  "03:00",
  "04:00",
  "05:00",
  "06:00",
  "07:00",
  "08:00",
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "13:00",
  "14:00",
  "15:00",
  "16:00",
  "17:00",
  "18:00",
  "19:00",
  "20:00",
  "21:00",
  "22:00",
  "23:00"
];

export default {
  props: {
    startTime: {
      type: String,
      required: false
    },
    endTime: {
      type: String,
      required: false
    }
  },
  data() {
    return {
      // 动态的
      disableTime: {
        "2019-03-25": [23]
      },
      month: "",
      day: "",
      start: "",
      end: "",
      total: "",
      total1: "",
      week1: "",
      week2: "",
      start1: "",
      end1: "",
      externalClasses: [],
      options: {},
      properties: {},
      data: {
        weeksCh: WEEKS_CH,
        viewTime: {
          year: "",
          month: "",
          day: "",
          formatDay: "",
          weekCh: "",
          viewDays: []
        }
      },
      viewDays: [],
      hasLeaveDate: true,
      availableMonths: []
    };
  },
  created() {
    //      this.cellWidth = wx.getSystemInfoSync().windowWidth / 7
    !this._inited && this._init();
    this.getData();
    //      this._checkDefaultSelected()
    console.log("this.availableMonths", this.availableMonths);
    console.log("xxxxxccccc", this.startTime, this.endTime);
    this.startTime
      ? this.onPressDay(
          moment(this.startTime, "MM月DD日HH:mm").format("MM-DDHH:mm"),
          "init"
        )
      : null;
    this.endTime
      ? this.onPressDay(
          moment(this.endTime, "MM月DD日HH:mm").format("MM-DDHH:mm"),
          "init"
        )
      : null;
    //根据时间控制 屏蔽
    this.availableMonths.forEach(o => {
      o.arr.map(d => {
        let h = parseInt(
          moment(d.day + d.hour, "YYYY-MM-DDHH:mm").format("HH")
        );
        let dat = moment(d.day + d.hour, "YYYY-MM-DDHH:mm").format(
          "YYYY-MM-DD"
        );
        if (this.disableTime[dat] && this.disableTime[dat].includes(h)) {
          this._setDisableDate(d);
        }
      });
    });
  },
  methods: {
    getData() {
      const me = this;
      wx.request({
        url: this.globalData.globalUrl + "/hotel/rooms/appStatus",
        data: {
          hotelId: wx.getStorageSync("hotelId"),
          type: "hour",
          dayStart: moment().format('YYYY-MM-DD'),
          dayEnd: moment().startOf("day").add(7, "day").format('YYYY-MM-DD')
        },
        header: {
          "content-type": "application/json",
          memberId: wx.getStorageSync("memberId")
        },
        success: function(res) {
          let result = res.data.data;
          let disableTime = {};
          for (let key in result) {
            console.log(key + "---" + result[key]);
            let s;
            result[key].forEach(t => {
              if (t.remain > 0) {
                s
                  ? (s = me.intersection(t.disableHours, s))
                  : (s = t.disableHours);
              }
            });
            console.log(key + "---" + s);
            disableTime[key] = s;
          }
          me.disableTime = disableTime;
          console.log(me.disableTime);
          me.disableDate();
        }
      });
    },
    clearFn() {
      this.availableMonths.forEach(o => {
        o.arr.forEach(d => {
          d.selected = null;
        });
      });
      this.disableDate();
      this.start = "";
      this.end = "";
      this.total = "";
      this.week1 = "";
      this.week2 = "";
    },
    saveFn() {
      if (this.start && this.end && this.total) {
        this.$emit("onOkSelected", {
          enter: this.start,
          leave: this.end,
          total: this.total,
          week1: this.week1,
          week2: this.week2,
          enter1: this.start1,
          leave1: this.end1,
          total1: this.total1
        });
      } else {
        wx.showToast({
          title: "请选择入店和离店时间！",
          icon: "none",
          duration: 1000
        });
      }
    },
    _init() {
      this.month = moment().month();
      this.day = moment().date();
      this._inited = true;
      let day = moment().startOf("day");
      console.log(day);
      this.availableMonths = [
        this._getAvailableDays(moment().startOf("hour")),
        this._getAvailableDays(
          moment()
            .startOf("day")
            .add(1, "day")
        ),
        this._getAvailableDays(
          moment()
            .startOf("day")
            .add(2, "day")
        ),
        this._getAvailableDays(
          moment()
            .startOf("day")
            .add(3, "day")
        ),
        this._getAvailableDays(
          moment()
            .startOf("day")
            .add(4, "day")
        ),
        this._getAvailableDays(
          moment()
            .startOf("day")
            .add(5, "day")
        ),
        this._getAvailableDays(
          moment()
            .startOf("day")
            .add(6, "day")
        )
      ];
      console.log(111);
    },

    _checkDefaultSelected() {
      const data = this.availableMonths;
      let hasSelected = false;
      data.forEach(o => {
        o.days.forEach(d => {
          if (o.selected) {
            hasSelected = true;
          }
        });
      });
      if (!hasSelected) {
        data.forEach(o => {
          o.days.forEach(d => {
            if (d.formatDay === moment().format(FORMAT_TYPE)) {
              d = this._setEnterDate(d);
            }
          });
        });
        this.hasLeaveDate = false;
      }
      this.availableMonths = data;
    },

    _getAvailableDays(time = moment()) {
      let year = time.year();
      let month = time.month() + 1;
      let day = time.date();
      let hour = time.hour();
      let arr = [];
      month = month < 10 ? "0" + month : month;
      HOUR_CH.forEach((o, index) => {
        if (index >= hour - 1) {
          let obj = {
            hour: o,
            day: year + "-" + month + "-" + (day < 10 ? "0" + day : day)
          };
          arr.push(obj);
        }
      });
      return {
        date: year + "年" + month + "月" + (day < 10 ? "0" + day : day) + "日",
        arr: arr
      };
    },

    // 补充剩余占位空格
    _supplement(formatDay, days) {
      const time = moment(formatDay).endOf("month");
      let whichWeek = time.format("E");
      whichWeek = parseInt(whichWeek) === 7 ? 0 : whichWeek;
      const restCount = 7 - (parseInt(whichWeek) + 1);
      const placeholders = [];
      for (let i = 0; i < restCount; i++) {
        placeholders.push({
          type: "placeholders",
          visible: false,
          day: ""
        });
      }
      return [...days, ...placeholders];
    },

    // 设置
    _setViewTime(time = moment()) {
      return this._dealMoment(time);
    },

    // 新增
    _calDate(time, length) {
      let arr = [];
      for (let i = 0; i < length; i++) {
        arr.push(this._dealMoment(time));
        time.add(1, "days");
      }
      return arr;
    },

    // 获取日期对象
    _dealMoment(time) {
      let { years, months, date } = time.toObject();
      const wn = time.format("E");
      return {
        year: years,
        month: months + 1,
        day: date,
        weekCh: "周" + this.data.weeksCh[wn === 7 ? 0 : wn],
        formatDay: time.format(FORMAT_TYPE)
      };
    },

    // 去重
    _uniq(array) {
      var temp = [];
      var index = [];
      var l = array.length;
      for (var i = 0; i < l; i++) {
        for (var j = i + 1; j < l; j++) {
          if (JSON.stringify(array[i]) === JSON.stringify(array[j])) {
            i++;
            j = i;
          }
        }
        temp.push(array[i]);
        index.push(i);
      }
      return temp;
    },

    intersection(a, b) {
      const s = new Set(b);
      return a.filter(x => s.has(x));
    },

    // 设置入住
    _setEnterDate(o) {
      o.selected = {
        type: "enter",
        cls: "item-enter",
        label: ENTER_WORD
      };
      return o;
    },

    // 设置离店
    _setLeaveDate(o) {
      o.selected = {
        type: "leave",
        cls: "item-leave",
        label: LEAVE_WORD
      };
      return o;
    },

    // 设置包含
    _setContainDate(o) {
      o.selected = {
        type: "contain",
        cls: "item-in",
        label: ""
      };
      return o;
    },

    // 设置Disable
    _setDisableDate(o) {
      o.selected = {
        type: "contain",
        cls: "item-disable",
        label: ""
      };
      return o;
    },

    disableDate() {
      this.availableMonths.forEach(o => {
        o.arr.map(d => {
          let h = parseInt(
            moment(d.day + d.hour, "YYYY-MM-DDHH:mm").format("HH")
          );
          let dat = moment(d.day + d.hour, "YYYY-MM-DDHH:mm").format(
            "YYYY-MM-DD"
          );
          if (this.disableTime[dat] && this.disableTime[dat].includes(h)) {
            this._setDisableDate(d);
          }
        });
      });
    },
    containDate() {
      this.availableMonths.forEach(o => {
        o.arr.forEach(d => {
          if (
            moment(d.day + " " + d.hour + ":00").unix() >
              moment(store[0].day + " " + store[0].hour + ":00").unix() &&
            moment(d.day + " " + d.hour + ":00").unix() <
              moment(currentItem.day + " " + currentItem.hour + ":00").unix()
          ) {
            d = this._setContainDate(d);
          }
        });
      });
    },
    // 清除所有选择的
    _cleanAllSelectedDate() {
      this.availableMonths.forEach(o => {
        o.arr.forEach(d => {
          d.selected = null;
        });
      });
      this.disableDate();
      return this.availableMonths;
    },

    // 点击
    onPressDay(e, type) {
      let currentItem;
      if (type) {
        this.availableMonths.forEach(o => {
          o.arr.forEach(d => {
            if (
              moment(d.day + d.hour, "YYYY-MM-DDHH:mm").format("MM-DDHH:mm") ==
              e
            ) {
              currentItem = d;
            }
          });
        });
      } else {
        const idx = e.currentTarget.dataset.eventid.split("-")[1];
        const panelidx = e.currentTarget.dataset.eventid
          .split("-")[0]
          .split("_")[1];
        currentItem = this.availableMonths[panelidx].arr[idx];
        // 禁用选择
        if (currentItem.selected && currentItem.selected.cls == "item-disable")
          return;
      }
      let store = [];
      this.availableMonths.forEach(o => {
        o.arr.forEach(d => {
          if (d.selected && d.selected.cls != "item-disable") {
            store.push({ ...d.selected, day: d.day, hour: d.hour });
          }
        });
      });
      store = this._uniq(store);
      if (!store.length) {
        //第一次点击
        this.availableMonths = this._cleanAllSelectedDate(this.availableMonths);
        currentItem = this._setEnterDate(currentItem);

        this.start1 = currentItem.day + " " + currentItem.hour + ":00";
        this.start =
          currentItem.day.substr(5).replace(/-/, "月") +
          "日" +
          " " +
          currentItem.hour;
        this.end = "";
        this.total = "";
        this.hasLeaveDate = false;
      } else if (store.length === 1) {
        if (
          store[0].day + store[0].hour !==
          currentItem.day + currentItem.hour
        ) {
          if (
            moment(currentItem.day + " " + currentItem.hour + ":00").unix() >
            moment(store[0].day + " " + store[0].hour + ":00").unix()
          ) {
            //增加判断 逻辑 控制不能选择 不设置
            let flag = true;
            this.availableMonths.forEach(o => {
              o.arr.forEach(d => {
                if (
                  moment(d.day + " " + d.hour + ":00").unix() >
                    moment(store[0].day + " " + store[0].hour + ":00").unix() &&
                  moment(d.day + " " + d.hour + ":00").unix() <
                    moment(
                      currentItem.day + " " + currentItem.hour + ":00"
                    ).unix()
                ) {
                  // d = this._setContainDate(d);
                  let h = parseInt(
                    moment(d.day + d.hour, "YYYY-MM-DDHH:mm").format("HH")
                  );
                  let dat = moment(d.day + d.hour, "YYYY-MM-DDHH:mm").format(
                    "YYYY-MM-DD"
                  );
                  if (
                    this.disableTime[dat] &&
                    this.disableTime[dat].includes(h)
                  ) {
                    flag = false;
                  }
                }
              });
            });

            if (flag) {
              currentItem = this._setLeaveDate(currentItem);
              this.availableMonths.forEach(o => {
                o.arr.forEach(d => {
                  if (
                    moment(d.day + " " + d.hour + ":00").unix() >
                      moment(
                        store[0].day + " " + store[0].hour + ":00"
                      ).unix() &&
                    moment(d.day + " " + d.hour + ":00").unix() <
                      moment(
                        currentItem.day + " " + currentItem.hour + ":00"
                      ).unix()
                  ) {
                    d = this._setContainDate(d);
                  }
                });
              });
            } else {
              wx.showToast({
                title: "分时不允许跨天哦！",
                icon: "none",
                duration: 1000
              });
              return;
            }

            this.start1 = store[0].day + " " + store[0].hour + ":00";
            this.end1 = currentItem.day + " " + currentItem.hour + ":00";
            this.total1 =
              (new Date(
                currentItem.day.replace(/-/g, "/") +
                  " " +
                  currentItem.hour +
                  ":00"
              ).getTime() -
                new Date(
                  store[0].day.replace(/-/g, "/") + " " + store[0].hour + ":00"
                ).getTime()) /
              (1000 * 60 * 60);
            this.total = this.total1 + "小时";
            this.week1 =
              "周" +
              this.data.weeksCh[
                moment(store[0].day).format("E") === "7"
                  ? 0
                  : moment(store[0].day).format("E")
              ];
            this.week2 =
              "周" +
              this.data.weeksCh[
                moment(currentItem.day).format("E") === "7"
                  ? 0
                  : moment(currentItem.day).format("E")
              ];
            this.start =
              store[0].day.substr(5).replace(/-/, "月") +
              "日" +
              " " +
              store[0].hour;
            this.end =
              currentItem.day.substr(5).replace(/-/, "月") +
              "日" +
              " " +
              currentItem.hour;
            this.hasLeaveDate = true;
          } else {
            // 二次点击 小于第一次点击 相当于第一次点击
            this._cleanAllSelectedDate(this.availableMonths);
            currentItem = this._setEnterDate(currentItem);
            this.start1 = currentItem.day + " " + currentItem.hour + ":00";
            this.start =
              currentItem.day.substr(5).replace(/-/, "月") +
              "日" +
              " " +
              currentItem.hour;
            this.end = "";
            this.total = "";
            this.hasLeaveDate = false;
          }
        }
      } else {
        //两次点击完 相当于第一次点击
        this.availableMonths = this._cleanAllSelectedDate(this.availableMonths);
        currentItem = this._setEnterDate(currentItem);
        this.start1 = currentItem.day + " " + currentItem.hour + ":00";
        this.start =
          currentItem.day.substr(5).replace(/-/, "月") +
          "日" +
          " " +
          currentItem.hour;
        this.end = "";
        this.total = "";
      }
    }
  }
};
</script>
<style scoped lang="less">
.calendar-container {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background: #fff;
  z-index: 1;
  .calendar-show {
    position: fixed;
    top: 0;
    width: 100%;
    height: 148rpx;
    background: #fff;
    border-top: 1rpx solid #e5e5e5;
    border-bottom: 1rpx solid #e5e5e5;
    display: flex;
    justify-content: space-around;
    align-items: center;
    z-index: 1;
    .time-title {
      flex: 1;
      font-size: 28rpx;
      height: 40rpx;
      line-height: 40rpx;
      color: #999999;
      text-align: center;
    }
    .time-show {
      height: 50rpx;
      font-size: 36rpx;
      font-weight: 400;
      color: #333333;
      line-height: 50rpx;
      text-align: center;
    }
    .long-box {
      width: 120rpx;
      height: 50rpx;
      border-radius: 5rpx;
      border: 2rpx solid #3ebbff;
      color: #3ebbff;
      text-align: center;
      font-size: 28rpx;
      line-height: 50rpx;
    }
    .item {
      flex: 1;
    }
  }
}

.calendar-weeks-list {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  box-sizing: border-box;
  padding: 20rpx 0;
  background-color: #eee;
  position: fixed;
  top: 150rpx;
  left: 0;
  right: 0;
}

.calendar-weeks-item {
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  flex: 1;
}

.calendar-weeks-item-text {
  color: #474747;
  font-size: 26rpx;
}

.calendar-body {
  padding-top: 150rpx;
}

.calendar-body-item {
  margin-bottom: 130rpx;
}

.calendar-header-wrap {
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  padding: 20rpx 0;
  border-top: 1rpx solid #e5e5e5;
}

.calendar-header-text {
  font-size: 26rpx;
}

.calendar-day-list {
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  box-sizing: border-box;
  flex-wrap: wrap;
}

.calendar-day-item {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  height: 80rpx;
  box-sizing: border-box;
  /*padding-top: 15rpx;*/
  flex: 0 0 150rpx;
  margin: 10rpx 0;
  .item-1 {
    height: 80rpx;
    line-height: 80rpx;
    font-size: 28rpx;
  }
}

.calendar-day-item.selected-item {
  background-color: #a0ddfd;
  color: #333;
}
.calendar-day-item.item-enter,
.calendar-day-item.item-leave {
  background-color: #a0ddfd;
  color: #333;
  .item-1 {
    width: 100%;
    height: 40rpx;
    line-height: 40rpx;
    text-align: center;
  }
  .desc-text {
    width: 100%;
    height: 34rpx;
    line-height: 34rpx;
    font-size: 24rpx;
    text-align: center;
  }
}
.calendar-day-item.item-enter {
  border-radius: 16rpx 0 0 16rpx;
}

.calendar-day-item.item-leave {
  border-radius: 0 16rpx 16rpx 0;
}
.calendar-day-item.item-in {
  background: #a0ddfd;
  color: #333;
}

.calendar-day-item.item-disable {
  color: #333;
  opacity: 0.3;
}

.calendar-day-item.visible-out text {
  visibility: hidden;
}

.tip-wrap {
  position: fixed;
  bottom: 60rpx;
  left: 50%;
  transform: translate3d(-50%, 0, 0);
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  padding: 10rpx;
  border-radius: 6rpx;
  background-color: #6d6d6d;
}

.tip-wrap text {
  color: #fff;
  font-size: 24rpx;
}
.button-box {
  position: fixed;
  bottom: 0rpx;
  background: #fff;
  width: 100%;
  height: 120rpx;
  box-shadow: 0rpx -2rpx 30rpx 0rpx rgba(0, 0, 0, 0.1);
  display: flex;
  .cancel {
    width: 200rpx;
    height: 90rpx;
    background: #666666;
    border-radius: 5rpx;
    margin: 15rpx 25rpx;
    text-align: center;
    line-height: 90rpx;
    font-weight: 400;
    color: #ffffff;
    font-size: 36rpx;
  }
  .submit {
    width: 475rpx;
    height: 90rpx;
    background: #3ebbff;
    border-radius: 5rpx;
    margin: 15rpx 25rpx;
    text-align: center;
    line-height: 90rpx;
    font-weight: 400;
    color: #ffffff;
    font-size: 36rpx;
  }
}
</style>
