<template>
  <div class="calendar-container">
    <div class="calendar-show">
      <div class="item">
        <div class="time-title">入住时间</div>
        <div class="time-show">{{start?start + ' 12:00':''}}</div>
      </div>
      <div>
        <div class="long-box">{{total + '整日'}}</div>
      </div>
      <div class="item"> 
        <div class="time-title">离开时间</div>
        <div class="time-show">{{end? end+ ' 12:00':''}}</div>
      </div>
    </div>
    <div class="calendar-weeks-list">
      <div class="calendar-weeks-item" v-for="(item,i) in data.weeksCh" :key="i">
        <div class="calendar-weeks-item-text">{{ item }}</div>
      </div>
    </div>
    <div class="calendar-body">
      <div class="calendar-body-item">
        <div v-for="(items, index) in availableMonths" :key='index'>
          <div class="calendar-header-wrap">
            <div class="calendar-header-text">{{ items.viewTime.year + '年' + ' ' + (items.viewTime.month > 10 ? 
              items.viewTime.month :'0' +items. viewTime.month) + '月' }}
            </div>
          </div>
          <div class="calendar-day-list">
            <div class="calendar-day-item" v-for="(item, k) in items.days"
                 :class="item.selected && item.day && item.selected.cls" :key="k" @click="onPressDay">
              <div class="calendar-day-text item-1">{{ item.day }}</div>
              <div v-if="!!item.selected" class="calendar-day-text desc-text">{{ item.selected.label }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="tip-wrap" v-if="!hasLeaveDate">
      <div>请选择离店日期</div>
    </div>
    <div class="button-box">
      <div class="cancel" @click="clearFn">清空时间</div>
      <div class="submit" @click="saveFn">保存</div>
    </div>
  </div>
</template>
<script>
import moment from "moment";

const FORMAT_TYPE = "YYYY-MM-DD";
const ENTER_WORD = "入店";
const LEAVE_WORD = "离店";
const WEEKS_CH = ["日", "一", "二", "三", "四", "五", "六"];

export default {
  props: {
    startTime: {
      type: String,
      required: false
    },
    endTime: {
      type: String,
      required: false
    }
  },
  data() {
    return {
      externalClasses: [],
      options: {},
      properties: {},
      data: {
        weeksCh: WEEKS_CH,
        viewTime: {
          year: "",
          month: "",
          day: "",
          formatDay: "",
          weekCh: "",
          viewDays: []
        }
      },
      viewDays: [],
      hasLeaveDate: true,
      start: "",
      end: "",
      total: "",
      total1: "",
      week1: "",
      week2: "",
      start1: "",
      end1: "",
      availableMonths: []
    };
  },
  created() {
    //      this.cellWidth = wx.getSystemInfoSync().windowWidth / 7
    !this._inited && this._init();
    //      this._checkDefaultSelected()
    // this.startTime = "03月21日12:00";
    // this.endTime = "04月21日12:00";
    this.startTime
      ? this.onPressDay(
          moment(this.startTime, "MM月DD日HH:mm").format("MM-DD"),
          "init"
        )
      : null;
    this.endTime
      ? this.onPressDay(
          moment(this.endTime, "MM月DD日HH:mm").format("MM-DD"),
          "init"
        )
      : null;
  },
  methods: {
    clearFn() {
      this.availableMonths.forEach(o => {
        o.days.forEach(d => {
          d.selected = null;
        });
      });
      this.start = "";
      this.end = "";
      this.total = "";
      this.week1 = "";
      this.week2 = "";
    },
    saveFn() {
      if (this.start && this.end && this.total) {
        this.$emit("onOkSelected", {
          enter: this.start,
          leave: this.end,
          total: this.total,
          week1: this.week1,
          week2: this.week2,
          enter1: this.start1,
          leave1: this.end1,
          total1: this.total1
        });
      } else {
        wx.showToast({
          title: "请选择入店和离店时间！",
          icon: "none",
          duration: 1000
        });
      }
    },
    _init() {
      this._inited = true;
      this.availableMonths = [
        this._getAvailableDays(moment().startOf("month"), "today"),
        this._getAvailableDays(
          moment()
            .month(moment().month() + 1)
            .startOf("month")
        ),
        this._getAvailableDays(
          moment()
            .month(moment().month() + 2)
            .startOf("month")
        )
      ];
      console.log(111);
    },

    _checkDefaultSelected() {
      const data = this.availableMonths;
      let hasSelected = false;
      data.forEach(o => {
        o.days.forEach(d => {
          if (o.selected) {
            hasSelected = true;
          }
        });
      });
      if (!hasSelected) {
        data.forEach(o => {
          o.days.forEach(d => {
            if (d.formatDay === moment().format(FORMAT_TYPE)) {
              d = this._setEnterDate(d);
            }
          });
        });
        this.hasLeaveDate = false;
      }
      this.availableMonths = data;
    },

    _getAvailableDays(time = moment(), type) {
      const result = {};
      result.viewTime = this._setViewTime(time);
      // 计算今天是星期几 添加判断逻辑 是否显示前一天 当天6点之前 显示前一天
      let flag = moment() - moment().startOf("day") < 6 * 3600 * 1000;
      const todayDayOfWeek =
        type === "today"
          ? moment().format("E") - (flag ? 1 : 0)
          : time.format("E");
      // 令时间变为当月1号的
      const firstDay = time.startOf("month");
      // 计算当月1号是星期几
      const firstDayOfWeek = firstDay.format("E");
      // 计算上个月多余时间
      const last = this._calDate(
        firstDay.subtract(firstDayOfWeek, "days"),
        firstDayOfWeek
      );
      last.forEach(o => {
        o.visible = false;
      });
      // 计算本月时间
      const current = this._calDate(firstDay, firstDay.daysInMonth());
      const fullMonths = [...last, ...current];
      let formatValue =
        !!type && type === "today"
          ? flag
            ? moment()
                .subtract(1, "days")
                .format(FORMAT_TYPE)
            : moment().format(FORMAT_TYPE)
          : result.viewTime.formatDay;
      const todayIdx = fullMonths.findIndex(o => o.formatDay === formatValue);
      const todayRestOfMonth = fullMonths.slice(todayIdx);
      todayRestOfMonth.forEach(o => {
        o.visible = true;
      });
      // 今天对应的一周，已过去的长度
      let currentTimeOrToday =
        !!type && type === "today"
          ? moment()
          : moment(result.viewTime.formatDay);
      let daysOfTodayWeekPassed = this._calDate(
        currentTimeOrToday.subtract(parseInt(todayDayOfWeek), "days"),
        todayDayOfWeek
      );
      daysOfTodayWeekPassed.forEach(o => {
        o.visible = false;
        o.day = "";
      });
      result.days = this._supplement(result.viewTime.formatDay, [
        ...daysOfTodayWeekPassed,
        ...todayRestOfMonth
      ]);
      return result;
    },

    // 补充剩余占位空格
    _supplement(formatDay, days) {
      const time = moment(formatDay).endOf("month");
      let whichWeek = time.format("E");
      whichWeek = parseInt(whichWeek) === 7 ? 0 : whichWeek;
      const restCount = 7 - (parseInt(whichWeek) + 1);
      const placeholders = [];
      for (let i = 0; i < restCount; i++) {
        placeholders.push({
          type: "placeholders",
          visible: false,
          day: ""
        });
      }
      return [...days, ...placeholders];
    },

    // 设置
    _setViewTime(time = moment()) {
      return this._dealMoment(time);
    },

    // 新增
    _calDate(time, length) {
      let arr = [];
      for (let i = 0; i < length; i++) {
        arr.push(this._dealMoment(time));
        time.add(1, "days");
      }
      return arr;
    },

    // 获取日期对象
    _dealMoment(time) {
      let { years, months, date } = time.toObject();
      const wn = time.format("E");
      return {
        year: years,
        month: months + 1,
        day: date,
        weekCh: "周" + this.data.weeksCh[wn === 7 ? 0 : wn],
        formatDay: time.format(FORMAT_TYPE)
      };
    },

    // 去重
    _uniq(array) {
      var temp = [];
      var index = [];
      var l = array.length;
      for (var i = 0; i < l; i++) {
        for (var j = i + 1; j < l; j++) {
          if (JSON.stringify(array[i]) === JSON.stringify(array[j])) {
            i++;
            j = i;
          }
        }
        temp.push(array[i]);
        index.push(i);
      }
      return temp;
    },

    // 设置入住
    _setEnterDate(o) {
      o.selected = {
        type: "enter",
        cls: "item-enter",
        label: ENTER_WORD
      };
      return o;
    },

    // 设置离店
    _setLeaveDate(o) {
      o.selected = {
        type: "leave",
        cls: "item-leave",
        label: LEAVE_WORD
      };
      return o;
    },

    // 设置包含
    _setContainDate(o) {
      o.selected = {
        type: "contain",
        cls: "item-in",
        label: ""
      };
      return o;
    },

    // 清除所有选择的
    _cleanAllSelectedDate(availableMonths) {
      availableMonths.forEach(o => {
        o.days.forEach(d => {
          d.selected = null;
        });
      });
      return availableMonths;
    },

    // 点击
    onPressDay(e, type) {
      console.log(e, type);
      let currentItem;
      if (type) {
        this.availableMonths.forEach(o => {
          o.days.forEach(d => {
            if (d.visible && d.formatDay && d.formatDay.indexOf(e) > -1) {
              currentItem = d;
            }
          });
        });
      } else {
        const idx = e.currentTarget.dataset.eventid.split("-")[1];
        const panelidx = e.currentTarget.dataset.eventid
          .split("-")[0]
          .split("_")[1];
        currentItem = this.availableMonths[panelidx].days[idx];
      }

      if (currentItem.visible == false) return;
      let store = [];

      this.availableMonths.forEach(o => {
        o.days.forEach(d => {
          if (d.selected) {
            store.push({ ...d.selected, formatDay: d.formatDay });
          }
        });
      });
      store = this._uniq(store);
      //重构逻辑
      if (!store.length) {
        this.availableMonths = this._cleanAllSelectedDate(this.availableMonths);
        currentItem = this._setEnterDate(currentItem);
        this.hasLeaveDate = false;
        this.start1 = currentItem.formatDay;
        this.start = currentItem.formatDay.substr(5).replace(/-/, "月") + "日";
        this.end = "";
        this.total = "";
      } else if (store.length === 1) {
        if (store[0].formatDay !== currentItem.formatDay) {
          if (
            moment(currentItem.formatDay).unix() >
            moment(store[0].formatDay).unix()
          ) {
            currentItem = this._setLeaveDate(currentItem);
            this.availableMonths.forEach(o => {
              o.days.forEach(d => {
                if (
                  moment(d.formatDay).unix() >
                    moment(store[0].formatDay).unix() &&
                  moment(d.formatDay).unix() <
                    moment(currentItem.formatDay).unix()
                ) {
                  d = this._setContainDate(d);
                }
              });
            });
            this.start1 = store[0].formatDay;
            this.end1 = currentItem.formatDay;
            this.total1 =
              (new Date(currentItem.formatDay).getTime() -
                new Date(store[0].formatDay).getTime()) /
              (1000 * 60 * 60 * 24);
            this.total = this.total1 + "天";
            this.week1 =
              "周" +
              this.data.weeksCh[
                moment(store[0].formatDay).format("E") === "7"
                  ? 0
                  : moment(store[0].formatDay).format("E")
              ];
            this.week2 =
              "周" +
              this.data.weeksCh[
                moment(currentItem.formatDay).format("E") === "7"
                  ? 0
                  : moment(currentItem.formatDay).format("E")
              ];
            this.start = store[0].formatDay.substr(5).replace(/-/, "月") + "日";
            this.end =
              currentItem.formatDay.substr(5).replace(/-/, "月") + "日";
            this.hasLeaveDate = true;
          } else {
            console.log(store, "store");
            this.availableMonths.forEach(o => {
              o.days.forEach(d => {
                d.selected = null;
              });
            });
            currentItem = this._setEnterDate(currentItem);
            this.start1 = currentItem.formatDay;
            this.start =
              currentItem.formatDay.substr(5).replace(/-/, "月") + "日";
            this.end = "";
            this.total = "";
            this.hasLeaveDate = false;
          }
        }
      } else {
        this.availableMonths.forEach(o => {
          o.days.forEach(d => {
            d.selected = null;
          });
        });
        currentItem = this._setEnterDate(currentItem);
        this.start1 = currentItem.formatDay;
        this.start = currentItem.formatDay.substr(5).replace(/-/, "月") + "日";
        this.end = "";
        this.total = "";
        this.hasLeaveDate = false;
      }
    }
  }
};
</script>
<style scoped lang="less">
.calendar-container {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background: #fff;
  z-index: 1;
  .calendar-show {
    position: fixed;
    top: 0;
    width: 100%;
    height: 148rpx;
    background: #fff;
    border-top: 1rpx solid #e5e5e5;
    border-bottom: 1rpx solid #e5e5e5;
    display: flex;
    justify-content: space-around;
    align-items: center;
    z-index: 1;
    .time-title {
      font-size: 28rpx;
      height: 40rpx;
      line-height: 40rpx;
      color: #999999;
      text-align: center;
    }
    .time-show {
      height: 50rpx;
      font-size: 36rpx;
      font-weight: 400;
      color: #333333;
      line-height: 50rpx;
      text-align: center;
    }
    .long-box {
      width: 120rpx;
      height: 50rpx;
      border-radius: 5rpx;
      border: 2rpx solid #3ebbff;
      color: #3ebbff;
      text-align: center;
      font-size: 28rpx;
      line-height: 50rpx;
    }
    .item {
      flex: 1;
    }
  }
}

.calendar-weeks-list {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  box-sizing: border-box;
  padding: 20rpx 0;
  background-color: #eee;
  position: fixed;
  top: 150rpx;
  left: 0;
  right: 0;
}

.calendar-weeks-item {
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  flex: 1;
}

.calendar-weeks-item-text {
  color: #474747;
  font-size: 26rpx;
}

.calendar-body {
  padding-top: 250rpx;
}

.calendar-body-item {
  margin-bottom: 130rpx;
}

.calendar-header-wrap {
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  padding: 20rpx 0;
  border-top: 1rpx solid #e5e5e5;
}

.calendar-header-text {
  font-size: 26rpx;
}

.calendar-day-list {
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  box-sizing: border-box;
  flex-wrap: wrap;
}

.calendar-day-item {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  height: 80rpx;
  box-sizing: border-box;
  /*padding-top: 15rpx;*/
  flex: 0 0 107rpx;
  margin: 10rpx 0;
  .item-1 {
    height: 80rpx;
    line-height: 80rpx;
    font-size: 28rpx;
  }
}

.calendar-day-item.selected-item {
  background-color: #A0DDFD;
  color: #333;
}
.calendar-day-item.item-enter,
.calendar-day-item.item-leave {
  background-color: #A0DDFD;
  color: #333;
  .item-1 {
    width: 100%;
    height: 40rpx;
    line-height: 40rpx;
    text-align: center;
  }
  .desc-text {
    width: 100%;
    height: 34rpx;
    line-height: 34rpx;
    font-size: 24rpx;
    text-align: center;
  }
}
.calendar-day-item.item-enter {
  border-radius: 16rpx 0 0 16rpx;
}

.calendar-day-item.item-leave {
  border-radius: 0 16rpx 16rpx 0;
}
.calendar-day-item.item-in {
  background: #A0DDFD;
  color: #333;
}

.calendar-day-item.visible-out text {
  visibility: hidden;
}

.tip-wrap {
  position: fixed;
  bottom: 60rpx;
  left: 50%;
  transform: translate3d(-50%, 0, 0);
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  padding: 10rpx;
  border-radius: 6rpx;
  background-color: #6d6d6d;
}

.tip-wrap text {
  color: #fff;
  font-size: 24rpx;
}
.button-box {
  position: fixed;
  bottom: 0rpx;
  background: #fff;
  width: 100%;
  height: 120rpx;
  box-shadow: 0rpx -2rpx 30rpx 0rpx rgba(0, 0, 0, 0.1);
  display: flex;
  .cancel {
    width: 200rpx;
    height: 90rpx;
    background: #666666;
    border-radius: 5rpx;
    margin: 15rpx 25rpx;
    text-align: center;
    line-height: 90rpx;
    font-weight: 400;
    color: #ffffff;
    font-size: 36rpx;
  }
  .submit {
    width: 475rpx;
    height: 90rpx;
    background: #3ebbff;
    border-radius: 5rpx;
    margin: 15rpx 25rpx;
    text-align: center;
    line-height: 90rpx;
    font-weight: 400;
    color: #ffffff;
    font-size: 36rpx;
  }
}
</style>
