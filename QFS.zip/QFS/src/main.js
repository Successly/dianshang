import Vue from 'vue'
import App from './App'

Vue.config.productionTip = false
App.mpType = 'app'

const app = new Vue(App)
app.$mount()

Vue.prototype.globalData = getApp().globalData

Vue.prototype.globalData.globalUrl = 'https://qfsapp.rainfn.com/qfs'
// Vue.prototype.globalData.globalUrl = 'http://qfs.dev.rainfn.com'

var Fly = require('flyio/dist/npm/wx')
var fly = new Fly()
Vue.prototype.$http = fly
