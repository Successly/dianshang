// 学习资料

var app = getApp()

var http = require('../../../utils/httpHelper')

Page({

  /**
   * 页面的初始数据
   */
  data: {

    // 选中
    activezz: true,  
    activedz: false, 
    
    // 返回按钮状态
    scrollTop: 0,
    backTopValue:false,

    zzdisplay: true,
    dzdisplay: false,

    // 纸质
    // 分页
    zzpageNum: 1, // 当前页
    zzpageSize: 8, // 每页条数
    zzList: [],
    zzhasMoreData: true,


    // 电子
    // 分页
    dzpageNum: 1, // 当前页
    dzpageSize: 8, // 每页条数
    dzList: [],
    dzhasMoreData: true,

    // 资料类型 1-纸质 2-电子
    type: 1,

    value: '搜索',

    keyword: '',
    


  },

  // 导航栏切换
  zzdata () {
    this.setData({
      activezz: true,  
      activedz: false,
      zzdisplay: true,
      dzdisplay: false,
      zzpageNum: 1,
      type: 1
    })

    this.zzinitList('', 0, 800)
  },

  dzdata () {
    this.setData({
      activezz: false,  
      activedz: true,
      zzdisplay: false,
      dzdisplay: true,
      dzpageNum: 1,
      type: 2
    })

    this.dzinitList('', 0, 800)
  },

  // 监听滚动条坐标
  onPageScroll: function (e) {
    var that = this
    var scrollTop = e.scrollTop
    var backTopValue = scrollTop > 280 ? true : false
    that.setData({
      backTopValue: backTopValue
    })
  },
  

  // 返回顶部
  goback () {
    // 控制滚动
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 300
    })
  },

  // 点击--每项
  gotoGoodDetail (e) {
    var id = e.currentTarget.dataset.id

    app.goto('navigateTo', 'index/goodDetail/goodDetail', {'fromStudydata': 1, 'id': id})
  },

  // 点击--搜索
  gotohotSearch () {
    app.goto('navigateTo', 'index/hotsearch/hotsearch', {'fromStudyData': 1, 'type': this.data.type})
  },


  // 获取列表
  zzinitList (message, load, time) {
    var param1 = {
      'keyword': this.data.keyword,
      'type': this.data.type,  // 1-纸质，2-电子
      'pageNum': this.data.zzpageNum, // 当前页
      'pageSize': this.data.zzpageSize, // 每页条数
    }

    http.httpGet("/resource/list", param1, app.globalData.userId, (res) => {    
      // 加载
      if(load == 1) {

        wx.showToast({
          title: message,
          icon: 'loading',
          duration: time,
          success: function () {
            if(message == '正在刷新数据') {
              wx.stopPullDownRefresh()            
            }
          }
        })
      }

      if(res.code == 0) {
        console.log('------获取资料列表成功-----', res)
        
     
        if(res.data && res.data.list.length) {
          // 当前页展示的数据
          var hasList = this.data.zzlist
          
          if (this.data.zzpageNum == 1) {
            hasList = []
          }

          // 获取新数据
          var zzlist = res.data.list

          // 分页加载
          if (zzlist.length < this.data.zzpageSize) {
            this.setData({
              zzlist: hasList.concat(zzlist),
              zzhasMoreData: false
            })
          } else {
            this.setData({
              zzlist: hasList.concat(zzlist),
              zzhasMoreData: true,
              zzpageNum: this.data.zzpageNum + 1
            })
          }
          
        }
     
        
    
      
      } else {
        console.log('------获取资料列表失败-----', res)
      }

    })
  },

  dzinitList (message, load, time) {
    var param1 = {
      'keyword': this.data.keyword,
      'type': this.data.type,  // 1-纸质，2-电子
      'pageNum': this.data.dzpageNum, // 当前页
      'pageSize': this.data.dzpageSize, // 每页条数
    }

    http.httpGet("/resource/list", param1, app.globalData.userId, (res) => {   

      // 加载
      if(load == 1) {

        wx.showToast({
          title: message,
          icon: 'loading',
          duration: time,
          success: function () {
            if(message == '正在刷新数据') {
              wx.stopPullDownRefresh()            
            }
          }
        })
      }

      if(res.code == 0) {
        console.log('------获取资料列表成功-----', res)
        
        if(res.data && res.data.list.length) {
          // 当前页展示的数据
          var hasList = this.data.dzlist

          if (this.data.dzpageNum == 1) {
            hasList = []
          }

          // 获取新数据
          var dzlist = res.data.list

          // 分页加载
          if (dzlist.length < this.data.dzpageSize) {
            this.setData({
              dzlist: hasList.concat(dzlist),
              dzhasMoreData: false
            })
          } else {
            this.setData({
              dzlist: hasList.concat(dzlist),
              dzhasMoreData: true,
              dzpageNum: this.data.dzpageNum + 1
            })
          }
          
        }
        
    
      
      } else {
        console.log('------获取资料列表失败-----', res)
      }
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 从搜索页来
    if(options.fromhotsearch) {
      this.setData({
        value: options.value == '' ? '搜索' : options.value,
        keyword: options.value,
        type: options.type
      })

      if(options.type == 2) {
        this.setData({
          activezz: false,  
          activedz: true,
          zzdisplay: false,
          dzdisplay: true,
          dzpageNum: 1
        })
      } else {
        this.setData({
          zzpageNum: 1
        })
      }

    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

    if(this.data.type == 1) {
      this.zzinitList('正在加载数据...', 1, 1000)
    } else {
      this.dzinitList('正在加载数据...', 1, 1000)
    }

   
  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    if(this.data.type == 1) {
      this.data.zzpageNum = 1
      this.zzinitList('正在刷新数据', 1, 800)
    } else {
      this.data.dzpageNum = 1
      this.dzinitList('正在刷新数据', 1, 800)
    }
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
      if(this.data.type == 1) {

        if (this.data.zzhasMoreData) {
          this.zzinitList('正在加载数据...', 1, 800)
        }

      } else {

        if (this.data.dzhasMoreData) {
          this.dzinitList('正在加载数据...', 1, 800)
        }

      }
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})