// 下单页
var app = getApp()
var http = require('../../../utils/httpHelper')

Page({

    /**
     * 页面的初始数据
     */
    data: {
        goodInfo: null
    },

    // 点击--购买规则
    gotoBuyRule() {
        app.goto('navigateTo', 'index/buyRule/buyRule')
    },
    goSetUserInfo() {
        http.httpGet(`/user/detail/${app.globalData.userId}`, null, app.globalData.userId, (res) => {
            if (res.code == 0) {
                console.log('------获取用户信息成功-----', res)
                app.globalData.users = res.data;
                app.globalData.usertype = res.data.type;
                console.log('11111111111', app.globalData.users.eduLevel);
                this.setData({
                    userinfo: res.data
                })
                if (res.data.type !== null) {
                    app.goto('navigateTo', 'my/changeuserinfo/changeuserinfo', this.data.userinfo)
                }else{
                  app.goto('navigateTo', 'my/changeinfo/changeinfo')
                }
            } else {
                console.log('------获取用户信息失败-----', res)
                app.goto('navigateTo', 'my/changeinfo/changeinfo')
            }
        })
    },

    initList() {
        http.httpGet(`/user/detail/${app.globalData.userId}`, null, app.globalData.userId, (res) => {
            if (res.code == 0) {
                console.log('------获取用户信息成功-----', res)
                this.setData({
                    userinfo: res.data
                })

            } else {
                console.log('------获取用户信息失败-----', res)
            }
        })
    },


    // 点击--支付
    payHandle() {

        http.httpGet(`/resource/buy/${this.data.goodInfo.id}`, null, app.globalData.userId, (res) => {
            console.log(res)
            if (res.code == 0) {
                console.log('------购买资料接口成功-----', res)

                // 成功--调微信支付
                if (res.data) {
                    wx.requestPayment({
                        'timeStamp': res.data.timeStamp,
                        'nonceStr': res.data.nonceStr,
                        'package': res.data.package,
                        'signType': "MD5",
                        'paySign': res.data.paySign,
                        'success': function (res) {

                            wx.showToast({
                                title: '支付成功',
                                icon: 'success',
                                duration: 3000
                            })

                            // 跳转--我的-我的资料
                            app.goto('navigateTo', '')


                        },
                        'fail': function (res) {
                            console.log("支付失败")
                        }
                    })
                }

            } else {
                console.log('------购买资料接口失败-----', res)
            }

        })

    },


    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        if (options.fromGoodDetail) {
            var goodInfo = wx.getStorageSync('goodInfo')
            this.setData({
                goodInfo: goodInfo,
                yunfei: goodInfo.isFreeDelivery == 1 ? 0 : 6
            })

        }

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.initList()
    },


    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})