// pages/index/demand/demand.js
var app = getApp()
// var config = require('../../../config.js')
var http = require('../../../utils/httpHelper')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    user: [],
    dzhasMoreData: true,
    backTopValue: false,
    // switch1Change: false,
    // checked: false,
    type: 2,
    inputvalue: '',
    isRelate: 0,
    pageNum: 1,
    pageSize: 10
  },
  // 监听滚动条坐标
  onPageScroll: function(e) {
    var that = this
    var scrollTop = e.scrollTop
    var backTopValue = scrollTop > 10 ? true : false
    that.setData({
      backTopValue: backTopValue
    })
  },

  // 返回顶部
  goback() {
    // 控制滚动
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 300
    })
    this.setData({ backTopValue: false});
  },

  //点击到我的咨询页面
  question(e) {
    var id = e.currentTarget.dataset.id;
    app.goto('navigateTo', 'index/demand/question/question', {
      id: id
    })
  },

  dynamicInputValue: function(e){
    this.setData({inputvalue:e.detail.value})
  },

  search: function(){
    this.getData('init');
  },

  //点击切换按钮
  switch1Change(e) {
    if (e.detail.value == false) {
      this.setData({'isRelate': 0});
    } else {
      this.setData({'isRelate': 1});
    }

    this.getData('init');
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.getData('init');
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  getData:function(mode){
    var that = this;
    if(mode === 'init'){
      that.setData({ pageNum: 0, dzhasMoreData: true, user: [], backTopValue:false});
    }
    
    if (that.data.dzhasMoreData){
      var param = {
        term: that.data.inputvalue,
        isRelate: that.data.isRelate,
        pageSize: that.data.pageSize,
        pageNum: that.data.pageNum
      }
      wx.showLoading({
        title: '加载数据...',
      });
      http.httpGet(`/user/search`, param, app.globalData.userId, (res) => {
        wx.hideLoading();
        console.log(res)
        var cPage = that.data.pageNum + 1;
        var cUser = that.data.user || [];
        that.setData({pageNum: cPage});
        if(cPage >= res.data.totalPage){
          that.setData({'dzhasMoreData':false});
        }
        that.setData({

          user: cUser.concat(res.data.list)
        })
      },() => {
        wx.hideLoading();
      })
    }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    this.getData('init');
    wx.stopPullDownRefresh();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    this.getData();
    },
  
    /**
     * 用户点击右上角分享
     */
  onShareAppMessage: function() {

  }
})