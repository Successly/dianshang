// pages/index/demand/question/my-question/my-question.js
var app = getApp()
var http = require('../../../../../utils/httpHelper')
const innerAudioContext = wx.createInnerAudioContext()
var config = require('../../../../../config')
const qiniuUploader = require("../../../../../utils/qiniuUploader")

// 初始化七牛相关参数
function initQiniu() {
    var options = {
        region: 'ECN', // 华东区，生产环境应换成自己七牛帐户bucket的区域
        uptokenURL: 'https://wxapp.yanyanbiji.com/yyapp/config/token', // 生产环境该地址应换成自己七牛帐户的token地址，具体配置请见server端
        domain: 'http://img.rainfn.com/' // 生产环境该地址应换成自己七牛帐户对象存储的域名
    };
    qiniuUploader.init(options);
}

const recorderManager = wx.getRecorderManager()
var util = require('../../../../../utils/util')
Page({

    /**
     * 页面的初始数据
     */
    data: {

        //textarea层级问题
        onFocus: false,
        isShow: true,
        //添加图片
        src: '../../../assets/camera.png',
        //语音图片
        src1: '../../../assets/yuyin.png',
        // 下拉框的选择
        // 1-入学时间
        selectTime: false,


        // 下拉框的选择
        // 选择无时，小纸条的标签不显示
        timeList: ['6', '12', '24', '48'],
        timeIndex: 0,
        ok: false,
        //上传图片个数
        // imgarr: [],

        // 七牛
        // 图片地址
        imageObject: {},
        imgarr: [],
        question: false,
        //输入框输入的值
        titlevalue: null,
        subjectvalue: null,
        coursevalue: null,
        selectedTime: 6,
        textvalue: '',
        id: 0,
        price: 0,
        //语音数据
        // 音频
        audioUrl: '',
        allow: true,

        tishi: false, // 超出1条语音提示

        reSuccess: false,

        isSpeaking: false,
        content: [],
        imageList: [],
        showModalStatus1: false,
        showModalStatus: false,
        voices: [], //音频数组
        isVoice: false,

        tsColor: '#49B0FF',
        //语音数据集合
        voice: [],
        das: null,
        vo: [{
            filePath: '123456',
            duration: 3,
            size: 231
        }],

        nickNameShow: false, // 问题标题
        nickName: '', // 问题标题
        nickNameTishi: '问题标题不能为空',

        zhuanyeShow: false, // 专业
        zhuanye: '', // 专业
        zhuanyeTishi: '问题专业不能为空',

        problemScourShow: false, //科目
        problemScour: '',
        problemScourTishi: '问题科目不能为空',
        disabled: false,
        audiosNow: []
    },

    // 下拉框
    // 时限选择
    showTimeBox() {
        this.setData({
            selectTime: !this.data.selectTime,
            // selectTime: false,
            selectSchool: false,
            selectYuanxi: false,
            selectXl: false,
            selectMoney: false,
            selectTag: false,
            // isShow: false,
            onFocus: false
        })
        console.log(this.data.selectedTime);
    },
    bindTimeChange(e) {
        this.setData({
            timeIndex: e.detail.value
        })
    },
    timeSelect(e) {
        var name = e.currentTarget.dataset.name
        this.setData({
            selectedTime: name,
            selectTime: false
        })
        console.log(this.data.selectedTime);
    },


    //问题标题输入值
    nickNameInput(e) {

        this.setData({
            titlevalue: e.detail.value,
            selectTime: false,
            selectSchool: false,
            selectYuanxi: false,
            // selectXl: false,
            // selectMoney: false,
            // selectTag: false
        })
    },

    // 失去焦点
    nickNameBlur: function (e) {
        // 空
        if (!e.detail.value.length) {

            this.setData({
                nickNameShow: true,
                nickNameTishi: '问题标题不能为空',
                // nickName:false
            })

        } else if (e.detail.value.length > 20) {

            this.setData({
                nickNameShow: true,
                nickNameTishi: '问题标题不能超过20个字',
                // nickName: false
            })

        } else {
            this.setData({
                nickNameShow: false,
                nickNamePass: true,
                // nickName: true
            })
        }
    },

    // 获取焦点
    nickNameFocus: function () {
        this.setData({
            nickNameShow: false,
            nickNameTishi: '问题标题不能为空',
            // nickName: false
        })
    },

    // 问题专业
    zhuanyeInput(e) {

        this.setData({
            zhuanye: e.detail.value,
            selectTime: false,
            selectSchool: false,
            selectYuanxi: false,
            // selectXl: false,
            // selectMoney: false,
            // selectTag: false
        })
    },

    // 失去焦点
    zhuanyeBlur: function (e) {
        // 空
        if (!e.detail.value.length) {

            this.setData({
                zhuanyeShow: true,
                zhuanyeTishi: '问题专业不能为空',
                // zhuanye: false
            })

        } else if (e.detail.value.length > 10) {

            this.setData({
                zhuanyeShow: true,
                zhuanyeTishi: '问题专业不能超过10个字',
                // zhuanye:false
            })

        } else {
            this.setData({
                zhuanyeShow: false,
                zhuanyePass: true,
                // zhuanye: true
            })
        }
    },

    // 获取焦点
    zhuanyeFocus: function () {
        this.setData({
            zhuanyeShow: false,
            zhuanyeTishi: '问题专业不能为空',
            // zhuanye: false
        })
    },

    //问题科目输入值
    problemScourInput(e) {

        this.setData({
            problemScour: e.detail.value,
            selectTime: false,
            selectSchool: false,
            selectYuanxi: false,
            // selectXl: false,
            // selectMoney: false,
            // selectTag: false
        })
    },

    // 失去焦点
    problemScourBlur: function (e) {
        // 空
        if (!e.detail.value.length) {

            this.setData({
                problemScourShow: true,
                problemScourTishi: '问题科目不能为空',
                //  problemScour: false

            })

        } else if (e.detail.value.length > 10) {

            this.setData({
                problemScourShow: true,
                problemScourTishi: '问题科目不能超过10个字',
                // problemScour: false
            })

        } else {
            this.setData({
                problemScourShow: false,
                problemScourPass: true,
                //  problemScour: true
            })
        }
    },

    // 获取焦点
    problemScourFocus: function () {
        this.setData({
            problemScourShow: false,
            problemScourTishi: '问题科目不能为空',
            //  problemScour: false
        })
    },

    //输入问题描述
    textarea(e) {
        console.log(e),
            this.setData({
                // isShow: true,
                // onFocus:true,
                textvalue: e.detail.value
            })
        console.log(e.detail.value);
    },
    filterEmotionText(str){
       return str.replace(/[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\A9|\AE]\u3030|\uA9|\uAE|\u3030/ig, "");
    },
    //点击确认咨询按钮
    confirmConsulting() {
        // if (this.data.textvalue !='') {
        if (this.data.titlevalue && this.data.zhuanye && this.data.problemScour) {
            var that = this
            wx.showModal({
                title: "温馨提示",
                content: '确认咨询后不可修改，是否确认咨询内容',
                success(res) {
                    if (res.confirm) {
                        console.log('打印图片1' + that.data.imgarr)
                        var pros = {
                            title: that.filterEmotionText(that.data.titlevalue),
                            specialty: that.filterEmotionText(that.data.zhuanye),
                            course: that.filterEmotionText(that.data.problemScour),
                            expireTime: that.data.timeList[that.data.timeIndex],
                            detail: that.filterEmotionText(that.data.textvalue),
                            targetId: parseInt(that.data.id),
                            price: parseFloat(that.data.price),
                            images: that.data.imgarr,
                            audios: that.data.audiosNow
                        }
                        // 提交发布问题
                        http.httpPost(`question/publish`, pros, app.globalData.userId, (res) => {
                            if (res.code == 0) {
                                console.log('------确认咨询提交成功-----', res)
                                var openid = app.globalData.openId
                                console.log('---openid:' + openid)
                                var payparam = {
                                    questionId: res.data.id,
                                    payCode: res.data.payCode,
                                    totalAmount: 0.01,
                                    price: 1,
                                    openId: openid,
                                    type: 1
                                }
                                http.httpPost(`question/pay`, payparam, app.globalData.userId, (res) => {
                                    console.log(res);
                                    if (res.code == 0) {
                                        console.log('------购买问题接口成功-----', res)
                                        // 成功--调微信支付
                                        if (res.data) {
                                            wx.requestPayment({
                                                'timeStamp': res.data.timeStamp,
                                                'nonceStr': res.data.nonceStr,
                                                'package': res.data.package,
                                                'signType': "MD5",
                                                'paySign': res.data.paySign,
                                                'success': function (res) {
                                                    wx.showToast({
                                                        title: '支付成功',
                                                        icon: 'success',
                                                        duration: 3000
                                                    })
                                                    wx.navigateBack({
                                                        delta: 2
                                                    })
                                                },
                                                'fail': function (res) {
                                                    console.log("支付失败")
                                                }
                                            })
                                        }
                                        // --微信支付结束
                                    } else {
                                        console.log('------购买问题接口失败-----', res)
                                    }
                                })
                                // qusetionpay请求结束
                            } else {
                                wx.showToast({
                                    title: '提问失败',
                                    icon: 'none',
                                    duration: 3000
                                })
                                console.log('------确认咨询接口失败-----', res)
                            }
                        })
                        // 提交发布接口结束
                    }
                }
            })
        } else {
            wx.showToast({
                title: '请先完善您的提问内容',
                icon: 'none',
                duration: 1800
            })
        }
    },
    // 七牛上传图片
    didPressChooesImage: function () {
        var that = this;
        didPressChooesImage(that);
        console.log(that.data.imgarr)
    },
    // 点击删除该图片
    deletePhoto(e) {
        var index1 = e.currentTarget.dataset.index
        var imgarr = this.data.imgarr
        imgarr.map((item, index, arr) => {
            if (index == index1) {
                imgarr.splice(index, 1)
            }
        })
        // 重新渲染
        this.setData({
            imgarr: imgarr
        })
    },


    // 点击--播放录音
    play() {

        innerAudioContext.play()

        wx.showToast({
            title: '开始播放',
            icon: 'success',
            duration: 1000
        })

        innerAudioContext.onError((res) => {

            console.log(res.errMsg)
            console.log(res.errCode)
        })


    },

    // 点击--删除录音
    closeHandle() {
        console.log("heh");
        this.setData({
            isVoice: false,
            audioUrl: '',
            allow: true,
            tishi: false,
            voices: [],
        })
    },

    //开始录音
    recordStart() {
        // 语音、文本--任选一条
        if (!this.data.content.length) {
            this.setData({
                tsColor: '#49B0FF'
            })

            if (this.data.voices.length < 1) {

                if (this.data.allow) {

                    var _this = this;
                    _this.setData({
                        isSpeaking: true,
                        isVoice: false
                    })

                    const options = {
                        duration: 60000, //指定录音的时长，单位 ms
                        sampleRate: 16000, //采样率
                        numberOfChannels: 1, //录音通道数
                        encodeBitRate: 96000, //编码码率
                        format: 'mp3', //音频格式，有效值 aac/mp3
                        frameSize: 50, //指定帧大小，单位 KB
                    }

                    //开始录音
                    recorderManager.start(options);
                    recorderManager.onStart(() => {
                        console.log('------开始录音-----')
                        var startTime = +new Date()
                        this.setData({
                            startTime: startTime
                        })
                    });

                    //错误回调
                    recorderManager.onError((res) => {
                        console.log(res);
                    })

                }

            } else {

                this.setData({
                    tishi: true,
                    allow: false
                })

            }

        } else {
            this.setData({
                tsColor: 'red'
            })
        }

    },

    // 录音结束
    recordEnd: function () {

        recorderManager.stop();
        recorderManager.onStop((res) => {
            var tempFilePath = res.tempFilePath;
            console.log(tempFilePath)
            var Duration = Math.floor(res.duration / 1000);
            var fileSize = res.fileSize;
            var that = this;
            wx.saveFile({
                tempFilePath: tempFilePath,
                success: function (lures) {
                    //持久路径
                    ;
                    var savedFilePath = lures.savedFilePath
                    console.log("savedFilePath: " + savedFilePath)
                    var ads = [{
                        url: savedFilePath,
                        duration: Duration,
                        size: fileSize
                    }];
                    console.log(ads)
                    that.setData({
                        isVoice: true,
                        isSpeaking: false,
                        voices: ads,
                        savedFilePath: savedFilePath
                    })
                    // 七牛上传语音
                    initQiniu();
                    // 微信 API 选文件
                    var audioFilePath = that.data.savedFilePath
                    // 交给七牛上传
                    qiniuUploader.upload(audioFilePath, (res) => {
                        console.log('------upload qiniu success.')
                        console.log(res)
                        // that.setData({
                        //   audioUrl: res.imageURL,
                        // })
                        audioFilePath = res.imageURL
                        console.log('----audioFilePath:' + audioFilePath)
                        var audios = []
                        audios.push({
                            url: audioFilePath
                        })
                        that.setData({
                            audiosNow: audios
                        })
                    })
                    // innerAudioContext.src = savedFilePath;
                    // innerAudioContext.onPlay(() => {

                    //   console.log('开始播放')
                    // })
                    // innerAudioContext.onError((res) => {
                    //   console.log(res.errMsg)
                    //   console.log(res.errCode)
                    // })
                }
            })
            wx.showToast({
                title: '恭喜!录音成功',
                icon: 'success',
                duration: 1000
            })
            console.log('停止录音', res.tempFilePath)
            this.setData({
                audioUrl: res.tempFilePath
            })

        })
    },
    // 录音
    touchStart() {
        this.start();
    },


    touchEnd() {
        this.stop()
    },


    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        console.log(options)
        // console.log(app.globalData.imgUrl);
        this.setData({
            id: options.id,
            price: options.price
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})

function didPressChooesImage(that) {
    initQiniu();

    if (that.data.imgarr.length == 2) {

        wx.showToast({
            icon: 'loading',
            title: '最多添加2张图片哦',
            duration: 1200
        })

    } else {

        // // 微信 API 选文件
        wx.chooseImage({
            count: 1,
            sizeType: ['compressed'],
            success: function (res) {
                var filePath = res.tempFilePaths[0];
                var files = res.tempFilePaths
                console.log('上传', filePath)


                var imgarr = that.data.imgarr
                console.log(that.data.imgarr)
                // 交给七牛上传
                qiniuUploader.upload(filePath, (res) => {
                    imgarr.push({
                        url: res.imageURL
                    })
                    that.setData({
                        'imageObject': res,
                        'imgarr': imgarr
                    });
                }, (error) => {
                    console.error('error: ' + JSON.stringify(error));
                });


            }
        })

    }
}