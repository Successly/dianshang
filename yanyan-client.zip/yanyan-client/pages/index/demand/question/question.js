// pages/index/question/question.js
var app = getApp()
var http = require('../../../../utils/httpHelper')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    mines: [],
    mine: null
  },

  //点击向他提问按钮
  question(e) {
    console.log(e)
    // wx.navigateTo({
    //   url: './my-question/my-question',
    // })
    app.goto("navigateTo",'index/demand/question/my-question/my-question',{
      price:e.currentTarget.dataset.price,
      id:e.currentTarget.dataset.id
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var id = options.id;
    // console.log(options.id);
    const that = this;
    http.httpGet(`/user/detail/${id}`, null, app.globalData.userId, (res) => {
      console.log(res.data);//obj
      that.setData({
        mine: res.data,
        mines: [res.data]
      })
      console.log(this.data.mines);
    })
  },
  

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})