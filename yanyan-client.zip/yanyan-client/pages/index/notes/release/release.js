// 发布小纸条
var util = require('../../../../utils/util')
var app = getApp()
var http = require('../../../../utils/httpHelper')
const qiniuUploader = require("../../../../utils/qiniuUploader")

const recorderManager = wx.getRecorderManager()
const innerAudioContext = wx.createInnerAudioContext()


// 初始化七牛相关参数
function initQiniu() {
  var options = {
    region: 'ECN', // 华东区，生产环境应换成自己七牛帐户bucket的区域
    uptokenURL: 'https://wxapp.yanyanbiji.com/yyapp/config/token', // 生产环境该地址应换成自己七牛帐户的token地址，具体配置请见server端
    domain: 'http://img.rainfn.com/' // 生产环境该地址应换成自己七牛帐户对象存储的域名
  };
  qiniuUploader.init(options);
}

Page({

  /**
   * 页面的初始数据
   */
  data: {
   // 下拉框的选择
    // 1-入学时间
    selectTime: false,
    selectedTime: '学习',
    
    // 下拉框的选择
    // 选择无时，小纸条的标签不显示
    timeList: ['无', '学习', '生活', '情感'],

    // 音频
    audioObject: {},
    audioUrl: '',
    allow: true,
    tempFilePaths:[],
    savedFilePath:'',

    tishi: false,  // 超出1条语音提示

    reSuccess: false,

    isSpeaking: false,
    content: false,
    imageList: [],
    showModalStatus1: false,
    showModalStatus: false,
    voices: [],//音频数组
    isVoice: false,

    tsColor: '#49B0FF'

  },


  // 下拉框
  // 1-入学时间
  showTimeBox () {
    this.setData({
      selectTime: !this.data.selectTime,
      // selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false,
    })
  },

  timeSelect (e) {
    var name = e.currentTarget.dataset.name
    this.setData({
      selectedTime: name,
      selectTime: false
    })
  },
  
  // 文本
  taValue (e) {
    if(this.data.voices.length == 1) {
      this.setData({
        tsColor: 'red'
      })
    } else {
      this.setData({
        content: e.detail.value,
        tsColor: '#49B0FF'
      })
    }

    if(e.detail.value.length == 0) {
      this.setData({
        tsColor: '#49B0FF'
      })
    }
   
  },


  //开始录音
  recordStart () {
    // 语音、文本--任选一条
    if(!this.data.content.length) {
      this.setData({
        tsColor: '#49B0FF'
      })

      if(this.data.voices.length < 1) {

        if(this.data.allow) {

          var _this = this;
          _this.setData({
            isSpeaking: true,
            isVoice: false
          })
        
          const options = {
            duration: 60000,//指定录音的时长，单位 ms
            sampleRate: 16000,//采样率
            numberOfChannels: 1,//录音通道数
            encodeBitRate: 96000,//编码码率
            format: 'mp3',//音频格式，有效值 aac/mp3
            frameSize: 50,//指定帧大小，单位 KB
          }

          //开始录音
          recorderManager.start(options);
          recorderManager.onStart(() => {
            console.log('------开始录音-----')
            var startTime = +new Date()
            this.setData({
              startTime: startTime
            })
          });

          //错误回调
          recorderManager.onError((res) => {
            console.log(res);
          })

        } 

      } else {

        this.setData({
          tishi: true,
          allow: false
        })

      }

    } else {
      this.setData({
        tsColor: 'red'
      })
    }

  },

  // 录音结束
  recordEnd: function () {
    recorderManager.stop();

    recorderManager.onStop((res) => {
      var tempFilePath = res.tempFilePath;
      var Duration = Math.floor(res.duration / 1000) ;
      var fileSize = res.fileSize;
      var that = this;
      var voices = {};
      wx.saveFile({
  
        tempFilePath: tempFilePath,
        success: function (lures) {
          //持久路径
          var savedFilePath = lures.savedFilePath
          console.log("savedFilePath: " + savedFilePath)
          voices = [{ filePath: savedFilePath, duration: Duration, size: fileSize }];
          that.setData({
            isVoice: true,
            isSpeaking: false,
            voices: voices,
            savedFilePath: savedFilePath
          })

          innerAudioContext.src = savedFilePath;
          innerAudioContext.onPlay(() => {

            console.log('开始播放')
          })
          innerAudioContext.onError((res) => {
            ;
            console.log(res.errMsg)
            console.log(res.errCode)
          })
        }
      })
      wx.showToast({
        title: '恭喜!录音成功',
        icon: 'success',
        duration: 1000
      })

      console.log('停止录音', res.tempFilePath)

      this.setData({
        audioUrl: res.tempFilePath
      })
      
    })

  }, 
  
  // 点击--播放录音
  play () {

    innerAudioContext.play()

    wx.showToast({
      title: '开始播放',
      icon: 'success',
      duration: 1000
    })

    innerAudioContext.onError((res) => {
      console.log(res.errMsg)
      console.log(res.errCode)
    })


  },

  // 点击--删除录音
  closeHandle () {
    this.setData({
      isVoice: false,
      audioUrl: '',
      allow: true,
      tishi: false,
      voices: []
    })
  },


  // 确定发布
  releaseHandle () {
    if (this.data.content.length) {
      if (this.data.tsColor == '#49B0FF') {
        // 1-消息
        var param1 = {

          content: this.data.content || '',	// 小纸条内容
          type: this.data.selectedTime == '无' ? 0 : (this.data.selectedTime == '学习' ? 1 : (this.data.selectedTime == '生活' ? 2 : 3)),	// 类型（0-无，1-学习，2-生活，3-情感）
          audio: audioFilePath,	// 回答语音链接地址
          time: this.data.audioUrl.length ? this.data.voices[0].duration : ''
        }
        console.log('-----发布小纸条传参-----', param1)
        http.httpPost("/scrip/publish", param1, app.globalData.userId, (res) => {
          console.log(res)
          if (res.code == 0) {
            console.log('------发布小纸条成功-----', res)

            this.setData({
              reSuccess: true
            })

            setTimeout(() => {

              this.setData({
                reSuccess: false
              })

            }, 1300)

            setTimeout(() => {
              app.goto('navigateBack', 'delta: 1')
            }, 1400)

          } else {
            console.log('------发布小纸条失败-----', res)
          }
        })
      }
    }
    console.log('-----a-----')
    // 七牛上传图片
    initQiniu();
    // 微信 API 选文件
var audioFilePath = this.data.savedFilePath
// 交给七牛上传
qiniuUploader.upload(audioFilePath, (res) => {
  console.log('------upload qiniu success.')
  console.log(res)
  this.setData({
    audioUrl: res.imageURL
  })
  audioFilePath = res.imageURL
  console.log('----audioFilePath:' + audioFilePath)

  if(this.data.tsColor == '#49B0FF') {
    // 1-消息
    var param1 = {

      content: this.data.content || '',	// 小纸条内容
      type: this.data.selectedTime == '无' ? 0 : (this.data.selectedTime == '学习' ? 1 : (this.data.selectedTime == '生活' ? 2 : 3)),	// 类型（0-无，1-学习，2-生活，3-情感）
      audio: audioFilePath,	// 回答语音链接地址
      time: this.data.audioUrl.length ? this.data.voices[0].duration : ''
    }
    console.log('-----发布小纸条传参-----', param1)
    http.httpPost("/scrip/publish", param1, app.globalData.userId, (res) => {            console.log(res)
      if(res.code == 0) {
        console.log('------发布小纸条成功-----', res)
      
        this.setData({
          reSuccess: true
        })

        setTimeout(() => {

          this.setData({
            reSuccess: false
          })

        }, 1300)

        setTimeout(() => {
          app.goto('switchTab', 'release/release')
        }, 1400)
      
      } else {
        console.log('------发布小纸条失败-----', res)
      }
    })
  }
  })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.recorderManager = wx.getRecorderManager()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
function releaseHandle1(that) {
  console('-------b----')
  initQiniu();
  wx.saveFile({
  count: 1,
  sizeType: ['compressed'],
  success: function (res) {
    var filePath = res.tempFilePaths[0];
    var files = res.tempFilePaths
    console.log('上传', filePath)
    var voices = that.data.voices
    // 交给七牛上传
    qiniuUploader.upload(filePath, (res) => {
      console.log('----upload qiniu success.')
      console.log(res)
      voices.push(res.audioUrl)
      that.setData({
        'imageObject': res,
        'imgarr': voices,
        'student': false
      });
    }, (error) => {
      console.error('error: ' + JSON.stringify(error));
    });
  },
  uploadURL: 'https://up.qbox.me',

  domain: 'bzkdlkaf.bkt.clouddn.com',

  uptokenURL: 'UpTokenURL.com/uptoken',
})
   
  // if (that.data.imgarr.length == 3) {

  //   wx.showToast({
  //     icon: 'loading',
  //     title: '最多添加3张图片哦',
  //     duration: 1200
  //   })

  // } else {

    //
  }
