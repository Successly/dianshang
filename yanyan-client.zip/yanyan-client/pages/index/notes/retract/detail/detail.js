// 收起的小纸条--详细信息
var app = getApp()
var http = require('../../../../../utils/httpHelper.js')
var util = require('../../../../../utils/util')
const qiniuUploader = require("../../../../../utils/qiniuUploader")
const recorderManager = wx.getRecorderManager()
const innerAudioContext = wx.createInnerAudioContext()
// 初始化七牛相关参数
function initQiniu() {
  var options = {
    region: 'ECN', // 华东区，生产环境应换成自己七牛帐户bucket的区域
    uptokenURL: 'https://wxapp.yanyanbiji.com/yyapp/config/token', // 生产环境该地址应换成自己七牛帐户的token地址，具体配置请见server端
    domain: 'http://img.rainfn.com/' // 生产环境该地址应换成自己七牛帐户对象存储的域名
  };
  qiniuUploader.init(options);
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
   // 音频
   audioUrl: '',
   savedFilePath: '',
   allow: true,
   tishi: false,  // 超出1条语音提示
   reSuccess: false,
   isSpeaking: false,
   content: '',
   audio:'',
   imageList: [],
   showModalStatus1: false,
   showModalStatus: false,
   voices: [],//音频数组
   isVoice: false,
   tsColor: '#49B0FF'
  },

  initList () {

    http.httpGet(`/scrip/info/${this.data.id}`, null, app.globalData.userId, (res) => {       

      if(res.code == 0) {

        console.log('小纸条详情获取成功', res)
        this.setData({
          retractInfo: res.data
        })

        if(res.data.replies && res.data.replies.length) {
          var replies = res.data.replies
          console.log(replies)
          this.setData({
            replies: res.data.replies
          })
          // replies.map((item, index, arr) => {
          //   var replyId = item.replyId

            // http.httpGet(`/user/detail/${replyId}`, null, app.globalData.userId, (res1) => {            
            //   if(res1.code == 0) {
            //     console.log('------获取用户信息成功-----', res1)
            //     item.name = res1.data.name

            //     this.setData({
            //       replies: res.data.replies 
            //     })
            
            //   } else {
            //     console.log('------获取用户信息失败-----', res1)
            //   }
            // })
            
          // })
        }

      } else {
        console.log('小纸条详情获取失败', res)
      }
    
    })
    
  },

  

  // 回复文本
  taValue (e) {
    if(this.data.voices.length == 1) {
      this.setData({
        tsColor: 'red'
      })
    } else {
      this.setData({
        content: e.detail.value,
        tsColor: '#49B0FF'
      })
    }

    if(e.detail.value.length == 0) {
      this.setData({
        tsColor: '#49B0FF'
      })
    }
    
  },

  //开始录音
  recordStart () {

    // 语音、文本--任选一条
    if(!this.data.content.length) {
      this.setData({
        tsColor: '#49B0FF'
      })

      if(this.data.voices.length < 1) {

        if(this.data.allow) {

          var _this = this;
          _this.setData({
            isSpeaking: true,
            isVoice: false
          })
        
          const options = {
            duration: 60000,//指定录音的时长，单位 ms
            sampleRate: 16000,//采样率
            numberOfChannels: 1,//录音通道数
            encodeBitRate: 96000,//编码码率
            format: 'mp3',//音频格式，有效值 aac/mp3
            frameSize: 50,//指定帧大小，单位 KB
          }

          //开始录音
          recorderManager.start(options);
          recorderManager.onStart(() => {
            console.log('------开始录音-----')
            var startTime = +new Date()
            this.setData({
              startTime: startTime
            })
          });

          //错误回调
          recorderManager.onError((res) => {
            console.log(res);
          })

        } 

      } else {

        this.setData({
          tishi: true,
          allow: false
        })

      }

    } else {
      this.setData({
        tsColor: 'red'
      })
    }

  },

  // 录音结束
  recordEnd: function () {
    recorderManager.stop();
    recorderManager.onStop((res) => {
      var tempFilePath = res.tempFilePath;
      var Duration = Math.floor(res.duration / 1000) ;
      var fileSize = res.fileSize;
      var that = this;
      var voices = {};
      wx.saveFile({
        tempFilePath: tempFilePath,
        success: function (lures) {
          //持久路径
          var savedFilePath = lures.savedFilePath
          console.log("savedFilePath: " + savedFilePath)
          voices = [{ filePath: savedFilePath, duration: Duration, size: fileSize }];
          that.setData({
            isVoice: true,
            isSpeaking: false,
            voices: voices,
            savedFilePath: savedFilePath
          })

          innerAudioContext.src = savedFilePath;
          innerAudioContext.onPlay(() => {

            console.log('开始播放')
          })
          innerAudioContext.onError((res) => {
            ;
            console.log(res.errMsg)
            console.log(res.errCode)
          })
        }
      })
      wx.showToast({
        title: '恭喜!录音成功',
        icon: 'success',
        duration: 1000
      })

      console.log('停止录音', res.tempFilePath)

      this.setData({
        audioUrl: res.tempFilePath
      })
      
    })
  }, 
  
  // 播放录音
  play (e) {
    var item = e.currentTarget.dataset.item
    console.log(item)
    innerAudioContext.src = item.replyAudio;
    innerAudioContext.play()

    wx.showToast({
      title: '开始播放',
      icon: 'success',
      duration: 1000
    })

    innerAudioContext.onError((res) => {
      ;
      console.log(res.errMsg)
      console.log(res.errCode)
    })


  },

  // 点击--删除录音
  closeHandle () {
    this.setData({
      isVoice: false,
      audioUrl: '',
      allow: true,
      tishi: false,
      voices: []
    })
  },

  // 播放录音--已有的
  playOrigin () {
  
    innerAudioContext.src = this.data.retractInfo.audio;
    innerAudioContext.play()

    wx.showToast({
      title: '开始播放',
      icon: 'success',
      duration: 1000
    })

    innerAudioContext.onError((res) => {
      ;
      console.log(res.errMsg)
      console.log(res.errCode)
    })


  },
  
  // 回复
  submit () {
    var item = this.data.retractInfo
    if (this.data.content == ""){
    // 七牛上传图片
    initQiniu();
    // 微信 API 选文件
    var audioFilePath = this.data.savedFilePath
    // 交给七牛上传
    qiniuUploader.upload(audioFilePath, (res) => {
      console.log('------upload qiniu success.')
      console.log(res)
      this.setData({
        audioUrl: res.imageURL,

      })
      audioFilePath = res.imageURL
      console.log('----audioFilePath:' + audioFilePath)
    var param1 = {
      scripId: this.data.id, // 小纸条的id
      replyId: app.globalData.userId, //回复者的id
      content: this.data.content || "",	// 小纸条内容
      audio: audioFilePath,	// 回答语音链接地址
      time: this.data.audioUrl.length ? this.data.voices[0].duration : '' // 语音时长
    }
    console.log('-----回复小纸条传参-----', param1)

    http.httpPost("/scrip/answer", param1, app.globalData.userId, (res) => {            
      if(res.code == 0) {
        console.log('------回复小纸条成功-----', res)
        
        this.setData({
          reSuccess: true
        })

        setTimeout(() => {

          this.setData({
            reSuccess: false
          })

        }, 1300)

        setTimeout(() => {
          app.goto('navigateBack', 'index/notes/retract/retract')
        }, 1400)

        // this.initList()
      
      } else {
        console.log('------回复小纸条失败-----', res)
      }
    })
    })
    }else{
      var param1 = {
        scripId: this.data.id, // 小纸条的id
        replyId: app.globalData.userId, //回复者的id
        content: this.data.content,	// 小纸条内容
        audio: audioFilePath,	// 回答语音链接地址
        time: this.data.audioUrl.length ? this.data.voices[0].duration : '' // 语音时长
      }
      console.log('-----回复小纸条传参-----', param1)

      http.httpPost("/scrip/answer", param1, app.globalData.userId, (res) => {
        if (res.code == 0) {
          console.log('------回复小纸条成功-----', res)

          this.setData({
            reSuccess: true
          })

          setTimeout(() => {

            this.setData({
              reSuccess: false
            })

          }, 1300)

          setTimeout(() => {
            app.goto('navigateBack', 'index/notes/retract/retract')
          }, 1400)

          // this.initList()

        } else {
          console.log('------回复小纸条失败-----', res)
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    if(options.fromRetract == 1) {
      this.setData({
        id: options.id
      })
      console.log(this.data.id)
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.recorderManager = wx.getRecorderManager()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.initList()
  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})