// 收起的小纸条
var app = getApp()
var http = require('../../../../utils/httpHelper.js')
var util = require('../../../../utils/util')
const innerAudioContext = wx.createInnerAudioContext()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    retractList: [],
    pageNum: 1,
    pageSize: 10,
    hasMoreData: true,
    isRead: false
    
  },
  
  audioPlay() {
    console.log('-----播放录音-----')
    this.audioCtx.play()
  },

  initList (message, load) {

    var params = {
      type: 2,	// 类别（1-发布的小纸条，2-收起的小纸条）	Integer	是
      pageNum: this.data.pageNum,	 // 分页数	Integer	否
      pageSize: this.data.pageSize 	// 分页尺寸	Integer	否
    }
    console.log('---params:' + params.type)
    http.httpGet(`/scrip/list`, params, app.globalData.userId, (res) => {    
      
      
      if(res.code == 0) {
        console.log('------获取小纸条列表成功-----', res)
      
        // 获取新数据
        var list = res.data.list
        console.log('新数据',res.data.list)
    
        if(list) {
          list.map((item, index, arr) => {

            item.receiveTime = util.formatDate1(item.receiveTime * 1000)
           
          })
          // 当前页展示的数据
          var hasList = res.data.list
          console.log('当前页', hasList)

          if (this.data.pageNum == 1) {
            hasList = []
          }
          // 分页加载
          if (list.length < this.data.pageSize) {
            this.setData({
              retractList: hasList.concat(list),
              hasMoreData: false
            })
          } else {
            this.setData({
              retractList: hasList.concat(list),
              hasMoreData: true,
              pageNum: this.data.pageNum + 1
            })
          }
        }
       
        // 加载
        if (load == 1) {

          wx.showToast({
            title: message,
            icon: 'loading',
            duration: 1000,
            success: function () {
              if (message == '正在刷新数据') {
                wx.stopPullDownRefresh()
              }
            }
          })
        }
      
      } else {
        console.log('------获取小纸条列表失败-----', res)
      }

    })


  },

  // 丢弃
  discardHandle (e) {
    var item = e.currentTarget.dataset.item
    var params = {
      ids: item.scripId,	// 小纸条id
    }
    http.httpGet(`/scrip/delete`, params, app.globalData.userId, (res) => {

      if(res.code == 0) {
        this.initList() 
      } else {
        console.log('------丢弃小纸条失败-----', res)
          wx.showToast({
              title: '网络故障，请稍后再试',
              icon: 'error',
              duration: 1000
          })
      }

    })


      var params = {
          scripId: item.scripId,	// 小纸条id
          replyId: item.replyId,	// 回复者id
          content: item.content,	// 回复内容
          audio: item.audio,	// 问题语音链接
          time: this.data.audioUrl.length ? this.data.voices[0].duration : '', // 语音时长
          operate: operate //拾起并收起
      }
      console.log('---回复并收起小纸条传参---', params)

      http.httpPost(`/scrip/answer`, params, app.globalData.userId, (res) => {

          if (res.code == 0) {

              console.log('------回复小纸条成功-----', res)
              app.goto('navigateBack', 'index/notes/notes')

          } else {
              console.log('-------回复小纸条失败-----', res)
          }

      })

  },
  
  // 播放录音
  play (e) {
    var item = e.currentTarget.dataset.item
    innerAudioContext.src = item.audio;
    innerAudioContext.play()

    wx.showToast({
      title: '开始播放',
      icon: 'success',
      duration: 1000
    })

    innerAudioContext.onError((res) => {
      ;
      console.log(res.errMsg)
      console.log(res.errCode)
    })


  },

  // 点击每项
  gotoDetail (e) {

    var item = e.currentTarget.dataset.item
    console.log(item)
    if (item.isRead == 0) {
      isRead: false
    } else {
      isRead: true
    }
    if (item.scripId !== undefined) {
      app.goto('navigateTo', 'index/notes/retract/detail/detail', {'fromRetract' : 1, 'id': item.scripId})
      this.audioCtx.pause()
    } else {
      app.goto('navigateTo', 'index/notes/retract/detail/detail', {'fromRetract' : 1, 'id': item.id})
      this.audioCtx.pause()
    }
    
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // this.initList()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.audioCtx = wx.createAudioContext('myAudio')
    this.initList()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // this.initList()
  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.data.pageNum = 1
    this.initList('正在刷新数据', 1)
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.hasMoreData) {
      this.initList('正在加载数据...', 1)
    } 
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})