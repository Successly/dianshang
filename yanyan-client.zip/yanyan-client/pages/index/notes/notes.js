// 小纸条
var app = getApp()
var http = require('../../../utils/httpHelper')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    linkpick: false
  },

  // 点击--拾起小纸条
  gotoPickup () {

    this.setData({
      linkpick: false
    })

    wx.showToast({
      title: '拾取中......',
      icon: 'loading',
      duration: 1000
    })

    http.httpGet('/scrip/pick', null, app.globalData.userId, (res) => {    
      
      if(res.code == 0) {

        console.log('------拾起小纸条成功-----', res)
         
        setTimeout(() => {
          this.setData({
            linkpick: false,
            retractInfo: res.data
            
          })
        
          app.goto('navigateTo', 'index/notes/pickup/pickup', res.data)

        }, 1500)

      
      } else if(res.code == 500 && res.msg == '没有捡到') {
        
        setTimeout(() => {
          wx.showToast({
            image: '../../../assets/noData2.png',
            title: '没有捡到',
            duration: 1900
          })

          this.setData({
            linkpick: false
          })
        }, 1500)


      } else {

        console.log('------拾起小纸条失败-----', res)
        

      }

    })

  },

  // 点击--发布小纸条 
  gotoRelease () {
    app.goto('navigateTo', 'index/notes/release/release')
  },

  // 点击--收起的小纸条 
  gotoRetract () {
    app.goto('navigateTo', 'index/notes/retract/retract')
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})