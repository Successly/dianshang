// 拾取小纸条
var app = getApp()
var util = require('../../../../utils/util')
var http = require('../../../../utils/httpHelper')
const qiniuUploader = require("../../../../utils/qiniuUploader")
const recorderManager = wx.getRecorderManager()
const innerAudioContext = wx.createInnerAudioContext()

// 初始化七牛相关参数
function initQiniu() {
    var options = {
        region: 'ECN', // 华东区，生产环境应换成自己七牛帐户bucket的区域
        uptokenURL: 'https://wxapp.yanyanbiji.com/yyapp/config/token', // 生产环境该地址应换成自己七牛帐户的token地址，具体配置请见server端
        domain: 'http://img.rainfn.com/' // 生产环境该地址应换成自己七牛帐户对象存储的域名
    };
    qiniuUploader.init(options);
}


Page({

    /**
     * 页面的初始数据
     */
    data: {
        items: [
            {value: '该内容有关色情、诱惑等内容；'},
            {value: '该内容含有暴力、不适的内容；'},
            {value: '该内容含有侮辱、谩骂的行为；'}
        ],

        jb: false,
        // 音频
        audioUrl: '',
        allow: true,
        savedFilePath: '',
        tishi: false,  // 超出1条语音提示
        audio: '',
        reSuccess: false,
        isSpeaking: false,
        content: '',
        imageList: [],
        showModalStatus1: false,
        showModalStatus: false,
        voices: [],//音频数组
        isVoice: false,

        tsColor: '#49B0FF',
        linkpick: false


    },

    // 点击--发布小纸条
    gotoRelease() {
        app.goto('navigateTo', 'index/notes/release/release')
    },


    // 点击--收起的小纸条
    gotoRetract() {
        app.goto('navigateTo', 'index/notes/retract/retract')
    },

    // 多选框
    checkboxChange(e) {
        console.log('checkbox发生change事件，携带value值为：', e.detail.value)
    },

    // 点击--举报
    showJb() {
        this.setData({
            jb: true
        })
    },

    // 点击--取消
    cancelHandle() {
        this.setData({
            jb: false
        })
    },

    // 点击--语音输入
    audioHandle() {
        wx.getAvailableAudioSources({
            success(e) {
                console.log(e)
            }
        })
    },
    // initList() {
    //   http.httpGet('/scrip/pick', null, app.globalData.userId, (res) => {
    //     if (res.code == 0) {
    //       console.log('------拾起小纸条成功-----', res)
    //       console.log(res.data)
    //       this.setData({
    //         retractInfo: res.data
    //       })
    //     }
    //     else {
    //       console.log('------拾起小纸条失败-----', res)
    //       wx.showToast({
    //         // image: './../../../assets/noData.png',
    //         title: '空的纸条',
    //         icon: 'none',
    //         duration: 1900
    //       })
    //     }
    //   })
    // },

    // 点击--下一个
    gotoNotes() {

        this.setData({
            linkpick: false
        })

        wx.showToast({
            title: '拾取中......',
            icon: 'loading',
            duration: 1000
        })

        http.httpGet('/scrip/pick', null, app.globalData.userId, (res) => {

            if (res.code == 0) {

                console.log('------拾起小纸条成功-----', res)
                this.setData({
                    retractInfo: res.data
                })

                // setTimeout(() => {
                //   this.setData({
                //     linkpick: false,

                //   })
                //   app.goto('redirectTo', 'index/notes/pickup/pickup')

                // }, 1500)


            } else if (res.code == 500 && res.msg == '没有捡到') {

                setTimeout(() => {
                    wx.showToast({
                        // image: './../../../assets/noData.png',
                        title: '没有捡到',
                        icon: 'none',
                        duration: 1900
                    })

                    this.setData({
                        linkpick: false
                    })
                }, 1500)


            } else {

                console.log('------拾起小纸条失败-----', res)
                wx.showToast({
                    // image: './../../../assets/noData.png',
                    title: '空的纸条',
                    icon: 'none',
                    duration: 1500
                })
            }

        })
    },


    // 播放录音--已有的
    playOrigin() {

        console.log(this.data)
        // if (res.code == 200) {
        innerAudioContext.src = this.data.retractInfo.audio;
        innerAudioContext.play()
        // } else {
        //   wx.showToast({
        //     title: '空的纸条',
        //     icon: 'none',
        //     duration: 1500
        //   })
        // }
        wx.showToast({
            title: '开始播放',
            icon: 'success',
            duration: 1000
        })

        innerAudioContext.onError((res) => {

            console.log(res.errMsg)
            console.log(res.errCode)
        })


    },


    // 回复文本
    taValue(e) {

        if (this.data.voices.length == 1) {
            this.setData({
                tsColor: 'red'
            })
        } else {
            this.setData({
                content: e.detail.value,
                tsColor: '#49B0FF'
            })
        }

        if (e.detail.value.length == 0) {
            this.setData({
                tsColor: '#49B0FF'
            })
        }

    },

    //开始录音
    recordStart() {

        // 语音、文本--任选一条
        if (!this.data.content.length) {

            this.setData({
                tsColor: '#49B0FF'
            })

            if (this.data.voices.length < 1) {

                if (this.data.allow) {

                    var _this = this;
                    _this.setData({
                        isSpeaking: true,
                        isVoice: false
                    })

                    const options = {
                        duration: 60000,//指定录音的时长，单位 ms
                        sampleRate: 16000,//采样率
                        numberOfChannels: 1,//录音通道数
                        encodeBitRate: 96000,//编码码率
                        format: 'mp3',//音频格式，有效值 aac/mp3
                        frameSize: 50,//指定帧大小，单位 KB
                    }

                    //开始录音
                    recorderManager.start(options);
                    recorderManager.onStart(() => {
                        console.log('------开始录音-----')
                        var startTime = +new Date()
                        this.setData({
                            startTime: startTime
                        })
                    });

                    //错误回调
                    recorderManager.onError((res) => {
                        console.log(res);
                    })

                }

            } else {

                this.setData({
                    tishi: true,
                    allow: false
                })

            }

        } else {
            this.setData({
                tsColor: 'red'
            })
        }

    },

    // 录音结束
    recordEnd: function () {
        recorderManager.stop();
        recorderManager.onStop((res) => {
            var tempFilePath = res.tempFilePath;
            var Duration = Math.floor(res.duration / 1000);
            var fileSize = res.fileSize;
            var that = this;
            var voices = {};
            wx.saveFile({
                tempFilePath: tempFilePath,
                success: function (lures) {
                    //持久路径
                    var savedFilePath = lures.savedFilePath
                    console.log("savedFilePath: " + savedFilePath)
                    voices = [{filePath: savedFilePath, duration: Duration, size: fileSize}];
                    that.setData({
                        isVoice: true,
                        isSpeaking: false,
                        voices: voices,
                        savedFilePath: savedFilePath
                    })

                    innerAudioContext.src = savedFilePath;
                    innerAudioContext.onPlay(() => {

                        console.log('开始播放')
                    })
                    innerAudioContext.onError((res) => {
                        ;
                        console.log(res.errMsg)
                        console.log(res.errCode)
                    })
                }
            })
            wx.showToast({
                title: '恭喜!录音成功',
                icon: 'success',
                duration: 1000
            })

            console.log('停止录音', res.tempFilePath)

            this.setData({
                audioUrl: res.tempFilePath
            })

        })
    },

    // 播放录音--回复的
    play() {

        innerAudioContext.src = this.data.audioUrl;
        innerAudioContext.play()

        wx.showToast({
            title: '开始播放',
            icon: 'success',
            duration: 1000
        })

        innerAudioContext.onError((res) => {
            console.log(res.errMsg)
            console.log(res.errCode)
        })


    },

    // 点击--删除录音
    closeHandle() {
        this.setData({
            isVoice: false,
            audioUrl: '',
            allow: true,
            tishi: false,
            voices: []
        })
    },

    // 播放录音--已有的
    // playOrigin() {
    //   console.log(this.data)
    //   // if (res.code == 200) {
    //   innerAudioContext.src = this.data.retractInfo.audio;
    //   innerAudioContext.play()
    //   // } else {
    //   //   wx.showToast({
    //   //     title: '空的纸条',
    //   //     icon: 'none',
    //   //     duration: 1500
    //   //   })
    //   // }
    //   wx.showToast({
    //     title: '开始播放',
    //     icon: 'success',
    //     duration: 1000
    //   })

    //   innerAudioContext.onError((res) => {

    //     console.log(res.errMsg)
    //     console.log(res.errCode)
    //   })


    // },
    answerHandler(operate,item,audioFilePath,){
        var params = {
            scripId: item.id,	// 小纸条id
            replyId: app.globalData.userId,	// 回复者id
            content: this.data.content || "",	// 回复内容
            audio: audioFilePath,	// 问题语音链接
            time: this.data.audioUrl.length ? this.data.voices[0].duration : '', // 语音时长
            operate: operate //拾起并收起
        }
        console.log('---回复并收起小纸条传参---', params)

        http.httpPost(`/scrip/answer`, params, app.globalData.userId, (res) => {

            if (res.code == 0) {

                console.log('------回复小纸条成功-----', res)
                app.goto('navigateBack', 'index/notes/notes')

            } else {
                console.log('-------回复小纸条失败-----', res)
            }

        })
    },
    // 回复并收起
    answerAndPick() {
        let that = this;
        var item = that.data.retractInfo
        if(that.data.savedFilePath == '' && that.data.content.trim() == ''){
            wx.showToast({
                title: '请补充回复内容',
                icon: 'error',
                duration: 1800
            })
        }else if(that.data.savedFilePath != ''){
            // 七牛上传图片
            initQiniu();
            // 微信 API 选文件
            var audioFilePath = that.data.savedFilePath;
            // 交给七牛上传
            qiniuUploader.upload(audioFilePath, (res) => {
                console.log('------upload qiniu success.');
                console.log(res)
                that.setData({
                    audioUrl: res.imageURL,

                })
                audioFilePath = res.imageURL
                console.log('----audioFilePath:' + audioFilePath);

                that.answerHandler(2,item,audioFilePath);

            })
        }else{
            that.answerHandler(2,item,'');
        }




    },

    // 回复并丢弃
    answerAndLose() {
        let that = this;
        var item = this.data.retractInfo
        if(that.data.savedFilePath == '' && that.data.content.trim() == ''){
            wx.showToast({
                title: '请补充回复内容',
                icon: 'error',
                duration: 1800
            })
        }else if(this.data.savedFilePath != ''){
            // 七牛上传图片
            initQiniu();
            // 微信 API 选文件
            var audioFilePath = this.data.savedFilePath
            // 交给七牛上传
            qiniuUploader.upload(audioFilePath, (res) => {
                console.log('------upload qiniu success.')
                console.log(res)
                this.setData({
                    audioUrl: res.imageURL,

                })
                audioFilePath = res.imageURL
                this.answerHandler(1,item,audioFilePath)

            })
        }else{
            this.answerHandler(1,item,'')
        }

    },


    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        console.log(options)
        this.setData({
            retractInfo: options
        })
        // this.initList()
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
        this.recorderManager = wx.getRecorderManager()
        // this.initList()
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        // this.initList()
        initQiniu();
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})

function releaseHandle1(that) {
    console('-------b----')
    initQiniu();
    wx.saveFile({
        count: 1,
        sizeType: ['compressed'],
        success: function (res) {
            var filePath = res.tempFilePaths[0];
            var files = res.tempFilePaths
            console.log('上传', filePath)
            var voices = that.data.voices
            // 交给七牛上传
            qiniuUploader.upload(filePath, (res) => {
                console.log('----upload qiniu success.')
                console.log(res)
                voices.push(res.audioUrl)
                that.setData({
                    'imageObject': res,
                    'imgarr': voices,
                    'student': false
                });
            }, (error) => {
                console.error('error: ' + JSON.stringify(error));
            });
        },
        uploadURL: 'https://up.qbox.me',

        domain: 'bzkdlkaf.bkt.clouddn.com',

        uptokenURL: 'UpTokenURL.com/uptoken',
    })
}