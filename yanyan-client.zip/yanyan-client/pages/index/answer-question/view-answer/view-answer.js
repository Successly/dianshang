// pages/index/answer-question/view-answer/view-answer.js
var http = require('../../../../utils/httpHelper')
var app = getApp()
var id;
const innerAudioContext = wx.createInnerAudioContext()
Page({
    /**
     * 页面的初始数据
     */
    data: {
        //爱心图标
        src: "../../../../assets/aixing.png",
        //向下图标
        down: '../../../../assets/down.png',
        pics: [1, 2, 3],
        count: 100,
        percent: 90,
        select: false,
        tihuoWay: 90,
        counts: [
            {value: 100, desc: '100%'},
            {value: 90, desc: '90%'},
            {value: 80, desc: '80%'},
            {value: 70, desc: '70%'},
            {value: 60, desc: '60%'},
            {value: 50, desc: '50%'},
            {value: 40, desc: '40%'},
            {value: 30, desc: '30%'},
            {value: 20, desc: '20%'},
            {value: 10, desc: '10%'},
            ],
        countIndex: 1,
        questionInfo: [],
        questionImage: [],
        answerImagesList: [],
        previewImgList: [],// 预览图片地址数组
        id: null,
        goodInfo: null,
        loading: false,
        btnDisabled: false
    },
    bindShowMsg() {
        this.setData({
            select: !this.data.select
        });
    },
    mySelect(e) {
        var name = e._relatedInfo.anchorTargetText;
        console.log(e._relatedInfo.anchorTargetText);
        this.setData({
            tihuoWay: name,
            select: false
        });
    },
    //点击确定按钮
    primary() {
        let that = this;
        var info = {
            questionId: this.data.id,
            accept: this.data.counts[that.data.countIndex].value
        }
        that.setData({
            btnDisabled: true,
            loading: true
        })
        http.httpGet(`question/accept`, info, app.globalData.userId, (res) => {
            console.log('采纳率' + res.data);
            that.setData({
                btnDisabled: false,
                loading: false
            })
        })
        app.goto('navigateBack', 'index/answer-question/answer-question')
    },
    // 点击收藏事件
    // joincollect(e) {
    //   console.log(e);
    //   var flag = e.currentTarget.dataset.flag;
    //   if(flag==0){
    //     var pr = {
    //       targetId:id,
    //       type:2,
    //       action:1
    //     }
    //     flag==0
    //   }else{
    //     var pr = {
    //       targetId: id,
    //       type: 2,
    //       action: 0
    //     }
    //     flag==1
    //   }

    //   console.log(pr);
    //   http.httpPost(`/favorite/do`, pr, app.globalData.userId,(res)=>{
    //     console.log(res);
    //   })

    // },

    // 点击收藏事件
    joincollect() {
        // 请求--添加、取消收藏
        var goodInfo = this.data.goodInfo
        console.log(goodInfo)
        if (goodInfo.favorite == 0) {
            // 收藏
            var params = {
                targetId: id,
                type: 2,
                action: 1  // 1-收藏
            }
        } else {
            var params = {
                targetId: id,
                type: 2,
                action: 0
            }
        }

        http.httpPost(`/favorite/do`, params, app.globalData.userId, (res) => {
            if (res.code == 0) {
                console.log('------添加、取消收藏-----', res)

                // 获取该商品详情
                var goodInfo = this.data.goodInfo
                goodInfo.favorite = !goodInfo.favorite
                this.setData({
                    goodInfo: goodInfo
                })

                if (this.data.goodInfo.favorite == 1) {
                    wx.showToast({
                        title: '收藏' + this.data.goodInfo.detail + '成功',
                        icon: 'none',
                        duration: 1000
                    })
                }


            } else {
                console.log(res.message)
            }
        })

    },
    // 播放语音
    play(e) {
        var url = e.currentTarget.dataset.url
        console.log(url)
        innerAudioContext.src = url;
        innerAudioContext.play()
        wx.showToast({
            title: '开始播放',
            icon: 'success',
            duration: 1000
        })
        innerAudioContext.onError((res) => {
            ;
            console.log(res.errMsg)
            console.log(res.errCode)
        })
    },
    bindPickerChange(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
            countIndex: e.detail.value
        })
    },
    previewImg(e) {
        const that = this
        var current = e.target.dataset.url
        console.log("previewImgList",that.data.previewImgList);
        console.log("current",current);
        wx.previewImage({
            urls: that.data.previewImgList,
            current: current,
            success: function (e) {
                console.log('预览成功');
            }
        })
    },
    /**
     * 生命周期函数--监听页面加载
     */

    onLoad: function (e) {
        console.log(e.id);
        this.setData({
            id: e.id
        })
        id = e.id;
        http.httpGet(`question/${id}`, id, app.globalData.userId, (res) => {
            console.log(res.data);
            let tempImgList = [];
            if(res.data.answerImagesList && res.data.answerImagesList.length > 0){
                res.data.answerImagesList.forEach(function (item, index) {
                    tempImgList.push(item.url);
                })
            }
            this.setData({
                questionInfo: res.data,
                goodInfo: res.data,
                // questionImage:res.data.questionImagesList,
                answerImagesList: res.data.answerImagesList,
                previewImgList: tempImgList
            })
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {
    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
    }
});
