// pages/index/answer-question/answer-question.js
const app = getApp()

var http = require('../../../utils/httpHelper.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    problems: [],
    keyword: '',
    isRelate: 1,
    hasMoreData: true,
    pageNum: 0,
    pageSize: 10,
    backTopValue: false
  },
  // 监听滚动条坐标
  onPageScroll: function (e) {
    var that = this
    var scrollTop = e.scrollTop
    var backTopValue = scrollTop > 10 ? true : false
    that.setData({
      backTopValue: backTopValue
    })
  },
  // 返回顶部
  goback() {
    // 控制滚动
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 300
    })
  },
  // 监听滚动条坐标
  onPageScroll: function (e) {
    var that = this
    var scrollTop = e.scrollTop
    var backTopValue = scrollTop > 10 ? true : false
    that.setData({
      backTopValue: backTopValue
    })
  },

  dynamicInputValue: function(e){
    this.setData({keyword: e.detail.value});
  },

  search: function(data){
    this.getData('init');
  },

  //点击switch按钮
  switchChange(e) {
    if(e.detail.value){
      this.setData({isRelate : 1});
    }else{
      this.setData({isRelate : 0});
    }
    
    this.getData('init');
  },

  //点击查看答案按钮
  btn(e) {
    console.log(e)
    var id = e.currentTarget.dataset.id;
    var payed = e.currentTarget.dataset.payed
    if (payed == 0) {
      var openid = app.globalData.openId
      var payparam = {
        questionId: id,
        openId: openid,
        price: this.data.price,
        totalAmount: 0.01,
        type: 2
      }
      console.log(payparam)
      http.httpPost(`/question/pay`, payparam, app.globalData.userId, (res) => {
        console.log(res)
        if (res.code == 0) {
          console.log('------购买问题接口成功-----', res)
          // 成功--调微信支付
          if (res.data) {
            wx.requestPayment({
              'timeStamp': res.data.timeStamp,
              'nonceStr': res.data.nonceStr,
              'package': res.data.package,
              'signType': "MD5",
              'paySign': res.data.paySign,
              'success': function (res) {
  
                wx.showToast({
                  title: '支付成功',
                  icon: 'success',
                  duration: 3000
                })
  
                // 跳转--我的-我的资料
                app.goto('navigateTo', 'index/answer-question/view-answer/view-answer', {
                  id: id
                })
              },
              'fail': function (res) {
                console.log("支付失败")
              }
            })
          }
  
        } else {
          console.log('------购买问题接口失败-----', res)
        }
  
      })
    } else {
      app.goto('navigateTo', 'index/answer-question/view-answer/view-answer', {
        id: id
      })
    }

  },


  //点击收藏
  shoucang(e) {
    var that = this;
    var targetId = e.currentTarget.dataset.questionid;
    var problems = that.data.problems;
    var index = -1;
    for(var i = 0 ; i < problems.length ; i++){
      if(problems[i].questionId == targetId){
        index = i;
        break;
      }
    }
    if(index == -1){
      return false;
    }
    var action = problems[index].favorite == 1 ? 0 : 1;
    var pro = {
      action: action,
      type: 2,
      targetId: targetId
    }
    wx.showLoading({
      title: '提交中...',
    })
    http.httpPost('/favorite/do', pro, app.globalData.userId, (res) => {
      wx.hideLoading();
      if (res.code == 0) {
        problems[index].favorite = action;
        that.setData({problems:problems});
      } else {
        //TODO
        //错误提示？
      }
    },() => {
      wx.hideLoading();
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getData('init');
  },

  getData(mode){
    var that = this;
    if(mode === 'init'){
      that.setData({pageNum:0,problems:[],hasMoreData:true,backTopValue:false})
    }
    if(that.data.hasMoreData){
      var param = {
        term: that.data.keyword,
        isRelate: that.data.isRelate,
        pageSize: that.data.pageSize,
        pageNum: that.data.pageNum
      };
      wx.showLoading({
        title: '加载数据...',
      })
      http.httpGet('/question/list',param,app.globalData.userId,(res) => {

        if(res.code == 0){
          wx.hideLoading();
          var cPage = that.data.pageNum + 1;
          var problems = that.data.problems;
          this.setData({ pageNum: cPage, problems: problems.concat(res.data.list)});
          if(cPage >= res.data.totalPage){
            that.setData({hasMoreData:false});
          }
        }
      },() => {
        wx.hideLoading();
      });
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.getData('init');
    wx.stopPullDownRefresh();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.getData();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})