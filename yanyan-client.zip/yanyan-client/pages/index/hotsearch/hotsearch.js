// pages/index/hotsearch/hotsearch.js
var app = getApp()

var http = require('../../../utils/httpHelper.js')

Page({

      /**
       * 页面的初始数据
       */
      data: {
        hotList: [], // 热门搜索数据
        iconleft: 335, // 搜索icon的左移
        valueleft: 50, // 输入值的左边距
        searchvalue: '' // 搜索值
      },

      // 请求--获取热门搜索数据
      initList() {


      },

      
      // 点击按钮时搜索
      keywordssearch(e) {
        console.log('输入框的值', this.data.searchvalue)
        // 跳转到--学习资料页
        if (this.data.from == 'studydata') {
          app.goto('navigateTo', 'index/studydata/studydata', {
            fromhotsearch: 1,
            value: this.data.searchvalue,
            type: this.data.type
          })
        } else {
          if (this.data.from == "answerquestion") {
            console.log("xiix")
            app.goto('navigateTo', 'index/answer-question/answer-question', {
              fromhotsearch: 1,
              value: this.data.searchvalue,
              type: this.data.type
            })
          } else {
            if (this.data.from == 'demand') {
              app.goto('navigateTo', 'index/demand/demand', {
                fromhotsearch: 1,
                vlaue: this.data.searchvalue,
                type: this.data.type
              })
            
          }
          
          }
          
        }
        
        },

      // 点击输入框
      focus(e) {
        console.log('输入框聚焦', e.detail.value)
        this.setData({
          searchvalue: e.detail.value
        })
      },

      // 失去焦点
      blur(e) {
        this.setData({
          searchvalue: e.detail.value,
          // blur: true
        })
      },

      // 点击完成按钮时
      confirm(e) {
        if (e) {
          this.setData({
            searchvalue: e.detail.value
          })


          // 跳转到--学习资料页
          if (this.data.from == 'studydata') {
            app.goto('navigateTo', 'index/studydata/studydata', {
              fromhotsearch: 1,
              value: this.data.searchvalue,
              type: this.data.type
            })
          } else {
            if (this.data.from == 'answerquestion') {
              console.log('searchvalue------', this.data.searchvalue + 'type-----', this.data.type)
              app.goto('navigateTo', 'index/answer-question/answer-question', {
                fromhotsearch: 1,
                value: this.data.searchvalue,
                type: this.data.type
              })
            } else {
              if (this.data.from == 'demand') {
                console.log('searchvalue------', this.data.searchvalue + 'type-----', this.data.type)
                app.goto('navigateTo', 'index/demand/demand', {
                  fromhotsearch: 1,
                  value: this.data.searchvalue,
                  type: this.data.type
                })
              }
            }
          }
        }
      },
      /**
       * 生命周期函数--监听页面加载
       */
      onLoad: function(options) {
        // 从学习资料列表页来
        console.log(options)
        if (options.fromStudyData) {
          this.setData({
            from: 'studydata',
            type: options.type
          })
        } else {
          if (options.fromanswerquestion) {
            this.setData({
              from: 'answerquestion',
              type: options.type,
              
              
            })
            console.log(options.fromanswerquestion)
          } else {
            if (options.fromdemand) {
              this.setData({
                from: 'demand',
                type: options.type
              })
            }
          }
          console.log("mm")
        }
      },

      /**
       * 生命周期函数--监听页面初次渲染完成
       */
      onReady: function() {

      },

      /**
       * 生命周期函数--监听页面显示
       */
      onShow: function() {
        this.initList()
      },

      /**
       * 用户点击右上角分享
       */
      onShareAppMessage: function() {　
        var that = this;　　 // 设置菜单中的转发按钮触发转发事件时的转发内容
        　　
        return {　　　　
          title: "研研笔记", // 默认是小程序的名称(可以写slogan等)
          　　　　path: `/pages/index/index`, // 默认是当前页面，现在跳转到首页
          　　　　imgUrl: 'http://img.rainfn.com/12-16-zuzehwaner-banner1.jpg', //自定义图片路径，可以是本地文件路径、代码包文件路径或者网络图片路径，支持PNG及JPG，不传入 imageUrl 则使用默认截图。显示图片长宽比是 5:4
          　　success: function(res) {　　　　　　 // 转发成功之后的回调
            　　　　　　
            if (res.errMsg == 'shareAppMessage:ok') {
              console.log('转发成功')　　　　　　
            }　　　　
          },
          　　　　fail: function() {　　　　　　 // 转发失败之后的回调
            　　　　　　
            if (res.errMsg == 'shareAppMessage:fail cancel') {
              console.log('用户取消转发')　　　　　　
            } else if (res.errMsg == 'shareAppMessage:fail') {
              console.log('转发失败')　　　　　　
            }　　　　
          },
          　　　complete: function() {　　　　　　 // 转发结束之后的回调（转发成不成功都会执行）
            　　　　}
        }
      }
})