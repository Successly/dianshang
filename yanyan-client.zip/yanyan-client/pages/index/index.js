// 首页
const app = getApp()

var http = require('../../utils/httpHelper.js')

Page({
  data: {
    // 轮播图
    arr: [
      // 'http://img3.imgtn.bdimg.com/it/u=1835284051,1409003492&fm=26&gp=0.jpg',
      // 'http://img2.imgtn.bdimg.com/it/u=3016494198,572851790&fm=26&gp=0.jpg',
      // 'http://img1.imgtn.bdimg.com/it/u=1918669872,169015639&fm=26&gp=0.jpg'
      'http://img.rainfn.com/yy_banner_0215-1.png', 
      'http://img.rainfn.com/yy_banner_0215-2.png',
      'http://img.rainfn.com/yy_banner_0215-3.png',
      'http://img.rainfn.com/yy_banner_0221-1.png'
    ],
    //研究生推荐
    recommended: [],
    src1: '',
    //热门问题
    problems: [],
    src: '../../assets/aixing.png',
    allarr: [],

    indicatorDots: true,
    autoplay: true,
    interval: 3000,
    duration: 1000,

    // 返回按钮状态
    scrollTop: 0,
    backTopValue: false,
    type: null,
    unreadnews: 0, // 未读消息
    // va: ''

  },


  // 获取
  initList() {
    var parames1 = {
      'pageNum': 1,
      'pageSize': 100000
    }

    http.httpGet("message/list", parames1, app.globalData.userId, (res) => {
      if (res.code == 0) {
        console.log('------获取消息列表成功-----', res)

        var messagelist = res.data.list

        // 取出未读项
        var num = []
        messagelist.map((item, index, arr) => {
          if (item.read == 0) {
            num.push(item)
          }
        })
        // 计算未读数
        this.setData({
          unreadnews: num.length
        })

      } else {
        console.log('------获取消息列表-----', res.message)
      }
    })
    var pro = {
      term: '',
      isRelate: 0,
      pageSize: 20,
      pageNum: 1
    }

    http.httpGet('question/list', pro, app.globalData.userId, (res) => {
      console.log("==================================")
      console.log(res);

      if (res.code == 0) {
        this.data.allarr = this.getallnum(res);
        // console.log(this.data.allarr);


        this.setData({
          problems: this.data.allarr
        })

        console.log(res.data.list);

      }
    })
  },
  
  // 跳转
  // 搜索框输入时
  searchHandle() {
    app.goto('navigateTo', 'index/hotsearch/hotsearch', { 'fromdemand': 1,'type': this.data.type})

  },
  

  // 跳转消息页
  opennews() {
    app.goto('navigateTo', 'index/news/news')
  },


  //点击研究生推荐
  tiaozhuan(e) {
    var id = e.currentTarget.dataset.id;
    app.goto('navigateTo', 'index/demand/question/question', {
      id: id
    })
  },

  more() {
    app.goto('navigateTo', 'index/demand/demand')
  },

  //点击热门问题
  verymore() {
    app.goto('navigateTo', 'index/answer-question/answer-question')
  },
  //点击查看答案按钮
   btn(e) {
     var id = e.currentTarget.dataset.id;
     var payed = e.currentTarget.dataset.payed
     if (payed == 0) {
      console.log('----questionId:' + id)
      var openid = app.globalData.openId

      var payparam = {
        questionId: id,
        // userinfo = app.globalData.users,
        // openId: openid,
        // paycode:paycode,
        // price: 0.01,
        totalAmount: 0.01,
        openId: openid,
        type: 2
      }
      console.log(payparam)
      http.httpPost(`question/pay`, payparam, app.globalData.userId, (res) => {
        console.log(res)
        if (res.code == 0) {
          console.log('------购买问题接口成功-----', res)
          // 成功--调微信支付
          if (res.data) {
            wx.requestPayment({
              'timeStamp': res.data.timeStamp,
              'nonceStr': res.data.nonceStr,
              'package': res.data.package,
              'signType': "MD5",
              'paySign': res.data.paySign,
              'success': function (res) {

                wx.showToast({
                  title: '支付成功',
                  icon: 'success',
                  duration: 3000
                })

                // 跳转--我的-我的资料
                app.goto('navigateTo', 'index/answer-question/view-answer/view-answer', {
                  id: id
                })
              },
              'fail': function (res) {
                console.log("支付失败")
              }
            })
          }

        } else {
          console.log('------购买问题接口失败-----', res)
        }

      })
     } else {
      app.goto('navigateTo', 'index/answer-question/view-answer/view-answer', {
        id: id
      })
     }
    },
  
  // 监听滚动条坐标
  onPageScroll: function (e) {
    var that = this
    var scrollTop = e.scrollTop
    var backTopValue = scrollTop > 280 ? true : false
    that.setData({
      backTopValue: backTopValue
    })
  },


  // 返回顶部
  goback() {
    // 控制滚动
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 300
    })
  },

  // 点击--学习资料
  gotoStudyData() {
    app.goto('navigateTo', 'index/studydata/studydata')
  },
  //点击需求广场
  change() {
    wx.navigateTo({
      url: './answer-question/answer-question',
    })
  },
  //点击专业问答
  question() {
    wx.navigateTo({
      url: './demand/demand',
    })
  },
  // 点击--小纸条
  gotodates() {
    app.goto('navigateTo', 'index/notes/notes')
  },

  // 点击--加入
  joinHandle() {

    if (this.data.type == 2) {
      wx.showToast({
        // icon: 'loading',
        title: '您已申请过',
        duration: 500
      })
    } else {
      app.goto('navigateTo', 'index/apply/apply')
    }

  },

  getallnum(res) {
    var alldata = res.data.list;
    for (var i = 0; i < alldata.length; i++) {
      if (alldata[i].favorite <= 0) {
        alldata[i].msrc = "../../../../../assets/aixing.png"
      } else {
        alldata[i].msrc = "../../../../../assets/hongxing.png"
      }

      //alldata[i].flag = "nochose"
    }
    console.log(alldata, '0-0-0-0-0-0--0')
    return alldata;
  },
  //点击收藏
  shoucang(e) {

    console.log(e);
    var pro = {
      action: null,
      type: 2,
      targetId: e.currentTarget.dataset.questionid
    }
    var oridata = this.data.allarr;
    var index = e.currentTarget.dataset.index
    var isflag = e.currentTarget.dataset.flag
    console.log(isflag, 'lilili');
    if (isflag <= 0) {
      pro.action = 1;
      isflag = 1
    } else {
      pro.action = 0;
      isflag = -1
    }

    console.log(isflag, 'dududud');
    // var ss = {
    //   questionid: e.currentTarget.dataset.questionid,
    //   action: pro.action
    // }
    // app.globalData.questionUsers.push(ss);
    // for (var j = 0; j < ss.length - 1; j++) {
    //   for (var i = 1; i < ss.length; i++) {
    //     if (ss[j].questionid === ss[i].questionid) {
    //       ss[j] = null
    //     }
    //   }

    // }

    //console.log(app.globalData.questionUsers)
    http.httpPost('favorite/do', pro, app.globalData.userId, (res) => {
      console.log(res);

      if (res.code == 0) {

        for (var i = 0; i < oridata.length; i++) {
          console.log(i, '---', index)
          if (i == index) {

            console.log(index, '当前index', isflag)
            if (isflag > 0) {
              console.log('lsilr')
              oridata[i]['favorite'] = 1;
              oridata[i].msrc = '../../assets/hongxing.png';

            } else {
              console.log('jinlaile')
              oridata[i]['favorite'] = -1;
              oridata[i].msrc = "../../assets/aixing.png"

            }
            break;
          }
        }

        console.log(oridata, '9090900')

        this.setData({
          problems: oridata,
          allarr: oridata
        })

      } else {

      }
    })
    console.log(isflag, '0-0-0-0-0-0-0-0-0')

  },



  onLoad: function (options) {
    // 判断是否研究生
    http.httpGet(`user/detail/${app.globalData.userId}`, null, app.globalData.userId, (res) => {
      if (res.code == 0) {
        console.log('------获取用户信息成功-----', res)
        app.globalData.users = res.data;
        app.globalData.usertype = res.data.type;
        console.log(app.globalData.users);
        this.setData({
          userinfo: res.data,
          type: res.data.type
        })
        console.log(this.data.type)
      } else {
        console.log('------获取用户信息失败-----', res)
      }
    })
    // console.log(options)
    //研究生推荐接口
    var date = {
      pageSize: 10,
      pageNum: 0,
      isRelate: 0
    }
    http.httpGet('user/recommend', date, 30, (res) => {
      console.log(res);
      console.log(app.globalData.userId)
      if (res.code == 0) {
        console.log('------recommend-----')
        console.log(res);
        this.setData({
          recommended: res.data
        })
      }
    })

    // var pro = {
    //   term: '',
    //   isRelate: 0,
    //   pageSize: 20,
    //   pageNum: 1
    // }
    // http.httpGet('question/list', pro, app.globalData.userId, (res) => {
    //   if (res.code == 0) {
    //     this.setData({
    //       problems: res.data.list
    //     })
    //     console.log(res.data.list);

    //   }
    // })
    // console.log(app.globalData.userInfo);

    if (options.fromhotsearch) {
      // this.data.switchChange=false
      this.setData({
        va: options.value
      })

      var po = {
        term: this.data.va,
        isRelate: 0,
        pageSize: 20,
        pageNum: 1
      }

      http.httpGet('question/list', po, app.globalData.userId, (res) => {
        console.log("问题列表" + res);

        if (res.code == 0) {
          this.data.allarr = this.getallnum(res);
          console.log(this.data.allarr);


          this.setData({
            problems: this.data.allarr
          })

          console.log(res.data.list);

        }
      })
    } else {
      console.log(options)

      var pro = {
        term: '',
        isRelate: 0,
        pageSize: 20,
        pageNum: 1
      }

      http.httpGet('question/list', pro, app.globalData.userId, (res) => {
        console.log("==================================")
        console.log(res);

        if (res.code == 0) {
          this.data.allarr = this.getallnum(res);
          // console.log(this.data.allarr);


          this.setData({
            problems: this.data.allarr
          })

          console.log(res.data.list);

        }
      })
    }
    this.setData({
      type: app.globalData.usertype
    })
    console.log(this.data.type);
    // this.initList()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.initList()
  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this;

    var img = ''　　 // 设置菜单中的转发按钮触发转发事件时的转发内容

    return {
      title: "研研笔记", // 默认是小程序的名称(可以写slogan等)
      path: `/pages/index/index`, // 默认是当前页面，现在跳转到首页
      imgUrl: img, //自定义图片路径，可以是本地文件路径、代码包文件路径或者网络图片路径，支持PNG及JPG，不传入 imageUrl 则使用默认截图。显示图片长宽比是 5:4
      success: function (res) {　　　　　　 // 转发成功之后的回调

        if (res.errMsg == 'shareAppMessage:ok') {
          console.log('转发成功')
        }
      },
      fail: function () {　　　　　　 // 转发失败之后的回调

        if (res.errMsg == 'shareAppMessage:fail cancel') {
          console.log('用户取消转发')
        } else if (res.errMsg == 'shareAppMessage:fail') {
          console.log('转发失败')
        }
      },
      complete: function () {　　　　　　 // 转发结束之后的回调（转发成不成功都会执行）
      }
    }
  }


})