// 商品详情页
var app = getApp()

var http = require('../../../utils/httpHelper.js')


Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 轮播图属性
    imgUrls: [],
    indicatorDots: false, // 点
    autoplay: true, // 自动播放
    interval: 3000, // 间隔时长
    duration: 1000, // 动画
    circular: true, // 是否衔接滑动
    current: 1, // 当前轮播图的第几张

    // 页面滚动
    scrollTop: 0,
    backTopValue: false,

    goodInfo: null,

    collected: false

  },


  // 点击--立即购买
  gotoBuy () {
    var goodInfo = this.data.goodInfo
    wx.setStorageSync('goodInfo', goodInfo)
    app.goto('navigateTo', 'index/goodOrder/goodOrder', {'fromGoodDetail': 1})
  },

  // 页面滚动事件
  onPageScroll (e) {

    // 1 返回顶部
    var scrollTop = e.scrollTop
    var backTopValue = scrollTop > 200 ? true : false
    this.setData({
      backTopValue: backTopValue
    })

  },


  // 返回顶部
  goback () {
    // 控制滚动
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 300
    })
  },


  // 请求-- 获取商品相关数据
  initList() {
    console.log(this.data.id, '9000')
    var id = this.data.id

    http.httpGet(`/resource/detail/${id}`, null, app.globalData.userId, (res) => {
      console.log(res.data)
      if (res.code == 0) {
        console.log('------获取资料详情成功-----', res)

        if (res.data) {
          if (res.data.imgs && res.data.imgs.length) {
            this.setData({
              imgUrls: res.data.imgs
            })
          }


          this.setData({
            goodInfo: res.data
          })

          var id = res.data.userId

          http.httpGet(`/user/detail/${id}`, null, app.globalData.userId, (res1) => {

            if (res1.code == 0) {
              console.log('------获取用户信息成功-----', res1)

              this.setData({
                userInfo: res1.data
              })


            } else {
              console.log('------获取用户信息失败-----', res1)
            }

          })

        }



      } else {
        console.log('------获取资料详情失败-----', res)
      }

    })


  },

  // 商品轮播图切换时--替换当前张数
  changedot (e) {
    this.setData({
      current: e.detail.current + 1
    })
  },


  // 点击收藏事件
  joincollect () {
    // 请求--添加、取消收藏
    var goodInfo = this.data.goodInfo

    if(goodInfo.favorite == 0) {
      // 收藏
      var params = {
        targetId: this.data.id,	
        type: 1,
        action: 1  // 1-收藏
      }
    } else {
      var params = {
        targetId: this.data.id,
        type: 1,
        action: 0
      }
    }

    http.httpPost(`/favorite/do`, params, app.globalData.userId, (res) => {           
      if(res.code == 0) {
        console.log('------添加、取消收藏-----',res)

        // 获取该商品详情
        var goodInfo = this.data.goodInfo
        goodInfo.favorite = !goodInfo.favorite
        this.setData({
          goodInfo: goodInfo
        })

        if(this.data.goodInfo.favorite == 1) {
          wx.showToast({
            title: '收藏' + this.data.goodInfo.name + '成功',
            icon: 'none',
            duration: 1000
          })
        }


      } else {
        console.log(res.message)
      }
    })

  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    if (options.fromStudydata) {
      this.setData({
        id: options.id
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    wx.setStorageSync('goodInfo', null)
    this.initList()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {　
    var that = this;　　 // 设置菜单中的转发按钮触发转发事件时的转发内容
    　　
    return {　　　　
      title: "研研笔记", // 默认是小程序的名称(可以写slogan等)
      　　　　path: `/pages/index/index`, // 默认是当前页面，现在跳转到首页
      　　　　imgUrl: '', //自定义图片路径，可以是本地文件路径、代码包文件路径或者网络图片路径，支持PNG及JPG，不传入 imageUrl 则使用默认截图。显示图片长宽比是 5:4
      　　success: function(res) {　　　　　　 // 转发成功之后的回调
        　　　　　　
        if (res.errMsg == 'shareAppMessage:ok') {
          console.log('转发成功')　　　　　　
        }　　　　
      },
      　　　　fail: function() {　　　　　　 // 转发失败之后的回调
        　　　　　　
        if (res.errMsg == 'shareAppMessage:fail cancel') {
          console.log('用户取消转发')　　　　　　
        } else if (res.errMsg == 'shareAppMessage:fail') {
          console.log('转发失败')　　　　　　
        }　　　　
      },
      　　　complete: function() {　　　　　　 // 转发结束之后的回调（转发成不成功都会执行）
        　　　　}
    }
  }

})