// 消息页
var app = getApp()

var http = require('../../../utils/httpHelper.js')

var util = require('../../../utils/util.js')

Page({

  data:{
    // 消息列表
    list: [],

    delBtnWidth:180, //删除按钮宽度单位（rpx）

    // 分页
    currentPage: 1,  // 当前页
    pageSize: 10,  // 每页多少条
    totalPage: 1,  // 总页数

    hasMoreData: true,

    // 箭头 
    arrimg: 'http://img.rainfn.com/12-18-zuzhewaner-arr1.png'

  },


  // 请求-获取消息列表
  initList (message, load, id) {

    var params = {
      'pageNum': this.data.currentPage,
      'pageSize': this.data.pageSize
    }
    http.httpGet(`/message/list`, params, app.globalData.userId, (res) => {         

      // 加载
      if(load == 1) {

        wx.showToast({
          title: message,
          icon: 'loading',
          duration: 1000,
          success: function () {
            if(message == '正在刷新数据') {
              wx.stopPullDownRefresh()            
            }
          }
        })
      }
     
      
      // 当前页展示的数据
      var hasList = this.data.list
      if(res.code == 0) {
        console.log('------获取消息列表成功-----',res)

        if (this.data.currentPage == 1) {
          hasList = []
        }
        
        // 获取新数据
        var list = res.data.list

        if(list) {
          // 获取时间、 默认都是合上的
          list.map((item, index, arr) => {
            if(item.createTime) {
              item.createTime = util.formatDate3(item.createTime) 
            }

            // 之前展开的那项--仍然展开
            if(id && item.id == id) {

              item.open = true
              item.arrimg = 'http://img.rainfn.com/12-18-zuzhewan-arr-xia.png'

            } else {
              item.open = false

              // 所有的加上右箭头
              item.arrimg = 'http://img.rainfn.com/12-18-zuzhewaner-arr1.png'
            }

          })
          
          // 分页加载
          if (list.length < this.data.pageSize) {
            this.setData({
              list: hasList.concat(list),
              hasMoreData: false
            })
          } else {
            this.setData({
              list: hasList.concat(list),
              hasMoreData: true,
              currentPage: this.data.currentPage + 1
            })
          }
        }
      
      } else {
        console.log('------获取消息列表失败-----', res)
      }
    })
  },

  // 点击每条消息时
  gowatchdetail (e) {
    // 1 展开
    var id = e.currentTarget.dataset.id

    var list = this.data.list

    list.map((item, index, arr) => {
      // 点击的这项 -- 展开
      if(id == item.id) {
        item.open = !item.open
        

        // 展开的同时--发请求
        if(item.open == true) {
          
          // 1. 展开的时候--将右箭头 换成 下箭头
          item.arrimg = 'http://img.rainfn.com/12-18-zuzhewan-arr-xia.png'

          // 2. 发请求--修改消息状态
          // 如果是未读 -- 请求: 变成已读
          list.map((item, index, arr) => {
            // 哪一项
            if(item.id == id) {
              // (1) 未读处理
              if(item.read == 0) {

                var ids = id

                // 请求--改变状态
                http.httpGet("/message/update", { 'ids': ids }, app.globalData.userId, (res) => {                                                                                        
                if(res.code == 0) {
                  console.log('------请求消息修改接口成功-----', res)

                  // this.setData({
                  //   currentPage: 1
                  // })

                  // 这条状态被改掉了
                  item.read = 1

                  // 渲染

                  this.setData({
                    list: list
                  })

                  // 刷新页面
                  // this.initList('正在加载数据...', 0, id)
                
                  } else {
                    console.log('------请求消息修改接口失败-----', res)
                  }
                })
              }
            }
          })
        } else {
          // 打开的时候--将右箭头换成下箭头
          // this.setData({
            item.arrimg = 'http://img.rainfn.com/12-18-zuzhewaner-arr1.png'
          // })
        }


      } else {

        // 其他的所有的项
        item.open = false
      }
    })
    
    
    // 重新渲染
    this.setData({
      list: this.data.list
    })

  },

  // 点击全部已读
  allread () {
    var ids = []

 
    // 1 获取 未读的id数组
    this.data.list.map((item, index, arr) => {
      if(item.read === 0) {
        ids.push(item.id)
      }
    })

    if(ids.length) {
      // 处理数据
      var str = ''

      ids.map((item, index, arr) => {
        str += 'ids=' + item + '&'
      })

      var newstr = str.substr(0, str.lastIndexOf('&'))

      // console.log(newstr)

      // 2 请求--全部已读--修改消息状态
      http.httpGet(`/message/update?${newstr}`, null, app.globalData.userId, (res) => { 

        if(res.code == 0) {
          console.log('------请求修改全部消息接口成功-----',res)
          // 刷新页面
          this.setData({
            currentPage: 1
          })

          this.initList('正在加载数据...', 0)
        
        } else {
          console.log('------请求修改全部消息接口失败-----',res)
        }
      })
    }
    
  
 

  },

  //点击删除按钮事件
  delItem:function(e){
    //获取列表中要删除项的下标
    var id = e.currentTarget.dataset.id
    var list = this.data.list
    
    // 哪一项
    list.map((item, index, arr) => {
      //  请求--删除
      if(item.id == id) {
        // var params = id // 处理数据 // var str = ''
        // param.map((item, index, arr) => {
        //   str += 'productIds=' + item + '&'
        // })
        // var newstr = str.substr(0, str.lastIndexOf('&'))
         
        http.httpGet(`/message/delete?ids=${id}`, null, app.globalData.userId, (res) => {
          if(res.code == 0) {
            console.log('------删除消息成功-----',res)
            // 关闭这一项
            item.txtStyle = 0
             
            // 自己删除这一项
            list.splice(index, 1)

            // 重新渲染
            this.setData({
              list: list
            })

            // this.setData({
            //   currentPage: 1
            // })

            // // 刷新页面
            // this.initList('正在加载数据...', 0)
          
          } else {
            console.log('------删除消息失败-----', res)
          }
        })
      }
    })
  },

  // 页面初始化 options为页面跳转所带来的参数
  onLoad:function(options){


  },

  // 页面渲染完成  
  onReady:function(){


  },

  // 页面显示  
  onShow:function(){
    // 渲染数据
    this.initList('正在加载数据...', 1)

    this.initEleWidth();

  },

  touchS:function(e){

    if(e.touches.length==1){
      this.setData({
        //设置触摸起始点水平方向位置
        startX:e.touches[0].clientX
      });
    }

  },

  touchM:function(e){

    if(e.touches.length==1){
      //手指移动时水平方向位置
      var moveX = e.touches[0].clientX;
      //手指起始点位置与移动期间的差值
      var disX = this.data.startX - moveX;
      var delBtnWidth = this.data.delBtnWidth;
      var txtStyle = "";
      if(disX == 0 || disX < 0){//如果移动距离小于等于0，文本层位置不变
        txtStyle = "left:0px";
      } else if(disX > 0) { //移动距离大于0，文本层left值等于手指移动距离
        txtStyle = "left:-"+disX+"px";
        if(disX>=delBtnWidth){
          //控制手指移动距离最大值为删除按钮的宽度
          txtStyle = "left:-"+delBtnWidth+"px";
        }
      }

      //获取手指触摸的是哪一项
      // var index = e.target.dataset.index;
      // var list = this.data.list;
      // list[index].txtStyle = txtStyle;
      // list[index].txtStyle = txtStyle;
      var id = e.target.dataset.id;
      var list = this.data.list;
      list.map((item, index, arr) => {
        if(item.id === id) {
          item.txtStyle = txtStyle;    
        } 
      })


      //更新列表的状态
      this.setData({
        list:list
      });

    }

  },
 
  touchE:function(e){
    // 滑动删除
    if(e.changedTouches.length==1){
      //手指移动结束后水平位置
      var endX = e.changedTouches[0].clientX;
      //触摸开始与结束，手指移动的距离
      var disX = this.data.startX - endX;
      var delBtnWidth = this.data.delBtnWidth;
      //如果距离小于删除按钮的1/2，不显示删除按钮
      var txtStyle = disX > delBtnWidth/2 ? "left:-"+ delBtnWidth + "px": "left:0px";
     
      //获取手指触摸的是哪一项
      // var index = e.target.dataset.index;
      // var list = this.data.list;
      // list[index].txtStyle = txtStyle;
      var id = e.target.dataset.id;
      var list = this.data.list;
      list.map((item, index, arr) => {
        if(item.id === id) {
          item.txtStyle = txtStyle;          
        } 
      })
      
      //更新列表的状态
      this.setData({
        list:list
      })
    }
  },

  //获取元素自适应后的实际宽度
  getEleWidth:function(w){

    var real = 0;
    try{
      var res = wx.getSystemInfoSync().windowWidth;
      var scale = (750/2)/(w/2);//以宽度750px设计稿做宽度的自适应
      // console.log(scale);
      real = Math.floor(res/scale);
      return real;
    } catch(e) {
      return false;
     // Do something when catch error
    }

  },

  initEleWidth:function(){

    var delBtnWidth = this.getEleWidth(this.data.delBtnWidth);
    this.setData({
      delBtnWidth:delBtnWidth
    });

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  // 6. 下拉加载
  onPullDownRefresh: function () {
    this.data.currentPage = 1
    this.initList('正在刷新数据', 1)
  },
  
  // 5. 监听用户上拉触底 -- 在触发距离内滑动期间，本事件只会被触发一次。
  // 重新请求 -- 分页显示 -- 改变当前页   +1页
  onReachBottom(){
    if (this.data.hasMoreData) {
      this.initList('正在加载数据...', 1)
    } 
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    　var that = this;
  　　// 设置菜单中的转发按钮触发转发事件时的转发内容
  　　return {
  　　　　title: "研研笔记",        // 默认是小程序的名称(可以写slogan等)
  　　　　path: `/pages/index/index`,     // 默认是当前页面，现在跳转到首页
  　　　　imgUrl: '',     //自定义图片路径，可以是本地文件路径、代码包文件路径或者网络图片路径，支持PNG及JPG，不传入 imageUrl 则使用默认截图。显示图片长宽比是 5:4
  　　    success: function(res){
  　　　　　　// 转发成功之后的回调
  　　　　　　if(res.errMsg == 'shareAppMessage:ok'){
                console.log('转发成功')
  　　　　　　}
  　　　　},
  　　　　fail: function(){
  　　　　　　// 转发失败之后的回调
  　　　　　　if(res.errMsg == 'shareAppMessage:fail cancel'){
                console.log('用户取消转发')
  　　　　　　} else if(res.errMsg == 'shareAppMessage:fail'){
                console.log('转发失败')
  　　　　　　}
  　　　　},
  　　　  complete: function() {
  　　　　　　// 转发结束之后的回调（转发成不成功都会执行）
  　　　　}
      }
  }
    
})