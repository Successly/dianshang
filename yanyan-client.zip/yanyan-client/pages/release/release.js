// 发布页
var app = getApp()
var http = require('../../utils/httpHelper.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    type: null
  },
   
  // 点击--发布资料
  gotoData() {
    app.goto('navigateTo', 'release/data/data')
  },

  //点击--专业问答
  gotoQuestion() {
    app.goto('navigateTo', 'index/demand/demand')
  },

  // 点击--发布小纸条
  gotoRelease() {
    app.goto('navigateTo', 'index/notes/release/release')
  },
  initList(){
 // 2-是否研究生
    http.httpGet(`/user/detail/${app.globalData.userId}`, null, app.globalData.userId, (res) => {
      if (res.code == 0) {
        console.log('------获取用户信息成功-----', res)
        app.globalData.users = res.data;
        app.globalData.usertype = res.data.type;
        console.log(app.globalData.users);
        this.setData({
          userinfo: res.data
        })

      } else {
        console.log('------获取用户信息失败-----', res)
      }
    })
  },
  // 考研党--申请加入
  gotoApply() {
    http.httpGet(`/user/detail/${app.globalData.userId}`, null, app.globalData.userId, (res) => {
      if (res.code == 0) {
        console.log('------获取用户信息成功-----', res)
        app.globalData.users = res.data;
        app.globalData.usertype = res.data.type;
        console.log(app.globalData.users);
        this.setData({
          userinfo: res.data
        })

      } else {
        console.log('------获取用户信息失败-----', res)
      }
    })
    if (this.data.userinfo.type == 2) {
      wx.showToast({
        icon: 'success',
        title: '您已申请过',
        duration: 500
      })
    } else {
      app.goto('navigateTo', 'index/apply/apply')
    }

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      type: app.globalData.usertype
    })
    console.log(this.data.type);
    this.initList()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})