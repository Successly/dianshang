// 发布资料
var app = getApp()
var http = require('../../../utils/httpHelper')
var config = require('../../../config')

const qiniuUploader = require("../../../utils/qiniuUploader")

// 初始化七牛相关参数
function initQiniu() {
  var options = {
    region: 'ECN', // 华东区，生产环境应换成自己七牛帐户bucket的区域
    uptokenURL: 'https://wxapp.yanyanbiji.com/yyapp/config/token', // 生产环境该地址应换成自己七牛帐户的token地址，具体配置请见server端
    domain: 'http://img.rainfn.com/' // 生产环境该地址应换成自己七牛帐户对象存储的域名
  };
  qiniuUploader.init(options);
}


Page({

  /**
   * 页面的初始数据
   */
  data: {
    customizeSchool: '',//其他学校名
    customizeYuanxi: '',//其他院系名
    dataInfo: [],
    // 下拉框的选择

    // 2-我的学校
    selectSchool: false,
    selectedSchool: '',
    // 下拉框的选择
    schoolList: [],

    checked: false, // 其他

    // 其他学校的填写
    selectOther: false,


    // 3-我的院系
    selectYuanxi: false,
    selectedYuanxi: '资料所属院系名称',
    // 下拉框的选择
    yuanxiList: ['资料所属院系名称1', '资料所属院系名称2'],

    checkedyuanxi: false, // 其他

    // 其他院系的填写
    selectOtherYuanxi: false,


    // 4-资料形式
    selectXl: false,
    selectedXl: '纸质资料',
    // 下拉框的选择
    XlList: ['纸质资料', '电子资料'],


    // 5-是否包邮
    selectTag: false,
    selectedTag: '是',
    // 下拉框的选择
    TagList: ['是', '否'],


    // 七牛
    // 图片地址
    imageObject: {},
    imgarr: [],

    // 弹窗--申请成功
    success: false,

    nickNameShow: false, // 资料名称   
    nickName: '', // 资料名称
    nickNameTishi: '资料名称不能为空',

    zhuanyeShow: false, // 专业   
    zhuanye: '', // 专业
    zhuanyeTishi: '专业不能为空',

    priceShow: false, // 资料价格   
    price: '', // 资料价格
    priceTishi: '资料价格不能为空',



  },

  // 获取院系
  getYuanxi(id) {
    http.httpGet(`/college/${id}/department/list`, null, app.globalData.userId, (res) => {

      if (res.code == 0) {
        console.log('------获取院系列表成功-----', res)

        if (res.data.length) {
          this.setData({
            yuanxiList: res.data,
            selectedYuanxi: res.data[0].name,
            selectedYuanxiID: res.data[0].id,
          })
        }



      } else {
        console.log('------获取院系列表失败-----', res)
      }
    })
  },

  initList() {
    // 1-获取学校列表
    var param1 = {
      'pageNum': this.data.pageNum, // 当前页
      'pageSize': this.data.pageSize, // 每页条数
    }

    http.httpGet("/college/list", param1, app.globalData.userId, (res) => {
      if (res.code == 0) {
        console.log('------获取学校成功-----', res)

        var schoolList = res.data

        if (schoolList.length) {
          this.setData({
            schoolList: schoolList,
            selectedSchool: schoolList[0].name,
            selectedSchoolId: schoolList[0].id
          })

          this.getYuanxi(schoolList[0].id)
        }



      } else {
        console.log('------获取学校失败-----', res)
      }
    })

  },

  // 下拉框
  // 2-学校
  showSchoolBox() {
    this.setData({
      selectSchool: !this.data.selectSchool,
      selectTime: false,
      // selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false,
    })
  },

  schoolSelect(e) {
    var item = e.currentTarget.dataset.item
    console.log(item)
    this.setData({
      selectedSchool: item.name,
      selectedSchoolId: item.id,
      selectSchool: false,
      checked: false,
      selectOther: false
    })

    this.getYuanxi(item.id)
  },

  // 其他单选框的改变
  schoolRadioChange(e) {
    if (e.detail.value == '其他') {
      this.setData({
        selectOther: true,
        selectSchool: false
      })
    }
  },
  otherSchool(e) {
    this.setData({
      customizeSchool: e.detail.value
    })
  },


  // 3-院系
  showYuanxiBox() {
    this.setData({
      selectYuanxi: !this.data.selectYuanxi,
      selectTime: false,
      selectSchool: false,
      // selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false,
    })
  },

  yuanxiSelect(e) {
    var item = e.currentTarget.dataset.item
    this.setData({
      selectedYuanxi: item.name,
      selectedYuanxiID: item.id,
      selectYuanxi: false,
      checkedyuanxi: false,
      selectOtherYuanxi: false
    })
  },

  // 其他单选框的改变
  yuanxiRadioChange(e) {
    if (e.detail.value == '其他') {
      this.setData({
        selectOtherYuanxi: true,
        selectYuanxi: false
      })
    }
  },
  otherYuanxi(e) {
    this.setData({
      customizeYuanxi: e.detail.value
    })
  },


  // 4-学历
  showXlBox() {
    this.setData({
      selectXl: !this.data.selectXl,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      // selectXl: false,
      selectMoney: false,
      selectTag: false,
    })
  },

  xlSelect(e) {
    var name = e.currentTarget.dataset.name
    this.setData({
      selectedXl: name,
      selectXl: false
    })
  },


  // 5-是否包邮
  showTagBox() {
    this.setData({
      selectTag: !this.data.selectTag,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      // selectTag: false,
    })
  },

  TagSelect(e) {
    var name = e.currentTarget.dataset.name
    this.setData({
      selectedTag: name,
      selectTag: false
    })
  },

  // 资料名称
  nickNameInput(e) {
    console.log(e)
    this.setData({
      nickName: e.detail.value,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false
    })
  },

  // 失去焦点
  nickNameBlur: function(e) {
    // 空
    if (!e.detail.value.length) {

      this.setData({
        nickNameShow: true,
        nickNameTishi: '资料名称不能为空'
      })

    } else if (e.detail.value.length > 20) {

      this.setData({
        nickNameShow: true,
        nickNameTishi: '资料名称不能超过20个字'
      })

    } else {
      this.setData({
        nickNameShow: false,
        nickNamePass: true
      })
    }
  },

  // 获取焦点
  nickNameFocus: function() {
    this.setData({
      nickNameShow: false,
      nickNameTishi: '资料名称不能为空'
    })
  },

  // 资料专业
  zhuanyeInput(e) {

    this.setData({
      specialtyName: e.detail.value,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false
    })
  },

  // 失去焦点
  zhuanyeBlur: function(e) {
    // 空
    if (!e.detail.value.length) {

      this.setData({
        zhuanyeShow: true,
        zhuanyeTishi: '专业不能为空'
      })

    } else if (e.detail.value.length > 20) {

      this.setData({
        zhuanyeShow: true,
        zhuanyeTishi: '专业不能超过20个字'
      })

    } else {
      this.setData({
        zhuanyeShow: false,
        zhuanyePass: true
      })
    }
  },

  // 获取焦点
  zhuanyeFocus: function() {
    this.setData({
      zhuanyeShow: false,
      zhuanyeTishi: '专业不能为空'
    })
  },

  // 资料价格
  priceInput(e) {

    this.setData({
      price: e.detail.value,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false
    })
  },

  // 失去焦点
  priceBlur: function(e) {
    // 空
    if (!e.detail.value.length) {

      this.setData({
        priceShow: true,
        priceTishi: '价格不能为空'
      })

    } else if (e.detail.value.length > 20) {

      this.setData({
        priceShow: true,
        priceTishi: '价格不能超过20个字'
      })

    } else {
      this.setData({
        priceShow: false,
        pricePass: true
      })
    }
  },

  // 获取焦点
  priceFocus: function() {
    this.setData({
      priceShow: false,
      priceTishi: '价格不能为空'
    })
  },

  // 邮费
  youfeiInput(e) {
    this.setData({
      deliveryFee: e.detail.value,
    })
  },

  // 自我简介
  summaryInput(e) {
    this.setData({
      summary: e.detail.value
    })
  },


  // 七牛上传图片
  didPressChooesImage: function() {
    var that = this;
    didPressChooesImage(that);
  },

  // 点击删除该图片
  deletePhoto(e) {
    var index1 = e.currentTarget.dataset.index
    var imgarr = this.data.imgarr
    imgarr.map((item, index, arr) => {
      if (index == index1) {
        imgarr.splice(index, 1)
      }
    })
    // 重新渲染
    this.setData({
      imgarr: imgarr
    })
  },

  // 确认申请
  subApply() {
    let that = this;

    if(that.data.imgarr.length == 0){
        wx.showToast({
            title: '至少需要上传一张资料图片',
            icon: 'none',
            duration: 1800
        })
        return false;
    }

    if(that.data.summary == '' || that.data.summary == undefined){
        wx.showToast({
            title: '请完善您的资料简介',
            icon: 'none',
            duration: 1800
        })
        return false;
    }


    var param1 = {
      name: that.data.nickName, // 是	资料名称	String
      type: that.data.selectedXl == '纸质资料' ? 1 : 2, // 是	资料类型：1-纸质，2-电子	Integer
      price: that.data.price * 100, // 是	价格，单位：分	Integer
      collegeId: that.data.selectOther ? '' : that.data.selectedSchoolId, // 我的学校ID，未选填0	Integer
      collegeName: that.data.selectOther ? that.data.customizeSchool : that.data.selectedSchool, // 我的学校名称	String
      departmentId: that.data.selectOtherYuanxi ? '' : that.data.selectedYuanxiID, // 我的院系ID，未选填0	Integer
      departmentName: that.data.selectOtherYuanxi ? that.data.customizeYuanxi : that.data.selectedYuanxi, //	院系名称	String
      specialtyName: that.data.specialtyName, // 是	我的专业名称	String
      isFreeDelivery: that.data.selectedTag == '是' ? 1 : 0, // 是	是否免费包邮，0否，1是	Integer
      deliveryFee: that.data.selectedTag == '是' ? 0 : that.data.deliveryFee * 100, // 是	邮费，单位：分	Integer
      imgs: that.data.imgarr, // 图片	String[]
      summary: that.data.summary, // 是	简介	String
    }

    if (that.data.nickNamePass && that.data.zhuanyePass && that.data.pricePass) {

      console.log('发布资料传参', param1)

      http.httpPost(`/resource/add`, param1, app.globalData.userId, (res) => {
        
        if (res.code == 0) {
          console.log('------发布资料成功-----', res)

            that.setData({
            success: true
          })

          setTimeout(() => {
            app.goto('switchTab', 'release/release')
          }, 2500)
          console.log("发布资料成功");

        } else {
          console.log('------发布资料失败-----', res)
        }
      })

    }


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.initList()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    
  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})

function didPressChooesImage(that) {
  initQiniu();

  if (that.data.imgarr.length == 3) {

    wx.showToast({
      icon: 'loading',
      title: '最多添加3张图片哦',
      duration: 1200
    })

  } else {

    // // 微信 API 选文件
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      success: function(res) {
        var filePath = res.tempFilePaths[0];
        var files = res.tempFilePaths
        console.log('上传', filePath)


        var imgarr = that.data.imgarr

        // 交给七牛上传
        qiniuUploader.upload(filePath, (res) => {
          imgarr.push(res.imageURL)
          that.setData({
            'imageObject': res,
            'imgarr': imgarr
          });
        }, (error) => {
          console.error('error: ' + JSON.stringify(error));
        });


      }
    })

  }
}