// 问题反馈页

const qiniuUploader = require("../../../utils/qiniuUploader")

// 初始化七牛相关参数
function initQiniu() {
  var options = {
    region: 'ECN', // 华东区，生产环境应换成自己七牛帐户bucket的区域
    uptokenURL: 'https://wxapp.yanyanbiji.com/yyapp/config/token', // 生产环境该地址应换成自己七牛帐户的token地址，具体配置请见server端
    domain: 'http://img.rainfn.com/' // 生产环境该地址应换成自己七牛帐户对象存储的域名
  };
  qiniuUploader.init(options);
}

//获取应用实例
var app = getApp()

var http = require('../../../utils/httpHelper.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    mob: false, // 手机号错误提示
    shouji: '手机号码不能为空',
    mobstatus: false, // 手机号验证通过吗
    
    // 七牛
    // 图片地址
    imageObject: {},
    imgarr: [],
    
    // 反馈的内容
    title: null,  // 标题
    texts: null,
    
    // 手机号或邮箱
    mobile: null
  },
  
  // 可填 -- 不需要校验
  // 手机号校验 -- 失去焦点
  mobHandle: function (e) {
    var myreg = /^[1][3,4,5,7,8][0-9]{9}$/;
    // 空
    if(!e.detail.value) {
       this.setData({
         mob: true,
         shouji: '手机号码不能为空',
         mobstatus: false,
       })  // 手机号码不正确
    } else if(!myreg.test(e.detail.value)) {
      this.setData({
        mob: true,
        shouji: '请输入正确的手机格式',
        mobstatus: false
      })
    } else {
      this.setData({
        mob: false,
        mobile: e.detail.value,
        mobstatus: true
      })
      console.log('格式正确', this.data.sjh)
    }
  },

  // 重新输入手机号 -- 获取焦点
  srHandle: function () {
    this.setData({
      mob: false,
      shouji: '手机号码不能为空',
      mobstatus: false
    })
  },
  
  // 七牛上传图片
  didPressChooesImage: function() {
    var that = this;
    didPressChooesImage(that);
  },

  // 点击删除该图片
  deletePhoto (e) {
    var index1 = e.currentTarget.dataset.index
    var imgarr = this.data.imgarr
    imgarr.map((item, index, arr) => {
      if(index == index1) {
        imgarr.splice(index, 1)
      }
    })
    // 重新渲染
    this.setData({
      imgarr: imgarr
    })
  },

  // 输入标题时
  titleHandle (e) {
    this.setData({
      title: e.detail.value
    })
  },

  // 输入手机号时
  mobileHandle (e) {
    this.setData({
      mobile: e.detail.value
    })
  },

  // 文本域输入内容时
  textHandle (e) {
    this.setData({
      texts: e.detail.value
    })
  },

  // 点击 提交时
  submitHandle () {
    if(this.data.texts && this.data.texts.length > 15) {
      // 请求--提交问题
      var params = {'title': '', 'photos': this.data.imgarr, 'remark': this.data.texts , 'mobile': this.data.mobile}
      http.httpPost(`/feedback/add`, params, app.globalData.userId, (res) => {            
        if(res.code == 0) {
          console.log('------问题反馈成功-----',res)
          // 提示
          wx.showToast({
            title: '问题反馈成功',
            icon: 'success',
            duration: 3000
          })

          // 跳转--我的页面
          wx.switchTab({
            url: '/pages/my/my'
          })
        } else {
          console.log(res.msg)
        }
      })
    } else {
      wx.showToast({
        icon: 'loading',
        title: '请输入15字以上问题',
        duration: 1000
      })
    }

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('onLoad')
    var that = this;
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
 * 用户点击右上角分享
 */
  onShareAppMessage: function () {
    　var that = this;
  　　// 设置菜单中的转发按钮触发转发事件时的转发内容
  　　return {
  　　　　title: "省心，省钱，省空间, 1折的价格，100%的爱！",        // 默认是小程序的名称(可以写slogan等)
  　　　　path: `/pages/index/index`,     // 默认是当前页面，现在跳转到首页
  　　　　imgUrl: 'http://img.rainfn.com/12-16-zuzehwaner-banner1.jpg',     //自定义图片路径，可以是本地文件路径、代码包文件路径或者网络图片路径，支持PNG及JPG，不传入 imageUrl 则使用默认截图。显示图片长宽比是 5:4
  　　    success: function(res){
  　　　　　　// 转发成功之后的回调
  　　　　　　if(res.errMsg == 'shareAppMessage:ok'){
                console.log('转发成功')
  　　　　　　}
  　　　　},
  　　　　fail: function(){
  　　　　　　// 转发失败之后的回调
  　　　　　　if(res.errMsg == 'shareAppMessage:fail cancel'){
                console.log('用户取消转发')
  　　　　　　} else if(res.errMsg == 'shareAppMessage:fail'){
                console.log('转发失败')
  　　　　　　}
  　　　　},
  　　　  complete: function() {
  　　　　　　// 转发结束之后的回调（转发成不成功都会执行）
  　　　　}
      }
  }
})

function didPressChooesImage(that) {
  initQiniu();

  // // 新增
  // var _this = that;
  // var ctx = wx.createCanvasContext('canvas1', this);


  // //选择图片
  // wx.chooseImage({
  //   success: function (res) {
  //     //图片预览压缩处理  ---指定图片最大宽度缩放
  //     var filePath  = res.tempFilePaths[0];
  //     var maxWidth = 100;

  //     wx.getImageInfo({
  //       src: filePath ,
  //       success: res => {
  //         _this.setData({
  //           imgwidth: res.width,
  //           imgheight: res.height
  //         });

  //         //绘制处理 (比例不变，最大宽度高度为100)
  //         var width = 100, height = 100;

  //         if (res.width > res.height) {
  //           width = maxWidth;
  //           height = res.height / res.width * maxWidth;

  //         } else {
  //           height = maxWidth;
  //           width = res.width / res.height * maxWidth;
  //         }

  //         ctx.drawImage(filePath , 0, 0, res.width, res.height);
  //         ctx.draw(true, function () {

  //           //导出图片为临时文件，然后上传
  //           wx.canvasToTempFilePath({
  //             canvasId: 'canvas1',
  //             fileType: 'jpg',
  //             destWidth: width,
  //             destHeight: height,
  //             success: res => {
  //               console.info(res.tempFilePath);
              
  //               var imgarr = that.data.imgarr

  //               // 交给七牛上传
  //               if(imgarr.length < 3) {
  //                 // 交给七牛上传
  //                 qiniuUploader.upload(filePath, (res) => {
  //                   imgarr.push(res.imageURL)
  //                   _this.setData({
  //                     'imageObject': res,
  //                     'imgarr': imgarr
  //                   });
  //                 }, (error) => {
  //                   console.error('error: ' + JSON.stringify(error));
  //                 });
  //               } else {
  //                 wx.showToast({
  //                   icon: 'loading',
  //                   title: '最多添加3张图片哦',
  //                   duration: 1200
  //                 })
  //               }

  //             }
  //           }, this);

  //         });

  //       }
  //     })

  //   },
  // })
  if(that.data.imgarr.length == 3) {

    wx.showToast({
      icon: 'loading',
      title: '最多添加3张图片哦',
      duration: 1200
    })

  } else {

    // // 微信 API 选文件
    wx.chooseImage({
        count: 1,
        sizeType: ['compressed'],
        success: function (res) {
          var filePath = res.tempFilePaths[0];
          var files = res.tempFilePaths
          console.log('上传', filePath)


          var imgarr = that.data.imgarr

          // 交给七牛上传
          qiniuUploader.upload(filePath, (res) => {
            imgarr.push(res.imageURL)
            that.setData({
              'imageObject': res,
              'imgarr': imgarr
            });
          }, (error) => {
            console.error('error: ' + JSON.stringify(error));
          });
          
        
        }
    })

  }
}
