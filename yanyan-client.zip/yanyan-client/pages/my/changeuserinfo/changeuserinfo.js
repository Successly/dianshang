const app = getApp();
let http = require('../../../utils/httpHelper');
var config = require('../../../config')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userinfo:{},
    username: '', // 我的昵称
    customSchool: '', // 其他自填学校
    customYuanxi: '', // 其他自填院系
    zhuanye: '', // 输入的专业名 
    email: '', //邮箱
    accept: '', // 收货人
    phone: '', // 手机号
    address: '', // 收货地址
    textarea: '', // 我想说
    selectedSchool: '', //  已选择的学校
    selectedSchoolId: '',// 已选择的学校id
    selectTime: false,
    selectSchool: false,
    // 下拉框的选择
    schoolList: [], //学校列表
    
    checked: false, // 其他学校
    // 其他学校的填写
    selectOtherSchool: false,
    // 院系
    selectedYuanxi: '',
    selectedYuanxiId: '',
    selectYuanxi: false,
    // 下拉框的选择
    yuanxiList: [],
    checkedyuanxi: false, // 其他院系
    // 其他院系的填写
    selectOtherYuanxi: false,
    pageNum: '',
    pageSize: '',
    //是否是研究生
    type: null,
    // 弹窗--修改成功
    success: false,
    isDisabled: false
  },



  inputzhuanye(e) {
    this.setData({
      zhuanye: e.detail.value
    })
  },

  inputemail(e) {
    this.setData({
      email: e.detail.value
    })
  },

  inputaccept(e) {
    this.setData({
      accept: e.detail.value
    })
  },

  inputphone(e) {
    var phonenum = e.detail.value;
    if (!(/^1[34578]\d{9}$/.test(phonenum)) && (phonenum.length >= 11)) {
      wx.showToast({
        title: '手机号有误',
        icon:'none',
        duration: 1500
      })
    } else {
      this.setData({
        phone: phonenum
      })
    } 
  },

  inputaddress(e) {
    this.setData({
      address: e.detail.value
    })
  },

  inputtext(e) {
    this.setData({
      textarea: e.detail.value
    })
  },

  changeUserInfo() {
    if (this.data.type == 2) {
      var params = {
        name: this.data.username.replace(/[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\A9|\AE]\u3030|\uA9|\uAE|\u3030/ig, ""),
        collegeId: this.data.selectOtherSchool ? '' : this.data.selectedSchoolId,
        collegeName: this.data.selectOtherSchool ? this.data.customSchool : this.data.selectedSchool,
        departmentId: this.data.selectOtherYuanxi ? '' : this.data.selectedYuanxiId,
        departmentName: this.data.selectOtherYuanxi ? this.data.customYuanxi : this.data.selectedYuanxi,
        specialtyName: this.data.zhuanye,
        email: this.data.email,
        deliveryConsignee: this.data.accept,
        deliveryMobile: this.data.phone,
        deliveryAddress: this.data.address,
        summary: this.data.textarea
      }
    } else {
      var params = {
        name: this.data.username.replace(/[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\A9|\AE]\u3030|\uA9|\uAE|\u3030/ig, ""),
        targetCollegeId: this.data.selectOtherSchool ? '' : this.data.selectedSchoolId,
        targetCollegeName: this.data.selectOtherSchool ? this.data.customSchool : this.data.selectedSchool,
        targetDepartmentId: this.data.selectOtherYuanxi ? '' : this.data.selectedYuanxiId,
        targetDepartmentName: this.data.selectOtherYuanxi ? this.data.customYuanxi : this.data.selectedYuanxi,
        targetSpecialtyName: this.data.zhuanye,
        email: this.data.email,
        deliveryConsignee: this.data.accept,
        deliveryMobile: this.data.phone,
        deliveryAddress: this.data.address,
        summary: this.data.textarea    
      }
    }
    console.log(params)
    http.httpPost("/user/update", params, app.globalData.userId, (res) => {
      console.log('------res-----', res)
      if (res.code == 0) {
        console.log('------修改个人信息成功-----', res)
        wx.showToast({
          title: '修改成功',
        })
        this.setData({
          success: true
        })

        setTimeout(() => {
          /*app.goto('switchTab', 'my/my')*/
            wx.navigateBack({
                delta: 1
            })
        }, 1000)


      } else {
        console.log('------修改个人信息失败-----', res)
        wx.showToast({
          title: '修改失败',
          icon:'none'
        })
      }
    })
  },

  
  // 获取院系
  getYuanxi(id) {
    http.httpGet(`/college/${id}/department/list`,null, app.globalData.userId, (res) => {

      if (res.code == 0) {
        console.log('------获取院系列表成功-----', res)

        if (res.data.length) {
          this.setData({
            yuanxiList: res.data
          })
        }
      } else {
        console.log('------获取院系列表失败-----', res)
      }
    })
  },

  initList() {
    // 1-获取学校列表
    var param1 = {
      'pageSize': this.data.pageSize, // 每页条数
      'pageNum': this.data.pageNum, // 当前页
      
    }

    http.httpGet("/college/list", param1, app.globalData.userId, (res) => {
      // console.log(res)
      if (res.code == 0) {
        console.log('------获取学校成功-----', res)
       
        var schoolList = res.data

        if (schoolList.length) {
          this.setData({
            schoolList: schoolList
          })
          this.getYuanxi(this.data.selectedSchoolId)
      } else {
        console.log('------获取学校失败-----', res)
      }
      }
    })

  },
  // 学校
  showSchoolBox() {
    if (this.data.type == 1) {
      this.setData({
        selectSchool: !this.data.selectSchool,
        selectTime: false,
        selectYuanxi: false,
        selectXl: false,
        selectMoney: false,
        selectTag: false,
      })
    }
  },
  
  schoolSelect(e) {
    console.log(e)
    var item = e.currentTarget.dataset.name
    // var name = e.currentTarget.dataset.name.name
    console.log(item)
    this.setData({
      selectedSchoolId: item.id,
      selectedSchool: item.name,
      selectSchool: false,
      checked: false,
      selectOtherSchool: false
    })
    this.getYuanxi(item.id)
  },

  // 其他单选框的改变
  radioChange(e) {
    if (e.detail.value == '其他') {
      this.setData({
        selectOtherSchool: true,
        selectSchool: false
      })
    }
  },

  // 院系
  showYuanxiBox() {
    if (this.data.type == 1) {
      console.log(this.data.type)
      this.setData({
        selectYuanxi: !this.data.selectYuanxi,
        selectTime: false,
        selectSchool: false,
        selectXl: false,
        selectMoney: false,
        selectTag: false,
      })
    }
  },

  yuanxiSelect(e) {
    var item = e.currentTarget.dataset.name
    // var name = e.currentTarget.dataset.name
    this.setData({
      selectedYuanxi: item.name,
      selectedYuanxiId: item.id,
      selectYuanxi: false,
      checkedyuanxi: false,
      selectOtherYuanxi: false
    })
  },

  // 其他单选框的改变
  radioChangeYuanXi(e) {
    if (e.detail.value == '其他') {
      this.setData({
        selectOtherYuanxi: true,
        selectYuanxi: false
      })
    }
  },

  inputname(e) {
    this.setData({
      username: e.detail.value
    })
  },

  inputschool(e) {
    this.setData({
      customSchool: e.detail.value
    })
  },

  inputyuanxi(e) {
    this.setData({
      customYuanxi: e.detail.value
    })
  },

  TagSelect(e) {
    var name = e.currentTarget.dataset.name
    this.setData({
      selectedTag: name,
      selectTag: false
    })
  },
  gotoApply() {
    if (this.data.userinfo.type == 2) {
      wx.showToast({
        icon: 'success',
        title: '您已申请过',
        duration: 500
      })
    } else {
      app.goto('navigateTo', 'index/apply/apply')
    }

  },

  gotoChange() {
    app.goto('navigateTo', 'my/changeinfo/changeinfo', this.data.userinfo)
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    this.setData({
      type: app.globalData.usertype,
      userinfo: options
    })
    if (options.type == '2') {
      this.setData({
        username: options.name,
        selectedSchool: options.collegeName == 'null' ? '' : options.collegeName,
        selectedSchoolId: options.collegeId == 'null' ? '' : options.collegeId,
        selectedYuanxi: options.departmentName == 'null' ? '' : options.departmentName,
        selectedYuanxiId: options.departmentId == 'null' ? '' : options.departmentId,
        zhuanye: options.specialtyName == 'null' ? '' : options.specialtyName,
        email: options.email == 'null' ? '' : options.email,
        accept: options.deliveryConsignee == 'null' ? '' : options.deliveryConsignee,
        phone: options.deliveryMobile == 'null' ? '' : options.deliveryMobile,
        address: options.deliveryAddress == 'null' ? '' : options.deliveryAddress,
        textarea: options.summary == 'null' ? '' : options.summary,
        isDisabled: true
      })
    } else {
      this.setData({
        username: options.name,
        selectedSchool: options.targetCollegeName == 'null' ? '' : options.targetCollegeName,
        selectedSchoolId: options.targetCollegeId == 'null' ? '' : options.targetCollegeId,
        selectedYuanxi: options.targetDepartmentName == 'null' ? '' : options.targetDepartmentName,
        selectedYuanxiId: options.targetDepartmentId == 'null' ? '' : options.targetDepartmentId,
        zhuanye: options.targetSpecialtyName == 'null' ? '' : options.targetSpecialtyName,
        email: options.email == 'null' ? '' : options.email,
        accept: options.deliveryConsignee == 'null' ? '' : options.deliveryConsignee,
        phone: options.deliveryMobile == 'null' ? '' : options.deliveryMobile,
        address: options.deliveryAddress == 'null' ? '' : options.deliveryAddress,
        textarea: options.summary == 'null' ? '' : options.summary
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.initList()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})