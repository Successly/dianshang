// pages/my/my-profile/gotodelivery/gotodelivery.js
var app = getApp()
var http = require('../../../../utils/httpHelper.js')
Page({

    /**
     * 页面的初始数据
     */
    data: {
        mapicon: '../../../../assets/map.png',

        //添加图片
        src: '../../../../../assets/camera.png',
        //语音图片
        src1: '../../../../../assets/yuyin.png',
        // 下拉框的选择
        // 1-入学时间
        selectTime: false,
        selectedTime: '顺丰快递',

        // 下拉框的选择
        // 选择无时，小纸条的标签不显示
        deliveryList: [
            {name: "中通快递",id: "1"},
            {name: "圆通快递",id: "2"},
            {name: "百世汇通",id: "3"},
            {name: "韵达快递",id: "4"},
            {name: "申通快递",id: "5"},
            ],
        deliveryIndex: 0,
        ok: false,
        //上传图片个数
        imgarr: [],

        // 音频
        audioUrl: '',
        allow: false,

        tishi: false, // 超出1条语音提示,

        inputyd: '', //表单输入的运单号
        qitaInput: false,
        selectTime: false,
        deliveryCompanyName: '',
        imgs: '',
        email: '',
        collegeName: '',
        name: '',
        specialtyName: '',
        summary: 0,
        price: 0,
        deliveryFee: 0,
        deliveryCode: '',
        orderId: '',
        deliveryCompanyId: ''

    },


//发货
    fahuo() {
        let that = this;
        let sp = null;
        if(!that.data.qitaInput){
            sp = {
                orderId: that.data.orderId,
                deliveryCode: that.data.deliveryCode,
                deliveryCompanyId: that.data.deliveryList[that.data.deliveryIndex].id,
                deliveryCompanyName: that.data.deliveryList[that.data.deliveryIndex].name
            }
        }else{
            sp = {
                orderId: that.data.orderId,
                deliveryCode: that.data.deliveryCode,
                deliveryCompanyId: '',
                deliveryCompanyName: that.data.inputyd
            }
        }

        http.httpPost(`/resource/delivery`, sp, app.globalData.userId, (res) => {
            console.log(res);
            app.globalData.myProfileType = 2;
            wx.navigateBack({
                delta: 1
            })
        })
    },
    bindPickerChange(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
            deliveryIndex: e.detail.value
        })
    },
    bindcodeInput(e){
      //快递单号
        this.setData({
            deliveryCode: e.detail.value
        })
    },


    // 其他单选框的改变
    switch2Change(e) {
        if (e.detail.value) {
            this.setData({
                qitaInput: true,
            })
        }else{
            this.setData({
                qitaInput: false,
            })
        }
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        let that = this;
        console.log("images", wx.getStorageSync('imgs'))
        that.setData({
            deliveryCompanyName: wx.getStorageSync('deliveryCompanyName'),
            imgs: wx.getStorageSync('imgs'),
            email: wx.getStorageSync('email'),
            collegeName: wx.getStorageSync('collegeName'),
            name: wx.getStorageSync('name'),
            specialtyName: wx.getStorageSync('specialtyName'),
            summary: wx.getStorageSync('summary'),
            price: wx.getStorageSync('price'),
            deliveryFee: wx.getStorageSync('deliveryFee'),
            deliveryCode: wx.getStorageSync('deliveryCode'),
            orderId: wx.getStorageSync("orderId"),
            deliveryCompanyId: wx.getStorageSync('deliveryCompanyId')
        })
        console.log("data",that.data)
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    getyd(e) {
        var _this = this;
        this.setData({
            inputyd: e.detail.value
        }, function () {
            console.log(_this.data.inputyd, '909090909090')
        })
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})