// 学习资料

var app = getApp()

var http = require('../../../utils/httpHelper')
var util = require('../../../utils/util.js')

Page({

    /**
     * 页面的初始数据
     */
    data: {
        shcontent: '确认收货',
        orinum: 0,
        // 选中
        activezz: true,
        activedz: false,

        // 返回按钮状态
        scrollTop: 0,
        backTopValue: false,

        zzdisplay: true,
        dzdisplay: false,

        // 纸质
        // 分页
        buyPageNum: 0, // 当前页
        zzpageSize: 8, // 每页条数
        zzhasMoreData: false,


        // 电子
        // 分页
        salePageNum: 0, // 当前页
        dzpageSize: 8, // 每页条数
        dzhasMoreData: true,

        // 资料类型 1-纸质 2-电子
        type: 1,

        value: '搜索',

        keyword: '',

        buy: [],
        buyListData: [], //买入
        saleListData: [], //卖出
        pageSize: 5, //单页容量
        loadBuyAllFlag: false, //买入列表加载完全标记
        loadSaleAllFlag: false // 卖出列表加载完全标记

    },

    // 导航栏切换
    zzdata() {
        this.setData({
            activezz: true,
            activedz: false,
            zzdisplay: true,
            dzdisplay: false,
            buyPageNum: 0,
            type: 1,
            orinum: 0
        })

        this.getinbuy("刷新数据", 800)
    },

    dzdata() {
        this.setData({
            activezz: false,
            activedz: true,
            zzdisplay: false,
            dzdisplay: true,
            salePageNum: 0,
            type: 2,
            orinum: 0
        })

        this.getinbuy("刷新数据", 800)
    },

    // 监听滚动条坐标
    //

    //去发货
    gotodelivery(e) {
        let that = this;
        var curid = e.currentTarget.dataset.id;
        var alldata = this.data.type == 1 ? this.data.buyListData : this.data.saleListData;
        console.log(alldata, '0-0-0-0-0-', e)
        for (var i = 0; i < alldata.length; i++) {
            if (alldata[i].orderId == curid) {
                console.log('进来了')

                wx.setStorageSync('deliveryCompanyName', alldata[i].deliveryCompanyName);
                wx.setStorageSync('imgs', alldata[i].imgs);
                wx.setStorageSync('email', alldata[i].email);
                wx.setStorageSync('collegeName', alldata[i].collegeName);
                wx.setStorageSync('name', alldata[i].name);
                wx.setStorageSync('specialtyName', alldata[i].specialtyName);
                wx.setStorageSync('summary', alldata[i].summary);
                wx.setStorageSync('price', alldata[i].price / 100);
                wx.setStorageSync('deliveryFee', alldata[i].deliveryFee / 100);
                wx.setStorageSync('deliveryCode', alldata[i].deliveryCode);
                wx.setStorageSync("orderId", alldata[i].orderId);
                // wx.setStorageSync('deliveryCompanyId', deliveryCompanyId)
                break;
            }
        }
        app.globalData.myProfileType = that.data.type; //设置离开的type类型
        app.goto("navigateTo", 'my/my-profile/gotodelivery/gotodelivery')
    },
    // 返回顶部
    onPageScroll: function (e) {
        var that = this
        var scrollTop = e.scrollTop
        var backTopValue = scrollTop > 280 ? true : false
        that.setData({
            backTopValue: backTopValue
        })
    },
    goback() {
        // 控制滚动
        wx.pageScrollTo({
            scrollTop: 0,
            duration: 300
        })
    },
    //物流单号
    traking(e) {
        let that = this;
        var curid = e.currentTarget.dataset.id;
        var alldata = this.data.type == 1 ? this.data.buyListData : this.data.saleListData;
        console.log(alldata, '0-0-0-0-0-', e)
        for (var i = 0; i < alldata.length; i++) {
            if (alldata[i].orderId == curid) {
                console.log('进来了')

                wx.setStorageSync('deliveryCompanyName', alldata[i].deliveryCompanyName);

                wx.setStorageSync('deliveryCode', alldata[i].deliveryCode);
                wx.setStorageSync('imgs', alldata[i].imgs);
                wx.setStorageSync('email', alldata[i].email);
                wx.setStorageSync('collegeName', alldata[i].collegeName);
                wx.setStorageSync('name', alldata[i].name);
                wx.setStorageSync('specialtyName', alldata[i].specialtyName);
                wx.setStorageSync('summary', alldata[i].summary);
                wx.setStorageSync('price', alldata[i].price / 100);
                wx.setStorageSync('deliveryFee', alldata[i].deliveryFee / 100);
                wx.setStorageSync('deliveryCode', alldata[i].deliveryCode);
                break;
            }
        }
        app.globalData.myProfileType = that.data.type; //设置离开的type类型
        app.goto("navigateTo", 'my/my-profile/traking/traking')


    },
    // 点击--每项
    gotoGoodDetail(e) {
        var id = e.currentTarget.dataset.id
        console.log(e)
        app.goto('navigateTo', 'my/my-profile/datadetails/datadetails', {
            'fromStudydata': 1,
            'id': id
        })
    },

    // // 点击--搜索
    gotohotSearch() {
        app.goto('navigateTo', 'index/hotsearch/hotsearch', {
            'fromStudyData': 1,
            'type': this.data.type
        })
    },


    // 获取列表
    zzinitList(message, load, time) {

    },

    //点击确认收货
    confirm(e) {
        var curid = e.currentTarget.dataset.id;
        var _this = this;
        wx.showModal({
            title: '确认收货',
            content: '',
            success: function (res) {
                if (res.confirm) {
                    var curid = e.currentTarget.dataset.id;
                    http.httpPost(`/resource/receive/${curid}`, {}, app.globalData.userId, (res) => {
                        if (res.code == 0) {
                            console.log("ce测试结果");
                            var alldata = _this.data.type == 1 ? _this.data.buyListData : _this.data.type == 2 ? this.data.saleListData : '';
                            for (var i = 0; i < alldata.length; i++) {
                                if (alldata[i].orderId == curid) {
                                    alldata[i].status = 3;
                                }
                            }

                            if (_this.data.type == 1) {
                                _this.setData({
                                    buyListData: alldata
                                })
                            } else {
                                _this.setData({
                                    saleListData: alldata
                                })
                            }

                        }


                        console.log(res, '测试的结合更')

                    })
                }
            }
        });


    },
    dzinitList(message, load, time) {
        var param1 = {
            'keyword': this.data.keyword,
            'type': this.data.type, // 1-纸质，2-电子
            'pageNum': this.data.salePageNum, // 当前页
            'pageSize': this.data.dzpageSize, // 每页条数
        }

    },


    getinbuy(message, time) {
        let that = this;
        var type = this.data.type == 1 ? 3 : this.data.type == 2 ? 2 : '';
        wx.showToast({
            title: message,
            icon: 'loading',
            duration: time,
            success: function () {
                if (message == '正在刷新数据') {
                    wx.stopPullDownRefresh()
                }
            }
        })
        http.httpGet(`/resource/mineList`, {
            "type": type,
            "pageSize": that.data.pageSize,
            "pageNum": that.data.orinum
        }, app.globalData.userId, (res) => {


            var data = res.data.list;
            if (data == undefined) {
                return;
            }
            if(data.length < that.data.pageSize && that.data.type == 1){
                that.setData({
                    loadBuyAllFlag : true
                })
            }else if(data.length < that.data.pageSize && that.data.type == 2){
                that.setData({
                    loadSaleAllFlag : true
                })
            }
            for (var i = 0; i < data.length; i++) {
                data[i].mytime = util.formatDate11(data[i].createTime * 1000)
            }
            if (this.data.type == 1) {
                this.setData({
                    buyListData: data
                })
            } else {
                this.setData({
                    saleListData: data
                })

            }

        })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

        this.getinbuy('正在刷新数据', 500);
        console.log(options)

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        let that = this;
        that.setData({
            orinum: 0,
            type: app.globalData.myProfileType
        });

        that.getinbuy("刷新数据", 800)


    },


    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
        let that = this;
        if (that.data.type == 1) {
            that.data.orinum = 0
            that.zzinitList('正在刷新数据', 1, 800)
        } else {
            that.data.orinum = 1
            that.dzinitList('正在刷新数据', 1, 800)
        }

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
        let that = this;
        var type = this.data.type == 1 ? 3 : this.data.type == 2 ? 2 : '';
        if(that.data.loadBuyAllFlag && type == 3){
            return false;
        }else if(that.data.loadSaleAllFlag && type == 2){
            return false;
        }
        wx.showToast({
            title: "正在刷新数据",
            icon: 'loading',
            duration: 800,
            success: function () {

                wx.stopPullDownRefresh()
            }

        })
        if(that.data.type == 1){
            that.setData({
                buyPageNum: that.data.buyPageNum + 1
            })
        }else{
            that.setData({
                salePageNum: that.data.salePageNum + 1
            })
        }

        http.httpGet(`/resource/mineList`, {
            "type": type,
            "pageSize": that.data.pageSize,
            "pageNum": that.data.type == 1 ? that.data.buyPageNum : that.data.salePageNum
        }, app.globalData.userId, (res) => {

            var data = res.data.list;
            if(data.length < that.data.pageSize && that.data.type == 1){
                that.setData({
                    loadBuyAllFlag: true
                })
            }else if(data.length < that.data.pageSize && that.data.type == 2){
                that.setData({
                    loadSaleAllFlag: true
                })
            }
            for (var i = 0; i < data.length; i++) {
                data[i].mytime = util.formatDate11(data[i].createTime * 1000)
            }

            if (this.data.type == 1) {
                this.setData({
                    buyListData: that.data.buyListData.concat(data)
                })
            } else {
                this.setData({
                    saleListData: that.data.saleListData.concat(data)
                })
            }

        })

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})