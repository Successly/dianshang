// 学习资料

var app = getApp()

var http = require('../../../utils/httpHelper')
// var ids = require('../../index/answer-question/answer-question')

Page({

  /**
   * 页面的初始数据
   */
  data: {

    src: '../../../assets/aixing.png',
    play: '../../../assets/play.png',
    arr: [1, 2],
    //红星图片
    hongxing: '../../../assets/hongxing.png',
    // 选中
    activezz: true,
    activedz: false,

    // 返回按钮状态
    scrollTop: 0,
    backTopValue: false,

    zzdisplay: false,
    dzdisplay: false,

    //资料[]
    profiles: [],
    //问题[]
    pros: [],

    // 纸质
    // 分页
    zzpageNum: 1, // 当前页
    zzpageSize: 8, // 每页条数
    zzList: [],
    zzhasMoreData: false,
    

    // 电子
    // 分页
    dzpageNum: 1, // 当前页
    dzpageSize: 8, // 每页条数
    dzList: [],
    dzhasMoreData: true,

    // 资料类型 1-纸质 2-电子
    type: 1,

    value: '搜索',

    keyword: '',
    questions: [],

    // question: false
  },

  // 导航栏切换

  //收藏的资料
  zzdata() {
    this.setData({
      activezz: true,
      activedz: false,
      zzdisplay: true,
      dzdisplay: false,
      zzpageNum: 1,
      type: 1
    })

    this.zzinitList('', 0, 800)
    this.zlinitList()

  },
  zlinitList(){
  var m = {
    type: 1,
    // action: 1
  }
    http.httpGet(`/favorite/list`, m, app.globalData.userId, (res) => {
    console.log(res.data);
    this.setData({
      pros: res.data,
      // question: true
      zzdisplay: true
      
    })
    
  })
  },

//收藏的问题
  dzdata() {
    this.setData({
      activezz: false,
      activedz: true,
      zzdisplay: false,
      dzdisplay: true,
      dzpageNum: 1,
      type: 2
    })

    this.dzinitList('', 0, 800)
    this.wtinitList()
   
  },
  wtinitList(){
    var m = {
      type: 2,
      // action: 1
    }
    http.httpGet(`/favorite/list`, m, app.globalData.userId, (res) => {
      // console.log(res.data.list);
      if(res.code==0){
        console.log('接口请求成功',res)
        var data = res.data
      this.setData({
        pros: data,
        // question: true
      })
      dzdisplay: true
      }else{
        console.log('接口请求失败',res)
      }
    })
    
  },

  // 监听滚动条坐标
  // 

  //去发货
  gotodelivery() {
    app.goto("navigateTo", 'my/my-profile/gotodelivery/gotodelivery')
  },
  // 返回顶部
  onPageScroll: function(e) {
    var that = this
    var scrollTop = e.scrollTop
    var backTopValue = scrollTop > 280 ? true : false
    that.setData({
      backTopValue: backTopValue
    })
  },
  goback() {
    // 控制滚动
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 300
    })
  },
  //物流单号
  traking() {
    app.goto("navigateTo", 'my/my-profile/traking/traking')
  },
  // 点击--每项
  gotoGoodDetail(e) {
    var id = e.currentTarget.dataset.id

    app.goto('navigateTo', 'my/my-profile/datadetails/datadetails', {
      'fromStudydata': 1,
      'id': id
    })
  },

  // // 点击--搜索
  gotohotSearch() {
    app.goto('navigateTo', 'index/hotsearch/hotsearch', {
      'fromStudyData': 1,
      'type': this.data.type
    })
  },


  // 获取列表
  zzinitList(message, load, time) {
    var param1 = {
      'keyword': this.data.keyword,
      'type': this.data.type, // 1-纸质，2-电子
      'pageNum': this.data.zzpageNum, // 当前页
      'pageSize': this.data.zzpageSize, // 每页条数
    }

    // http.httpGet("/resource/list", param1, app.globalData.userId, (res) => {
    //   //     // 加载
    //   if (load == 1) {

    //     wx.showToast({
    //       title: message,
    //       icon: 'loading',
    //       duration: time,
    //       success: function () {
    //         if (message == '正在刷新数据') {
    //           wx.stopPullDownRefresh()
    //         }
    //       }
    //     })
    //   }

    //   if (res.code == 0) {
    //     console.log('------获取资料列表成功-----', res)

    //     if (res.data && res.data.list.length) {
    //       // 当前页展示的数据
    //       var hasList = this.data.zzlist

    //       if (this.data.zzpageNum == 1) {
    //         hasList = []
    //       }

    //       //         // 获取新数据
    //       var zzlist = res.data.list

    //       // 分页加载
    //       if (zzlist.length < this.data.zzpageSize) {
    //         this.setData({
    //           zzlist: hasList.concat(zzlist),
    //           zzhasMoreData: false
    //         })
    //       } else {
    //         this.setData({
    //           zzlist: hasList.concat(zzlist),
    //           zzhasMoreData: true,
    //           zzpageNum: this.data.zzpageNum + 1
    //         })
    //       }

    //     }



    //   } else {
    //     console.log('------获取资料列表失败-----', res)
    //   }

    // })
  },

  //点击确认收货
  confirm() {
    wx.showModal({
      title: '确认收货',
      content: '',
    })
  },
  dzinitList(message, load, time) {
    var param1 = {
      'keyword': this.data.keyword,
      'type': this.data.type, // 1-纸质，2-电子
      'pageNum': this.data.dzpageNum, // 当前页
      'pageSize': this.data.dzpageSize, // 每页条数
    }

    http.httpGet("/resource/list", param1, app.globalData.userId, (res) => {

      // 加载
      if (load == 1) {

        wx.showToast({
          title: message,
          icon: 'loading',
          duration: time,
          success: function () {
            if (message == '正在刷新数据') {
              wx.stopPullDownRefresh()
            }
          }
        })
      }

      if (res.code == 0) {
        console.log('------获取资料列表成功-----', res)

        if (res.data && res.data.list.length) {
          // 当前页展示的数据
          var hasList = this.data.dzlist

          if (this.data.dzpageNum == 1) {
            hasList = []
          }

          // 获取新数据
          var dzlist = res.data.list

          // 分页加载
          if (dzlist.length < this.data.dzpageSize) {
            this.setData({
              dzlist: hasList.concat(dzlist),
              dzhasMoreData: false
            })
          } else {
            this.setData({
              dzlist: hasList.concat(dzlist),
              dzhasMoreData: true,
              dzpageNum: this.data.dzpageNum + 1
            })
          }

        }



      } else {
        console.log('------获取资料列表失败-----', res)
      }
    })
  },

  //纸质资料取消收藏
  cancle(e) {
    var targetid = e.currentTarget.dataset.targetid
    var type = e.currentTarget.dataset.type
    console.log(e);
    var cs = {
      targetId: targetid,
      // type:(type==1?'纸质资料':'电子资料'),
      type: type,
      action: 0
    }
    console.log(cs)
    http.httpPost(`/favorite/do`, cs, app.globalData.userId, (res) => {
      console.log(res)
      if (res.code == 0) {
        console.log("12333333333333333333333333")
        this.collection()
        // app.goto('navigateTo', 'my/mycollection/mycollection')
      }
    })
  },
  collection() {
    var sc = {
      type: 1,
    }
    http.httpGet(`/favorite/list`, sc, app.globalData.userId, (res) => {
      this.setData({
        profiles: res.data
      })
      console.log(res.data);
    })
  },
  //收藏的问题---查看答案
  btn(e) {
    var id = e.currentTarget.dataset.id
    console.log(id);
    app.goto('navigateTo', 'index/answer-question/view-answer/view-answer', {
      id: id
    })
  },
  //取消收藏的问题
  quxiao(e) {
    console.log('11111111111111111111111')
    var targetid = e.currentTarget.dataset.targetid
    var type = e.currentTarget.dataset.type
    var cs = {
      targetId: targetid,
      type: type,
      action: 0
    }
    console.log(cs)
    http.httpPost(`/favorite/do`, cs, app.globalData.userId, (res) => {
      console.log(res)
      if (res.code == 0) {
        this.collections()
        
      }
    })
  },
  collections() {
    var sc = {
      type: 2,
    }
    http.httpGet(`/favorite/list`, sc, app.globalData.userId, (res) => {
      if(res.code==0){
        console.log('接口请求成功',res)
        
      this.setData({
        pros: res.data,
        
      })
        console.log('接口请求失败', res)
      }
    })
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
     this.zzinitList(),
      this.zlinitList(),
      this.wtinitList(),
     this.dzinitList(),
    console.log(options)
    // 从搜索页来
    if (options.fromhotsearch) {
      this.setData({
        value: options.value == '' ? '搜索' : options.value,
        keyword: options.value,
        type: options.type
      })

      if (options.type == 2) {
        this.setData({
          activezz: false,
          activedz: true,
          zzdisplay: false,
          dzdisplay: true,
          dzpageNum: 1
        })
      } else {
        this.setData({
          zzpageNum: 1
        })
      }

    }
    console.log(app.globalData.questionUsers)
    for (var i = 0; i < app.globalData.questionUsers.length; i++) {
      var sk = {
        targetId: app.globalData.questionUsers.questionid,
        action: app.globalData.questionUsers.action,
        type: 2
      }
      console.log(sk);


    }




    if (options.fromStudydata) {
      this.setData({
        id: options.id
      })
    }
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    // this.zlinitList()

    if (this.data.type == 1) {
      this.zzinitList('正在加载数据...', 1, 1000)
    } else {
      this.dzinitList('正在加载数据...', 1, 1000)
    }
    this.collection()
    this.collections()


  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    if (this.data.type == 1) {
      this.data.zzpageNum = 1
      this.zzinitList('正在刷新数据', 1, 800)
    } else {
      this.data.dzpageNum = 1
      this.dzinitList('正在刷新数据', 1, 800)
    }

    this.initList()

    this.initList()

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

    if (this.data.type == 1) {

      if (this.data.zzhasMoreData) {
        this.zzinitList('正在加载数据...', 1, 800)
      }

    } else {

      if (this.data.dzhasMoreData) {
        this.dzinitList('正在加载数据...', 2, 800)
      }

    }

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})