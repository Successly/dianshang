// 我要修改
var app = getApp()

var http = require('../../../utils/httpHelper')

var config = require('../../../config')

const qiniuUploader = require("../../../utils/qiniuUploader")

// 初始化七牛相关参数
function initQiniu() {
  var options = {
    region: 'ECN', // 华东区，生产环境应换成自己七牛帐户bucket的区域
    uptokenURL: `https://wxapp.yanyanbiji.com/yyapp/config/token`, // 生产环境该地址应换成自己七牛帐户的token地址，具体配置请见server端
    domain: 'http://img.rainfn.com/' // 生产环境该地址应换成自己七牛帐户对象存储的域名
  };
  qiniuUploader.init(options);
}


Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl: '',// 图片
    //修改接口输入参数
    name: '', //昵称
    realName: '', // 姓名
    customSchool: '', // 自填学校
    customYuanxi: '',// 自填院系
    zhuanye: '', //我的专业
    skilledCourse: '', //擅长科目
    // eduLevel: 0,
    // idcardImage: '',
    // questionPrice: 60,
    mobile: '',
    summary: '',
    // 下拉框的选择
    // 1-入学时间
    selectTime: false,
    selectedTime: '', //已选入学时间
    // 下拉框的选择
    timeList: ['2018', '2017', '2016', '2015', '2014', '2013', '2012', '2011', '2010', '2009', '2008', '2007', '2006', '2005', '2004', '2003', '2002', '2001', '2000'],

    // 2-我的学校
    selectSchool: false,
    selectedSchool: '',
    selectedSchoolId: 0,
    // 下拉框的选择
    schoolList: [],

    checked: false, // 其他

    // 其他学校的填写
    selectOther: false,


    // 3-我的院系
    selectYuanxi: false,
    selectedYuanxi: '',
    selectedYuanxiId: 0,
    // 下拉框的选择
    yuanxiList: [],

    checkedyuanxi: false, // 其他

    // 其他院系的填写
    selectOtherYuanxi: false,


    // 4-我的学历
    selectXl: false,
    selectedXl: '', // 学历
    // 下拉框的选择
    XlList: ['研究生', '博士'],


    // 5-我的问题酬劳
    selectMoney: false,
    selectedMoney: 2,
    // 下拉框的选择
    MoneyList: [2, 3, 4, 5, 6, 7, 8, 9, 10],


    // 6-我的标签
    selectTag: false,
    selectedTag: '',
    // 下拉框的选择
    TagList: ['冷静分析', '专业', '高效'],


    // 七牛
    // 图片地址
    imageObject: {},
    imgarr: [],

    // 弹窗--修改成功
    success: false,


    // 手机号
    mob: false, // 手机号错误提示
    shouji: '手机号码不能为空',
    mobstatus: false, // 手机号验证通过吗
    // mobile: '',

    pageNum: 1,
    pageSize: 30,
    nickNameShow: false, // 昵称   
    realNameShow: false, // 姓名
    specialtyNameShow: false, // 专业
    skilledCourseShow: false, // 擅长的科目 

    // nickName: '', // 昵称
    nickNameTishi: '昵称不能为空',
    // realName: '', // 姓名
    realNameText: '姓名不能为空',
    // specialtyName: '', // 专业
    specialtyNameText: '我的专业不能为空',
    // skilledCourse: '', // 擅长的科目
    skilledCourseText: '擅长科目不能为空',
    // summary: '', // 自我简介
    summaryShow: false,
    student: false  // 学生证

  },
  // 获取院系
  getYuanxi(id) {
    console.log('请求的大学id', id)
    http.httpGet(`/college/${id}/department/list`, null, app.globalData.userId, (res) => {

      if (res.code == 0) {
        console.log('------获取院系列表成功-----', res)

        if (res.data.length) {
          this.setData({
            yuanxiList: res.data
          })
        }
      } else {
        console.log('------获取院系列表失败-----', res)
      }
    })
  },

  // 获取院系
  // getYuanxi(id) {
  //   console.log('请求的大学id', id)
  //   http.httpGet(`/college/${id}/department/list`, null, app.globalData.userId, (res) => {

  //     if (res.code == 0) {
  //       console.log('------获取院系列表成功-----', res)

  //       if (res.data.length) {
  //         this.setData({
  //           yuanxiList: res.data,
  //           selectedYuanxi: res.data[0].name,
  //           selectedYuanxiID: res.data[0].id,
  //         })
  //       }



  //     } else {
  //       console.log('------获取院系列表失败-----', res)
  //     }
  //   })
  // },

  //获取我的昵称的值
  inputname(e) {
    console.log(e);
  },
  initList() {
    // 学校
    var param1 = {
      'pageNum': this.data.pageNum, // 当前页
      'pageSize': this.data.pageSize, // 每页条数
    }

    http.httpGet("/college/list", param1, app.globalData.userId, (res) => {
      if (res.code == 0) {
        console.log('------获取学校成功-----', res)

        var schoolList = res.data

        if (schoolList.length) {
          this.setData({
            schoolList: schoolList
          })
          this.getYuanxi(this.data.selectedSchoolId)
        } else {
          console.log('------获取学校失败-----', res)
        }
      }
    })


    // 3-获取标签列表
    http.httpGet("/tag/list", param1, app.globalData.userId, (res) => {

      if (res.code == 0) {
        console.log('------获取标签列表成功-----', res)

        if (res.data.length) {
          this.setData({
            TagList: res.data
          })
        }



      } else {
        console.log('------获取标签列表失败-----', res)
      }
    })
  },


  // 下拉框
  // 1-入学时间
  showTimeBox() {
    this.setData({
      selectTime: !this.data.selectTime,
      // selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false,
    })
  },

  timeSelect(e) {
    var name = e.currentTarget.dataset.name
    this.setData({
      selectedTime: name,
      selectTime: false
    })
  },


  // 2-学校
  showSchoolBox() {
    // this.setData({
    //   selectSchool: !this.data.selectSchool,
    //   selectTime: false,
    //   // selectSchool: false,
    //   selectYuanxi: false,
    //   selectXl: false,
    //   selectMoney: false,
    //   selectTag: false,
    // })
  },

  schoolSelect(e) {
    var item = e.currentTarget.dataset.item
    var name = e.currentTarget.dataset.name
    this.setData({
      selectedSchool: item.name,
      selectedSchoolId: item.id,
      selectSchool: false,
      checked: false,
      selectOther: false
    })


    this.getYuanxi(item.id)
  },

  // 其他单选框的改变
  radioChange1(e) {
    if (e.detail.value == '其他') {
      this.setData({
        selectOther: true,
        selectSchool: false
      })
    }
  },

  otherSchool(e) {
    this.setData({
      customSchool: e.detail.value
    })
  },


  // 3-院系
  showYuanxiBox() {
    // this.setData({
    //   selectYuanxi: !this.data.selectYuanxi,
    //   selectTime: false,
    //   selectSchool: false,
    //   // selectYuanxi: false,
    //   selectXl: false,
    //   selectMoney: false,
    //   selectTag: false,
    // })
  },

  yuanxiSelect(e) {
    var item = e.currentTarget.dataset.item
    var name = e.currentTarget.dataset.name
    this.setData({
      selectedYuanxi: item.name,
      selectedYuanxiId: item.id,
      selectYuanxi: false,
      checkedyuanxi: false,
      selectOtherYuanxi: false
    })
  },

  // 其他单选框的改变
  radioChange2(e) {
    if (e.detail.value == '其他') {
      this.setData({
        selectOtherYuanxi: true,
        selectYuanxi: false
      })
    }
  },

  otherYuanxi(e) {
    this.setData({
      customYuanxi: e.detail.value
    })
  },


  // 4-学历
  showXlBox() {
    this.setData({
      selectXl: !this.data.selectXl,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      // selectXl: false,
      selectMoney: false,
      selectTag: false,
    })
  },

  xlSelect(e) {
    var name = e.currentTarget.dataset.name
    this.setData({
      selectedXl: name,
      selectXl: false
    })
  },


  // 5-酬劳
  showMoneyBox() {
    this.setData({
      selectMoney: !this.data.selectMoney,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      // selectMoney: false,
      selectTag: false,
    })
  },

  MoneySelect(e) {
    var name = e.currentTarget.dataset.name
    this.setData({
      selectedMoney: name,
      selectMoney: false
    })
  },


  // 6-标签
  showTagBox() {
    this.setData({
      selectTag: !this.data.selectTag,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      // selectTag: false,
    })
  },

  TagSelect(e) {
    var item = e.currentTarget.dataset.item
    this.setData({
      selectedTag: item.tagName,
      selectedTagID: item.id,
      selectTag: false
    })
  },

  // 昵称
  nickNameInput(e) {

    this.setData({
      name: e.detail.value,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false
    })
  },

  // 失去焦点
  nickNameBlur: function (e) {
    // 空
    if (!e.detail.value.length) {

      this.setData({
        nickNameShow: true,
        nickNameTishi: '昵称不能为空'
      })

    } else if (e.detail.value.length > 10) {
      this.setData({
        nickNameShow: true,
        nickNameTishi: '昵称不能超过10个字'
      })

    } else {
      this.setData({
        nickNameShow: false,
        nickNamePass: true
      })
    }
  },

  // 获取焦点
  nickNameFocus: function () {
    this.setData({
      nickNameShow: false,
      nickNameTishi: '昵称不能为空'
    })
  },

  // 专业
  specialtyNameInput(e) {
    this.setData({
      zhuanye: e.detail.value,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false
    })
  },

  // 失去焦点
  specialtyNameBlur: function (e) {
    // 空
    if (!e.detail.value.length) {

      this.setData({
        specialtyNameShow: true,
        specialtyNameText: '我的专业不能为空',
      })

    } else if (e.detail.value.length > 20) {
      this.setData({
        specialtyNameShow: true,
        specialtyNameText: '我的专业不能超过20字'
      })
    } else {
      this.setData({
        specialtyNameShow: false,
        specialtyNamePass: true
      })
    }
  },

  // 获取焦点
  specialtyNameFocus: function () {
    this.setData({
      specialtyNameShow: false,
      specialtyNameText: '我的专业不能为空',
    })
  },

  // 擅长科目
  skilledCourseInput(e) {
    this.setData({
      skilledCourse: e.detail.value,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false
    })
  },

  // 失去焦点
  skilledCourseBlur: function (e) {
    // 空
    if (!e.detail.value.length) {

      this.setData({
        skilledCourseShow: true,
        skilledCourseText: '擅长科目不能为空'
      })

    } else if (e.detail.value.length > 20) {

      this.setData({
        skilledCourseShow: true,
        skilledCourseText: '擅长科目不能超过20字'
      })

    } else {
      this.setData({
        skilledCourseShow: false,
        skilledCoursePass: true
      })
    }
  },

  // 获取焦点
  skilledCourseFocus: function () {
    this.setData({
      skilledCourseShow: false,
      skilledCourseText: '擅长科目不能为空'
    })
  },


  // 姓名
  realNameInput(e) {
    this.setData({
      realName: e.detail.value,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false
    })
  },

  // 失去焦点
  realNameBlur: function (e) {
    // 空
    if (!e.detail.value.length) {

      this.setData({
        realNameShow: true,
        realNameText: '姓名不能为空',
      })

    } else if (e.detail.value.length > 20) {

      this.setData({
        realNameShow: true,
        realNameText: '姓名不能超过20字',
      })

    } else {
      this.setData({
        realNameShow: false
      })
    }
  },

  // 获取焦点
  realNameFocus: function () {
    this.setData({
      realNameShow: false,
      realNameText: '姓名不能为空',
    })
  },


  // 输入手机号时
  mobileHandle(e) {
    this.setData({
      mobile: e.detail.value,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false
    })
  },

  // 手机号校验 -- 失去焦点
  mobHandle: function (e) {
    var myreg = /^[1][3,4,5,7,8][0-9]{9}$/;
    // 空
    if (!e.detail.value) {
      this.setData({
        mob: true,
        shouji: '手机号码不能为空',
        mobstatus: false,
      }) // 手机号码不正确
    } else if (!myreg.test(e.detail.value)) {
      this.setData({
        mob: true,
        shouji: '请输入正确的手机格式',
        mobstatus: false
      })
    } else {
      this.setData({
        mob: false,
        mobile: e.detail.value,
        mobstatus: true
      })
    }
  },

  // 重新输入手机号 -- 获取焦点
  srHandle: function () {
    this.setData({
      mob: false,
      shouji: '手机号码不能为空',
      mobstatus: false
    })
  },


  // 自我简介
  summaryInput(e) {
    this.setData({
      summary: e.detail.value
    })
  },

  // 失去焦点
  summaryBlur: function (e) {
    // 空
    if (!e.detail.value.length) {

      this.setData({
        summaryShow: true
      })

    } else {
      this.setData({
        summaryShow: false,
        summaryPass: true
      })
    }
  },

  // 获取焦点
  summaryFocus: function () {
    this.setData({
      summaryShow: false
    })
  },



  // 七牛上传图片
  didPressChooesImage: function () {
    var that = this;
    didPressChooesImage(that);
  },

  // 点击删除该图片
  deletePhoto(e) {
    var index1 = e.currentTarget.dataset.index
    var imgarr = this.data.imgarr
    imgarr.map((item, index, arr) => {
      if (index == index1) {
        imgarr.splice(index, 1)
      }
    })
    // 重新渲染
    this.setData({
      imgarr: imgarr
    })
  },

  // 确认修改
  submit() {

    if (!this.data.imgarr.length) {
      this.setData({
        student: true
      })
    } else {

      var param1 = {
        name: this.data.name.replace(/[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\A9|\AE]\u3030|\uA9|\uAE|\u3030/ig, ""),	// 是	昵称	String
        realName: this.data.realName,		// 真实姓名	String
        collegeId: this.data.selectOther ? '' : this.data.selectedSchoolId,		// 我的学校ID，未选填0	Integer
        collegeName: this.data.selectOther ? this.data.customSchool : this.data.selectedSchool,		// 我的学校名称	String
        departmentId: this.data.selectOtherYuanxi ? '' : this.data.selectedYuanxiId,		// 我的院系ID，未选填0	Integer
        departmentName: this.data.selectOtherYuanxi ? this.data.customYuanxi : this.data.selectedYuanxi,
        collegeEnterTime: this.data.selectedTime,	// 是	大学入学时间（年份，2018）	String
        specialtyName: this.data.zhuanye,	// 是	我的专业名称	String
        skilledCourse: this.data.skilledCourse,	// 是	擅长科目名称	String
        eduLevel: this.data.selectedXl == '研究生' ? 1 : (this.data.selectedXl == '博士' ? 2 : 0),	// 是	学历水平(1-研究生，2-博士，未知填0)	Integer
        idcardImage: this.data.imgarr[0],	// 是	学生证图片URL	String
        questionPrice: this.data.selectedMoney * 100,	// 是	我的问题酬劳，单位：分	Integer
        mobile: this.data.mobile,		// 我的联想方式	String
        summary: this.data.summary,	// 是	自我简介	String
        tagId: this.data.selectedTagID,		// 标签ID	Ingeter
        tagName: this.data.selectedTag		// 标签名称	String
      }

        console.log('修改研究生传参', param1)

        http.httpPost("/user/update", param1, app.globalData.userId, (res) => {
          if (res.code == 0) {

            console.log('------修改研究生成功-----', res)
            console.log(res)
            this.setData({
              success: true
            })

            setTimeout(() => {
              app.goto('switchTab', 'my/my')
            }, 2500)


          } else {
            console.log('------修改研究生失败-----', res)
          }
        })

    }

  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    this.setData({
      name: options.name,
      selectedTime: options.collegeEnterTime,
      selectedSchool: options.collegeName,
      selectedSchoolId: options.collegeId,
      selectedYuanxi: options.departmentName,
      selectedYuanxiId: options.departmentId,
      zhuanye: options.specialtyName,
      skilledCourse: options.skilledCourse,
      selectedXl: options.eduLevel == '1' ? '研究生': (options.eduLevel == '2' ? '博士' : '其他'),
      imgUrl: options.idcardImage,
      selectedMoney: options.questionPrice / 100,
      selectedTagID: options.tagId,
      selectedTag: options.tagName,
      realName: options.realName,
      mobile: options.mobile,
      summary: options.summary
    })
    var iarr = []
    iarr.push(this.data.imgUrl)
    this.setData({
      imgarr: iarr
    })
    this.initList()
    //修改接口调用
    // var param2 = {
    //   'name': this.data.name,
    //   'realName': this.data.realName,
    //   'collegeEnterTime': this.data.collegeEnterTime,
    //   'specialtyName': this.data.specialtyName,
    //   'skilledCourse': this.data.skilledCourse,
    //   'eduLevel': this.data.eduLevel,
    //   'idcardImage': this.data.idcardImage,
    //   'questionPrice': this.data.questionPrice,
    //   'summary': this.data.summary
    // }
    // http.httpGet("user/income", null, 2, (res) => {
    //   console.log(res);
    //   if (res.code == 0) {
    //     console.log('------获取学校成功-----', res)
    //     console.log(res);
    //   } else {
    //     console.log('------获取学校失败-----', res)
    //   }
    // })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})

function didPressChooesImage(that) {
  initQiniu();

  if (that.data.imgarr.length == 3) {

    wx.showToast({
      icon: 'loading',
      title: '最多添加3张图片哦',
      duration: 1200
    })

  } else {

    // // 微信 API 选文件
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      success: function (res) {
        var filePath = res.tempFilePaths[0];
        var files = res.tempFilePaths
        console.log('上传', filePath)


        var imgarr = that.data.imgarr

        // 交给七牛上传
        qiniuUploader.upload(filePath, (res) => {
          imgarr.push(res.imageURL)
          that.setData({
            'imageObject': res,
            'imgarr': imgarr,
            'student': false
          });
        }, (error) => {
          console.error('error: ' + JSON.stringify(error));
        });
      },
      error: function (error) {
        console.error('error: ' + JSON.stringify(error));
      }
    })

  }
}