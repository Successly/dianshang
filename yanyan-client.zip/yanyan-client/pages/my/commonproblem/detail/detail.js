// pages/my/commonproblem/detail/detail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    problem: {}
  },
  
  // 请求--获取问题列表
  initList () {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('---问题详情页 参数---', options)
    var cproblem = {}
    cproblem.id = options.id
    cproblem.remark = options.remark
    cproblem.title = options.title
    cproblem.image = options.image

    this.setData({
      problem: cproblem
    }) 

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

    /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    　var that = this;
  　　// 设置菜单中的转发按钮触发转发事件时的转发内容
  　　return {
  　　　　title: "省心，省钱，省空间, 1折的价格，100%的爱！",        // 默认是小程序的名称(可以写slogan等)
  　　　　path: `/pages/index/index`,     // 默认是当前页面，现在跳转到首页
  　　　　imgUrl: 'http://img.rainfn.com/12-16-zuzehwaner-banner1.jpg',     //自定义图片路径，可以是本地文件路径、代码包文件路径或者网络图片路径，支持PNG及JPG，不传入 imageUrl 则使用默认截图。显示图片长宽比是 5:4
  　　    success: function(res){
  　　　　　　// 转发成功之后的回调
  　　　　　　if(res.errMsg == 'shareAppMessage:ok'){
                console.log('转发成功')
  　　　　　　}
  　　　　},
  　　　　fail: function(){
  　　　　　　// 转发失败之后的回调
  　　　　　　if(res.errMsg == 'shareAppMessage:fail cancel'){
                console.log('用户取消转发')
  　　　　　　} else if(res.errMsg == 'shareAppMessage:fail'){
                console.log('转发失败')
  　　　　　　}
  　　　　},
  　　　  complete: function() {
  　　　　　　// 转发结束之后的回调（转发成不成功都会执行）
  　　　　}
      }
  }
    

})