// 常见问题页
var app = getApp()

var http = require('../../../utils/httpHelper.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    queslist: [], // 问题列表
    hidden: false,
  },

  initList() {
    // 请求 -- 获取问题列表
    console.log('------获取问题列表----pre-')
    http.httpGet("/problem/list", null, (res) => {

      console.log('------获取问题列表----after-')

      if(res.code == 0) {
        console.log('------获取问题列表-----',res)

        this.setData({
          queslist: res.data
        })

      } else {
        console.log(res.msg)
      }
    })
  },

  // 点击展开
  linkarr(e) {
    // TODO 展开remark字段内容
    console.log(e)
    queslist : e.currentTarget.dataset
    hidden: true
   
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    http.httpGet(`/problem/list`, null, 30, (res) => {
      console.log(res);
      if (res.code == 0) {
        console.log('------获取问题列表-----', res)

        this.setData({
          queslist: res.data
        })

      } else {
        console.log(res.msg)
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.initList()
  },


})