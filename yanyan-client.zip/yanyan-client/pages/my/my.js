// 我的页面
var app = getApp()

var http = require('../../utils/httpHelper.js')

Page({

    /**
     * 页面的初始数据
     */
    data: {
        userlogin: null,
        popOpen: false, // 手机弹窗

        pt: true, // 普通会员的测试
        tit: "立即登录",
        //用户登录图片
        src: '',


        // 用户信息
        loginUserInfo: null,


        // 各个数量
        unCommentCount: 0, // 待评价
        unDeliveryCount: 0, // 待发货
        unPayCount: 0, // 待付款
        unReceivingCount: 0, // 待收货
        unReturnCount: 0, // 待归还

        // 会员的话--会员卡类型
        bgtype: null,

        userInfo: null,
        type: null,
        name: null


    },

    // 点击--立即登录
    gotoLogin(res) {
        app.authorizeHandle(res, app.refeusetologin, app.gotologin, this.afterLogin)
        // console.log(res.userInfo.nickName)
        // console.log(this.afterLogin)
        this.setData({
            // src: res.userInfo.avatarUrl,
            // tit: res.name
        })
    },

    afterLogin() {
        // 登录后执行
        this.setData({
            userInfo: true
        })

        this.initList()
    },

    //我的发布
    myrealese() {
        wx.navigateTo({
            url: './my-realese/my-realese',
        })
    },
    //我的资料
    myprofile() {
        app.goto('navigateTo', 'my/my-profile/my-profile')
    },
    // 修改个人信息
    goChangeUserInfo() {
        http.httpGet(`/user/detail/${app.globalData.userId}`, null, app.globalData.userId, (res) => {
            if (res.code == 0) {
                console.log('------获取用户信息成功-----', res)
                app.globalData.users = res.data;
                app.globalData.usertype = res.data.type;
                console.log('11111111111', app.globalData.users.eduLevel);
                this.setData({
                    userinfo: res.data
                })
                if (res.data.type !== null) {
                    app.goto('navigateTo', 'my/changeuserinfo/changeuserinfo', this.data.userinfo)
                }
                // else{
                //   app.goto('navigateTo', 'my/changeinfo/changeinfo')
                // }
            } else {
                console.log('------获取用户信息失败-----', res)
            }
        })
    },

    // 我的收益
    goMyIncome() {
        app.goto('navigateTo', 'my/myincome/myincome')

    },
    //我收到的问题
    myreceive() {
        app.goto('navigateTo', 'my/myreceive/myreceive')
    },
    // 我的收藏
    gomycollection() {
        app.goto('navigateTo', 'my/mycollection/mycollection')
    },

    // 问题反馈
    goproblemfeedback() {
        app.goto('navigateTo', 'my/problemfeedback/problemfeedback')
    },

    // 常见问题
    gocommonproblem() {
        app.goto('navigateTo', 'my/commonproblem/commonproblem')
    },

    // 手机弹窗
    // 显示
    openHandle() {
        this.setData({
            popOpen: true
        })
    },
    // 否 -- 关闭
    popcancel() {
        this.setData({
            popOpen: false
        })
    },
    // 点击屏幕关闭
    closeHandle() {
        this.setData({
            popOpen: false
        })
    },
    // 是 -- 拨打电话
    popsure() {
        wx.makePhoneCall({
            phoneNumber: '18168064412',
            success: (e) => {
                console.log('拨打电话成功', e)
                this.setData({
                    popOpen: false
                })
            },
            fail: (res) => {
                console.log(res)
            }
        })
    },

    // 请求--判断用户是否是会员
    initList() {

    },
    getUserInfo() {
        http.httpGet(`/user/detail/${app.globalData.userId}`, null, app.globalData.userId, (res) => {
            if (res.code == 0) {
                console.log('------获取用户信息成功-----', res)
                this.setData({
                    name: res.data.name,
                    src: res.data.avatar
                })
            } else {
                console.log('------获取用户信息失败-----', res)
            }
        })
    },


    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        console.log(app.globalData.users);
        app.globalData.usertype = app.globalData.users.type;
        console.log(app.globalData.usertype);
        this.setData({
            type: app.globalData.users.type,
            name: app.globalData.users.name,
            src: app.globalData.users.avatar
        })

        // console.log(this.data.type)
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.getUserInfo()
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
        var that = this;　　 // 设置菜单中的转发按钮触发转发事件时的转发内容

        return {
            title: "省心，省钱，省空间, 1折的价格，100%的爱！", // 默认是小程序的名称(可以写slogan等)
            path: `/pages/index/index`, // 默认是当前页面，现在跳转到首页
            imgUrl: 'http://img.rainfn.com/12-16-zuzehwaner-banner1.jpg', //自定义图片路径，可以是本地文件路径、代码包文件路径或者网络图片路径，支持PNG及JPG，不传入 imageUrl 则使用默认截图。显示图片长宽比是 5:4
            success: function (res) {　　　　　　 // 转发成功之后的回调

                if (res.errMsg == 'shareAppMessage:ok') {
                    console.log('转发成功')
                }
            },
            fail: function () {　　　　　　 // 转发失败之后的回调

                if (res.errMsg == 'shareAppMessage:fail cancel') {
                    console.log('用户取消转发')
                } else if (res.errMsg == 'shareAppMessage:fail') {
                    console.log('转发失败')
                }
            },
            complete: function () {　　　　　　 // 转发结束之后的回调（转发成不成功都会执行）
            }
        }
    }


})