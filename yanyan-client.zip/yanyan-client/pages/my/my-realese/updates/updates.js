// 修改资料
var app = getApp()
var http = require('../../../../utils/httpHelper')
var config = require('../../../../config')

const qiniuUploader = require("../../../../utils/qiniuUploader")

// 初始化七牛相关参数
function initQiniu() {
  var options = {
    region: 'ECN', // 华东区，生产环境应换成自己七牛帐户bucket的区域
    uptokenURL: 'https://wxapp.yanyanbiji.com/yyapp/config/token', // 生产环境该地址应换成自己七牛帐户的token地址，具体配置请见server端
    domain: 'http://img.rainfn.com/' // 生产环境该地址应换成自己七牛帐户对象存储的域名
  };
  qiniuUploader.init(options);
}


Page({

  /**
   * 页面的初始数据
   */
  data: {
    // dataname: '', // 资料名
    customizeSchool: '', // 其他学校名
    customizeYuanxi: '', // 其他院系名
    ziliaoZhuanye: '', // 资料专业
    summary: '',
    youfei: 0,
    // 下拉框的选择

    // 2-我的学校
    selectSchool: false,
    selectedSchool: '',
    selectedSchoolId: 0,
    // 下拉框的选择
    schoolList: [],

    checked: false, // 其他

    // 其他学校的填写
    selectOther: false,


    // 3-我的院系
    selectYuanxi: false,
    selectedYuanxi: '',
    selectedYuanxiId: 0,
    // 下拉框的选择
    yuanxiList: [],

    checkedyuanxi: false, // 其他

    // 其他院系的填写
    selectOtherYuanxi: false,


    // 4-资料形式
    selectXl: false,
    selectedXl: '纸质资料',
    // 下拉框的选择
    XlList: ['纸质资料', '电子资料'],


    // 5-是否包邮
    selectTag: false,
    selectedTag: '是',
    // 下拉框的选择
    TagList: ['是', '否'],


    // 七牛
    // 图片地址
    imageObject: {},
    imgarr: [],

    // 弹窗--申请成功
    success: false,

    nickNameShow: false, // 资料名称   
    nickName: '', // 资料名称
    nickNameTishi: '资料名称不能为空',

    zhuanyeShow: false, // 专业   
    zhuanye: '', // 专业
    zhuanyeTishi: '专业不能为空',

    priceShow: false, // 资料价格   
    price: 0, // 资料价格
    priceTishi: '资料价格不能为空',



  },

  // 获取院系
  getYuanxi(id) {
    http.httpGet(`/college/${id}/department/list`, null, app.globalData.userId, (res) => {

      if (res.code == 0) {
        console.log('------获取院系列表成功-----', res)

        if (res.data.length) {
          this.setData({
            yuanxiList: res.data
          })
        }
      } else {
        console.log('------获取院系列表失败-----', res)
      }
    })
  },

  initList() {
    // 1-获取学校列表
    var param1 = {
      'pageNum': 1, // 当前页
      'pageSize': 20, // 每页条数
    }

    http.httpGet("/college/list", param1, app.globalData.userId, (res) => {
      if (res.code == 0) {
        console.log('------获取学校成功-----', res)

        var schoolList = res.data

        if (schoolList.length) {
          this.setData({
            schoolList: schoolList
          })
          this.getYuanxi(this.data.selectedSchoolId)
        }



      } else {
        console.log('------获取学校失败-----', res)
      }
    })

  },

  // 下拉框
  // 2-学校
  showSchoolBox() {
    this.setData({
      selectSchool: !this.data.selectSchool,
      selectTime: false,
      // selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false,
    })
  },

  schoolSelect(e) {
    var item = e.currentTarget.dataset.item
    console.log(item)
    this.setData({
      selectedSchool: item.name,
      selectedSchoolId: parseInt(item.id),
      selectSchool: false,
      checked: false,
      selectOther: false
    })

    this.getYuanxi(item.id)
  },

  // 其他单选框的改变
  schoolRadioChange(e) {
    if (e.detail.value == '其他') {
      this.setData({
        selectOther: true,
        selectSchool: false
      })
    }
  },
  otherSchool(e) {
    this.setData({
      customizeSchool: e.detail.value
    })
  },


  // 3-院系
  showYuanxiBox() {
    this.setData({
      selectYuanxi: !this.data.selectYuanxi,
      selectTime: false,
      selectSchool: false,
      // selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false,
    })
  },

  yuanxiSelect(e) {
    var item = e.currentTarget.dataset.item
    // console.log(item)
    this.setData({
      selectedYuanxi: item.name,
      selectYuanxi: false,
      checkedyuanxi: false,
      selectOtherYuanxi: false
    })
  },

  // 其他单选框的改变
  yuanxiRadioChange(e) {
    if (e.detail.value == '其他') {
      this.setData({
        selectOtherYuanxi: true,
        selectYuanxi: false
      })
    }
  },
  otherYuanxi(e) {
    this.setData({
      customizeYuanxi: e.detail.value
    })
  },


  // 4-学历
  showXlBox() {
    this.setData({
      selectXl: !this.data.selectXl,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      // selectXl: false,
      selectMoney: false,
      selectTag: false,
    })
  },

  xlSelect(e) {
    var name = e.currentTarget.dataset.name
    this.setData({
      selectedXl: name,
      selectXl: false
    })
  },


  // 5-是否包邮
  showTagBox() {
    this.setData({
      selectTag: !this.data.selectTag,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      // selectTag: false,
    })
  },

  TagSelect(e) {
    var name = e.currentTarget.dataset.name
    this.setData({
      selectedTag: name,
      selectTag: false
    })
  },

  // 资料名称
  nickNameInput(e) {
    this.setData({
      nickName: e.detail.value,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false
    })
  },

  // 失去焦点
  nickNameBlur: function (e) {
    // 空
    if (!e.detail.value.length) {

      this.setData({
        nickNameShow: true,
        nickNameTishi: '资料名称不能为空'
      })

    } else if (e.detail.value.length > 10) {

      this.setData({
        nickNameShow: true,
        nickNameTishi: '资料名称不能超过10个字'
      })

    } else {
      this.setData({
        nickNameShow: false,
        nickNamePass: true
      })
    }
  },

  // 获取焦点
  nickNameFocus: function () {
    this.setData({
      nickNameShow: false,
      nickNameTishi: '资料名称不能为空'
    })
  },

  // 资料专业
  zhuanyeInput(e) {

    this.setData({
      zhuanye: e.detail.value,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false
    })
  },

  // 失去焦点
  zhuanyeBlur: function (e) {
    // 空
    if (!e.detail.value.length) {

      this.setData({
        zhuanyeShow: true,
        zhuanyeTishi: '专业不能为空'
      })

    } else if (e.detail.value.length > 10) {

      this.setData({
        zhuanyeShow: true,
        zhuanyeTishi: '专业不能超过10个字'
      })

    } else {
      this.setData({
        zhuanyeShow: false,
        zhuanyePass: true
      })
    }
  },

  // 获取焦点
  zhuanyeFocus: function () {
    this.setData({
      zhuanyeShow: false,
      zhuanyeTishi: '专业不能为空'
    })
  },

  // 资料价格
  priceInput(e) {

    this.setData({
      price: e.detail.value,
      selectTime: false,
      selectSchool: false,
      selectYuanxi: false,
      selectXl: false,
      selectMoney: false,
      selectTag: false
    })
  },

  // 失去焦点
  priceBlur: function (e) {
    // 空
    if (!e.detail.value.length) {

      this.setData({
        priceShow: true,
        priceTishi: '价格不能为空'
      })

    } else if (e.detail.value.length > 10) {

      this.setData({
        priceShow: true,
        priceTishi: '价格不能超过10个字'
      })

    } else {
      this.setData({
        priceShow: false,
        pricePass: true
      })
    }
  },

  // 获取焦点
  priceFocus: function () {
    this.setData({
      priceShow: false,
      priceTishi: '价格不能为空'
    })
  },

  // 邮费
  youfeiInput(e) {
    this.setData({
      youfei: e.detail.value,
    })
  },

  // 自我简介
  summaryInput(e) {
    this.setData({
      summary: e.detail.value
    })
  },


  // 七牛上传图片
  didPressChooesImage: function () {
    var that = this;
    didPressChooesImage(that);
  },

  // 点击删除该图片
  deletePhoto(e) {
    var index1 = e.currentTarget.dataset.index
    var imgarr = this.data.imgarr
    imgarr.map((item, index, arr) => {
      if (index == index1) {
        imgarr.splice(index, 1)
      }
    })
    // 重新渲染
    this.setData({
      imgarr: imgarr
    })
  },

  // 确认修改
  subApply() {

    var param1 = {
      name: this.data.nickName, // 是	资料名称	String
      type: this.data.selectedXl == '纸质资料' ? 1 : 2, // 是	资料类型：1-纸质，2-电子	Integer
      price: parseFloat(this.data.price * 100), // 是	价格，单位：分	Integer
      collegeId: this.data.selectOther ? '' : this.data.selectedSchoolId, // 我的学校ID，未选填0	Integer
      collegeName: this.data.selectOther ? this.data.customizeSchool : this.data.selectedSchool, // 我的学校名称	String
      departmentId: this.data.selectOtherYuanxi ? '' : this.data.selectedYuanxiID, // 我的院系ID，未选填0	Integer
      departmentName: this.data.selectOtherYuanxi ? this.data.customizeYuanxi : this.data.selectedYuanxi, //	院系名称	String
      specialtyName: this.data.zhuanye, // 是	我的专业名称	String
      isFreeDelivery: this.data.selectedTag == '是' ? 1 : 0, // 是	是否免费包邮，0否，1是	Integer
      deliveryFee: this.data.selectedTag == '是' ? 0 : this.data.youfei * 100, // 是	邮费，单位：分	Integer
      imgs: this.data.imgarr, // 图片	String[]
      summary: this.data.summary, // 是	简介	String
      status: 1
    }

    if (this.data.nickName != '' && this.data.zhuanye != '' && this.data.price != '') {

      console.log('修改资料传参', param1)

      http.httpPost(`/resource/update/${this.data.id}`, param1, app.globalData.userId, (res) => {

        if (res.code == 0) {
          console.log('------修改资料成功-----', res)

          this.setData({
            success: true
          })

          setTimeout(() => {
            app.goto('navigateBack', 'release/release')
          }, 2500)
          console.log("修改资料成功");

        } else {
          console.log('------修改资料失败-----', res)
        }
      })

    } else {
      console.log("12333333333333333333")
    }


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log(JSON.parse(options.imgs))
    let arrimg = JSON.parse(options.imgs)
    var imgnow = []
    if (arrimg != null) {
      for (let i = 0; i<arrimg.length;i++) {
        imgnow.push(arrimg[i].url)
      }
    }
    // if (options.collegeId != '0' && options.departmentId != '0') {
    this.setData({
      id: options.id,
      nickName: options.name,
      selectedSchool: options.collegeName,
      selectedSchoolId: parseInt(options.collegeId),
      selectedYuanxi: options.departmentName,
      selectedYuanxiId: parseInt(options.departmentId),
      zhuanye: options.specialtyName,
      selectedXl: options.type == 1 ? '纸质资料' : '电子资料',
      price: options.price / 100,
      selectedTag: options.isFreeDelivery == 1 ? '是' : '否',
      youfei: options.deliveryFee / 100,
      imgarr: imgnow,
      summary: options.summary,  
    })
    // }
    // } else {
    //   this.setData({
    //     id: options.id,
    //     nickName: options.name,
    //     checked: true,
    //     selectOther: true,
    //     checkedyuanxi: true,
    //     selectOtherYuanxi: true,
    //     customizeSchool: options.collegeName,
    //     customizeYuanxi: options.departmentName,
    //     zhuanye: options.specialtyName,
    //     selectedXl: options.type == 1 ? '纸质资料' : '电子资料',
    //     price: options.price / 100,
    //     selectedTag: options.isFreeDelivery == 1 ? '是' : '否',
    //     youfei: options.deliveryFee / 100,
    //     imgarr: imgnow,
    //     summary: options.summary
    //   })
    // }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.initList()
  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})

function didPressChooesImage(that) {
  initQiniu();

  if (that.data.imgarr.length == 3) {

    wx.showToast({
      icon: 'loading',
      title: '最多添加3张图片哦',
      duration: 1200
    })

  } else {

    // // 微信 API 选文件
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      success: function (res) {
        var filePath = res.tempFilePaths[0];
        var files = res.tempFilePaths
        console.log('上传', filePath)


        var imgarr = that.data.imgarr
        // 交给七牛上传
        qiniuUploader.upload(filePath, (res) => {
          imgarr.push(res.imageURL)
          that.setData({
            'imageObject': res,
            'imgarr': imgarr
          });
        }, (error) => {
          console.error('error: ' + JSON.stringify(error));
        });


      }
    })

  }
}