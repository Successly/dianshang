// pages/my/my-realese/my-realese.js
var app = getApp();
var http = require('../../../utils/httpHelper')
var utils = require('../../../utils/util.js')
var util = require('../../../utils/util')

const innerAudioContext = wx.createInnerAudioContext()


Page({
  /**
   * 页面的初始数据
   */
  data: {
    tab1boolean: false,
    tab2boolean: true,
    tab3boolean: true,
    color1: "#4697e6",
    color2: "black",
    color3: "black",
    src: "../../../../assets/edit.png",
    src1: "../../../assets/delete.png",
    departments: "计算机学院",
    subjects: "数学",
    fabu: [],
    name: null,
    departmentName: null,
    specialtyName: null,
    price: null,
    isFreeDelivery: null,
    deliveryFee: null,
    summary: null,
    problems: [],


    fabulist: [],
    //导入retract.js
    retractList: [],
    pageNum: 1,
    pageSize: 10,
    hasMoreData: true,
    istishi:true
  },

  // 监听滚动条坐标
  onPageScroll: function(e) {
    var that = this
    var scrollTop = e.scrollTop
    var backTopValue = scrollTop > 10 ? true : false
    that.setData({
      backTopValue: backTopValue
    })
  },
  // 返回顶部
  goback() {
    // 控制滚动
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 300
    })
  },
  //点击编辑
  edit(e) {
    console.log(e);
    var edititem = e.currentTarget.dataset.item
    console.log(edititem)
    app.goto('navigateTo', 'my/my-realese/updates/updates', {
      id: edititem.id,
      name: edititem.name,
      collegeName: edititem.collegeName,
      collegeId: edititem.collegeId,
      departmentName: edititem.departmentName,
      departmentId: edititem.departmentId,
      specialtyName: edititem.specialtyName,
      type: edititem.type,
      price: edititem.price,
      isFreeDelivery: edititem.isFreeDelivery,
      deliveryFee: edititem.deliveryFee,
      imgs: JSON.stringify(edititem.imgs),
      summary: edititem.summary
    })
  },
  //点击回复
  reply() {
    wx.showModal({
      title: '',
      content: '确定收回吗',
    })
  },
  //点击删除
  discard() {
    wx.showModal({
      title: '',
      content: '确定删除吗',
    })
  },
  //点击下架
  soldout(e) {
    console.log('下架',e.currentTarget.dataset.id);
    var ids = [e.currentTarget.dataset.id]
    var status = [e.currentTarget.dataset.status];
    console.log(ids);
    if(status != 2){
        var w = {
            id: ids
        }
        http.httpPost(`/resource/down/${ids}`, w, app.globalData.userId, (res) => {
            console.log(res);
            if (res.code == 0) {
                this.onLoad();
                this.fabu();
            }
        })
    }
  },
  //点击切换
  date(e) {
    this.setData({
      tab1boolean: false,
      tab2boolean: true,
      tab3boolean: true,
      color1: "#4697e6",
      color2: "black",
      color3: "black",
    })
  },

  //点击发布的问题按钮
  problem() {
    this.setData({
      tab1boolean: true,
      tab2boolean: false,
      tab3boolean: true,
      color1: "black",
      color2: "#4697e6",
      color3: "black",
    })
    var pro = {
      pageSize: 30,
      pageNum: 0
    }

    http.httpGet(`/question/mineList?type=1`, pro, app.globalData.userId, (res) => {
      console.log(res);
      if (res.data != "") {
        var data = res.data.list
        console.log(data);
        if (data != []) {
          for (var i = 0; i < data.length; i++) {

            data[i].mtime = utils.formatDateTime(data[i].expireTime * 1000)
            // var mday = ((data[i].mtime / 1000) / 60) / 60/24;

          }
          this.setData({
            problems: data
          })
        }
      }


      console.log(res.data.list);

    })
  },
  //点击小纸条
  paper() {
    this.setData({
      tab1boolean: true,
      tab2boolean: true,
      tab3boolean: false,
      color1: "black",
      color2: "black",
      color3: "#4697e6",
    })
    var k = {
      type: 1,
      pageSize: 20,
      pageNum: 0
    }
    http.httpGet(`/scrip/list`, k, app.globalData.userId, (res) => {
      console.log(res)
      var list = res.data.list
      if (list) {
        list.map((item, index, arr) => {
          item.createTime = util.formatDate1(item.createTime)
          console.log('时间', item.createTime)
        })
     
      this.setData({
        fabulist: res.data.list

      })
      }
      console.log(this.data.fabulist);
    })
  
    // app.goto('navigateTo', 'index/notes/retract/retract')
  
  },
  //详情页
  detail() {
    app.goto('navigateTo', 'index/notes/retract/detail/detail')
  },
  //点击查看问题答案
  findanswer(e) {
    console.log(e.currentTarget.dataset.id);
    this.setData({
      id: e.currentTarget.dataset.id
    })
    app.goto('navigateTo', 'index/answer-question/view-answer/view-answer',{
      'id': this.data.id
    })
  },
  //发布问题删除按钮
  delete(e) {

    var ids = e.currentTarget.dataset.questionid
    // var ids = 21
    // console.log(e.currentTarget.dataset.questionid)
    http.httpGet(`/question/delete?id=${ids}`, null, app.globalData.userId, (res) => {
      console.log(res);
      if (res.code == 0) {
        this.problem()
        // app.goto('switchTab','my/my-realese/my-realese')
      }
    })



    // http
  },


  //导入retract.js
  audioPlay() {
    console.log('-----播放录音-----')
    this.audioCtx.play()
  },

  initList(message, load) {

    var params = {
      type: 1, // 类别（1-发布的小纸条，2-收起的小纸条）	Integer	是
      pageNum: this.data.pageNum, // 分页数	Integer	否
      pageSize: this.data.pageSize // 分页尺寸	Integer	否
    }

    http.httpGet(`/scrip/list`, params, app.globalData.userId, (res) => {

      // 加载
      if (load == 1) {

        wx.showToast({
          title: message,
          icon: 'loading',
          duration: 1000,
          success: function() {
            if (message == '正在刷新数据') {
              wx.stopPullDownRefresh()
            }
          }
        })
      }

      // 当前页展示的数据
      var hasList = this.data.list
      if (res.code == 0) {
        console.log('------获取小纸条列表成功-----', res)
        

        if (this.data.pageNum == 1) {
          hasList = []
        }

        // 获取新数据
        var list = res.data.list

        if (list) {
          list.map((item, index, arr) => {
            item.createTime = util.formatDate1(item.createTime)
            console.log('时间',item.createTime)
          })


          // 分页加载
          if (list.length < this.data.pageSize) {
            this.setData({
              retractList: hasList.concat(list),
              hasMoreData: false
            })
          } else {
            this.setData({
              retractList: hasList.concat(list),
              hasMoreData: true,
              pageNum: this.data.pageNum + 1
            })
          }
        }


      } else {
        console.log('------获取小纸条列表失败-----', res)
      }

    })


  },

  // 丢弃
  discardHandle(e) {
    console.log('丢弃',e)
    var item = e.currentTarget.dataset.item
    console.log(item)
    var params = {
      scripId: item.id, // 小纸条id
      replyId: item.replyId, // 回复者id
      content: item.content, // 回复内容
      audio: item.audio, // 问题语音链接
      status: 3 // 1-已捡到并回复，2-回复并丢掉，3- 丢弃
    }
    console.log('---丢弃小纸条传参---', params)

    http.httpGet(`scrip/delete/?ids=` +item.id, null , app.globalData.userId, (res) => {

      if (res.code == 0) {
        console.log('------丢弃小纸条成功-----', res)
        // this.onShow()
        this.paper()
        this.initList()
        
        // perpage.onLoad()
      } else {
        console.log('------丢弃小纸条失败-----', res)
      }

    })

  },

  // 播放录音
  play(e) {
    var item = e.currentTarget.dataset.item
    innerAudioContext.src = item.audio;
    innerAudioContext.play()

    wx.showToast({
      title: '开始播放',
      icon: 'success',
      duration: 1000
    })

    innerAudioContext.onError((res) => {;
      console.log(res.errMsg)
      console.log(res.errCode)
    })


  },
  // 点击每项
  gotoDetail(e) {
    console.log('111111111111')
    var item = e.currentTarget.dataset.item
    var id = item.id
    app.goto('navigateTo', 'index/notes/retract/detail/detail', {
      'fromRetract': 1,
      'id': id,
      'isRead': 1
    })
    this.audioCtx.pause()
  },
  fabu() {
    var s = {
      pageSize: 30,
      pageNum: 1,
      type: 1
    }
    http.httpGet(`/resource/minePublish`, s, app.globalData.userId, (res) => {
      console.log('发布的资料',res);
      this.setData({
        fabu: res.data.list,
        // name: res.data.list.name,
        // departmentName: res.data.list.departmentName,
        // specialtyName: res.data.list.specialtyName,
        // price: res.data.list.price,
        // isFreeDelivery: res.data.list.isFreeDelivery,
        // deliveryFee: res.data.list.deliveryFee,
        // summary: res.data.list.summary,
      })
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    
    // this.fabu()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    this.audioCtx = wx.createAudioContext('myAudio')
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.fabu()
    this.initList()
    
    
    // this.delete()
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
   
  },
  
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    this.problem();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    this.data.pageNum = 1
    this.initList('正在刷新数据', 1)
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    if (this.data.hasMoreData) {
      this.initList('正在加载数据...', 1)
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {}
});