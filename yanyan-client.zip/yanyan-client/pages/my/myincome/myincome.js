// pages/my/myincome/myincome.js

const app = getApp()

var resourcesType = {
  '纸质资料': 1,
  '电子资料': 2
}

let http = require('../../../utils/httpHelper');

let formatDate = require('../../../utils/util');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifLook: true,
    ifLookAt: true,
    historyData: null,
    historyDataAt: null,
    answerCount: 0,
    answerIncome: 0,
    resourceCont: 0,
    resourceIncome: null,
    resourceTotal: null,
    resourcePaperCont: 0,
    resourcePaperIncome: null
  },

  clickLook () {
    this.setData({
      ifLook: !this.data.ifLook
    })
  },

  clickLookAt () {
    this.setData({
      ifLookAt: !this.data.ifLookAt
    })
  },

  initList () {
    http.httpGet("user/income", null, app.globalData.userId, (res) => {
      if (res.code === 0) {
        if (res.data != null) {
          if (res.data.answers != null) {
            res.data.answers.map((item) => {
              item.createTime = formatDate.formatDate1(item.createTime);
            })
          }
          if (res.data.resources != null) {
            res.data.resources.map((item) => {
              item.createTime = formatDate.formatDate1(item.createTime);
              if (item.resourceType === resourcesType.纸质资料) {
                item.resourceType = '纸质资料';
              } else if (item.resourceType === resourcesType.电子资料) {
                item.resourceType = '电子资料';
              }
            })
          }
          this.setData({
            historyData: res.data.answers,
            historyDataAt: res.data.resources,
            answerCount: res.data.answerCount,
            answerIncome: res.data.answerIncome,
            answerTotalIncome: res.data.answerTotalIncome,
            resourceCont: res.data.resourceElecCount,
            resourceIncome: res.data.resourceElecIncome,
            resourceTotal: res.data.resourcePaperIncome + res.data.resourceElecIncome,
            resourcePaperCont: res.data.resourcePaperCount,
            resourcePaperIncome: res.data.resourcePaperIncome
          })
        }
      } else {
        console.log('************res', res);
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.initList();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})