// pages/my/myreceive/goanswer/goanswer.js
var app = getApp()
var http = require('../../../../utils/httpHelper')
const innerAudioContext = wx.createInnerAudioContext()
var config = require('../../../../config')
const qiniuUploader = require("../../../../utils/qiniuUploader")
// 初始化七牛相关参数
function initQiniu() {
  var options = {
    region: 'ECN', // 华东区，生产环境应换成自己七牛帐户bucket的区域
    uptokenURL: 'https://wxapp.yanyanbiji.com/yyapp/config/token', // 生产环境该地址应换成自己七牛帐户的token地址，具体配置请见server端
    domain: 'http://img.rainfn.com/' // 生产环境该地址应换成自己七牛帐户对象存储的域名
  };
  qiniuUploader.init(options);
}

const recorderManager = wx.getRecorderManager()
var util = require('../../../../utils/util')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: null,
    questionInfo: {},
    //添加图片
    src: '../../../../assets/camera.png',
    //语音图片
    src1: '../../../../assets/yuyin.png',

    //上传图片个数
    // imgarr: [],

    // 七牛
    // 图片地址
    imageObject: {},
    imgarr: [],

    textareavalue: '',
    // id: null,
    // price: null,
    //语音数据
    // 音频
    audioUrl: '',
    allow: true,

    tishi: false, // 超出3条语音提示

    reSuccess: false,

    isSpeaking: false,
    // content: [],
    imageList: [],
    showModalStatus1: false,
    showModalStatus: false,
    voices: [], //音频数组
    isVoice: false,

    tsColor: '#49B0FF',
    //语音数据集合
    voice: [],
    das: null,
    vo: [{
      filePath: '123456',
      duration: 3,
      size: 231
    }],
    audiosNow: []
  },


  //输入问题描述
  textarea(e) {
    this.setData({
      textareavalue: e.detail.value
    })
  },
  //点击确认咨询按钮
  confirmConsulting() {
    var that = this
    // console.log(that.data.imgarr)
    if (that.data.textareavalue == '') {
      wx.showToast({
        title: '请将回答的内容填写完整',
        icon: 'none',
        duration: 2000,
        mask: true,
      })
    } else {
      var pros = {
        questionId: parseInt(that.data.id),
        content: that.data.textareavalue,
        audios: that.data.audiosNow,
        images: that.data.imgarr
      }
      wx.showModal({
        title: "温馨提示",
        content: '确认提交回答内容？',
        success(res) {
          if (res.confirm) {
            http.httpPost(`/question/answer`, pros, app.globalData.userId, (res) => {
              console.log(res);
              if (res.code == 0) {
                wx.showToast({
                  title: '提交成功',
                  duration: 3000,
                })
                wx.navigateBack({delta: 1})
              } else {
                wx.showToast({
                  title: '提交失败'
                })
              }
            })
          }
        }
      })
    }
  },


  // 七牛上传图片
  didPressChooesImage: function () {
    var that = this;
    didPressChooesImage(that);
    console.log(that.data.imgarr)
  },
  // 点击删除该图片
  deletePhoto(e) {
    var index1 = e.currentTarget.dataset.index
    var imgarr = this.data.imgarr
    imgarr.map((item, index, arr) => {
      if (index == index1) {
        imgarr.splice(index, 1)
      }
    })
    // 重新渲染
    this.setData({
      imgarr: imgarr
    })
  },


  // 点击--播放录音
  play(e) {
    var adurl = e.currentTarget.dataset.url
    innerAudioContext.src = adurl
    innerAudioContext.play()

    wx.showToast({
      title: '开始播放',
      icon: 'success',
      duration: 1000
    })

    innerAudioContext.onError((res) => {
      ;
      console.log(res.errMsg)
      console.log(res.errCode)
    })


  },

  // 点击--删除录音
  closeHandle(e) {
    console.log(e.currentTarget.dataset.index)
    var ids = e.currentTarget.dataset.index
    // var newvoices = this.data.voices
    this.data.voices.map((item, index, arr) => {
      if (index == ids) {
        this.data.voices.splice(index, 1)
      }
    })
    // var newaudios = this.data.audiosNow
    this.data.audiosNow.map((item, index, arr) => {
      if (index == ids) {
        this.data.audiosNow.splice(index, 1)
      }
    })
    // 重新渲染
    this.setData({
      // isVoice: false,
      allow: true,
      tishi: false,
      voices: this.data.voices,
      audiosNow: this.data.audiosNow
    })
    // this.setData({
    //   isVoice: false,
    //   audioUrl: '',
    //   allow: true,
    //   tishi: false,
    //   voices: [],
    // })
  },

  //开始录音
  recordStart() {
    // 语音、文本--任选一条
    // if (!this.data.textareavalue.length) {
    //   this.setData({
    //     tsColor: '#49B0FF'
    //   })

    if (this.data.voices.length < 3) {

      if (this.data.allow) {

        var _this = this;
        _this.setData({
          isSpeaking: true
        })

        const options = {
          duration: 60000, //指定录音的时长，单位 ms
          sampleRate: 16000, //采样率
          numberOfChannels: 1, //录音通道数
          encodeBitRate: 96000, //编码码率
          format: 'mp3', //音频格式，有效值 aac/mp3
          frameSize: 50, //指定帧大小，单位 KB
        }

        //开始录音
        recorderManager.start(options);
        recorderManager.onStart(() => {
          console.log('------开始录音-----')
          var startTime = +new Date()
          this.setData({
            startTime: startTime
          })
        });

        //错误回调
        recorderManager.onError((res) => {
          console.log(res);
        })

      }

    } else {

      this.setData({
        tishi: true,
        allow: false,
        tsColor: 'red'
      })

    }

    // } else {
    //   this.setData({
    //     tsColor: 'red'
    //   })
    // }

  },

  // 录音结束
  recordEnd: function () {

    recorderManager.stop();
    recorderManager.onStop((res) => {
      var tempFilePath = res.tempFilePath;
      console.log(tempFilePath)
      var Duration = Math.floor(res.duration / 1000);
      var fileSize = res.fileSize;
      var that = this;
      wx.saveFile({
        tempFilePath: tempFilePath,
        success: function (lures) {
          //持久路径
          ;
          var savedFilePath = lures.savedFilePath
          console.log("savedFilePath: " + savedFilePath)
          that.data.voices.push({
            filePath: savedFilePath,
            duration: Duration,
            size: fileSize
          })
          that.setData({
            isVoice: true,
            isSpeaking: false,
            voices: that.data.voices,
            savedFilePath: savedFilePath
          })
          // 上传语音
          initQiniu();
          // 微信 API 选文件
          var audioFilePath = that.data.savedFilePath
          // 交给七牛上传
          qiniuUploader.upload(audioFilePath, (res) => {
            console.log('------upload qiniu success.')
            console.log(res)
            that.data.audiosNow.push({
              url: res.imageURL
            })
            that.setData({
              audiosNow: that.data.audiosNow
            })
            console.log(that.data.voices)
            console.log(that.data.audiosNow)
          })
          //     innerAudioContext.src = savedFilePath;
          //     innerAudioContext.onPlay(() => {
          //       console.log('开始播放')
          //     })
          //     innerAudioContext.onError((res) => {
          //       console.log(res.errMsg)
          //       console.log(res.errCode)
          //     })
          //   }
          // })
        }
      })
      wx.showToast({
        title: '恭喜!录音成功',
        icon: 'success',
        duration: 1000
      })


      console.log('停止录音', res.tempFilePath)

      // this.setData({
      //   audioUrl: res.tempFilePath
      // })
    })
  },
  // 录音
  // touchStart() {
  //   this.start();
  // },


  // touchEnd() {
  //   this.stop()
  // },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options.id)
    this.setData({
      id: options.id
    })
    var id = options.id
    http.httpGet(`/question/info/${id}`, null, app.globalData.userId, (res) => {
      console.log(res.data)
      if (res.code == 0) {
        this.setData({
          questionInfo: res.data
        })
      }
    })
    this.setData({
      // id: options.id,
      // price: options.price
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})

function didPressChooesImage(that) {
  initQiniu();

  if (that.data.imgarr.length == 2) {

    wx.showToast({
      icon: 'loading',
      title: '最多添加2张图片哦',
      duration: 1200
    })

  } else {

    // // 微信 API 选文件
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      success: function (res) {
        var filePath = res.tempFilePaths[0];
        var files = res.tempFilePaths
        console.log('上传', filePath)


        var imgarr = that.data.imgarr
        console.log(that.data.imgarr)
        // 交给七牛上传
        qiniuUploader.upload(filePath, (res) => {
          imgarr.push({
            url: res.imageURL
          })
          that.setData({
            'imageObject': res,
            'imgarr': imgarr
          });
        }, (error) => {
          console.error('error: ' + JSON.stringify(error));
        });


      }
    })

  }
}