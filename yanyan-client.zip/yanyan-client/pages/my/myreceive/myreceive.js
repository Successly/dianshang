// 学习资料

var app = getApp()

var http = require('../../../utils/httpHelper')
var utils = require('../../../utils/util.js')
var api = require('../../../utils/api.js')

Page({

    /**
     * 页面的初始数据
     */
    data: {
        orinum: 1,
        type: 2,
        src: '../../../assets/aixing.png',
        play: '../../../assets/play.png',
        arr: [1, 2],
        //红星图片
        hongxing: '../../../assets/hongxing.png',
        // 选中
        activezz: true,
        activedz: false,

        // 返回按钮状态
        scrollTop: 0,
        backTopValue: false,

        shoudaodisplay: true,
        huidadisplay: false,
        profiles: [],
        prs: [],
        // 纸质
        // 分页
        zzpageNum: 1, // 当前页
        zzpageSize: 8, // 每页条数
        zzList: [],
        zzhasMoreData: false,


        // 电子
        // 分页
        dzpageNum: 1, // 当前页
        dzpageSize: 8, // 每页条数
        dzList: [],
        dzhasMoreData: true,

        // 资料类型 1-纸质 2-电子
        type: 1,
        value: '搜索',
        keyword: '',

        allgetin: [],
    },

    //点击去回答按钮
    btn(e) {
        var as = e.currentTarget.dataset.as
        var id = e.currentTarget.dataset.id
        if (as == 1) {
            wx.showToast({
                title: '你已回答过',
                icon: 'none',
                duration: 2000
            })
        } else {
            app.goto('navigateTo', "my/myreceive/goanswer/goanswer", {id: id})
        }
    },
    //点击问题答案
    btns(e) {
        var id = e.currentTarget.dataset.id
        app.goto('navigateTo', "my/my-realese/findanswer/findanswer", {id: id})
    },

    // 监听滚动条坐标
    //

    //去发货
    gotodelivery() {
        app.goto("navigateTo", 'my/my-profile/gotodelivery/gotodelivery')
    },
    // 返回顶部
    onPageScroll: function (e) {
        var that = this
        var scrollTop = e.scrollTop
        var backTopValue = scrollTop > 280 ? true : false
        that.setData({
            backTopValue: backTopValue
        })
    },
    goback() {
        // 控制滚动
        wx.pageScrollTo({
            scrollTop: 0,
            duration: 300
        })
    },
    //物流单号
    traking() {
        app.goto("navigateTo", 'my/my-profile/traking/traking')
    },
    // 点击--每项
    gotoGoodDetail(e) {
        var id = e.currentTarget.dataset.id

        app.goto('navigateTo', 'my/my-profile/datadetails/datadetails', {
            'fromStudydata': 1,
            'id': id
        })
    },

    // 点击--搜索
    gotohotSearch() {
        app.goto('navigateTo', 'index/hotsearch/hotsearch', {
            'fromStudyData': 1,
            'type': this.data.type
        })
    },

    getquestion() {
        let that = this;
        http.httpGet(`/question/mineList?type=2`, null, app.globalData.userId, (res) => {
            if (res.code == 0) {
                if (res.data !== "") {
                    that.setData({
                        profiles: res.data.list,
                    })
                } else {
                    that.setData({
                        profiles: [],
                    })
                    wx.showToast({
                        title: '暂未收到',
                        icon: 'none',
                        duration: 2000
                    })
                }
            } else {
                console.log('---接口请求失败---', res)
            }
        })
    },
//回答的问题
    receiveproblem() {
        http.httpGet(`/question/mineList?type=2&status=2`, null, app.globalData.userId, (res) => {
            console.log(res)
            if (res.data != "") {
                var data = res.data.list

                console.log(data);
                if (data != []) {
                    for (var i = 0; i < data.length; i++) {

                        data[i].mtime = utils.remainTime(data[i].expireTime)
                        // var mday = ((data[i].mtime / 1000) / 60) / 60/24;

                    }
                    this.setData({
                        pros: data,
                        // dzdisplay: true,
                    })
                }
            }


            console.log(res.data.list);

        })

    },
    // 点击残忍拒绝
    del(e) {
        let that = this;
        var id = e.currentTarget.dataset.id
        console.log(e);
        var dl = {
            id: id,
        }
        console.log(dl)
        wx.showModal({
            title: '提示',
            content: '是否残忍拒绝',
            success(res) {
                if (res.confirm) {
                    console.log('用户点击确定')
                    http.httpGet(`/question/delete`, dl, app.globalData.userId, (res) => {
                        if (res.code == 0) {
                            wx.showToast({
                                title: '删除成功',
                                icon: 'success',
                                duration: 2000
                            })
                            that.getquestion()
                        } else {
                            wx.showToast({
                                title: '删除失败',
                                icon: 'none',
                                duration: 2000
                            })
                        }
                    })
                } else if (res.cancel) {
                    console.log('用户点击取消')
                }
            }
        })
    },


    // 导航栏切换
    shoudaodata() {
        this.setData({
            activezz: true,
            activedz: false,
            shoudaodisplay: true,
            huidadisplay: false,
        })


        // this.zzinitList('', 0, 800)
        this.getquestion()

    },

    huidadata() {
        this.setData({
            activezz: false,
            activedz: true,
            shoudaodisplay: false,
            huidadisplay: true,
        })

        // this.dzinitList('', 0, 800)
        this.receiveproblem()

    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        // this.getquestion()
        // this.receiveproblem()
        // this.getquestion('正在刷新数据',800);
        // console.log(options)
        // // 从搜索页来
        // if (options.fromhotsearch) {
        //   this.setData({
        //     value: options.value == '' ? '搜索' : options.value,
        //     keyword: options.value,
        //     type: options.type
        //   })

        //   if (options.type == 2) {
        //     this.setData({
        //       activezz: false,
        //       activedz: true,
        //       zzdisplay: false,
        //       dzdisplay: true,
        //       dzpageNum: 1
        //     })
        //   } else {
        //     this.setData({
        //       zzpageNum: 1
        //     })
        //   }

        // }
        // var sc={
        //   targetId:1,
        //   type:1,
        //   action:1
        // }
        // http.httpPost(`/favorite/do`,sc,app.globalData.userId,(res)=>{
        //   console.log(res);
        // })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.getquestion()
        // this.receiveproblem()
        // if (this.data.type == 1) {

        // } else {
        //  this.receiveproblem()
        // }


    },


    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
        if (this.data.type == 1) {
            this.data.zzpageNum = 1
            this.zzinitList('正在刷新数据', 1, 800)
        } else {
            this.data.dzpageNum = 1
            this.dzinitList('正在刷新数据', 1, 800)
        }

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

        if (this.data.type == 1) {

            if (this.data.zzhasMoreData) {
                this.zzinitList('正在加载数据...', 1, 800)
            }

        } else {

            if (this.data.dzhasMoreData) {
                this.dzinitList('正在加载数据...', 1, 800)
            }

        }

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})