// 登录页
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  getUserInformation(e) {

    // 允许
    if (e.detail.userInfo) {

      app.getuserinfo(this.gotoIndex)

      app.globalData.userInfo = e.detail.userInfo

    }

  },

  gotoIndex() {
    wx.showToast({
      title: '授权成功',
      icon: 'success',
      duration: 1000
    })

    app.goto('switchTab', 'index/index')
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (wx.getStorageSync("userId") && wx.getStorageSync("openId") && wx.getStorageSync("userInfo")) {
      //if(app.globalData.openId) {
      console.log('--------已授权-------')
      app.globalData.userInfo = wx.getStorageSync("userInfo");
      app.globalData.openId = wx.getStorageSync("openId");
      app.globalData.userId = wx.getStorageSync('userId');
      wx.switchTab({
        url: `/pages/index/index`
      })
    }
  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})