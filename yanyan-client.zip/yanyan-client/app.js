//app.js
const api = require('./utils/api.js')
var http = require('./utils/httpHelper.js')

App({
    onLaunch: function () {

    },

    // 跳转
    goto(way, path, data) {
        data = data || ''

        if (data) {
            var str = '?'
            for (var k in data) {
                str += k + '=' + data[k] + '&'
            }
            var newstr = str.substr(0, str.lastIndexOf('&'))
        } else {
            newstr = ''
        }

        // 保留当前页面， 跳转到应用内的某个页面
        // 使用 wx.navigateBack  可以返回
        if (way === 'navigateTo') {
            wx.navigateTo({
                url: `/pages/${path}${newstr}`
            })
        } else if (way === 'switchTab') {
            // 跳转到带有tab的页面
            wx.switchTab({
                url: `/pages/${path}${newstr}`
            })
        } else if (way === 'redirectTo') {
            // 跳转到非tabBar的某个页面
            wx.redirectTo({
                url: `/pages/${path}${newstr}`
            })
        } else if (way === 'navigateBack') {
            // 关闭当前页面，返回上一页面或多级页面
            wx.navigateBack({
                delta: 1, // 返回的层技数
                url: `/pages/${path}${newstr}`
            })
        } else {
            //  关闭所有页面，打开到应用内的某个页面
            wx.reLaunch({
                delta: 1, // 返回的层技数
                url: `/pages/${path}${newstr}`
            })
        }
    },

    // 用户登录
    getuserinfo: function (cb) {

        var that = this
        // 调用登录API
        wx.login({
            success: (res) => {
                // 1. 获取code
                // 如果拿到code 验证用户登录状态
                if (res.code) {
                    console.log("---code 获取成功: ---", res.code)
                    var code = res.code

                    // 2. 通过code 换取 openId     that.getOpenId(code)
                    var that = this
                    http.httpGet(`/user/getopenid?code=${code}`, null, that.globalData.userId, (res) => {

                        if (res.code == 0 && res.message == 'success') {

                            console.log('---获取openid成功---', res)
                            //  3. 将 openid 存储起来
                            wx.setStorageSync("openId", res.msg);
                            that.globalData.openId = res.msg

                            // 4. 通过 wx.getUserInfo获取用户信息
                            wx.getUserInfo({
                                // 用户授权 调用
                                success: function (res) {
                                    console.log('-----获取用户信息成功-----', res)

                                    // 获取到用户信息
                                    var userInfo = res.userInfo;
                                    // 存储用户信息
                                    wx.setStorageSync('userInfo', userInfo);
                                    that.globalData.userInfo = userInfo;

                                    // 请求--发送用户信息
                                    var params = {
                                        'openId': that.globalData.openId,
                                        'name': userInfo.nickName,
                                        'avatar': userInfo.avatarUrl,
                                        'sex': userInfo.gender,
                                        'province': userInfo.province,
                                        'city': userInfo.city
                                    }
                                    http.httpGet(`/user/addOrUpdate`, params, that.globalData.userId, function (res) {

                                        if (res.code == 0) {
                                            console.log('-------发送用户信息成功--------', res)

                                            // 存储请求头中要用的userid
                                            that.globalData.userId = res.data.id
                                            wx.setStorageSync("userId", res.data.id)

                                            typeof cb == "function" && cb()


                                        } else {
                                            console.log("-----发送用户信息失败------", res)
                                        }
                                    })
                                },
                                // 用户 拒绝授权 提示
                                fail: function () {
                                }
                            })

                        } else {
                            console.log("-----获取openid失败------")
                        }

                    })

                } else {
                    console.log('获取 code 用户登录态失败！' + res.errMsg)
                }
            }
        })

    },


    // 封装公用的授权处理
    // 参数1 -- res -- 授权信息
    // 参数2 -- cb1 -- 未登录时 拒绝处理
    // 参数3 -- cb2 -- 未登录时 允许处理
    // 参数4 -- cb3 -- 登录时 处理
    authorizeHandle(res, cb1, cb2, cb3) {
        // 1. 跳出授权页面
        // (1) 拒绝处理  跳转登录页 -- 有自动验证
        if (!res.detail.userInfo) {
            // 不登录--留在当前页面
            // typeof cb1 == "function" && cb1()

        } else {
            // (2) 同意授权时 -- 不管有没有登录--都先传送用户信息
            //  存储用户信息
            this.globalData.userInfo = res.detail.userInfo

            //  获取openid、发送用户信息、跳转登录页 -- 没有自动验证
            this.getuserinfo(cb2, cb3)


            // 未登录
            // if(!wx.getStorageSync("openId")) {
            //   // (1) 存储用户信息
            //   this.globalData.userInfo = res.detail.userInfo

            //   // (2) 请求--登录
            //   // (3) 跳转登录页 -- 没有自动验证
            //   this.getuserinfo(typeof cb2 == "function" && cb2())
            // } else {
            //   // 已登录
            //   console.log('用户已经登录了')
            //   // 跳转--消息页
            //   typeof cb3 == "function" && cb3()
            // }
        }
    },

    // (3) 未登录 -- 拒绝处理
    refeusetologin() {
        this.goto('navigateTo', 'login/login', {
            'allow': 0,
            'from': 'my/my',
            'id': null
        })
    },

    // (3) 未登录 -- 允许处理
    gotologin() {
        console.log('-----------------允许')
        this.goto('navigateTo', 'login/login', {
            'allow': 1,
            'from': 'my/my',
            'id': null
        })
    },

    globalData: {
        userInfo: null,
        userId: 0,
        openId: null,
        users: null,
        usertype: null,
        questionUsers: [],
        myProfileType: 1//我的资料默认类型，1：买入的资料；2：卖出的自来哦
        // imgUrl: []
    }
})