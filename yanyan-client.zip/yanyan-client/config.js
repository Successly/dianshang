var config = {

  APPID: 'wx16ad2c5bdc9ed945',
  secret: 'de738e09134403a5e6480a4a155a1d60',

  // HTTP_BASE_URL:'https://t.clouden.cn/zzwapp'
  // HTTP_BASE_URL:'http://192.168.1.150:8091/'
  // HTTP_BASE_URL:'http://192.168.0.122:8071/'
  HTTP_BASE_URL:'https://wxapp.yanyanbiji.com/yyapp/'
  // HTTP_BASE_URL: 'http://localhost:8071/'
 
}

module.exports = config;