<template>
  <transition name="fade">
    <router-view></router-view>
  </transition>
</template>

<script>
  export default {
  }
</script>

<style lang="scss" scoped>
// 引入覆盖文件
@import './stylus/element.styl';
</style>

