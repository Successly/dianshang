<template>
	<div class="block">
		<el-upload
		  class="avatar-uploader"
		  :action="uploadUrl"
		  :show-file-list="false"
      :on-progress="uploadProcess"
		  :before-upload="handleBeforeUpload"
		  :on-success="handleSuccess">
			<img
			  v-if="imageUrl"
			  :src="imageUrl"
			  class="avatar"
			  :style="'width: ' + imgWidth + 'px;height: ' + imgHeight + 'px;'" />
			<i
			  v-else
			  class="el-icon-plus avatar-uploader-icon"
			  :style="'width: ' + imgWidth + 'px;height: ' + imgHeight + 'px;line-height: ' + imgHeight + 'px;'">
			</i>
		</el-upload>
    <!--<el-progress v-if="uploadingFlag == true" :text-inside="true" :stroke-width="12" :percentage="uploadPercent" style="margin-top:30px;"></el-progress>-->
  </div>
</template>

<script>
	export default {
		data () {
			return {
				imageUrl: '',
        uploadingFlag: false,
        uploadPercent: 0,
			}
		},
		props: {
			uploadUrl: String,
			imgUrl: String,
			imgWidth: Number,
			imgHeight: Number
		},
		created () {

		},
		activated () {

		},
		mounted (){
			this.imageUrl = this.imgUrl;
		},
		methods: {
			handleBeforeUpload(file){
				if (file.type !== 'image/jpg' && file.type !== 'image/jpeg' && file.type !== 'image/png' && file.type !== 'image/gif') {
					this.$message.error('只支持jpg、jpeg、png、gif格式的图片！');
					return false;
				}
				return true;
			},
			handleSuccess(response, file){
        this.uploadingFlag = false;
        this.uploadPercent = 0;
				if (response && response.code === 0) {
					/*this.imageUrl = URL.createObjectURL(file.raw);*/
					this.$emit('changeFileListFunc', this.imageUrl);
				} else {
					this.$message.error(response.msg)
				}
			},

      uploadProcess(event, file, fileList){
        this.uploadingFlag = true;
        this.uploadPercent = file.percentage.toFixed(0)*1;
      }
		},
		components: {

		}
	}
</script>

<style lang="scss">
	.avatar-uploader .el-upload {
		border: 1px dashed #d9d9d9;
		border-radius: 6px;
		cursor: pointer;
		position: relative;
		overflow: hidden;
	}
	.avatar-uploader .el-upload:hover {
		border-color: #17B3A3;
	}
	.avatar-uploader-icon {
		font-size: 28px;
		color: #8c939d;
		text-align: center;
	}
	.avatar {
		display: block;
	}
</style>
