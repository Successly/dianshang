<template>
  <div class="hotel-select">
    <el-select v-model="hotelId" filterable placeholder="请选择" clearable style="width: 200px;">
      <el-option
        v-for="item in hotelAllList"
        :key="item.id"
        :label="item.name"
        :value="item.id">
      </el-option>
    </el-select>
  </div>
</template>

<script>
  export default {
    data () {
      return {
        hotelOriginalData: [],
        hotelAllList: [],
        hotelId: ''
      }
    },
    props: {
      defaultHotelId: {
        type: Number,
        default: -1
      },
      addressCode: {
        type: String,
        default: ''
      },
      defaultName: {
        type: String,
        default: ''
      },
      defaultSelect: {
        type: Boolean,
        default: true
      }
    },
    created() {
      this.queryAllHotelList();
    },
    mounted() {

    },
    methods: {
      // 查询所有酒店列表
      queryAllHotelList(){
        this.$http({
          url: this.$http.adornUrl_qfs('/hotel/hotels/collect/all'),
          method: 'get',
          params: this.$http.adornParams({'addressCode': this.addressCode})
        }).then(({data}) => {
          if (data && data.code === 0) {
            this.hotelOriginalData = data.data;
            this.hotelAllList = data.data;
            // 暂时屏蔽，过滤时候取消注释
            if(this.defaultName === ''){
              this.hotelAllList = data.data;
            }else{
              let tempList = [];
              data.data.forEach((item,index) => {
                if(item.name.indexOf(this.defaultName) > -1){
                  tempList.push(item)
                }
              })
              this.hotelAllList = tempList;
            }
            if(this.defaultSelect && data.data.length > 0){
              this.hotelId = this.defaultHotelId == -1 ? data.data[0].id : this.defaultHotelId;
            }else{
              this.hotelId = '';
            }
          } else {
            this.hotelListData = [];
          }
          this.$emit('changeSelectFunc', this.hotelId);
        })
      }
    },
    watch: {
      hotelId(val, oldVal){
        if(val != oldVal){
          let _this = this;
          /* let name = '';
                   _this.hotelAllList.forEach((item) =>{
             if(item.id == _this.hotelId){
               name = item.name;
           }
           })*/
          _this.$emit('changeSelectFunc', _this.hotelId);
        }
      },
      addressCode(val,oldValue){
        this.queryAllHotelList();
      },
      defaultName(val,oldVla){
        let tempList = [];
        this.hotelOriginalData.forEach((item,idnex) => {
          if(item.name.indexOf(val) > -1){
            tempList.push(item)
          }
        });
        this.hotelAllList = tempList;
      }
    }
  }
</script>

<style lang="scss">

</style>

