<template>
  <div>
    <!-- 图片上传组件辅助-->
    <el-upload
      class="avatar-uploader"
      :action="serverUrl"
      name="img"
      :show-file-list="false"
      :on-success="uploadSuccess"
      :on-error="uploadError"
      :before-upload="beforeUpload">
    </el-upload>

    <!--富文本编辑器组件-->
    <!-- <el-row v-loading="quillUpdateImg"> -->
    <div class="quill-wrap">
      <quill-editor
        v-model="content"
        ref="myQuillEditor"
        :options="editorOption"
        @change="onEditorChange($event)"
        @ready="onEditorReady($event)"
        @blur="onEditorBlur($event)" 
        @focus="onEditorFocus($event)"
        id="editor"
      >
      </quill-editor>
      <p @click="getContent">点击</p>
    </div>
    <!-- </el-row> -->
  </div>
</template> 

<script>
  // import {userList} from '@/api/index'
  import {quillEditor, Quill} from 'vue-quill-editor'
  import {container, ImageExtend} from 'quill-image-extend-module'

  Quill.register('modules/ImageExtend', ImageExtend)

  var url = 'http://192.168.1.150:8000/renren-fast/app/imgUpload'
  
  export default{
    data () {
      return {
        quillUpdateImg: false, // 根据图片上传状态来确定是否显示loading动画，刚开始是false,不显示
        serverUrl: url,  // 这里写你要上传的图片服务器地址
        // header: {token: this.$cookie.get('token')},  // 有的图片服务器要求请求头需要有token之类的参数，写在这里
        content: '', // 富文本内容
        // 富文本框参数设置
        editorOption: {
          modules: {
            ImageExtend: {
              loading: true, // 可选参数 是否显示上传进度和提示语
              name: 'img', // 图片参数名
              action: url, // 服务器地址, 如果action为空，则采用base64插入图片
              // response 为一个函数用来获取服务器返回的具体图片地址
              // 例如服务器返回{code: 200; data:{ url: 'baidu.com'}}
              // 则 return res.data.url
              response: (res) => {
                return res.url
              }
            },
            toolbar: {
              container: container,
              handlers: {
                'image': function (value) {
                  if (value) {
                    // 触发input框选择图片文件
                    document.querySelector('.avatar-uploader input').click()
                    // document.querySelector('.quill-image-input').click()
                  } else {
                    this.quill.format('image', false)
                  }
                }
              }
            }
          }
        }
      }
    },
    components: {quillEditor},
    mounted () {
    },
    methods: {
      getContent (e) {
        // this.dialogVisible = true
        // var quill = new Quill('#editor', {
        //   theme: 'snow'
        // })
        // var delta = Quill.getContents()
        console.log(e)
      },
      // 上传图片前
      beforeUpload (res, file) {
        // 显示loading动画
        this.quillUpdateImg = true
      },
      // 上传图片成功
      uploadSuccess (res, file) {
        // res为图片服务器返回的数据
        // 获取富文本组件实例
        let quill = this.$refs.myQuillEditor.quill
        // console.log(res)
        // 如果上传成功
        if (res.code === 200) {
          console.log('执行')
          // 获取光标所在位置
          let length = quill.getSelection().index
          // 插入图片  res.info为服务器返回的图片地址
          quill.insertEmbed(length, 'image', res.url)
          // 调整光标到最后
          quill.setSelection(length + 1)
        } else {
          this.$message.error('图片插入失败')
        }
        // loading动画消失
        this.quillUpdateImg = false
      },
      // 上传图片失败
      uploadError (res, file) {
        // loading动画消失
        this.quillUpdateImg = false
        this.$message.error('图片插入失败')
      },
      onEditorBlur () { // 失去焦点事件
      },
      onEditorFocus () { // 获得焦点事件
      },
      onEditorChange () { // 内容改变事件
      },
      onEditorReady () {
      }
    }
  }
</script>

<style lang="scss" scoped>
</style>
