<template>
	<div class="block">
	
	</div>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		created () {
			
		},
		activated () {
			
		},
		methods: {
			
		},
		components: {
			
		}
	}
</script>

<style lang="scss">

</style>