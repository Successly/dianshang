<template>

</template>

<script>
export default {
  data () {
    return {
    }
  },
  mounted () {
    this.drawLine()
  },
  methods: {

  }
}
</script>

<style>
  /* 初始化 */
  html,body,h1,h2,h3,h4,h5,h6,ul,li,p {
    margin: 0;
    padding: 0;
    font-weight: 400;
  }

  ul li {
    list-style: none;
    float: left;
  }


</style>
