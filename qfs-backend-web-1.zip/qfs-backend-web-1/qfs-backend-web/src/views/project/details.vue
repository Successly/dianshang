<template>
  <div class="details">
    <div id="box" @click="changeFz">管理</div>
  </div>
</template>

<script>
import $ from 'jquery'
export default {
  methods: {
    changeFz () {
      $('#box').css('fontSize', '20px')
    }
  }
}
</script>

<style lang="scss" scoped>
.details {
  width: 100px;
  height: 100px;
  #box {
    width: 100%;
    height: 100%;
  }
}
</style>
