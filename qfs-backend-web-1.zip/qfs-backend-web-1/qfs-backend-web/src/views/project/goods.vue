<template>
  <div>
    <!-- 表格展示  引入封装的功能性组件 -->
    <tree-grid :treeStructure='true' :columns='columns' :data-source='dataSource' @deleteCate='deleteCategory' @editCate='editCategory'>
    </tree-grid>
  </div>
</template>

<script>
import TreeGrid from '@/components/TreeGrid/TreeGrid'
export default {
  data () {
    return {
      // 引入的 功能性组件 树控件
      dataSource: [
        {
          cat_id: 1,
          cat_name: '大家电',
          cat_pid: 0,
          cat_level: 0,
          cat_deleted: false,
          children: [
            {
              cat_id: 3,
              cat_name: '电视',
              cat_pid: 1,
              cat_level: 1,
              cat_deleted: false,
              children: [
                {
                  cat_id: 6,
                  cat_name: '曲面电视',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 7,
                  cat_name: '海信',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 8,
                  cat_name: '夏普',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 9,
                  cat_name: '创维',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 10,
                  cat_name: 'TCL',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 11,
                  cat_name: 'PPTV',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 12,
                  cat_name: '小米',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 13,
                  cat_name: '长虹',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 14,
                  cat_name: '康佳',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 15,
                  cat_name: '三星',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 16,
                  cat_name: '飞利浦',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 17,
                  cat_name: '索尼',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 18,
                  cat_name: '先锋',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 19,
                  cat_name: '家庭影院',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 20,
                  cat_name: '音响',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 21,
                  cat_name: '盒子',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                }
              ]
            },
            {
              cat_id: 4,
              cat_name: '空调',
              cat_pid: 1,
              cat_level: 1,
              cat_deleted: false,
              children: [
                {
                  cat_id: 23,
                  cat_name: '变频空调',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 24,
                  cat_name: '立柜空调',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 25,
                  cat_name: '挂壁空调',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 27,
                  cat_name: '中央空调',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 28,
                  cat_name: '移动空调',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 29,
                  cat_name: '海尔',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 30,
                  cat_name: '三菱重工',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 31,
                  cat_name: '志高',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 32,
                  cat_name: '奥克斯',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 33,
                  cat_name: '长虹',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 34,
                  cat_name: '科龙',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 35,
                  cat_name: '海信',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 36,
                  cat_name: '惠而浦',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 37,
                  cat_name: '空调清洗',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 38,
                  cat_name: '空调维修',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 39,
                  cat_name: '空调安装',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 40,
                  cat_name: '空调回收',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                }
              ]
            }
          ]
        },
        {
          cat_id: 52,
          cat_name: '热门推荐',
          cat_pid: 0,
          cat_level: 0,
          cat_deleted: false,
          children: [
            {
              cat_id: 64,
              cat_name: '圣诞狂欢',
              cat_pid: 52,
              cat_level: 1,
              cat_deleted: false,
              children: [
                {
                  cat_id: 73,
                  cat_name: '护肤套装',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 74,
                  cat_name: '面膜',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 76,
                  cat_name: '巧克力',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 77,
                  cat_name: '儿童玩具',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 78,
                  cat_name: '童装童鞋',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 79,
                  cat_name: '平板电脑',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 80,
                  cat_name: '笔记本',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 81,
                  cat_name: '苹果手机',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 82,
                  cat_name: '小米手机',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 83,
                  cat_name: '数码相机',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 84,
                  cat_name: '耳机耳麦',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 85,
                  cat_name: '挂机空调',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 86,
                  cat_name: '空气净化器',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 87,
                  cat_name: '洗衣机',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 88,
                  cat_name: '4K超高清',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 89,
                  cat_name: '洗碗机',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                }
              ]
            },
            {
              cat_id: 1008,
              cat_name: '冲锋衣',
              cat_pid: 52,
              cat_level: 2,
              cat_deleted: false
            }
          ]
        }
      ],
      columns: [
        {
          text: '分类名称',
          dataIndex: 'cat_name',
          width: ''
        },
        {
          text: '是否有效',
          dataIndex: 'cat_deleted',
          width: ''
        },
        {
          text: '排序',
          dataIndex: 'cat_level',
          width: ''
        }
      ]
    }
  },
  components: {
    TreeGrid
  },
  methods: {
    // 引入的功能性组件中
    deleteCategory (cid) {
      console.log(cid)
    },
    editCategory (cid) {
      console.log(cid)
    }
  }
}
</script>

<style lang='scss' scoped>
</style>
