<template>
 <div>
  <tree/>
 </div>
</template>

<script>
  import tree from '@/views/demo/tree'
  export default {
    data () {
      return {}
    },
    components: {
      tree
    }
  }
</script>

<style lang="scss" scoped>
</style>