 <template>
  <div>
    <!-- 表格展示  引入封装的功能性组件 -->
    <tree-grid 
    :treeStructure='true'
    :columns='columns' 
    :data-source='dataSource' 
    @deleteCate='deleteCategory' 
    @editCate='editCategory'>
    </tree-grid>
    <!-- 编辑 弹窗 -->
    
  </div>
</template>

<script>
import TreeGrid from '@/components/TreeGrid/TreeGrid'
export default {
  data () {
    return {
      // 引入的 功能性组件 树控件
      dataSource: [ // 展示的数据
        {
          cat_id: 1,
          cat_name: '玩具',
          cat_pid: 0,
          cat_level: 0,
          cat_deleted: false,
          children: [
            {
              cat_id: 3,
              cat_name: '小型玩具',
              cat_pid: 1,
              cat_level: 1,
              cat_deleted: false,
              children: [
                {
                  cat_id: 6,
                  cat_name: '乐高卡车和挖掘车套装',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 7,
                  cat_name: '伟易达宠物化妆盒',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                }
              ]
            },
            {
              cat_id: 4,
              cat_name: '大型玩具',
              cat_pid: 1,
              cat_level: 1,
              cat_deleted: false,
              children: [
                {
                  cat_id: 23,
                  cat_name: '星辉法拉利电动童车',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 24,
                  cat_name: '贝瑞佳手推杆儿童电动车',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 25,
                  cat_name: '米高迷你随性箱滑板车',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                }
              ]
            }
          ]
        },
        {
          cat_id: 52,
          cat_name: '热门品牌',
          cat_pid: 0,
          cat_level: 0,
          cat_deleted: false,
          children: [
            {
              cat_id: 64,
              cat_name: '小泰克',
              cat_pid: 52,
              cat_level: 1,
              cat_deleted: false,
              children: [
                {
                  cat_id: 73,
                  cat_name: '小泰克超级厨房',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 74,
                  cat_name: '小泰克广东丛林树屋',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                }
              ]
            },
            {
              cat_id: 1008,
              cat_name: '费雪',
              cat_pid: 52,
              cat_level: 2,
              cat_deleted: false
            }
          ]
        }
      ],
      columns: [ // 表格的列名
        {
          text: '分类名称',
          dataIndex: 'cat_name',
          width: ''
        },
        {
          text: '是否有效',
          dataIndex: 'cat_deleted',
          width: ''
        },
        {
          text: '排序',
          dataIndex: 'cat_level',
          width: ''
        }
      ]
    }
  },
  components: {
    TreeGrid
  },
  methods: {
    // 引入的功能性组件中
    deleteCategory (cid) {
      console.log(cid)
    },
    editCategory (cid) {
      console.log(cid)
      // 获取到 编辑的是哪个 获取信息展示在弹框中
    }
  }
}
</script>

<style lang='scss' scoped>
</style>
