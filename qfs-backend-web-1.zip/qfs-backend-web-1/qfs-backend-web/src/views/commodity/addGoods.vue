<template>
  <div class="addgoods">
    <!-- 第1行 添加商品信息 -->
    <el-row class="infomation">
      <el-col :span="24">
        <span>添加商品信息</span>
      </el-col>
    </el-row>

    <!-- 第2行 步骤条 -->
    <el-steps :active="active" finish-status="success">
      <el-step title="步骤 1"></el-step>
      <el-step title="步骤 2"></el-step>
      <el-step title="步骤 3"></el-step>
      <el-step title="步骤 4"></el-step>
      <el-step title="步骤 5"></el-step>
    </el-steps>

    <!-- 第3行 tab栏 -->
    <!-- element-ui中的tab栏 一般选用时 都选用第一个实例 -->
    <el-tabs :tab-position="tabPosition" style="height: 200px;"  v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="基本信息" name="first">基本信息</el-tab-pane>
      <el-tab-pane label="商品参数" name="second">商品参数</el-tab-pane>
      <el-tab-pane label="商品属性" name="third">商品属性</el-tab-pane>
      <el-tab-pane label="商品图片" name="fourth">
        <!-- element-ui中的 Upload 上传 - 图片列表缩略图 -->
        <!-- action是后台给的 -->
        <el-upload
          action="http://localhost:8888/api/private/v1/upload"
          :on-preview="handlePreview"
          :on-remove="handleRemove"
          :headers="setHeaders()"
          :on-success="handleSuccess"
          list-type="picture">
          <el-button size="small" type="primary">点击上传</el-button>
          <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
        </el-upload>
      </el-tab-pane>
      <el-tab-pane label="商品内容" name="fivth">商品内容</el-tab-pane>
    </el-tabs>

  </div>
</template>

<script>
export default {
  data () {
    return {
      // 步骤条
      active: 0,
      // tab栏的位置
      tabPosition: 'left',
      activeName: 'first'
    }
  },
  methods: {
    handleClick (tab, event) {
      // console.log(tab, event)
      // 判断当前点击的是第几个tab, 让对应的进度条显示
      switch (tab.name) {
        case 'first':
          this.active = 0
          break
        case 'second':
          this.active = 1
          break
        case 'third':
          this.active = 2
          break
        case 'fourth':
          this.active = 3
          break
        default:
          this.active = 4
      }
    },
    // 删除图片的函数
    // 点击图片时
    handleRemove (file, fileList) {
      // console.log(file, fileList)
    },
    // 删除图片上时
    handlePreview (file) {
      // console.log(file)
    },
    // 设置上传的请求头 需要带上token
    setHeaders () {
      // 取出token
      let token = localStorage.getItem('mytoken')
      if (token) {
        return {
          Authorization: token
        }
      }
    },
    // 上传成功的函数
    handleSuccess (response, file, fileList) {
      // console.log(response)
      // console.log(file)
      // console.log(fileList)
      if (response.meta.status === 200) {
        this.$message({
          type: 'success',
          message: response.meta.msg
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.addgoods {
  .el-row {
    margin-bottom: 10px;
  }
  .infomation {
    background: #D5E0ED;
    padding: 10px;
    margin-bottom: 50px;
  }
}
</style>
