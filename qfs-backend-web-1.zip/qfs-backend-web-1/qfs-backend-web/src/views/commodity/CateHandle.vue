<template>
  <div class="categories">
    <!-- 第1行 添加分类 -->
    <el-row>
      <el-col :span="24">
        <!-- 添加分类 -->
        <el-button type="success" plain @click="addCate">添加分类</el-button>
      </el-col>
    </el-row>

    <!-- 第2行 表格展示  引入封装的功能性组件 -->
    <tree-grid
      :treeStructure="true"
      :columns="columns"
      :data-source="dataSource"
      @deleteCate="deleteCategory"
      @editCate="editCategory"
    >
    </tree-grid>

    <!-- 第3行 分页 -->
    <div class="block">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="1"
        :page-sizes="[10, 20, 30]"
        :page-size="10"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total">
      </el-pagination>
    </div>

    <!-- 添加分类的弹出层 -->
    <el-dialog title="添加分类" :visible.sync="addDialogFormVisible">
      <el-form :model="addForm" label-width="80px" :rules="rules" ref="addCateForm">
        <!-- 分类名称 -->
        <el-form-item label="分类名称" prop="cat_name">
          <el-input v-model="addForm.cat_name" auto-complete="off"></el-input>
        </el-form-item>

        <!-- 父级名称 element-ui中的级联选择器-->
        <el-form-item label="父级名称">
          <el-cascader
            :options="options"
            v-model="selectedOptions"
            :props="props"
            @change="handleChange">
          </el-cascader>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addDialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addCateHandle('addCateForm')">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 编辑分类的弹出层 -->
    <el-dialog title="编辑分类" :visible.sync="editDialogFormVisible">
      <el-form :model="editForm" label-width="80px" :rules="editrules" ref="editCateForm">
        <!-- 分类名称 -->
        <el-form-item label="分类名称" prop="name">
          <el-input v-model="editForm.name" auto-complete="off"></el-input>
        </el-form-item>

        <!-- 是否有效 -->
        <el-form-item label="是否有效" prop="pid">
          <el-input v-model="editForm.pid" auto-complete="off"></el-input>
        </el-form-item>

        <!-- 排序 -->
        <el-form-item label="排序" prop="level">
          <el-input v-model="editForm.level" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="editDialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="editCateHandle('editCateForm')">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
// 引入components中存放的功能性组件 TreeGrid
import TreeGrid from '@/components/TreeGrid/TreeGrid'
// import {getGoodList, addCate} from '@/api/api'
export default {
  data () {
    return {
      // 添加分类 初始状态
      addDialogFormVisible: false,
      // 添加分类的弹出层
      addForm: {
        cat_name: '',
        cat_pid: 0,
        cat_level: 0
      },
      // 编辑分类 初始状态
      editDialogFormVisible: false,
      // 编辑分类的弹出层
      editForm: {},
      // 引入的功能性组件
      dataSource: [
        {
          cat_id: 1,
          cat_name: '玩具',
          cat_pid: 0,
          cat_level: 0,
          cat_deleted: false,
          children: [
            {
              cat_id: 3,
              cat_name: '小型玩具',
              cat_pid: 1,
              cat_level: 1,
              cat_deleted: false,
              children: [
                {
                  cat_id: 6,
                  cat_name: '乐高卡车和挖掘车套装',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 7,
                  cat_name: '伟易达宠物化妆盒',
                  cat_pid: 3,
                  cat_level: 2,
                  cat_deleted: false
                }
              ]
            },
            {
              cat_id: 4,
              cat_name: '大型玩具',
              cat_pid: 1,
              cat_level: 1,
              cat_deleted: false,
              children: [
                {
                  cat_id: 23,
                  cat_name: '星辉法拉利电动童车',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 24,
                  cat_name: '贝瑞佳手推杆儿童电动车',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 25,
                  cat_name: '米高迷你随性箱滑板车',
                  cat_pid: 4,
                  cat_level: 2,
                  cat_deleted: false
                }
              ]
            }
          ]
        },
        {
          cat_id: 52,
          cat_name: '热门品牌',
          cat_pid: 0,
          cat_level: 0,
          cat_deleted: false,
          children: [
            {
              cat_id: 64,
              cat_name: '小泰克',
              cat_pid: 52,
              cat_level: 1,
              cat_deleted: false,
              children: [
                {
                  cat_id: 73,
                  cat_name: '小泰克超级厨房',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                },
                {
                  cat_id: 74,
                  cat_name: '小泰克广东丛林树屋',
                  cat_pid: 64,
                  cat_level: 2,
                  cat_deleted: false
                }
              ]
            },
            {
              cat_id: 1008,
              cat_name: '费雪',
              cat_pid: 52,
              cat_level: 2,
              cat_deleted: false
            }
          ]
        }
      ],
      columns: [{
        text: '分类名称',
        dataIndex: 'cat_name',
        width: ''
      }, {
        text: '是否有效',
        dataIndex: 'cat_deleted',
        width: ''
      }, {
        text: '排序',
        dataIndex: 'cat_level',
        width: ''
      }],
      // 第4行 分页
      // 总条数
      total: 0,
      // 每页条数
      pagesize: 10,
      // 当前页
      pagenum: 1,
      // 表单验证
      rules: {
        cate_name: [
          { required: true, message: '请输入分类名称', trigger: 'blur' }
        ]
      },
      // 编辑表单验证
      editrules: {
        cate_name: [
          { required: true, message: '请输入分类名称', trigger: 'blur' }
        ]
      },
      // 级联选择器
      options: [], // 级联的数据来源
      selectedOptions: [], // 选择的级联,
      // 级联菜单的默认展示修改
      props: {
        value: 'cat_id',
        label: 'cat_name'
      }
    }
  },
  mounted () {
    // this.initList()
  },
  // 注入组件
  components: {
    TreeGrid
  },
  methods: {
    // 获取商品分类列表
    initList () {
      // 请求完成前 有loading动画
      this.loading = true
      // 页面一打开 就获取分类列表
      // http({
      //   url: http.adornUrl('/category/list'),
      //   method: 'get',
      //   params: http.adornParams()
      // }).then(({res}) => {
      //   console.log(res)
      //   // if (data && data.code === 0) {
      //   //   fnAddDynamicMenuRoutes(data.menuList)
      //   //   router.options.isAddDynamicMenuRoutes = true
      //   //   sessionStorage.setItem('menuList', JSON.stringify(data.menuList || '[]'))
      //   //   sessionStorage.setItem('permissions', JSON.stringify(data.permissions || '[]'))
      //   //   next({ ...to, replace: true })
      //   // } else {
      //   //   sessionStorage.setItem('menuList', '[]')
      //   //   sessionStorage.setItem('permissions', '[]')
      //   //   next()
      //   // }
      // }).catch((e) => {
      //   // console.log(`%c${e} 请求菜单列表和权限失败，跳转至登录页！！`, 'color:blue')
      //   // router.push({ name: 'login' })
      // })
      // getGoodList({type: '3', pagenum: this.pagenum, pagesize: this.pagesize}).then(res => {
      //   if (res.meta.status === 200) {
      //     this.total = res.data.total
      //     console.log(res.data.result)
      //     this.dataSource = res.data.result
      //     // 请求完, 关闭loading
      //     this.loading = false
      //   }
      // })
    },
    // 引入的功能性组件中
    deleteCategory (cid) {
      console.log(cid)
    },
    editCategory (row) {
      this.row = row
      // console.log(row)
      this.editDialogFormVisible = true
      this.editForm.name = row.cat_name
      this.editForm.pid = row.cat_pid
      this.editForm.level = row.cat_level
    },
    // 第4行 分页
    handleSizeChange (val) {
      // console.log(`每页 ${val} 条`)
      this.pagesize = val
      // this.initList()
    },
    handleCurrentChange (val) {
      // console.log(`当前页: ${val}`)
      this.pagenum = val
      // this.initList()
    },
    // 级联选择器 选择层级之后
    handleChange (value) {
      // console.log(value)
    },
    // 添加分类按钮的点击事件
    addCate () {
      // 展示弹出层
      this.addDialogFormVisible = true
      // 发送请求 获取分类数据 页面打开时获取过的 只是这里只需要2级
      // getGoodList({type: '2'}).then(res => {
      //   if (res.meta.status === 200) {
      //     this.options = res.data
      //   }
      // })
    },
    // 点击添加分类中的确认按钮时
    addCateHandle (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          // 1 如果没有选择级联, 就让它默认为0  1级分类
          if (this.selectedOptions.length === 0) {
            this.addForm.cat_pid = 0
            this.addForm.cat_level = 0
          } else if (this.selectedOptions.length === 1) { // 2级分类
            this.addForm.cat_pid = this.selectedOptions[0]
            this.addForm.cat_level = 1
          } else { // 3级分类
            this.addForm.cat_pid = this.selectedOptions[1]
            this.addForm.cat_level = 2
          }
          // 验证通过了 才去请求
          // addCate(this.addForm).then(res => {
          //   if (res.meta.status === 201) {
          //     // 关闭弹出层
          //     this.addDialogFormVisible = false
          //     // 提示
          //     this.$message({
          //       type: 'success',
          //       message: res.meta.msg
          //     })
          //     // 重新刷新一次
          //     this.initList()
          //   }
          // })
        } else {
          return false
        }
      })
    },
    // 点击编辑 确认按钮时
    editCateHandle (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          // 更新 修改
          console.log(this.editForm)
          this.row = this.editForm
          this.editDialogFormVisible = false
        } else {
          return false
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.categories {
  .el-row {
    margin-bottom: 10px;
  }
  // 第4行 分页
  .block {
    padding: 5px 0;
    background: #D1DAE5;
    margin-top: 10px;
  }
}
</style>
