<template>
  <div class='goods'>
    <!-- 第1行 输入框和按钮 -->
    <el-row>
      <el-col :span='24'>
        <!-- element-ui中  input输入框 -->
        <el-input placeholder='请输入搜索内容' v-model='input1' class='input-search' @keydown.native.enter='initList'>
          <el-button slot='append' icon='el-icon-search' @click='initList'></el-button>
        </el-input>
        <!-- 添加商品 -->
        <el-button type='success' plain @click='addGoods'>添加商品</el-button>
      </el-col>
    </el-row>

    <!-- 第2行 表格 -->
    <el-table :data='goodList' border style='width: 100%' v-loading='loading'>
      <!-- 第1列 序号 -->
      <el-table-column type='index' label='编号' width='50'>
      </el-table-column>

      <!-- 第2列 商品名称 -->
      <el-table-column prop='goods_name' label='商品名称' width='380'>
      </el-table-column>

      <!-- 第3列 商品价格 -->
      <el-table-column prop='goods_price' label='商品价格' width='100'>
      </el-table-column>

      <!-- 第4列 商品状态 -->
      <el-table-column prop='goods_state' label='商品状态' width='80'>
      </el-table-column>

      <!-- 第5列 商品重量 -->
      <el-table-column prop='goods_weight' label='商品重量' width='100'>
      </el-table-column>

      <!-- 第6列 创建时间 -->
      <el-table-column prop='upd_time' label='创建时间' width='150'>
      </el-table-column>

      <!-- 第7列 操作 -->
      <el-table-column label='操作'>
        <template slot-scope='scope'>
          <!-- 编辑 -->
          <el-button type='primary' icon='el-icon-edit' plain size='mini' @click='handleEdit(scope.$index, scope.row)'>
          </el-button>
          <!-- 删除 -->
          <el-button type='danger' icon='el-icon-delete' plain size='mini' @click='handleDelete(scope.$index, scope.row)'>
          </el-button>
          <!-- 成功按钮 -->
          <el-button type='success' icon='el-icon-check' plain size='mini' @click='handleCheck(scope.$index, scope.row)'>
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 第3行 分页 -->
    <div class='block'>
      <el-pagination @size-change='handleSizeChange' @current-change='handleCurrentChange' :current-page='1' :page-sizes='[20, 40, 60, 80, 100]' :page-size='20' layout='total, sizes, prev, pager, next, jumper' :total='total'>
      </el-pagination>
    </div>

    <!-- 编辑商品的弹出层 -->
    <!-- 编辑还没完成 -->
    <el-dialog title='编辑商品' :visible.sync='editDialogFormVisible'>
      <el-form :model='editForm' label-width='80px' :rules='rules' ref='editUserForm'>
        <!-- 商品名称 -->
        <el-form-item label='商品名称' prop='goods_name'>
          <el-input v-model='editForm.goods_name' auto-complete='off'></el-input>
        </el-form-item>

        <!-- 商品价格 -->
        <el-form-item label='商品价格' prop='goods_price'>
          <el-input v-model='editForm.goods_price' auto-complete='off'></el-input>
        </el-form-item>

        <!-- 商品数量 -->
        <el-form-item label='商品数量' prop='goods_number'>
          <el-input v-model='editForm.goods_number' auto-complete='off'></el-input>
        </el-form-item>
        <!-- 商品重量 -->
        <el-form-item label='商品重量' prop='goods_weight'>
          <el-input v-model='editForm.goods_weight' auto-complete='off'></el-input>
        </el-form-item>

        <!-- 商品介绍 -->
        <el-form-item label='商品介绍' prop='goods_introduce'>
          <el-input v-model='editForm.goods_introduce' auto-complete='off'></el-input>
        </el-form-item>
      </el-form>
      <div slot='footer' class='dialog-footer'>
        <el-button @click='editDialogFormVisible = false'>取 消</el-button>
        <el-button type='primary' @click="editUserHandle('editUserForm')">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
// import { goodList, editGoodList, deleteGoods } from '@/api/api'
export default {
  data () {
    return {
      // 添加商品输入框的值
      input1: '',
      // 添加商品的弹出层的初始状态
      addDialogFormVisible: false,
      // 编辑商品的弹出层的初始状态
      editDialogFormVisible: false,
      // 编辑用户弹出层中的form
      editForm: {
        goods_id: 1,
        goods_name: 1,
        goods_price: 1,
        goods_number: 1,
        goods_weight: 1,
        goods_introduce: '',
        pics: {},
        attrs: []
      },
      // 表格
      goodList: [],
      // 加载动画的初始状态
      loading: false,
      // 第4行 分页
      currentPage1: 5,
      // 总条数
      total: 0,
      // 每页条数
      pagesize: 20,
      // 当前页
      pagenum: 1,
      // 表单验证
      rules: {
        goods_name: [
          { required: true, message: '请输入商品名称', trigger: 'blur' }
        ],
        goods_price: [
          { required: true, message: '请输入商品价格', trigger: 'blur' }
        ],
        goods_number: [
          { required: true, message: '请输入商品数量', trigger: 'blur' }
        ],
        goods_weight: [
          { required: true, message: '请输入商品重量', trigger: 'blur' }
        ]
      }
    }
  },
  mounted () {
    this.initList()
  },
  methods: {
    initList () {
      // 获取数据前 开启动画
      // this.loading = true
      // 获取商品列表
      // let params = {query: this.input1, pagenum: this.pagenum, pagesize: this.pagesize}
      // goodList(params).then(res => {
      //   if (res.meta.status === 200) {
      //     this.total = res.data.total
      //     this.goodList = res.data.goods
      //     this.loading = false
      //   }
      // })
      // 模拟数据
      this.total = 20
      this.goodList = [
        {
          goods_id: 926,
          cat_id: null,
          goods_name:
            'Btoys宝宝回力卡通车',
          goods_price: 259,
          goods_number: 100,
          goods_weight: 100,
          goods_state: 0,
          add_time: 1513578632,
          upd_time: 1513578632,
          hot_mumber: 0,
          is_promote: false,
          cat_one_id: null,
          cat_two_id: null,
          cat_three_id: null
        },
        {
          goods_id: 925,
          cat_id: null,
          goods_name:
            '乐高米奇的汽车工作室',
          goods_price: 188,
          goods_number: 100,
          goods_weight: 100,
          goods_state: 0,
          add_time: 1525259853,
          upd_time: 1525259853,
          hot_mumber: 0,
          is_promote: false,
          cat_one_id: null,
          cat_two_id: null,
          cat_three_id: null
        }
      ]
    },
    // 编辑商品
    handleEdit (index, row) {
      console.log(index, row)
      this.editDialogFormVisible = true
      // 给弹出层添加数据
      this.editForm = row
      // let params = {id: this.editForm.goods_id, goods_name: this.editForm.goods_name, goods_price: this.editForm.goods_price, goods_number: this.editForm.goods_number, goods_weight: this.editForm.goods_weight, goods_introduce: this.editForm.goods_introduce, pics: this.editForm.pics, attrs: this.editForm.attrs}
      // editGoodList(params).then(res => {
      //   console.log(res)
      // })
    },
    // 删除商品
    handleDelete (index, row) {
      // console.log(index, row)
      // 删除商品 弹出层
      this.$confirm('此操作将永久删除该用户, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          // deleteGoods(row.goods_id).then(res => {
          //   if (res.meta.status === 200) {
          //     this.$message({
          //       type: 'success',
          //       message: '删除成功!'
          //     })
          //     this.initList()
          //   }
          // })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    // 分配商品
    handleCheck (index, row) {
      // console.log(index, row)
    },
    // 第4行 分页
    // 每页多少条 变化时
    handleSizeChange (val) {
      this.pagesize = val
      this.initList()
    },
    // 页码改变时
    handleCurrentChange (val) {
      this.pagenum = val
      this.initList()
    },
    // 添加商品
    addGoods () {
      // 编程式导航
      this.$router.push({ name: 'addgoods' })
    }
  }
}
</script>

<style lang='scss' scoped>
.goods {
  .el-row {
    margin-bottom: 10px;
  }

  // 第2行 输入框和按钮
  .input-search {
    width: 300px;
  }

  // 第4行 分页
  .block {
    padding: 5px 0;
    background: #d1dae5;
    margin-top: 10px;
  }
}
</style>
