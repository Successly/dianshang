<template>
  <el-dialog
    title="绑定酒店"
    :close-on-click-modal="false"
    :visible.sync="visible">

	<el-table
      :data="bangList"
      style="width: 400px;">
      <el-table-column
        prop="hotelName"
        label="已关联酒店"
        width="200">
      </el-table-column>
      <el-table-column
        prop="name"
        label="操作"
        width="200">
			<template slot-scope="scope">
				<el-button
				  @click.native.prevent="deleteContact(scope.row)"
				  type="text"
				  size="small">
				  取消关联
				</el-button>
			</template>
      </el-table-column>
    </el-table>

	<el-select @change="changeSelect" filterable v-model="hotelId" placeholder="请选择" clearable style="width: 200px;margin: 20px 0;">
		<el-option
		  v-for="item in allHotelList"
		  :key="item.id"
		  :label="item.name"
		  :value="item.id+'_'+item.name">
		</el-option>
	</el-select>

	<el-table
      :data="waitBangList"
      style="width: 400px;">
      <el-table-column
        prop="hotelName"
        label="酒店列表"
        width="200">
      </el-table-column>
      <el-table-column
        prop="name"
        label="操作"
        width="200">
			<template slot-scope="scope">
				<el-button
				  @click.native.prevent="contact(scope.row)"
				  type="text"
				  size="small">
				  关联
				</el-button>
			</template>
      </el-table-column>
    </el-table>
  </el-dialog>
</template>

<script>
  import { isEmail, isMobile } from '@/utils/validate'
  export default {
    data () {
      return {
        visible: false,
		hotelId: '',
		bangList: [],
		waitBangList: [],
		allHotelList: [],
		userId: ''
      }
    },
    methods: {
		changeSelect(val){
			var arr = val.split('_');
			var flag = true;
			for(var i = 0; i < this.waitBangList.length; i++){
				if(this.waitBangList[i].hotelId == arr[0]){
					flag = false;
				}
			}
			for(var i = 0; i < this.bangList.length; i++){
				if(this.bangList[i].hotelId == arr[0]){
					flag = false;
				}
			}
			if(flag){
				this.waitBangList.push({
					hotelId: arr[0],
					hotelName: arr[1]
				})
			}
		},
      init (id) {
		this.userId = id;
		this.$http({
			url: this.$http.adornUrl_qfs('/hotel/hotels/collect/all'),
			method: 'get',
			params: this.$http.adornParams()
		}).then(({data}) => {
			this.visible = true;
			if (data && data.code === 0) {
				this.allHotelList = data.data;
				this.refreshBangList()
			} else {
				this.allHotelList = [];
			}
		})
      },
	  refreshBangList(){
		this.$http({
			url: this.$http.adornUrl_qfs('/system/accounthotel/list'),
			method: 'get',
			params: this.$http.adornParams({
				account: this.userId
			})
		}).then(({data}) => {
			if (data && data.code === 0) {
				this.bangList = data.data;
			} else {
				this.allHotelList = [];
			}
		})
	  },
      contact (row) {
        this.$http({
			url: this.$http.adornUrl_qfs('/system/accounthotel/add'),
			method: 'post',
			data: this.$http.adornData({
				hotelId: row.hotelId,
				account: this.userId
			})
		}).then(({data}) => {
			if (data && data.code === 0) {
				this.waitBangList.splice(this.waitBangList.indexOf(row), 1);
				this.refreshBangList();
			} else {
				this.$message.error(data.msg)
			}
		})
      },
	  deleteContact(row){
		 this.$confirm('确定要取消关联该酒店吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
			this.$http({
				url: this.$http.adornUrl_qfs('/system/accounthotel/deleted/' + row.id),
				method: 'post',
				data: this.$http.adornData()
			}).then(({data}) => {
				if (data && data.code === 0) {
					this.refreshBangList()
				} else {
					this.$message.error(data.msg)
				}
			})
		}).catch(() => {})
	  }
    }
  }
</script>
