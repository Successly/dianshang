<template>
  <div class="categories">
    <!-- 第1行 添加一级分类 -->
    <el-row>
      <el-col :span="24">
        <!-- 添加一级分类 -->
        <el-button v-if="isAuth('biz:category:add')" type="success" title="添加1级分类" plain @click="addFirstCate">
          <i class="el-icon-circle-plus-outline"></i> 1级分类
        </el-button>
      </el-col>
    </el-row>

    <!-- 第2行 表格展示  引入封装的功能性组件 -->
    <tree-grid
      :treeStructure="true"
      :columns="columns"
      :data-source="dataSource"
      @deleteCate="deleteCategory"
      @editCate="editCategory"
      @addCate="addCategory"
    >
    </tree-grid>

    <!-- 添加1级分类的弹出层 -->
    <el-dialog title="添加分类" :visible.sync="addFirstDialogFormVisible">
      <el-form :model="addFirstForm" label-width="80px" :rules="rules" ref="addFirstCateForm">
        <!-- 分类名称 -->
        <el-form-item label="分类名称" prop="name">
          <el-input v-model="addFirstForm.name" auto-complete="off"></el-input>
        </el-form-item>

        <!-- 排序 -->
        <el-form-item label="排序" prop="order">
          <el-input v-model="addFirstForm.order" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addFirstDialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addFirstCateHandle('addFirstCateForm')">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 添加子分类的弹出层 -->
    <el-dialog title="添加子分类" :visible.sync="addDialogFormVisible">
      <el-form :model="addForm" label-width="80px" :rules="rules" ref="addCateForm">
        <!-- 分类名称 -->
        <el-form-item label="分类名称" prop="name">
          <el-input v-model="addForm.name" auto-complete="off"></el-input>
        </el-form-item>

        <!-- 排序 -->
        <el-form-item label="排序" prop="order">
          <el-input v-model="addForm.order" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addDialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addCateHandle('addCateForm')">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 编辑分类的弹出层 -->
    <el-dialog title="编辑分类" :visible.sync="editDialogFormVisible">
      <el-form :model="editForm" label-width="80px" :rules="editrules" ref="editCateForm">
        <!-- 分类名称 -->
        <el-form-item label="分类名称" prop="name">
          <el-input v-model="editForm.name" auto-complete="off"></el-input>
        </el-form-item>

        <!-- 排序 -->
        <el-form-item label="排序" prop="order">
          <el-input v-model="editForm.order" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="editDialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="editCateHandle('editCateForm')">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
// 引入components中存放的功能性组件 TreeGrid
import TreeGrid from '@/components/TreeGrid/TreeGrid'
// import {deleteCateWork} from '@/api/api'
// import axios from 'axios'
export default {
  data () {
    return {
      // 添加 子分类 初始状态
      addDialogFormVisible: false,
      // 添加 1级分类 初始状态
      addFirstDialogFormVisible: false,
      // 添加 1级分类的弹出层中数据
      addForm: {
        name: '',
        id: 0,
        order: null
      },
      // 添加 子级分类
      addFirstForm: {
        name: '',
        id: '',
        order: ''
      },
      // 编辑分类 初始状态
      editDialogFormVisible: false,
      // 编辑分类的弹出层
      editForm: {},
      // 引入的功能性组件
      dataSource: [],
      columns: [{
        text: '分类名称',
        dataIndex: 'name',
        width: ''
      }, {
        text: '排序',
        dataIndex: 'order',
        width: ''
      }],
      // 添加一级分类 表单验证
      rules: {
        name: [
          { required: true, message: '请输入分类名称', trigger: 'blur' }
        ],
        order: [
          { required: true, message: '请输入排序数字', trigger: 'blur' }
        ]
      },
      // 编辑表单验证
      editrules: {
        name: [
          { required: true, message: '请输入分类名称', trigger: 'blur' }
        ],
        order: [
          { required: true, message: '请输入排序数字', trigger: 'blur' }
        ]
      }
    }
  },
  activated () {
    this.initList()
  },
  // 注入组件
  components: {
    TreeGrid
  },
  methods: {
    // 获取商品分类列表
    initList () {
      // 请求完成前 有loading动画
      this.loading = true
      // 页面一打开 就获取分类列表
      this.$http({
        url: this.$http.adornUrl('/category/list'),
        method: 'get',
        params: {}
      }).then(({data}) => {
        console.log('数据格式：', this.dataSource)
        console.log('-----分类列表 成功-----: ', data.data)
        // 正常
        if (data && data.code === 0) {
          this.loading = false
          // 获取列表
          this.dataSource = data.data
        } else if (data.code === 1) {
          console.log('-----/category/list-----', data.msg)
        } else {
          console.log('-----/category/list 服务器异常-----', data.msg)
        }
      }).catch((e) => {
        console.log('获取分类列表失败', e)
      })
    },
    // 添加 1级分类
    addFirstCate () {
      // 打开添加弹窗
      this.addFirstDialogFormVisible = true
      this.addForm.id = 0
      this.addForm.name = ''
      this.addForm.order = ''
    },
    // 点击 1级分类弹窗 —— 确认按钮
    addFirstCateHandle (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          // 1 如果没有选择级联, 就让它默认为0  1级分类
          // 验证通过了 才去请求
          this.addRequest(this.addFirstForm.name, this.addFirstForm.order)
          // 关闭 添加弹窗
          this.addDialogFormVisible = false
        } else {
          return false
        }
      })
    },
     // 封装请求： 添加 分类
    addRequest (value, order, pid) {
      var pides = pid || 0
      this.$http({
        url: this.$http.adornUrl('/category/add'),
        method: 'post',
        data: this.$http.adornData({
          'name': value,
          'pid': pides,
          'order': order
        })
      }).then(({data}) => {
        console.log('-------添加 子分类--------', data)
        // 正常
        if (data && data.code === 0) {
          // 添加分类 成功提示
          this.$message({
            type: 'success',
            message: data.msg
          })
          // 重新刷新一次
          this.initList()
        } else if (data.code === 1) {
          console.log('-----/category/add 请求参数错误-----')
        } else {
          console.log('-----/category/add 服务器异常-----')
        }
      }).catch((e) => {
        console.log(e)
      })
    },
    // 添加 子分类（除 1级）
    addCategory (row) {
      // 打开添加弹窗
      this.addDialogFormVisible = true
      this.addForm.id = row.id
      this.addForm.name = ''
      this.addForm.order = ''
    },
    // 点击 添加子分类弹窗 —— 确认按钮
    addCateHandle (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          // 1 如果没有选择级联, 就让它默认为0  1级分类
          // 验证通过了 才去请求
          this.addRequest(this.addForm.name, this.addForm.order, this.addForm.id)
          // 关闭添加弹窗
          this.addDialogFormVisible = false
        } else {
          return false
        }
      })
    },
    // 引入的功能性组件中
    // 删除分类
    deleteCategory (row) {
      // 删除时 获取一行数据
      this.$confirm('删除该分类?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        // 调用删除接口
        this.$http({
          url: this.$http.adornUrl('/category/delete'),
          method: 'delete',
          data: this.$http.adornData({
            'id': row.id
          })
        }).then(({data}) => {
          console.log('-------删除--------', data)
          if (data.code === 0) {
            this.initList()
          }
          // 正常
        }).catch((e) => {
          console.log(e)
        })
        // deleteCateWork([row.id]).then(res => {
        //   console.log(res)
        //   // 提示
        //   this.$message({
        //     type: 'success',
        //     message: '删除成功!'
        //   })
        // })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    // 编辑分类
    editCategory (row) {
      this.editDialogFormVisible = true
      this.editForm.id = row.id
      this.editForm.name = row.name
    },
    // 点击编辑 确认按钮时
    editCateHandle (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          // 更新 修改
          // 调用 编辑分类接口 post
          this.$http({
            url: this.$http.adornUrl('/category/update'),
            method: 'post',
            data: this.$http.adornData(this.editForm)
          }).then(({data}) => {
            // 正常
            if (data && data.code === 0) {
              console.log('----- /category/update success-----: ', data)
              // 刷新列表
              this.initList()
              // 关闭 编辑弹窗
              this.editDialogFormVisible = false
            } else if (data.code === 1) {
              console.log('-----/category/list-----', data.msg)
            } else {
              console.log('-----/category/list 服务器异常-----', data.msg)
            }
          }).catch((e) => {
            console.log('获取分类列表失败', e)
          })
        } else {
          return false
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.categories {
  .el-row {
    margin-bottom: 10px;
  }
  // 第4行 分页
  .block {
    padding: 5px 0;
    background: #D1DAE5;
    margin-top: 10px;
  }
}
</style>
