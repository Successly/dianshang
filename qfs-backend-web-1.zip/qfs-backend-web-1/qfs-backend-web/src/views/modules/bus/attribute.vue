<template>
  <div class='mod-user'>
    <!-- 用户名 -->
    <el-form :inline='true' :model='dataForm' @keyup.enter.native='getDataList()'>
      <el-form-item>
        <el-input v-model='dataForm.attrName' placeholder='属性名' clearable></el-input>
      </el-form-item>
      
      <!-- 查询 -->
      <el-form-item>
        <el-button v-if="isAuth('biz:attribute:list')" @click='getDataList()' @keydown.native.enter='getDataList()'>查询</el-button>
        <el-button v-if="isAuth('biz:attribute:save')" type='primary' @click='addOrUpdateHandle()'>新增</el-button>
        <el-button v-if="isAuth('biz:attribute:delete')" type='danger' @click='deleteHandle()' :disabled='dataListSelections.length <= 0'>批量删除</el-button>
      </el-form-item>
    </el-form>
    <!-- 表格 -->
    <!-- 属性: selection-change: 当选择项发生变化时会触发该事件 -->
    <el-table
      :data='dataList'
      border
      v-loading='dataListLoading'
      @selection-change='selectionChangeHandle'
      style='width: 100%;'>
      <!-- 多选框 -->
      <el-table-column
        type='selection'
        header-align='center'
        align='center'
        width='50'>
      </el-table-column>

      <!-- 属性 id -->
      <el-table-column
        prop='id'
        header-align='center'
        align='center'
        label='属性ID'>
      </el-table-column>

      <!-- 属性 名 -->
      <el-table-column
        prop='name'
        header-align='center'
        align='center'
        label='属性名'>
      </el-table-column>

      <!-- 属性 标题 -->
      <el-table-column
        prop='label'
        header-align='center'
        align='center'
        label='属性标题'>
      </el-table-column>

      <!-- 属性值 id -->
      <el-table-column
        prop='propertyvalueId'
        header-align='center'
        align='center'
        label='属性值ID'>
      </el-table-column>

      <!-- 属性值 -->
      <el-table-column
        prop='propertyValue'
        header-align='center'
        align='center'
        label='属性值'>
      </el-table-column>

      <!-- 操作 -->
      <el-table-column
        fixed='right'
        header-align='center'
        align='center'
        label='操作'>
        <template slot-scope='scope'>
          <!-- 编辑 -->
          <el-button v-if="isAuth('biz:attribute:update')" type='primary' icon='el-icon-edit' size='small' @click='addOrUpdateHandle(scope.row)'></el-button>
          <!-- 删除 -->
          <el-button v-if="isAuth('biz:attribute:delete')" type='danger' icon='el-icon-delete' size='small' @click='deleteHandle(scope.row.id)'></el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <div class='block'>
      <el-pagination
        @size-change='sizeChangeHandle'
        @current-change='currentChangeHandle'
        :current-page='pageNumber'
        :page-sizes='[5, 10, 15, 20]'
        :page-size='pageSize'
        :total='totalPage'
        layout='total, sizes, prev, pager, next, jumper'>
      </el-pagination>
    </div>
    
    <!-- 弹窗, 新增 / 修改 -->
    <AddOrUpdate v-if='addOrUpdateVisible' ref='addOrUpdate' @refreshDataList='getDataList'></AddOrUpdate>
  </div>
</template>

<script>
  import AddOrUpdate from './attribute-add-or-update'
  export default {
    data () {
      return {
        // 属性名
        dataForm: {
          attrName: ''
        },
        // 属性数据
        dataList: [],
        // 当前页
        pageNumber: 1,
        // 每页条数
        pageSize: 10,
        // 总页数
        totalPage: 0,
        // 表格数据加载状态
        dataListLoading: false,
        // 批量删除时选中的
        dataListSelections: [],
        // 弹窗: 添加、修改
        addOrUpdateVisible: false,
        ceshi: []
      }
    },
    components: {
      AddOrUpdate
    },
    activated () {
      this.getDataList()
    },
    methods: {
      // 获取属性列表
      getDataList () {
        // 开启加载中
        this.dataListLoading = true
        // 请求数据
        this.$http({
          url: this.$http.adornUrl('/property/list'),
          method: 'get',
          params: this.$http.adornParams({
            'page': this.pageNumber,
            'limit': this.pageSize,
            'name': this.dataForm.attrName // 属性名
          })
        }).then(({data}) => {
          if (data && data.code === 0) {
            console.log('获取属性列表', data)
            // var datas = data
            // 处理
            // var newArr = []

            // data.page.list.map(function (item, index, arr) {
            //   newArr.push(item.pro)
            //   console.log(item.pve, index, '渲染')
            //   // newArr[index].propertyvalueId = item.pve[index].id || null
            //   // newArr[index].propertyValue = item.pve[index].propertyValue
            // })
            // console.log(newArr, 18)
            // 每一项
            // newArr.map((item, index, arr) => {
            //   // 获取属性详情
            //   // this.$http({
            //   //   url: this.$http.adornUrl(`/property/${item.id}`),
            //   //   method: 'get',
            //   //   params: this.$http.adornParams({})
            //   // }).then(({data}) => {
            //   //   // console.log('-----获取属性详情-----: ', data)
            //   //   // 正常
            //   //   if (data && data.code === 0) {
            //   //     // 获取列表
            //   //     item.propertyvalueId = data.data.pve.propertyvalueId
            //   //     item.propertyvalue = data.data.pve.propertyValue
            //   //   }
            //   // }).catch((e) => {
            //   //   console.log('获取属性详情失败', e)
            //   // })
            //   // item.propertyvalueId = data.data.pve.propertyvalueId
            //   // item.propertyvalue = data.data.pve.propertyValue
            // })
            // 渲染表格数据
            this.dataList = data.page.list
            this.pageNumber = data.page.currPage
            this.pagSize = data.page.pageSize
            this.totalPage = data.page.totalCount
          } else {
            this.dataList = []
            this.totalPage = 0
          }
          // 关闭加载中
          this.dataListLoading = false
        })
      },
      // 每页数
      sizeChangeHandle (val) {
        this.pageSize = val
        this.pageNumber = 1
        this.getDataList()
      },
      // 当前页
      currentChangeHandle (val) {
        this.pageNumber = val
        this.getDataList()
      },
      // 多选
      selectionChangeHandle (val) {
        this.dataListSelections = val
      },
      // 新增 / 修改
      addOrUpdateHandle (row) {
        this.addOrUpdateVisible = true
        this.$nextTick(() => {  // 当dom发生变化，更新后执行的回调。
          this.$refs.addOrUpdate.init(row)
        })
      },
      // 删除
      deleteHandle (id) {
        // 单个、批量
        var ids = id ? [id] : this.dataListSelections.map(item => {
          return item.id
        })
        // 对话框
        this.$confirm(`确定对[id=${ids}]进行[${id ? '删除' : '批量删除'}]操作?`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {  // 确定删除
          // 请求删除接口
          // post类似删除
          this.$http({
            url: this.$http.adornUrl('/property/delete'),
            method: 'delete',
            data: this.$http.adornData({
              'ids': ids
            })
          }).then(({data}) => {
            // console.log('-------属性删除--------', data)
            if (data.code === 0 && data.msg === 'success') {
              this.$message({
                type: 'success',
                message: '删除成功'
              })
              this.getDataList()
            } else {
              console.log(data.msg)
            }
          }).catch((e) => {
            console.log(e)
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      }
    }
  }
</script>

<style lang='scss' scoped>
 .block {
    background: #d1dae5;
    margin-top: 20px;
    .el-pagination {
      padding: 10px;
    }
  }
</style>
