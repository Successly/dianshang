<template>
  <div class="addgoods">
    <!-- 第1行 添加商品信息 -->
    <el-row class="infomation">
      <el-col :span="24">
        <span>{{localStorage.getItem('add') ? '添加' : '修改'}}商品信息</span>
      </el-col>
    </el-row>

    <!-- 第2行 步骤条 -->
    <el-steps :active="active" finish-status="success">
      <el-step title="步骤 1"></el-step>
      <el-step title="步骤 2"></el-step>
      <el-step title="步骤 3"></el-step>
      <el-step title="步骤 4"></el-step>
      <el-step title="步骤 5"></el-step>
    </el-steps>

    <!-- 第3行 tab栏 -->
    <!-- element-ui中的tab栏 一般选用时 都选用第一个实例 -->
    <el-tabs :tab-position="tabPosition" style="height: 200px;"  v-model="activeName" @tab-click="handleClick">
      <!-- 基本信息 -->
      <el-tab-pane label="基本信息" name="first">基本信息</el-tab-pane>

      <!-- 商品参数 -->
      <el-tab-pane label="商品参数" name="second">商品参数</el-tab-pane>

      <!-- 商品属性 -->
      <el-tab-pane label="商品属性" name="third">
        <!-- 添加属性  v-if="isAuth('biz:goods:update')"-->
        <div class='addAttribute'>
          <!-- 编辑 -->
          <el-button type='primary' icon='el-icon-circle-plus-outline' size='small' title='添加属性' @click='addAttrHandle()'>
          属性
          </el-button>
        </div>

        <!-- 属性、属性值 选择 -->
        <div v-for='item in dynamic' :key='item.id'>
          <!-- 下拉框: 属性 -->
          <el-dropdown trigger="click" @command="getAttr">
            <!-- 请选择 -->
            <span class="el-dropdown-link">
              {{item.attrSelected}}<i class="el-icon-arrow-down el-icon--right"></i>
            </span>
 
            <!-- 遍历: 显示属性下拉框 -->
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item :command='item1' v-for='item1 in attrList' :key='item1.id' data-id='item1.id'>{{item1.attr}}</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>

          <!-- 按钮: 添加属性值 v-if="isAuth('biz:goods:update')" -->
          <el-button class='addval' type='info' icon='el-icon-circle-plus-outline' size='small' title='添加属性值' @click='addAttrValHandle()'>
          属性值
          </el-button>

          <!-- 下拉框: 属性值 v-for='item in dynamicValue' :key='item.id'-->
          <div style='display: inline-block;'>
            <el-dropdown v-if='item.attrValVisib' trigger="click" @command="getAttrVal">
              <span class="el-dropdown-link">
                {{item.attrValSelected}}<i class="el-icon-arrow-down el-icon--right"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item :command='item' v-for='item in attrValList' :key='item.id'  :disabled="item.attrSelected === '请选择'">{{item}}</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </div>
        </div>
      </el-tab-pane>

      <!-- 商品图片 -->
      <el-tab-pane label="商品图片" name="fourth">
        <!-- element-ui中的 Upload 上传 - 图片列表缩略图 -->
        <!-- action是后台给的 -->
        <el-upload
          action="http://localhost:8888/api/private/v1/upload"
          :on-preview="handlePreview"
          :on-remove="handleRemove"
          :headers="setHeaders()"
          :on-success="handleSuccess"
          list-type="picture">
          <el-button size="small" type="primary">点击上传</el-button>
          <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
        </el-upload>
      </el-tab-pane>
      <el-tab-pane label="商品内容" name="fivth">商品内容</el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
export default {
  data () {
    return {
      // 步骤条
      active: 0,
      // tab栏的位置
      tabPosition: 'left',
      activeName: 'first',
      // 属性
      attrSelected: '请选择', // 选择值
      attrNewSelected: '请选择', // 新添加
      attrList: [], // 下拉框: 属性 数据
      // 动态添加
      dynamic: [], // 属性  下拉框次数
      dynamicValue: [], // 属性值  下拉框次数
      // 属性值
      attrValSelected: '请选择', // 选择值
      // 下拉框:
      attrValVisib: false, // 显示状态
      attrValList: [], // 属性值 数据
      // 测试 属性选择值
      addAttrForm: {}
    }
  },
  methods: {
    // 点击: 添加属性
    addAttrHandle (res) {
      // 1. 动态添加 一个 属性下拉框
      if (this.dynamic.length <= this.attrList.length) {
        this.dynamic.push({'attrSelected': '请选择', 'attrValSelected': '请选择', 'attrValVisib': false})
      }

      // 2. 修改 下拉框: 属性值的显示状态
      this.attrValVisib = false

      // 3. 请求: 获取属性下拉框数据
      this.attrList = [{id: 1, attr: '颜色'}, {id: 2, attr: '大小'}, {id: 3, attr: '长度'}]
    },

    // 下拉框: 属性 改变
    getAttr (res) {
      console.log(res, 18)
      // 1. 获取当前 属性的 id 和 attr值
      this.attrId = res.id

      // 2. 修改当前选择的下拉框的 值
      this.dynamic[this.dynamic.length - 1].attrSelected = res.attr

      // 3. 修改下拉框: 属性值的显示状态
      // this.attrValVisib = false
      this.dynamic.attrValVisib = false

      // 4. 修改下拉框： 属性值的初始值
      this.dynamic[this.dynamic.length - 1].attrValSelected = '请选择'

      // 2. 请求: 获取属性下拉框数据  参数: 属性 id
      // console.log(this.attrId)
      if (this.attrId === 1) {
        this.attrValList = ['红', '黄', '蓝']
      } else if (this.attrId === 2) {
        this.attrValList = ['小', '中', '大']
      } else {
        this.attrValList = ['1m', '2m', '3m']
      }
    },

    // 点击: 添加属性值
    addAttrValHandle (res) {
      // 1. 显示 下拉框: 属性值
      // this.attrValVisib = true
      this.dynamic[this.dynamic.length - 1].attrValVisib = true
      // 2. 请求: 获取属性下拉框数据  参数: 属性 id
      // console.log(this.attrId)
      // if (this.attrId === 1) {
      //   this.attrValList = ['红', '黄', '蓝']
      // } else if (this.attrId === 2) {
      //   this.attrValList = ['小', '中', '大']
      // } else {
      //   this.attrValList = ['1m', '2m', '3m']
      // }
    },

    // 属性值 下拉框
    getAttrVal (res) {
      // 选择的属性值 -- 当前的属性
      // console.log(this.dynamic[this.dynamic.length - 1], 'mm')
      // this.dynamicValue[this.dynamic.length - 1].push({'attrValSelected': res})
      // this.dynamic[this.dynamic.length - 1].attrValSelected = res
      // this.attrValSelected = res
      this.dynamic[this.dynamic.length - 1].attrValSelected = res
      console.log(res, '重新修改后')

      // this.dynamicValue.push(res)
    },

    handleClick (tab, event) {
      // console.log(tab, event)
      // 判断当前点击的是第几个tab, 让对应的进度条显示
      switch (tab.name) {
        case 'first':
          this.active = 0
          break
        case 'second':
          this.active = 1
          break
        case 'third':
          this.active = 2
          break
        case 'fourth':
          this.active = 3
          break
        default:
          this.active = 4
      }
    },

    // 删除图片的函数
    // 点击图片时
    handleRemove (file, fileList) {
      // console.log(file, fileList)
    },

    // 删除图片上时
    handlePreview (file) {
      // console.log(file)
    },

    // 设置上传的请求头 需要带上token
    setHeaders () {
      // 取出token
      let token = localStorage.getItem('mytoken')
      if (token) {
        return {
          Authorization: token
        }
      }
    },
    // 上传成功的函数
    handleSuccess (response, file, fileList) {
      // console.log(response)
      // console.log(file)
      // console.log(fileList)
      if (response.meta.status === 200) {
        this.$message({
          type: 'success',
          message: response.meta.msg
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.addgoods {
  .el-row {
    margin-bottom: 10px;
  }
  .infomation {
    background: #D5E0ED;
    padding: 10px;
    margin-bottom: 50px;
  }
  // 添加属性按钮 所在box
  .addAttribute {
    margin-bottom: 25px;
  }
  // 下拉框
  .el-dropdown {
    margin-bottom: 25px!important;
  }
  // 按钮: 添加属性值
  .el-button--small.addval {
    margin: 0 20px;
  }
}
</style>
