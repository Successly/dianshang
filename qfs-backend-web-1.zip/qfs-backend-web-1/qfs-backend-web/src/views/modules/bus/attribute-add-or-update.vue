<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
      <!-- 属性名 -->
      <el-form-item label="属性名" prop="name">
        <el-input v-model="dataForm.name" placeholder="属性名"></el-input>
      </el-form-item>

      <!-- 属性标题 -->
      <el-form-item label="属性标题" prop="label">
        <el-input v-model="dataForm.label" placeholder="属性标题"></el-input>
      </el-form-item>

      <!-- 属性id -->
      <!-- <el-form-item label="属性id" prop="id">
        <el-input v-model="dataForm.name" placeholder="属性id"></el-input>
      </el-form-item> -->

      <!-- 属性值id -->
      <!-- <el-form-item label="属性值id" prop="propertyvalueId">
        <el-input v-model="dataForm.label" placeholder="属性值"></el-input>
      </el-form-item> -->

      <!-- 属性值 -->
      <el-form-item label="属性值" prop="propertyvalue">
        <el-input v-model="dataForm.propertyvalue" placeholder="属性值"></el-input>
        <!-- <el-select v-model="value1" multiple placeholder="请选择">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select> -->
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        dataForm: {
          id: null, // 属性id
          name: '', // 属性名
          label: '', // 属性标题
          propertyValue: '', // 属性值
          propertyvalueId: null // 属性值 id
        },
        // // 下拉框
        // options: [{
        //   value: '选项1',
        //   label: '黄金糕'
        // }, {
        //   value: '选项2',
        //   label: '双皮奶'
        // }],
        // value1: '',
        dataRule: {
          name: [
            { required: true, message: '属性名不能为空', trigger: 'blur' }
          ],
          label: [
            { required: true, message: '属性标题不能为空', trigger: 'blur' }
          ],
          propertyvalue: [
            { required: true, message: '属性值不能为空', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      // 从属性页面传入
      init (row) {
        // 获取数据
        if (row) {
          this.dataForm = row
        }
        // 打开弹窗
        this.visible = true
        // 修改
        if (this.dataForm.id) {
          this.dataForm = row || {}
        } else {  // 新增
          this.dataForm = {
            propertyId: 0, // 属性id
            name: '', // 属性名
            label: '', // 属性标题
            propertyvalue: '', // 属性值
            propertyvalueId: 0 // 属性值 id
          }
        }
      },
      // 表单提交 确定
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            // 增加
            if (!this.dataForm.id) {
              this.$http({
                url: this.$http.adornUrl('/property/add'),
                method: 'post',
                data: this.$http.adornData({
                  'name': this.dataForm.name, // 属性名
                  'label': this.dataForm.label, // 属性标题
                  'propertyValue': this.dataForm.propertyvalue // 属性值
                })
              }).then(({data}) => {
                console.log(data, '添加中')
                if (data && data.code === 0) {
                  this.$message({
                    message: '操作成功',
                    type: 'success',
                    duration: 1500,
                    onClose: () => {
                      this.visible = false
                      this.$emit('refreshDataList')
                    }
                  })
                } else {
                  this.$message.error(data.msg)
                }
              })
            } else {
              // 修改
              this.$http({
                url: this.$http.adornUrl('/property/update'),
                method: 'post',
                data: this.$http.adornData({
                  'id': this.dataForm.id, // 属性 id
                  'name': this.dataForm.name, // 属性名
                  'label': this.dataForm.label, // 属性标题
                  'propertyvalueId': this.dataForm.propertyvalueId, // 属性值 id
                  'propertyValue': this.dataForm.propertyvalue// 属性值
                })
              }).then(({data}) => {
                console.log(data, '修改中')
                if (data && data.code === 0) {
                  this.$message({
                    message: '操作成功',
                    type: 'success',
                    duration: 1500,
                    onClose: () => {
                      this.visible = false
                      this.$emit('refreshDataList')
                    }
                  })
                } else {
                  this.$message.error(data.msg)
                }
              })
            }
          }
        })
      }
    }
  }
</script>
