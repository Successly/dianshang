<template>
  <div class='goods'>
    <!-- 第1行 输入框和按钮 -->
    <el-row>
      <el-col :span='24'>
        <!-- element-ui中  input输入框 -->
        <el-input placeholder='请输入搜索内容：商品名或分类id' v-model='dataForm.goodName' class='input-search' @keydown.native.enter='initList'>
          <el-button v-if="isAuth('biz:goods:list')" slot='append' icon='el-icon-search' @click='initList'></el-button>
        </el-input>
        <!-- 添加商品 -->
        <el-button  v-if="isAuth('biz:goods:save')" type='primary' @click='addUpGoods()'>添加商品</el-button>
        <el-button v-if="isAuth('biz:goods:delete')" type="danger" @click="deleteHandle()" :disabled="dataListSelections.length <= 0">批量删除</el-button>
      </el-col>
    </el-row>

    <!-- 第2行 表格 -->
    <el-table 
    :data='goodList' 
    @selection-change="selectionChangeHandle"
    border 
    style='width: 100%' 
    v-loading='loading'
    > 
      <!-- 第1列 选择 -->
      <el-table-column
        type="selection"
        header-align="center"
        align="center"
        width="50">
      </el-table-column>

      <!-- 第2列 id -->
      <el-table-column 
        prop='id' 
        label='ID'
        header-align="center"
        align="center"
        width='50'>
      </el-table-column>

      <!-- 第3列 商品 中文名 -->
      <el-table-column 
        prop='name' 
        label='商品中文名'
        header-align="center"
        align="center" 
        width='100'>
      </el-table-column>

      <!-- 第4列 商品 英文名 -->
      <el-table-column 
        prop='label' 
        label='商品英文名'
        header-align="center"
        align="center" 
        width='100'>
      </el-table-column>

      <!-- 第5列 商品 价格 -->
      <el-table-column 
        prop='price' 
        label='商品价格' 
        header-align="center"
        align="center"
        width='90'>
      </el-table-column>

      <!-- 第6列 商品 市场价 -->
      <el-table-column 
        prop='priceMarket' 
        label='商品市场价'
        header-align="center"
        align="center" 
        width='100'>
      </el-table-column>

      <!-- 第7列 商品对应的分类id-->
      <el-table-column 
        prop='categoryId'  
        label='分类id' 
        header-align="center"
        align="center"
        width='70'> 
      </el-table-column>

      <!-- 第8列 商品默认库存-->
      <el-table-column 
        prop='defaultInventory'  
        label='商品库存'
        header-align="center"
        align="center" 
        width='80'> 
      </el-table-column>

      <!-- 第9列 商品简介-->
      <el-table-column 
        prop='summary'  
        label='商品简介'
        header-align="center"
        align="center"
        width='400'> 
      </el-table-column>

      <!-- 第10列 商品默认图片-->
      <el-table-column 
        prop='defaultImage'  
        label='商品默认图片' 
        width='250'
        header-align="center"
        align="center"> 
      </el-table-column>

      <!-- 第11列 商品状态 0-新建，1-待审核，2-审核通过，3-审核失败，4-上架，5-下架-->
      <el-table-column 
        prop='status' 
        label='商品状态'
        header-align="center"
        align="center" 
        width='100'>
        <template slot-scope="scope">
          <el-tag v-if="scope.row.status === 0" size="small">新建</el-tag>
          <el-tag v-else-if="scope.row.status === 1" size="small">待审核</el-tag>
          <el-tag v-else-if="scope.row.status === 2" size="small">审核通过</el-tag>
          <el-tag v-else-if="scope.row.status === 3" size="small">审核失败</el-tag>
          <el-tag v-else-if="scope.row.status === 4" size="small">上架</el-tag>
          <el-tag v-else size="small">下架</el-tag>
        </template>
      </el-table-column>

      <!-- 第12列 操作 -->
      <el-table-column 
        label='操作'
        header-align="center"
        align="center"
      >
        <template slot-scope='scope'>
          <!-- 编辑 -->
          <el-button  v-if="isAuth('biz:goods:update')"  type='primary' icon='el-icon-edit' size='mini' title='编辑商品' @click='addUpGoods(scope.row, scope.row.id)'>
          </el-button>
          <!-- 删除 -->
          <el-button  v-if="isAuth('biz:goods:delete')"  type='danger' icon='el-icon-delete' size='mini' title='删除商品'  @click='deleteHandle(scope.row.id)'>
          </el-button>
          <!-- 成功按钮 -->
          <!-- <el-button type='success' icon='el-icon-check' plain size='mini' @click='handleCheck(scope.$index, scope.row)'>
          </el-button> -->
        </template>
      </el-table-column>
    </el-table>

    <!-- 第3行 分页 -->
    <div class='block'>
      <el-pagination
      @size-change='handleSizeChange' 
      @current-change='handleCurrentChange' 
      :current-page='pageNumber' 
      :page-sizes='[10, 20, 30, 50, 100]' 
      :page-size='pageSize' 
      :total='totalPage'
      layout='total, sizes, prev, pager, next, jumper' 
      >
      </el-pagination>
    </div>

    <!-- 弹出层: 添加、修改 -->
    <el-dialog 
    :title="addUpForm.id ? '修改商品' : '添加商品'" 
    :visible.sync='addUpDialogFormVisible'>
      <!-- 表格 -->
      <el-form :model='addUpForm' label-width='90px' :rules='addUprules' ref='addUpForm'>
        <div class="addgoods">

          <!-- 第1行 步骤条 -->
          <el-steps :active="active" finish-status="success">
            <el-step title="步骤 1"></el-step>
            <el-step title="步骤 2"></el-step>
            <el-step title="步骤 3"></el-step>
            <el-step title="步骤 4"></el-step>
            <el-step title="步骤 5"></el-step>
          </el-steps>

          <!-- 第2行 tab栏 -->
          <!-- element-ui中的tab栏 一般选用时 都选用第一个实例 -->
          <el-tabs :tab-position="tabPosition" v-model="activeName" @tab-click="handleClick">
            <!-- 基本信息 -->
            <el-tab-pane label="基本信息" name="first">
              <!-- 中文名、英文名 -->
              <el-form-item label="中文名" prop="name">
                <el-input v-model="addUpForm.name" placeholder="中文名"></el-input>
              </el-form-item>

              <!-- 英文名 -->
              <el-form-item label="英文名" prop="label">
                <el-input v-model="addUpForm.label" placeholder="英文名"></el-input>
              </el-form-item>
            </el-tab-pane>

            <!-- 商品参数 -->
            <el-tab-pane label="商品参数" name="second">
              <!-- 价格、市场价、分类id、商品库存、商品状态 -->
              <!-- 商品价格 -->
              <el-form-item label="商品价格" prop="price">
                <el-input v-model="addUpForm.price" placeholder="商品价格"></el-input>
              </el-form-item>

              <!-- 商品市场价 -->
              <el-form-item label="市场价" prop="priceMarket">
                <el-input v-model="addUpForm.priceMarket" placeholder="商品市场价"></el-input>
              </el-form-item>

              <!-- 分类id -->
              <!-- <el-form-item label="分类id" prop="categoryId">
                <el-input v-model="addUpForm.categoryId" placeholder="分类id"></el-input>
              </el-form-item> -->

              <!-- 商品库存 -->
              <el-form-item label="商品库存" prop="defaultInventory">
                <el-input v-model="addUpForm.defaultInventory" placeholder="商品库存"></el-input>
              </el-form-item>

              <!-- 商品状态 -->
              <el-form-item label="商品状态" prop="status">
                <el-input v-model="addUpForm.status" placeholder="商品状态: 0-新建、1-待审核、2-审核通过、3-审核失败、4-上架、5-下架"></el-input>
              </el-form-item>
            </el-tab-pane>

            <!-- 商品属性 -->
            <el-tab-pane label="商品属性" name="third">
              <div class='addAttribute'>
                <!-- 编辑 -->
                <el-button type='primary' icon='el-icon-circle-plus-outline' size='small' title='添加属性' @click='addAttrHandle(addUpForm)'>
                属性
                </el-button>
              </div>

               <!-- 属性、属性值 选择 -->
              <div v-for='item in dynamic' :key='item.id'>
                <el-cascader
                  :options="optionsWithDisabled"
                  @change = "change"
                  @focus = "focus"
                  @blur = "blur"
                ></el-cascader>
                <!-- 选择属性 -->
                <!-- <el-select v-model="value1" clearable placeholder="请选择">
                  <el-option
                    v-for="item in attrList"
                    :key="item.id"
                    :label="item.label"
                    :value="item.name"
                    :disabled="item.disabled">
                  </el-option>
                </el-select> -->

                <!-- 选择属性值 -->
                <!-- <el-select v-model="value2" clearable multiple placeholder="请选择">
                  <el-option
                    v-for="item in attrValueList"
                    :key="item.value"
                    :value="item"
                    :label="item.label"
                    :disabled="item.disabled">
                  </el-option>
                </el-select> -->
              </div>
              <!-- 选择的: -->
              <div class='zonghe' v-if='selecedValue'>
                您所选择的属性是: <span>{{selecedValue}}</span>
              </div>
            </el-tab-pane>

            <!-- 商品图片 -->
            <el-tab-pane label="商品图片" name="fourth">
              <!-- element-ui中的 Upload 上传 - 图片列表缩略图 -->
              <!-- action是后台给的 -->
              <el-upload
                action="http://192.168.1.152:8090/renren-fast/app/imgUpload"
                :on-preview="handlePreview"
                :on-remove="handleRemove"
                :on-success="handleSuccess"
                list-type="picture">
                <el-button size="small" type="primary">点击上传</el-button>
                <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
              </el-upload>
            </el-tab-pane>

            <!-- 商品简介 -->
            <el-tab-pane label="商品简介" name="fivth">
              <!-- 简介 -->
              <el-form-item label="商品简介" prop="summary">
                <el-input type="textarea" :rows="15" v-model="addUpForm.summary" placeholder="商品简介"></el-input>
              </el-form-item>
            </el-tab-pane>
          </el-tabs>
        </div>
      </el-form>

      <!-- 综合选择 -->
      <!-- <div class='zonghe'>
        您所选择的属性是: <span>{{collSelected}}</span>
      </div> -->

      <!-- 确认、取消 -->
      <div slot='footer' class='dialog-footer'>
        <el-button @click='addUpDialogFormVisible = false'>取 消</el-button>
        <el-button type='primary' @click="addGoodSubmit()">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data () {
    return {
      // 添加商品输入框的值
      dataForm: {
        goodName: null
      },
      // 弹出层: 添加、修改商品 -- 初始状态
      addUpDialogFormVisible: false,
      // 弹出层数据来源
      addUpForm: {
        id: null,
        name: '', // 中文名
        label: '', // 英文名
        price: null, // 价格
        priceMarket: null, // 市场价
        categoryId: null,  // 分类 id
        defaultInventory: null, // 商品库存
        summary: '', // 商品简介
        defaultImage: '', // 默认图片
        status: null // 状态
      },
      // 校验
      addUprules: {
        name: [
          { required: true, message: '中文名不能为空', trigger: 'blur' }
        ],
        label: [
          { required: true, message: '英文名不能为空', trigger: 'blur' }
        ],
        price: [
          { required: true, message: '价格不能为空', trigger: 'blur' }
        ],
        priceMarket: [
          { required: true, message: '市场价不能为空', trigger: 'blur' }
        ],
        categoryId: [
          { required: true, message: '分类id不能为空', trigger: 'blur' }
        ],
        defaultInventory: [
          { required: true, message: '默认库存不能为空', trigger: 'blur' }
        ],
        status: [
          { required: true, message: '默认库存不能为空', trigger: 'blur' }
        ]
      },
      // 表格
      goodList: [],
      // 加载动画的初始状态
      loading: false,
      // 第4行 分页
      // 当前页
      pageNumber: 1,
      // 每页条数
      pageSize: 20,
      // 总条数
      totalPage: 0,
      // 批量删除时选中的
      dataListSelections: [],
      // 表单验证
      rules: {
        goods_name: [
          { required: true, message: '请输入商品名称', trigger: 'blur' }
        ],
        goods_price: [
          { required: true, message: '请输入商品价格', trigger: 'blur' }
        ],
        goods_number: [
          { required: true, message: '请输入商品数量', trigger: 'blur' }
        ],
        goods_weight: [
          { required: true, message: '请输入商品重量', trigger: 'blur' }
        ]
      },
      // 添加、修改弹出层
      // 步骤条
      active: 0,
      // tab栏的位置
      tabPosition: 'left',
      activeName: 'first',
      // 动态添加属性
      // 属性
      dynamic: [], // 下拉框次数
      attrList: [], // 数据
      value1: '', // 选择
      // 属性值
      attrValueList: [], // 下拉数据
      value2: '', // 选择
      // 获取属性 参数
      attDataForm: {
        pageNumber: null,
        pageSize: null,
        name: null
      },
      // 级联选择器 数据
      optionsWithDisabled: [],
      selecedValue: '' // 选中的属性值
    }
  },
  mounted () {
    this.initList()
  },
  methods: {
    // 获取商品列表
    initList () {
      // 1. 获取数据前 开启动画
      // this.loading = true
      // 2. 如果是查询 数字、字符串
      // 分类id
      var reg = /^[0-9]*$/
      if (reg.test(this.dataForm.goodName)) {
        this.dataForm.category = this.dataForm.goodName
        this.dataForm.goodName = ''
      } else {
        this.dataForm.category = null
      }

      // 3. 请求: 获取商品列表
      this.$http({
        url: this.$http.adornUrl('/product/list'),
        method: 'get',
        params: this.$http.adornParams({
          'page': this.pageNumber,
          'limit': this.pageSize,
          'name': this.dataForm.goodName, // 搜索商品名称的信息
          'category': this.dataForm.category // 根据分类进行商品信息查询
        })
      }).then(({data}) => {
        if (data && data.code === 0) {
          console.log('获取商品列表', data)
          // 处理接收的数据
          // this.tableDatas = {}
          this.proArr = []
          this.shuxing = []
          data.data.list.map((item, index, arr) => {
            // this.tableDatas = {}
            for (var k in item) {
              if (k === 'pro') {
                // console.log(item, '这一项')
                this.proArr.push(item.pro)
                // if (!item.pfb || item.pfb.length === 0) {
                //   this.tableDatas.pfbid = null
                //   this.tableDatas.pfbname = null
                //   this.tableDatas.pfblabel = null
                //   this.tableDatas.pfbproductpropertyId = null
                //   this.tableDatas.pfbpropertyvalueId = null
                //   this.tableDatas.pfbpropertyValue = null
                // } else { [{},{}]
                //   for(var i = 0; i < item.pfb.length; i++) {
                //   }
                //   // this.tableDatas.pfbid = item.pfb.id || null
                //   // this.tableDatas.pfbname = item.pfb.name || null
                //   // this.tableDatas.pfblabel = item.pfb.label || null
                //   // this.tableDatas.pfbproductpropertyId = item.pfb.productpropertyId || null
                //   // this.tableDatas.pfbpropertyvalueId = item.pfb.propertyvalueId || null
                //   // this.tableDatas.pfbpropertyValue = item.pfb.propertyValue || null
                //   }
              } else {
                this.shuxing.push(item.pfb)
              }
            }
          })
          // console.log(this.proArr, 111)
          this.goodList = this.proArr
          // console.log(this.goodList, '列表')
          this.pageNumber = data.data.currPage
          this.pageSize = data.data.pageSize
          this.totalPage = data.data.totalCount
        } else {
          console.log(data.msg)
          this.goodList = []
          this.totalPage = 0
        }
        // 关闭加载中
        this.loading = false
      })
    },

    // 弹窗: 添加、修改
    addUpGoods (row, id) {
      this.addUpForm.row = row || null
      this.addUpForm.id = id || null
      // 开启弹窗
      this.addUpDialogFormVisible = true
      // 修改
      if (this.addUpForm.id) {
        this.addUpForm = row
        // 请求: 获取商品详情
        // var sta = row.status === 0 ? '新建' : (row.status === 1 ? '待审核' : (row.status === 2 ? '审核通过' : (row.status === 3 ? '审核失败' : (row.status === 4 ? '上架' : '下架'))))
        // this.$http({
        //   url: this.$http.adornUrl(`/product/${sta}/${this.addUpForm.id}`),
        //   method: 'get',
        //   params: this.$http.adornParams()
        // }).then(({data}) => {
        //   if (data && data.code === 0) {
        //     console.log(135, data)
        //     // 修改
        //     // this.dataForm.id = data.merchant.id
        //     // this.dataForm.name = data.merchant.name
        //     // this.dataForm.label = data.merchant.label
        //     // this.dataForm.email = data.merchant.email
        //     // this.dataForm.mobile = data.merchant.mobile
        //     // this.dataForm.address = data.merchant.address
        //     // this.dataForm.status = data.merchant.status
        //   } else {
        //     console.log('获取商品详情', data.msg)
        //   }
        // }).catch((e) => {
        //   console.log(e)
        // })
      } else {  // 新增
        // 初始化
        this.addUpForm = {
          id: null,
          name: '', // 中文名
          label: '', // 英文名
          price: null, // 价格
          priceMarket: null, // 市场价
          categoryId: null,  // 分类 id
          defaultInventory: null, // 商品库存
          summary: '', // 商品简介
          defaultImage: '', // 默认图片
          status: null // 状态
        }
        // 获取属性、属性值
        // this.$http({
        //   url: this.$http.adornUrl('/property/list'),
        //   method: 'get',
        //   params: this.$http.adornParams({
        //     'page': this.attDataForm.pageNumber,
        //     'limit': this.attDataForm.pageSize,
        //     'name': this.attDataForm.name // 属性名
        //   })
        // }).then(({data}) => {
        //   if (data && data.code === 0) {
        //     console.log('获取属性列表', data)
        //     // 渲染表格数据
        //     this.attrList = data.page.list
        //   }
        // })
      }
    },

    // 点击: 添加属性
    addAttrHandle (res) {
      // 1. 动态添加 一个 属性下拉框
      if (this.dynamic.length < this.optionsWithDisabled.length) {
        this.dynamic.push({'selected': 1})
      }

      // 2. 展示属性
      // (1) 添加--获取所有的属性
      if (!this.addUpForm.id) {
        this.$http({
          url: this.$http.adornUrl('/property/list'),
          method: 'get',
          params: this.$http.adornParams({
            'page': this.attDataForm.pageNumber,
            'limit': this.attDataForm.pageSize,
            'name': this.attDataForm.name // 属性名
          })
        }).then(({data}) => {
          if (data && data.code === 0) {
            // 处理数据
            var arr1 = []
            data.page.list.map((item, index, arr) => {
              var obj = {}
              // obj.id = item.id
              obj.value = item.id
              obj.label = item.label
              if (this.selatt) {
                if (item.id === this.selatt[0]) {
                  obj.disabled = true
                }
              }

              obj.children = [{
                value: item.propertyvalueId,
                label: item.propertyValue
              }]
              arr1.push(obj)
            })
            this.optionsWithDisabled = arr1
          }
        })
      } else {
        // (2) 修改
        // 显示该商品的所有属性

        // 添加其他的属性
      }

      // 1. 请求: 获取下拉框数据: 属性、属性值
      // this.$http({
      //   url: this.$http.adornUrl('/property/list'),
      //   method: 'get',
      //   params: this.$http.adornParams({
      //     'page': this.attDataForm.pageNumber,
      //     'limit': this.attDataForm.pageSize,
      //     'name': this.attDataForm.name // 属性名
      //   })
      // }).then(({data}) => {
      //   if (data && data.code === 0) {
      //     console.log('添加商品时 获取属性列表', data)
      //     var Arr = []
      //     data.page.list.map((item, index, arr) => {
      //       Arr.push(item.label)
      //     })
      //     // 下拉框: 属性数据
      //     this.attrList = Arr
      //   } else {
      //     this.attrList = []
      //   }
      //   // 关闭加载中
      //   this.dataListLoading = false
      // })
    },

    change (res) {
      // console.log(res, 'chanage')
      this.selatt = res
    },

    focus (e) {
      // this.selecedValue += e.target.defaultValue
    },

    blur (e) {
      this.selecedValue += e.target.defaultValue + ' '
    },

    // 弹窗提交
    addGoodSubmit () {
      this.$refs['addUpForm'].validate((valid) => {
        if (valid) {
          this.obj = {}
          this.obj.pro = this.addUpForm
          this.obj.pfb = [
            {
              'id': null,
              'name': '',
              'label': '',
              'propertyValue': '',
              'propertyvalueId': null,
              'productpropertyId': null
            }
          ]
          console.log(this.obj, '123')
          // 增加、修改
          this.$http({
            url: this.$http.adornUrl(`/product/${!this.addUpForm.id ? 'add' : 'update'}`),
            method: 'post',
            data: this.$http.adornData(this.obj)
          }).then(({data}) => {
            console.log(data)
            if (data && data.code === 0) {
              this.$message({
                message: '操作成功',
                type: 'success',
                duration: 1500,
                onClose: () => {
                  this.addUpDialogFormVisible = false
                  // 刷新商品列表
                  this.initList()
                }
              })
            } else {
              this.$message.error(data.msg)
            }
          })
        }
      })
    },

    // 删除商品
    deleteHandle (id) {
      // 单个、批量
      var ids = id ? [id] : this.dataListSelections.map(item => {
        return item.id
      })
      // 对话框
      this.$confirm(`确定对[id=${ids}]进行[${id ? '删除' : '批量删除'}]操作?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {  // 确定删除
        // 请求删除接口
        // post类似删除
        this.$http({
          url: this.$http.adornUrl('/product/delete'),
          method: 'delete',
          data: this.$http.adornData({
            'ids': ids
          })
        }).then(({data}) => {
          // console.log('-------删除--------', data)
          if (data.code === 0 && data.msg === 'success') {
            this.initList()
          }
        }).catch((e) => {
          console.log(e)
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },

    // 第4行 分页
    // 每页多少条 变化时
    handleSizeChange (val) {
      this.pageSize = val
      this.initList()
    },

    // 页码改变时
    handleCurrentChange (val) {
      this.pageNumber = val
      this.initList()
    },

    // 多选
    selectionChangeHandle (val) {
      this.dataListSelections = val
      console.log(val)
    },

    // 下拉框: 属性 改变
    getAttr (res) {
      // console.log(res, 18)
      // // 1. 获取当前 属性的 id 和 attr值
      // this.attrId = res.id

      // // 2. 修改当前选择的下拉框的 值
      // this.dynamic[this.dynamic.length - 1].attrSelected = res.attr

      // // 3. 修改下拉框: 属性值的显示状态
      // // this.attrValVisib = false
      // this.dynamic.attrValVisib = false

      // // 4. 修改下拉框： 属性值的初始值
      // this.dynamic[this.dynamic.length - 1].attrValSelected = '请选择'

      // // 2. 请求: 获取属性下拉框数据  参数: 属性 id
      // // console.log(this.attrId)
      // if (this.attrId === 1) {
      //   this.attrValList = ['红', '黄', '蓝']
      // } else if (this.attrId === 2) {
      //   this.attrValList = ['小', '中', '大']
      // } else {
      //   this.attrValList = ['1m', '2m', '3m']
      // }
    },

    // 点击: 添加属性值
    addAttrValHandle (res) {
      // 1. 显示 下拉框: 属性值
      // this.attrValVisib = true
      // this.dynamic[this.dynamic.length - 1].attrValVisib = true
      // 2. 请求: 获取属性下拉框数据  参数: 属性 id
      // console.log(this.attrId)
      // if (this.attrId === 1) {
      //   this.attrValList = ['红', '黄', '蓝']
      // } else if (this.attrId === 2) {
      //   this.attrValList = ['小', '中', '大']
      // } else {
      //   this.attrValList = ['1m', '2m', '3m']
      // }
    },

    // 属性值 下拉框
    getAttrVal (res) {
      // 选择的属性值 -- 当前的属性
      // console.log(this.dynamic[this.dynamic.length - 1], 'mm')
      // this.dynamicValue[this.dynamic.length - 1].push({'attrValSelected': res})
      // this.dynamic[this.dynamic.length - 1].attrValSelected = res
      // this.attrValSelected = res
      // this.dynamic[this.dynamic.length - 1].attrValSelected = res
      // console.log(res, '重新修改后')

      // this.dynamicValue.push(res)
    },

    handleClick (tab, event) {
      // console.log(tab, event)
      // 判断当前点击的是第几个tab, 让对应的进度条显示
      switch (tab.name) {
        case 'first':
          this.active = 0
          break
        case 'second':
          this.active = 1
          break
        case 'third':
          this.active = 2
          break
        case 'fourth':
          this.active = 3
          break
        default:
          this.active = 4
      }
    },

    // 删除图片的函数
    // 点击图片时
    handleRemove (file, fileList) {
      // console.log(file, fileList)
    },

    // 删除图片时
    handlePreview (file) {
      // console.log(file)
    },

    // 设置上传的请求头 需要带上token
    // setHeaders () {
    //   // 取出token
    //   let token = localStorage.getItem('mytoken')
    //   if (token) {
    //     return {
    //       Authorization: token
    //     }
    //   }
    // },
    // 上传成功的函数
    handleSuccess (response, file, fileList) {
      // console.log(response)
      // console.log(file)
      // console.log(fileList)
      if (response.meta.status === 200) {
        this.$message({
          type: 'success',
          message: response.meta.msg
        })
      }
    }
  }
}
</script>

<style lang='scss' scoped>
  .goods {
    .el-row {
      margin-bottom: 20px;
    }

    // 第2行 输入框和按钮
    .input-search {
      width: 300px;
      margin-right: 12px;
    }

    // 第4行 分页
    .block {
      background: #d1dae5;
      margin-top: 20px;
      .el-pagination {
        padding: 10px;
      }
    }
    // 下拉框
    .zonghe {
      font-size: 16px;
      span {
        color: red
      }
    }
    // + 属性
    .el-form-item.addAttribute {
      margin-bottom: 10px;
    }
    // 添加、修改弹出层
    .addgoods {
      .el-row {
        margin-bottom: 10px;
      }
      .infomation {
        background: #D5E0ED;
        padding: 10px;
        margin-bottom: 50px;
      }
      // 添加属性按钮 所在box
      .addAttribute {
        margin-bottom: 25px;
      }
      // 下拉框
      .el-dropdown {
        margin-bottom: 25px!important;
      }
      // 按钮: 添加属性值
      .el-button--small.addval {
        margin: 0 20px;
      }
      // select下拉框
      .el-select {
        margin: 0 20px 20px 0;
      }
    }
  }
</style>
