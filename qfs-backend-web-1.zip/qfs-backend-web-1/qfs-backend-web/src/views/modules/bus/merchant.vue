<template>
  <div class="mod-user">
    <!-- 用户名 -->
    <el-form :inline="true" :model="dataForm" @keyup.enter.native="getDataList()">
      <el-form-item>
        <el-input v-model="dataForm.merName" placeholder="用户名" clearable></el-input>
      </el-form-item>
      
      <!-- 查询 -->
      <el-form-item>
        <el-button v-if="isAuth('biz:merchant:list')" @click="getDataList()" @keydown.native.enter="getDataList()">查询</el-button>
        <el-button v-if="isAuth('biz:merchant:save')" type="primary" @click="addOrUpdateHandle()">新增</el-button>
        <el-button v-if="isAuth('biz:merchant:delete')" type="danger" @click="deleteHandle()" :disabled="dataListSelections.length <= 0">批量删除</el-button>
      </el-form-item>
    </el-form>
    <!-- 表格 -->
    <!-- 商家: selection-change: 当选择项发生变化时会触发该事件 -->
    <el-table
      :data="dataList"
      border
      v-loading="dataListLoading"
      @selection-change="selectionChangeHandle"
      style="width: 100%;">
      <!-- 多选框 -->
      <el-table-column
        type="selection"
        header-align="center"
        align="center"
        width="50">
      </el-table-column>

      <!-- 商家 id -->
      <el-table-column
        prop="id"
        header-align="center"
        align="center"
        width="80"
        label="ID">
      </el-table-column>

      <!-- 商家 中文名 -->
      <el-table-column
        prop="name"
        header-align="center"
        align="center"
        label="中文名">
      </el-table-column>

      <!-- 商家 英文名 -->
      <el-table-column
        prop="label"
        header-align="center"
        align="center"
        label="英文名">
      </el-table-column>

      <!-- 商家 邮箱 -->
      <el-table-column
        prop="email"
        header-align="center"
        align="center"
        label="邮箱">
      </el-table-column>

      <!-- 商家 手机号 -->
      <el-table-column
        prop="mobile"
        header-align="center"
        align="center"
        label="手机号">
      </el-table-column>

      <!-- 商家 地址 -->
      <el-table-column
        prop="address"
        header-align="center"
        align="center"
        label="地址">
      </el-table-column>

      <!-- 商家 状态 -->
      <el-table-column
        prop="status"
        header-align="center"
        align="center"
        label="状态">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.status === 1" size="small" type="danger">禁用</el-tag>
          <el-tag v-else size="small">正常</el-tag>
        </template>
      </el-table-column>

      <!-- 操作 -->
      <el-table-column
        fixed="right"
        header-align="center"
        align="center"
        width="150"
        label="操作">
        <template slot-scope="scope">
          <!-- 编辑 -->
          <el-button v-if="isAuth('biz:merchant:update')" type="primary" icon="el-icon-edit" size="small" @click="addOrUpdateHandle(scope.row.id)"></el-button>
          <!-- 删除 -->
          <el-button v-if="isAuth('biz:merchant:delete')" type="danger" icon="el-icon-delete" size="small" @click="deleteHandle(scope.row.id)"></el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <div class="block">
      <el-pagination
        @size-change="sizeChangeHandle"
        @current-change="currentChangeHandle"
        :current-page="pageNumber"
        :page-sizes="[5, 10, 15, 20]"
        :page-size="pageSize"
        :total="totalPage"
        layout="total, sizes, prev, pager, next, jumper">
      </el-pagination>
    </div>
    
    <!-- 弹窗, 新增 / 修改 -->
    <AddOrUpdate v-if="addOrUpdateVisible" ref="addOrUpdate" @refreshDataList="getDataList"></AddOrUpdate>
  </div>
</template>

<script>
  import AddOrUpdate from './merchant-add-or-update'
  export default {
    data () {
      return {
        // 商家名
        dataForm: {
          merName: ''
        },
        // 商家数据
        dataList: [],
        // 当前页
        pageNumber: 1,
        // 每页条数
        pageSize: 10,
        // 总页数
        totalPage: 0,
        // 表格数据加载状态
        dataListLoading: false,
        // 批量删除时选中的
        dataListSelections: [],
        // 添加商家 弹窗
        addOrUpdateVisible: false
      }
    },
    components: {
      AddOrUpdate
    },
    activated () {
      this.getDataList()
    },
    methods: {
      // 获取商家列表
      getDataList () {
        // 开启加载中
        this.dataListLoading = true
        // 请求数据
        this.$http({
          url: this.$http.adornUrl('/merchant/list'),
          method: 'get',
          params: this.$http.adornParams({
            'page': this.pageNumber,
            'limit': this.pageSize,
            'name': this.dataForm.merName
          })
        }).then(({data}) => {
          // console.log('商家列表', data)
          if (data && data.code === 0) {
            console.log('获取商家列表', data)
            this.dataList = data.page.list
            this.pageNumber = data.page.currPage
            this.pageSize = data.page.pageSize
            this.totalPage = data.page.totalCount
          } else {
            this.dataList = []
            this.totalPage = 0
          }
          // 关闭加载中
          this.dataListLoading = false
        })
      },
      // 每页数
      sizeChangeHandle (val) {
        this.pageSize = val
        this.pageNumber = 1
        this.getDataList()
      },
      // 当前页
      currentChangeHandle (val) {
        this.pageNumber = val
        this.getDataList()
      },
      // 多选
      selectionChangeHandle (val) {
        this.dataListSelections = val
      },
      // 新增 / 修改
      addOrUpdateHandle (id) {
        this.addOrUpdateVisible = true
        this.$nextTick(() => {  // 当dom发生变化，更新后执行的回调。
          this.$refs.addOrUpdate.init(id)
        })
      },
      // 删除
      deleteHandle (id) {
        // 单个、批量
        var ids = id ? [id] : this.dataListSelections.map(item => {
          return item.id
        })
        // 对话框
        this.$confirm(`确定对[id=${ids}]进行[${id ? '删除' : '批量删除'}]操作?`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {  // 确定删除
          // 请求删除接口
          // post类似删除
          this.$http({
            url: this.$http.adornUrl('/merchant/delete'),
            method: 'delete',
            data: this.$http.adornData({
              'ids': ids
            })
          }).then(({data}) => {
            // console.log('-------删除--------', data)
            if (data.code === 0 && data.msg === 'success') {
              this.getDataList()
            }
          }).catch((e) => {
            console.log(e)
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
 .block {
    background: #d1dae5;
    margin-top: 20px;
    .el-pagination {
      padding: 10px;
    }
  }
</style>
