<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
      <!-- 中文名 -->
      <el-form-item label="中文名" prop="name">
        <el-input v-model="dataForm.name" placeholder="中文名"></el-input>
      </el-form-item>

      <!-- 英文名 -->
      <el-form-item label="英文名" prop="label">
        <el-input v-model="dataForm.label" placeholder="英文名"></el-input>
      </el-form-item>
      
      <!-- 邮箱 -->
      <el-form-item label="邮箱" prop="email">
        <el-input v-model="dataForm.email" placeholder="邮箱"></el-input>
      </el-form-item>

      <!-- 手机 -->
      <el-form-item label="手机号" prop="mobile">
        <el-input v-model="dataForm.mobile" placeholder="手机号"></el-input>
      </el-form-item>

      <!-- 地址 -->
      <el-form-item label="地址" prop="address">
        <el-input v-model="dataForm.address" placeholder="地址"></el-input>
      </el-form-item>

      <!-- 状态 0-生效  1-失效 -->
      <el-form-item label="状态" size="mini" prop="status">
        <el-radio-group v-model="dataForm.status">
          <el-radio :label="0">正常</el-radio>
          <el-radio :label="1">禁用</el-radio>
        </el-radio-group>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  import { isEmail, isMobile } from '@/utils/validate'
  export default {
    data () {
      var validateEmail = (rule, value, callback) => {
        if (!isEmail(value)) {
          callback(new Error('邮箱格式错误'))
        } else {
          callback()
        }
      }
      var validateMobile = (rule, value, callback) => {
        if (!isMobile(value)) {
          callback(new Error('手机号格式错误'))
        } else {
          callback()
        }
      }
      return {
        visible: false,
        dataForm: {
          id: 0,
          name: '',
          label: '',
          email: '',
          mobile: '',
          address: '',
          status: 0
        },
        dataRule: {
          name: [
            { required: true, message: '中文名不能为空', trigger: 'blur' }
          ],
          label: [
            { required: true, message: '英文名不能为空', trigger: 'blur' }
          ],
          email: [
            { required: true, message: '邮箱不能为空', trigger: 'blur' },
            { validator: validateEmail, trigger: 'blur' }
          ],
          mobile: [
            { required: true, message: '手机号不能为空', trigger: 'blur' },
            { validator: validateMobile, trigger: 'blur' }
          ],
          address: [
            { required: true, message: '地址不能为空', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      // 从商家页面传入
      init (id) {
        this.dataForm.id = id || 0
        // 打开弹窗
        this.visible = true
        // 请求: 获取商家信息
        // 修改
        if (this.dataForm.id) {
          this.$http({
            url: this.$http.adornUrl(`/merchant/${this.dataForm.id}`),
            method: 'get',
            params: this.$http.adornParams()
          }).then(({data}) => {
            if (data && data.code === 0) {
              // 修改
              // this.dataForm.id = data.merchant.id
              this.dataForm.name = data.merchant.name
              this.dataForm.label = data.merchant.label
              this.dataForm.email = data.merchant.email
              this.dataForm.mobile = data.merchant.mobile
              this.dataForm.address = data.merchant.address
              this.dataForm.status = data.merchant.status
            } else {
              console.log('增加/修改商家失败', data.msg)
            }
          }).catch((e) => {
            console.log(e)
          })
        } else {  // 新增
          this.dataForm = {
            id: 0,
            name: '',
            label: '',
            email: '',
            mobile: '',
            address: '',
            status: 0
          }
        }
      },
      // 表单提交 确定
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            // 增加、修改
            this.$http({
              url: this.$http.adornUrl(`/merchant/${!this.dataForm.id ? 'add' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'id': this.dataForm.id || undefined,
                'name': this.dataForm.name,
                'label': this.dataForm.label,
                'email': this.dataForm.email,
                'mobile': this.dataForm.mobile,
                'address': this.dataForm.address,
                'status': this.dataForm.status
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
