<template>
  <div class="test">
    <div class="area">
      <area-select
      :level='2' 
      type='text'
      placeholder="请选择地区"
      v-model='selected'
      :data="pcaa">
      </area-select>
      <!-- 选择的数据是 -->
      <el-row>
        <el-col :span="24" style="height: 50px; line-height: 50px; font-size: 16px; padding-left: 10px; margin-top: 20px;">
          <div class="selectData">
            选择的数据是：
            {{selected.length > 0 ? selected: ''}}
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
import { pca, pcaa } from 'area-data'
export default {
  data () {
    return {
      selected: [],
      pca: pca,
      pcaa: pcaa
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
