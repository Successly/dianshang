<template>
  <div class="custom-tree-container">
    <div class="block">
      <!-- 自定义树节点 -->
      <!-- 添加 一级新节点 -->
      <el-button
        type="success"
        icon="el-icon-circle-plus-outline"
        size="small"
        class="level"
        round
        @click="() => appendParent(data1)">
        一级节点
      </el-button>

      <el-tree
        :data="data1"
        show-checkbox
        node-key="id"
        default-expand-all
        draggable
        :expand-on-click-node="false">
        <span class="custom-tree-node" slot-scope="{ node, data }">
          <!-- 级别 标题 -->
          <span class="item1">{{ node.label }}</span>
          <!-- 操作 -->
          <span class="item2">
            <!-- 修改名 -->
            <el-button
              type="primary" 
              icon="el-icon-edit"
              size="mini"
              @click="() => editor(node, data)">
            </el-button>
            <!-- 删除节点 -->
            <el-button
              type="danger" 
              icon="el-icon-delete"
              size="mini"
              @click="() => remove(node, data)">
              <!-- 删除该节点 -->
            </el-button>
            <!-- 添加 子节点 -->
            <el-button
              type="warning" 
              icon="el-icon-circle-plus-outline"
              size="mini"
              @click="() => appendChild(data)">
              <!-- 添加子节点 -->
            </el-button>
          </span>
        </span>
      </el-tree>
    </div>
  </div>
</template>

<script>
  let id = 1000

  export default {
    data () {
      const data = [{
        id: 1,
        label: '一级 1',
        children: [{
          id: 4,
          label: '二级 1-1',
          children: [{
            id: 9,
            label: '三级 1-1-1'
          }, {
            id: 10,
            label: '三级 1-1-2'
          }]
        }]
      }, {
        id: 2,
        label: '一级 2',
        children: [{
          id: 5,
          label: '二级 2-1'
        }, {
          id: 6,
          label: '二级 2-2'
        }]
      }, {
        id: 3,
        label: '一级 3',
        children: [{
          id: 7,
          label: '二级 3-1'
        }, {
          id: 8,
          label: '二级 3-2'
        }]
      }]
      return {
        data1: JSON.parse(JSON.stringify(data)),
        m: null
      }
    },
    mounted () {
      // console.log(this.data)
    },
    methods: {
      // 添加 子节点
      appendChild (data) {
        this.$prompt('请输入节点名', '添加 子节点', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          inputPattern: /^[\s\S]*.*[^\s][\s\S]*$/,
          inputErrorMessage: '节点名不能为空'
        }).then(({ value }) => {
          // 点击确认的处理
          // -------------发送请求------------
          // -----------成功后的处理-----------
          // 1. 提示
          this.$message({
            type: 'success',
            message: '添加节点成功'
          })
          // 将 子节点 追加到 父节点
          const newChild = { id: id++, label: value, children: [] }
          if (!data.children) {
            this.$set(data, 'children', [])
          }
          data.children.push(newChild)
        }).catch(() => {
          // 点击取消的处理
          this.$message({
            type: 'info',
            message: '取消输入'
          })
        })
      },
      // 删除节点
      remove (node, data) {
        // -------------发送请求------------
        // -----------成功后的处理-----------
        // node指： 当前节点的 Node 对象
        // data指： 当前节点的数据
        const parent = node.parent
        const children = parent.data.children || parent.data
        const index = children.findIndex(d => d.id === data.id)
        children.splice(index, 1)
      },
      // 添加 新 一级节点
      appendParent (data) {
        this.$prompt('请输入节点名', '添加 一级节点', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          inputPattern: /^[\s\S]*.*[^\s][\s\S]*$/,
          inputErrorMessage: '节点名不能为空'
        }).then(({ value }) => {
          // 点击确认的处理
          // -------------发送请求------------
          // -----------成功后的处理-----------
          // 1. 提示
          this.$message({
            type: 'success',
            message: '添加节点成功'
          })
          // 将 新节点 追加到 data
          const newNode = { id: id++, label: value, children: [] }
          data.push(newNode)
          console.log('----------', data)
        }).catch(() => {
          // 点击取消的处理
          this.$message({
            type: 'info',
            message: '取消输入'
          })
        })
      },
      // 修改节点名
      editor (node, data) {
        this.$prompt('请输入节点名', '节点重命名', {
          confirmButtonText: '确定',  // 确定按钮的文本内容
          cancelButtonText: '取消',   // 取消按钮的文本内容
          inputValue: node.data.label,  // 输入框的初始文本
          inputPattern: /^[\s\S]*.*[^\s][\s\S]*$/, // 输入框的校验表达式
          inputErrorMessage: '节点名不能为空' // 校验未通过时的提示文本
        }).then(({ value }) => {
          // 点击确认的处理
          // -------------发送请求------------
          // -----------成功后的处理-----------
          // 1. 提示
          this.$message({
            type: 'success',
            message: '节点重命名成功'
          })
          // 重命名
          node.data.label = value
        }).catch(() => {
          // 点击取消的处理
          this.$message({
            type: 'info',
            message: '取消输入'
          })
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .custom-tree-node {
    flex-basis: 380px;
    display: flex;
    align-items: center;
    // justify-content: center;
    font-size: 14px;
    padding-right: 8px;
    margin-bottom: 10px;
    .item1 {
      flex-basis: 180px;
    }
  }
</style>