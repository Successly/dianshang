<template>
  <el-dialog
    title="账单信息"
    fullscreen="true"
    :close-on-click-modal="false"
    :visible.sync="visible">
    <div class="block">
      <div class="reconcilitionInfo">
        <el-row>
          <el-col class="headBlock" :span="24">
            <el-button type="text" icon="el-icon-tickets">对账单信息</el-button>
          </el-col>
          <el-col :span="24">
            <div class="headInfo">
              <div class="infoBlock reconcilitionTime" style="margin-right: 2rem;">
                <div class="infoTitle">对账周期</div>
                <div class="infoContent">{{billPeriod}}</div>
              </div>
              <div class="infoBlock reconcilitionState">
                <div class="infoTitle">对账状态</div>
                <div class="infoContent">{{billStatus}}</div>
              </div>
            </div>
          </el-col>
        </el-row>
      </div>

      <div class="storeInfo">
        <el-row>
          <el-col class="headBlock" :span="24">
            <el-button type="text" icon="el-icon-tickets">储值信息</el-button>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-table
              :data="receivablesInfoList"
              border
              stripe
              style="width: 100%">
              <el-table-column
                prop="account"
                label="储值用户"
                align="center"
                width="300">
              </el-table-column>
              <el-table-column
                prop="time"
                label="储值时间"
                align="center">
              </el-table-column>
              <el-table-column
                prop="money"
                label="储值金额"
                align="center"
                width="150">
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>
      </div>
      <el-row>
        <el-col class="headBlock" :span="24">
          <el-button type="text" icon="el-icon-tickets">订单信息</el-button>
        </el-col>
      </el-row>
      <div class="search_result">
        <el-table
          :data="reconciliationDetailListData"
          border
          stripe
          :v-loading="dataListLoading"
          style="width: 100%">
          <el-table-column
            prop="orderNo"
            label="订单号"
            align="center"
            width="300">
          </el-table-column>
          <el-table-column
            prop="hotelName"
            label="酒店"
            align="center">
          </el-table-column>
          <el-table-column
            prop="roomTypeName"
            label="房型"
            align="center"
            width="150">
          </el-table-column>
          <el-table-column
            prop="orderTime"
            label="下单时间"
            align="center"
            width="150">
          </el-table-column>
          <el-table-column
            prop="period"
            label="入离时间"
            align="center"
            width="80">
            <template slot-scope="scope">
              <div>
                {{scope.row.period.startTime}} - {{scope.row.period.endTime}}<br/>
                共{{scope.row.period.duration}}小时
              </div>
            </template>
          </el-table-column>
          <el-table-column
            prop="priceInfo"
            label="价格"
            align="center">
            <template slot-scope="scope">
              <div>
                订单价￥{{scope.row.priceInfo.roomFee}}
              </div>
              <div>
                支付价￥{{scope.row.priceInfo.payAmount}}
              </div>
            </template>
          </el-table-column>
          <el-table-column
            prop="name"
            label="客人姓名"
            align="center">
          </el-table-column>
          <el-table-column
            prop="mobile"
            label="联系方式"
            align="center">
          </el-table-column>
          <el-table-column
            prop="memberDiscount"
            label="折扣"
            align="center">
          </el-table-column>
          <el-table-column
            prop="status"
            label="状态"
            align="center">
            <template slot-scope="scope">
              <div v-if="scope.row.status == '0'">
                待确认
              </div>
              <div v-else-if="scope.row.status == '1'">
                已确认
              </div>
              <div v-else>
                已打款
              </div>
            </template>
          </el-table-column>
          <el-table-column
            label="操作"
            align="center"
            width="200">
            <template slot-scope="scope">
              <el-button
                @click.native.prevent="showDetail(scope.row)"
                type="text"
                size="small">
                查看详情
              </el-button>
            </template>
            <el-dialog
              title="订单详情"
              :visible.sync="orderDetailDialogVisible"
              append-to-body
              width="46%">
              <div>
                <p><span class="orderDetailDialogTitle">订单号：</span><span>{{orderDetailInfo.orderNo}}</span></p>
                <p><span class="orderDetailDialogTitle">酒店名称：</span><span>{{orderDetailInfo.hotelName}}</span></p>
                <p><span class="orderDetailDialogTitle">房型名称：</span><span>{{orderDetailInfo.roomTypeName}}</span></p>
                <p><span class="orderDetailDialogTitle">下单时间：</span><span>{{orderDetailInfo.orderTime}}</span></p>
                <p><span class="orderDetailDialogTitle">入住时间：</span><span>{{orderDetailInfo.startTime}}</span></p>
                <p><span class="orderDetailDialogTitle">退房时间：</span><span>{{orderDetailInfo.endTime}}</span></p>
                <p><span class="orderDetailDialogTitle">时长：</span><span>{{orderDetailInfo.duration}}小时</span></p>
                <p><span class="orderDetailDialogTitle">订单价：</span><span>{{orderDetailInfo.roomFee}}元</span></p>
                <p><span class="orderDetailDialogTitle">支付价：</span><span>{{orderDetailInfo.payAmount}}元</span></p>
                <p><span class="orderDetailDialogTitle">折扣：</span><span>{{orderDetailInfo.memberDiscount}}折</span></p>
                <p><span class="orderDetailDialogTitle">客人姓名：</span><span>{{orderDetailInfo.name}}</span></p>
                <p><span class="orderDetailDialogTitle">联系方式：</span><span>{{orderDetailInfo.mobile}}</span></p>
                <p><span class="orderDetailDialogTitle">订单状态：</span><span>{{orderDetailInfo.status == 0 ? '待确认' : orderDetailInfo.status == 1 ? '已确认': '已打款'}}</span></p>
              </div>
            </el-dialog>
          </el-table-column>
        </el-table>

        <div class='block'>
          <el-pagination
            @size-change='handleSizeChange'
            @current-change='handleCurrentChange'
            :current-page='paginationData.pageNumber'
            :page-sizes='[10, 20, 30, 50, 100]'
            :page-size='paginationData.pageSize'
            :total='paginationData.totalPage'
            layout='total, sizes, prev, pager, next, jumper'
          >
          </el-pagination>
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        roleList: [],
        dataListLoading: false,
        orderDetailDialogVisible: false,
        orderDetailInfo: {},
        billPeriod: '',
        billStatus: '',
        paginationData: {
          pageNumber: 1,
          pageSize: 20,
          totalPage: 0
        },
        receivablesInfoList: [],
        reconciliationDetailListData: []
      }
    },
    methods: {
      init (parmObj) {
        this.visible = false;
        this.dataListLoading = true;
        let param = {
          hotelId: parmObj ? parmObj.hotelId : '',
          startTime: parmObj ? parmObj.billStartTime : '',
          endTime: parmObj ? parmObj.biilEndTime : '',
          pageNum: this.paginationData.pageNumber,
          pageSize: this.paginationData.pageSize,

        };
        this.searchTableDetailInfo(param);
        this.searchOtherDetailInfo(parmObj.id);

      },
      searchOtherDetailInfo(id){
        this.$http({
          url: this.$http.adornUrl_qfs('/hotel/bill/info/'+id),
          method: 'get',
          params: this.$http.adornParams()
        }).then(({data}) => {
          this.visible = true;
          if (data && data.code === 0) {
            this.billPeriod = data.data.startDate.substring(0,10) + ' 至 ' + data.data.endDate.substring(0,10);
            this.billStatus = data.data.status == 0 ? '待确认' : data.data.status == 1 ? '已确认': '已打款';
            this.receivablesInfoList = data.data.cardOrderBeans;
          } else {
            this.receivablesInfoList = [];
          }
        })
      },
      searchTableDetailInfo(param){
        this.$http({
          url: this.$http.adornUrl_qfs('/roomOrder/member'),
          method: 'get',
          params: this.$http.adornParams({
            'hotelId': param.hotelId,
            'startTime': param.startTime,
            'endTime': param.endTime,
            'pageNum': param.pageNum,
            'pageSize': param.pageSize
          })
        }).then(({data}) => {
          this.dataListLoading = false;
          this.visible = true;
          if (data && data.code === 0) {
            let tempList = [];
            data.data.list.forEach((item,index) => {
              item.period = {
                startTime: item.startTime.substring(0,10),
                endTime: item.endTime.substring(0,10),
                duration: item.duration,
              };
              item.priceInfo = {
                roomFee: item.roomFee,
                payAmount: item.payAmount,
                Discount: item.memberDiscount
              }
              tempList.push(item);
            })
            this.reconciliationDetailListData = tempList;
          } else {
            this.reconciliationDetailListData = [];
          }
        })
      },
      handleSizeChange(val){
        this.paginationData.pageSize = val;
        this.paginationData.pageNumber = 1;
        this.searchTableDetailInfo();
      },
      handleCurrentChange(val){
        this.paginationData.pageNumber = val;
        this.searchTableDetailInfo();
      },
      showDetail(row){
        //查看订单详情
        this.orderDetailInfo = row;
        this.orderDetailDialogVisible = true;
      }
    }
  }
</script>
<style lang="scss">
  .headBlock{
    background: #f3f3f3;
    padding: .8rem 1rem;
    display: flex;
    justify-content: space-between;
  }
  .headInfo{
    margin: 1rem 0;
    display: flex;
  }
  .infoBlock{
    display: flex;
    border: 1px solid #f1f1f1;
    .infoTitle{
      background: #f3f3f3;
      border-right: 1px solid #f9fafc;
      line-height: 3;
      text-align: center;
      width: 8rem;
    }
    .infoContent{
      line-height: 3;
      text-align: center;
      padding: 0 1.6rem;
    }
  }

</style>
