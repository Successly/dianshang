<template xmlns="http://www.w3.org/1999/html">
  <div class="block">
    <div class="search_area">
      <el-row>
        <el-col class="headBlock" :span="24">
          <el-button type="text" icon="el-icon-search">筛选查询</el-button>
        </el-col>
      </el-row>
      <el-form :inline="true" :model="formInline" class="demo-form-inline" style="margin-top: 1rem;">
        <el-form-item label="酒店名称">
          <hotel-select :defaultSelect="defaultSelectHotel" :addressCode="formInline.addressCode" :defaultName="formInline.name" @changeSelectFunc="changeHotelSelectFunc"></hotel-select>
        </el-form-item>
        <el-form-item label="输入搜索">
          <el-input v-model="formInline.name" placeholder="酒店名称" style="width: 200px;"></el-input>
        </el-form-item>
        <el-form-item label="省市区">
          <ssq-select @changeFunc="changeProvince" :ssqValuesArr="formInline.ssqValuesArr"></ssq-select>
        </el-form-item>
        <br/>
        <el-form-item label="周期范围">
          <el-date-picker
            v-model="formInline.time"
            type="daterange"
            :editable="false"
            align="center"
            start-placeholder="开始日期"
            end-placeholder="结束日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="对账状态">
          <el-select v-model="formInline.status" placeholder="请选择">
            <el-option
              v-for="item in reconciliationstatusList"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="searchReconciliation">查询</el-button>
        </el-form-item>
      </el-form>
    </div>

    <div class="receivables_info">
      <el-row>
        <el-col class="headBlock" :span="24">
          <el-button type="text" icon="el-icon-tickets">收款账号</el-button>
          <el-button type="info" plain @click="billSettlementVisible = true">账单结算说明</el-button>
          <el-dialog
            title="账单结算说明"
            :visible.sync="billSettlementVisible"
            width="48%">
            <span>1.2019年3月1日起开通酒店管理后台，每笔订单的在线支付金额以及购买储值卡的支付金额收取1%作为交易结算费用；交易结算费用主要用于支付微信提现、转账等产生的费用。若消费者支付后又取消订单申请退款成功的，就退款部分将不收取交易结算费用<br/>2.打款说明： 预订客房订单：每周五，结算离店时间在上周一00：00至上周日23：59之间支付成功的订单 购储值卡订单：每周五，结算下单时间在上周一00：00至上周日23：59之间支付成功的订单 <br/>3.因部分商家为跨行打款，到账时间可能会延迟1-3个工作日；周五如遇节假日则推迟节后第一个工 作日进行打款。 <br/>4.结算款项会汇入商家在【酒店管理】-【财务信息】中设置的账户中（修改请联系BD)。</span>
          </el-dialog>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-table
            :data="receivablesInfoList"
            border
            stripe
            style="width: 100%">
            <el-table-column
              prop="bank"
              label="开户行"
              align="center"
              width="300">
            </el-table-column>
            <el-table-column
              prop="accountName"
              label="开户名"
              align="center">
            </el-table-column>
            <el-table-column
              prop="account"
              label="账号"
              align="center"
              width="150">
            </el-table-column>
            <el-table-column
              prop="isPublic"
              label="公私"
              align="center"
              width="150">
            </el-table-column>
          </el-table>
        </el-col>
      </el-row>
    </div>

    <el-row>
      <el-col class="headBlock" :span="24">
        <el-button type="text" icon="el-icon-tickets">数据列表</el-button>
        <el-dropdown>
					<span class="el-dropdown-link" style="line-height: 3">
						导出数据<i class="el-icon-arrow-down el-icon--right"></i>
					</span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item @click.native="downloadAll">当前页面</el-dropdown-item>
            <el-dropdown-item @click.native="downloadListConfirming">待确认</el-dropdown-item>
            <el-dropdown-item @click.native="downloadListConfirmed">已确认</el-dropdown-item>
            <el-dropdown-item @click.native="downloadListPaied">已打款</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </el-col>
    </el-row>
    <div class="search_result">
      <el-table
        :data="reconciliationListData"
        border
        stripe
        @selection-change="selectionChangeHandle"
        style="width: 100%">
        <!--<el-table-column
          type="selection"
          header-align="center"
          align="center"
          width="50">
        </el-table-column>-->
        <el-table-column
          prop="period"
          label="结算周期"
          align="center"
          width="300">
        </el-table-column>
        <el-table-column
          prop="orderNumber"
          label="订单总数"
          align="center">
        </el-table-column>
        <el-table-column
          prop="hotelOrderMoney"
          label="在线支付金额"
          align="center"
          width="150">
        </el-table-column>
        <el-table-column
          prop="hotelCardMoney"
          label="储值"
          align="center"
          width="150">
        </el-table-column>
        <el-table-column
          prop="billFee"
          label="交易结算费"
          align="center"
          width="80">
        </el-table-column>
        <el-table-column
          prop="billMoney"
          label="结算金额"
          align="center">
        </el-table-column>
        <el-table-column
          prop="status"
          label="状态"
          align="center">
          <template slot-scope="scope">
            <div v-if="scope.row.status == '0'">
              待确认
            </div>
            <div v-else-if="scope.row.status == '1'">
              已确认
            </div>
            <div v-else>
              已打款
            </div>
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="center"
          width="200">
          <template slot-scope="scope">
            <el-button
              @click.native.prevent="queryInfo(scope.row);"
              type="text"
              size="small">
              查看详情
            </el-button>
            <div v-if="scope.row.status == '0'">
              <el-button
                @click.native.prevent="sureAtOnce(scope.row);"
                type="text"
                size="small">
                立即确认
              </el-button>
              <el-dialog
                title="提示"
                :visible.sync="confirmDialogVisible"
                width="30%">
                <div>
                  <p style="font-size: 1.4rem;">已确认账单结算金额</p>
                  <p style="font-size: 1rem; color: #c3c3c3;">确认不可取消</p>
                </div>
                <span slot="footer" class="dialog-footer">
              <el-button @click="confirmDialogVisible = false">取 消</el-button>
              <el-button type="primary" @click="confirmHandler" :loading="confimLoading">确 定</el-button>
              </span>
              </el-dialog>
            </div>
          </template>
        </el-table-column>
      </el-table>

      <div class='block'>
        <el-pagination
          @size-change='handleSizeChange'
          @current-change='handleCurrentChange'
          :current-page='paginationData.pageNumber'
          :page-sizes='[10, 20, 30, 50, 100]'
          :page-size='paginationData.pageSize'
          :total='paginationData.totalPage'
          layout='total, sizes, prev, pager, next, jumper'
        >
        </el-pagination>
      </div>
      <!-- 弹窗, 账单详情 -->
      <reconciliationDetail v-if="reconciliationDetailVisible" ref="reconciliationDetailRef"></reconciliationDetail>
    </div>
  </div>
</template>

<script>

  import HotelSelect from '../../../plugin/hotelSelect'
  import SsqSelect from '../../../plugin/ssqSelect'
  import reconciliationDetail from './reconciliationDetail'

  export default {
    data () {
      return {
        billSettlementVisible: false,
        defaultProvince: '',
        billId: '',//确认的账单id
        confimLoading: false,
        defaultSelectHotel: true,
        reconciliationDetailVisible: false,
        formInline: {
          name: '',
          hotelId: '',
          ssqValuesArr: [],
          time: [],
          status: '',
          addressCode: ''
        },
        /*defaultProvince: '',*/
        reconciliationstatusList: [
          { label: '全部', value: '' },
          { label: '待确认', value: 0 },
          { label: '已确认', value: 1 },
          { label: '已打款', value: 2 },
        ],
        receivablesInfoList: [],
        reconciliationListData: [],
        paginationData: {
          pageNumber: 1,
          pageSize: 20,
          totalPage: 0
        },
        dataListSelections: [],
        confirmDialogVisible: false
      }
    },
    /* watch: {
       formInline: function (val, oldVal) {
         this.defaultProvince = val.ssqValuesArr.length > 0 ? val.ssqValuesArr[0].name : '';
       },
     },*/
    created () {

    },
    activated () {
      this.queryReceivablesInfo();
      this.searchReconciliation();
    },
    methods: {
      changeHotelSelectFunc(value){
        console.log('根据酒店id:'+value);
        this.formInline.hotelId = value;
        this.searchReconciliation();

      },
      changeProvince(result){
        //省市区发生修改
        console.log("省市区修改：",result);
        if(result.length == 0){
          this.formInline.addressCode = '';
        }else{
          this.defaultProvince = result[0].value;
          this.formInline.addressCode = result[2].key;
        }
      },
      searchReconciliation(){
        this.searchReconciliationInfoList()
        this.searchReconciliationList()
      },
      searchReconciliationInfoList(){
        this.$http({
          url: this.$http.adornUrl_qfs('/hotel/hotels/bank'),
          method: 'get',
          params: this.$http.adornParams(Object.assign(this.formInline))
        }).then(({data}) => {
          if (data && data.code === 0) {
            this.receivablesInfoList = [{
              'bank': data.data.bank,
              'branchBank': data.data.branchBank,
              'subBaranchBank': data.data.subBaranchBank,
              'accountName': data.data.accountName,
              'account': data.data.account
            }]
          } else {
            this.receivablesInfoList = [];
          }
        })
      },
      searchReconciliationList(){
        this.$http({
          url: this.$http.adornUrl_qfs('/hotel/bill/list'),
          method: 'get',
          params: this.$http.adornParams(Object.assign({
            'pageNum': this.paginationData.pageNumber,
            'pageSize': this.paginationData.pageSize
          }, this.formInline))
        }).then(({data}) => {
          if (data && data.code === 0) {
            this.reconciliationListData = data.data.list;
            this.paginationData.totalPage = data.data.totalCount;
            this.reconciliationListData.forEach((item)=>{
              item.period = item.billStartTime.substring(0,10)+' 至 '+item.billEndTime.substring(0,10);
            })
            this.hotelId = this.defaultHotelId == -1 ? data.data[0].id : this.defaultHotelId;
          } else {
            this.reconciliationListData = [];
          }
        })
      },
      queryReceivablesInfo(){

      },
      queryInfo(row){
        // 查看详情
        this.reconciliationDetailVisible = true;
        this.$nextTick(() => {
          this.$refs.reconciliationDetailRef.init(row);
        })
      },
      sureAtOnce(row){
        // 立即确认
        this.confirmDialogVisible = true;
        console.log(row);
        this.billId = row.id;
      },
      confirmHandler(){
        // 确认账单
        this.confimLoading = true;
        this.$http({
          url: this.$http.adornUrl_qfs('/hotel/bill/opt/'+this.billId),
          method: 'get',
          params: this.$http.adornParams({
            'optType': 1,
          })
        }).then(({data}) => {
          this.confimLoading = false;
          if (data && data.code === 0) {
            this.$message({
              message: '确认账单成功',
              type: 'success'
            });
          } else {
            this.$message({
              message: '确认账单失败',
              type: 'error'
            });
          }
          this.confirmDialogVisible = false;
        })
      },
      handleSizeChange(val){
        this.paginationData.pageSize = val;
        this.paginationData.pageNumber = 1;
        this.searchHotelInfo();
      },
      handleCurrentChange(val){
        this.paginationData.pageNumber = val;
        this.searchHotelInfo();
      },
      selectionChangeHandle (val) {
        // 多选
        this.dataListSelections = val;
      },
      downloadListConfirming(){
        let ids = [];
        this.reconciliationListData.forEach((item) => {
          if(item.status == 0){
            ids.push(item.id);
          }
        });
        this.exportHandler(ids);

      },
      downloadListConfirmed(){
          let ids = [];
          this.reconciliationListData.forEach((item) => {
            if(item.status == 1){
              ids.push(item.id);
            }
          });
          this.exportHandler(ids);

      },
      downloadListPaied(){
        let ids = [];
        this.reconciliationListData.forEach((item) => {
          if(item.status == 2){
            ids.push(item.id);
          }
        });
        this.exportHandler(ids);

      },
      downloadAll(){
        this.exportHandler([]);
      },
      exportHandler(ids){
        let idsParam = ids.join("&ids=");

        window.open(this.$http.adornUrl_qfs('/hotel/bill/export?ids='+idsParam));
      },
    },
    components: {
      HotelSelect,
      SsqSelect,
      reconciliationDetail
    }
  }
</script>

<style lang="scss">
  .headBlock{
    background: #f3f3f3;
    padding: .8rem 1rem;
    display: flex;
    justify-content: space-between;
  }
  .search_area,.receivables_info{
    margin-bottom: 1rem;
  }
</style>
