<template>
	<div class="block">
		<div class="search_area">
			<el-form :inline="true" :model="formInline" class="demo-form-inline">
				<el-form-item label="酒店名称">
					<hotel-select @changeSelectFunc="changeHotelSelectFunc" :addressCode="formInline.addressCode"></hotel-select>
				</el-form-item>
				<el-form-item label="省市区">
					<ssq-select :ssqValuesArr="formInline.ssqValuesArr" @changeFunc="ssqChange"></ssq-select>
				</el-form-item>
				<br/>
				<el-form-item label="周期范围">
					<el-date-picker
					  v-model="formInline.time"
					  type="daterange"
					  :editable="false"
					  align="center"
					  start-placeholder="开始日期"
					  end-placeholder="结束日期">
					</el-date-picker>
				</el-form-item>
				<el-form-item label="对账状态">
					<el-select v-model="formInline.state" placeholder="请选择">
						<el-option
						  v-for="item in reconciliationStateList"
						  :key="item.value"
						  :label="item.label"
						  :value="item.value">
						</el-option>
					</el-select>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="searchReconciliationList">查询</el-button>
				</el-form-item>
			</el-form>
		</div>
		<div class="search_result">
			<el-table
			  :data="reconciliationListData"
			  border
			  stripe
			  style="width: 100%">
				<el-table-column
				  prop="hotelId"
				  label="结算周期"
				  align="center"
				  width="100">
				</el-table-column>
				<el-table-column
				  prop="hotelName"
				  label="订单总数"
				  align="center">
				</el-table-column>
				<el-table-column
				  prop="tel"
				  label="在线支付金额"
				  align="center"
				  width="150">
				</el-table-column>
				<el-table-column
				  prop="contect"
				  label="储值"
				  align="center"
				  width="150">
				</el-table-column>
				<el-table-column
				  label="佣金"
				  align="center"
				  width="80">
				</el-table-column>
				<el-table-column
				  prop="ssq"
				  label="结算金额"
				  align="center">
				</el-table-column>
				<el-table-column
				  prop="addr"
				  label="状态"
				  align="center">
				</el-table-column>
				<el-table-column
				  label="操作"
				  align="center"
				  width="100">
					<template slot-scope="scope">
						<el-button
						  @click.native.prevent="queryInfo()"
						  type="text"
						  size="small">
						  查看详情
						</el-button>
						<el-button
						  @click.native.prevent="sureAtOnce()"
						  type="text"
						  size="small">
						  打款
						</el-button>
					</template>
				</el-table-column>
			</el-table>

			<div class='block'>
				<el-pagination
				  @size-change='handleSizeChange'
				  @current-change='handleCurrentChange'
			      :current-page='paginationData.pageNumber'
				  :page-sizes='[10, 20, 30, 50, 100]'
				  :page-size='paginationData.pageSize'
				  :total='paginationData.totalPage'
				  layout='total, sizes, prev, pager, next, jumper'
				>
				</el-pagination>
			</div>
		</div>
	</div>
</template>

<script>

	import HotelSelect from '../../../plugin/hotelSelect'
	import SsqSelect from '../../../plugin/ssqSelect'

	export default {
		data () {
			return {
				formInline: {
					hotelName: '',
					ssqValuesArr: [],
					time: [],
					state: 0,
          addressCode: ''
				},
				reconciliationStateList: [
					{ label: '全部', value: 0 }
				],
				reconciliationListData: [],
				paginationData: {
					pageNumber: 1,
					pageSize: 20,
					totalPage: 0
				}
			}
		},
		created () {

		},
		activated () {
			this.searchReconciliationList();
		},
		methods: {
			changeHotelSelectFunc(value){
				console.log('根据酒店id:'+value+'查询酒店信息');
			},
			searchReconciliationList(){

			},
      ssqChange(result){
        if(result.length == 0){
          this.formInline.addressCode = '';
        }else{
          this.formInline.addressCode = result[2].key;
        }
      },
			queryInfo(){
				// 查看详情
			},
			sureAtOnce(){
				// 打款
			},
			handleSizeChange(val){
				this.paginationData.pageSize = val;
				this.paginationData.pageNumber = 1;
				this.searchHotelInfo();
			},
			handleCurrentChange(val){
				this.paginationData.pageNumber = val;
				this.searchHotelInfo();
			}
		},
		components: {
			HotelSelect,
			SsqSelect
		}
	}
</script>

<style lang="scss">
.receivables_info{
	border-top: 1px solid #a1a1a1;
	width: 100%;
}
.receivables_info_thead{
	font-size: 20px;
	line-height: 40px;
	text-align: center;
	font-weight: bold;
	border-left: 1px solid #a1a1a1;
	border-bottom: 1px solid #a1a1a1;
}
.receivables_info_tbody{
	font-size: 14px;
	line-height: 40px;
	text-align: center;
	border-left: 1px solid #a1a1a1;
	border-bottom: 1px solid #a1a1a1;
}
.receivables_info_text{
	border-right: 1px solid #a1a1a1;
}
</style>
