<template>
	<div class="block">
		<el-table
		  :data="roleListData"
		  border
		  stripe
		  :v-loading="dataListLoading"
		  style="width: 100%">
			<el-table-column
			  prop="roleName"
			  label="角色名称"
			  align="center"
			  style="width: 33%;">
			</el-table-column>
			<el-table-column
			  prop="hotelName"
			  label="是否启用"
			  align="center"
			  style="width: 33%;">
				<template slot-scope="scope">
					<el-switch
					  active-color="#13ce66"
					  inactive-color="#ff4949">
					</el-switch>
				</template>
			</el-table-column>
			<el-table-column
			  label="操作"
			  align="center"
			  style="width: 34%;">
				<template slot-scope="scope">
					<el-button
					  @click.native.prevent="editJurisdiction(scope.row.roleId)"
					  type="text"
					  size="small">
					  权限设置
					</el-button>
					<el-button
					  @click.native.prevent="deleteThisRow(scope.row.roleId)"
					  type="text"
					  size="small"
					  style="margin-left: 20px;">
					  删除
					</el-button>
				</template>
			</el-table-column>
		</el-table>
		
		<div class='block'>
			<el-pagination
			  @size-change='handleSizeChange' 
			  @current-change='handleCurrentChange' 
			  :current-page='paginationData.pageNumber' 
			  :page-sizes='[1, 10, 20, 30, 50, 100]' 
			  :page-size='paginationData.pageSize' 
			  :total='paginationData.totalPage'
			  layout='total, sizes, prev, pager, next, jumper' 
			>
			</el-pagination>
		</div>
		
		<!--权限设置弹窗-->
		<el-dialog
		  v-if="editJurisdictionDialogShow"
		  title="权限设置"
		  :close-on-click-modal="false"
		  :before-close="closeDialog"
		  :visible.sync="visible">
			<el-form :model="dataForm" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
				<el-row style="background: #e4e4e4;margin-bottom: 20px;">
					<el-col :span="24"><h4 style="margin-left: 20px;">当前角色：{{dataForm.roleName}}</h4></el-col>
				</el-row>
				<div v-for="(item, topIndex) in menuListLast" style="width: 100%;" :key="topIndex">
					<el-row
					  style="background: #efefef;">
						<el-col :span="24">
							<div class="page_checkbox">
								<!-- element-ui的checkbox动态生成,v-model绑定造成鼠标勾选无效,未解决,使用原生界面进行展示 -->
								<!--<el-checkbox :indeterminate="item.indeterminate" :key="topIndex" v-model="item.isChecked" :label="item.menuId" @change="changeCheckbox_f(topIndex, item.menuId, $event)">{{item.name}}</el-checkbox>-->
								<input type="checkbox" v-model="item.isChecked" :data-menuId="item.menuId" :id="'checkbox-f-'+item.menuId" style="margin-right: 15px;" @change="changeCheckbox_f(topIndex, item.menuId, $event)" />
								<label :for="'checkbox-f-'+item.menuId">{{item.name}}</label>
							</div>
						</el-col>
					</el-row>
					<el-row>
						<el-col :span="6" v-for="childItem in item.children" :key="childItem.menuId">
							<div class="page_checkbox">
								<!--<el-checkbox v-model="childItem.isChecked" @change="changeCheckbox_s(topIndex, childItem.menuId, item.menuId, $event)" :label="childItem.menuId" :key="childItem.menuId">{{childItem.name}}</el-checkbox>-->
								<input type="checkbox" v-model="childItem.isChecked" :data-menuId="childItem.menuId" :name="'checkbox-f-'+item.menuId" :id="'checkbox-s-'+childItem.menuId" style="margin-right: 15px;" @change="changeCheckbox_s(topIndex, childItem.menuId, item.menuId, $event)" />
								<label :for="'checkbox-s-'+childItem.menuId">{{childItem.name}}</label>
							</div>
						</el-col>
					</el-row>
				</div>
			</el-form>
			<span slot="footer" class="dialog-footer">
				<el-button @click="closeDialog">取消</el-button>
				<el-button type="primary" @click="dataFormSubmit">确定</el-button>
			</span>
		</el-dialog>
	</div>
</template>

<script>

	import { treeDataTranslate } from '@/utils'

	export default {
		data () {
			return {
				dataListLoading: false,
				roleListData: [],
				paginationData: {
					pageNumber: 1,
					pageSize: 20,
					totalPage: 0
				},
				editJurisdictionDialogShow: false,
				visible: false,
				menuList: [],
				menuListLast: [],
				menuCheckedList: [],
				dataForm: {
					id: 0,
					roleName: '',
					remark: ''
				}
			}
		},
		created () {
			
		},
		activated () {
			this.queryRoleList();
		},
		methods: {
			queryRoleList(){
				this.dataListLoading = true;
				this.$http({
					url: this.$http.adornUrl('/sys/role/list'),
					method: 'get',
					params: this.$http.adornParams({
						'page': this.paginationData.pageNumber,
						'limit': this.paginationData.pageSize,
						'roleName': ''
					})
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.roleListData = data.page.list;
						this.paginationData.totalPage = data.page.totalCount;
					} else {
						this.roleListData = [];
						this.paginationData.totalPage = 0;
					}
					this.dataListLoading = false
				})
			},
			handleSizeChange(val){
				this.paginationData.pageSize = val;
				this.queryRoleList();
			},
			handleCurrentChange(val){
				this.paginationData.pageNumber = val;
				this.queryRoleList();
			},
			editJurisdiction(id){
				// 权限设置
				this.editJurisdictionDialogShow = true;
				this.init(id);
			},
			deleteThisRow(id){
				// 删除
				this.$confirm(`确定对该角色进行删除操作?`, '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
					this.$http({
						url: this.$http.adornUrl('/sys/role/delete'),
						method: 'post',
						data: this.$http.adornData([id], false)
					}).then(({data}) => {
						if (data && data.code === 0) {
							this.$message({
								message: '操作成功',
								type: 'success',
								duration: 1500,
								onClose: () => {
									this.queryRoleList();
								}
							})
						} else {
							this.$message.error(data.msg);
						}
					})
				}).catch(() => {})
			},
			
			// 权限设置弹窗
			init(id){
				this.dataForm.id = id || 0;
				
				this.$http({
					url: this.$http.adornUrl('/sys/menu/list'),
					method: 'get',
					params: this.$http.adornParams()
				}).then(({data}) => {
					this.menuList = treeDataTranslate(data, 'menuId');
					this.menuListAddChecked(this.menuList);
					this.menuListLast = this.menuList;
				}).then(() => {
					this.visible = true;
				}).then(() => {
					this.$http({
						url: this.$http.adornUrl(`/sys/role/info/${this.dataForm.id}`),
						method: 'get',
						params: this.$http.adornParams()
					}).then(({data}) => {
						if (data && data.code === 0) {
							this.$nextTick(() => {
								this.dataForm.roleName = data.role.roleName;
								this.dataForm.remark = data.role.remark;
								this.menuCheckedList = data.role.menuIdList;
								this.changeMenuListChecked(this.menuListLast);
							})
						}
					})
				})
			},
			dataFormSubmit(){
				this.$http({
					url: this.$http.adornUrl('/sys/role/update'),
					method: 'post',
					data: this.$http.adornData({
						'roleId': this.dataForm.id || undefined,
						'roleName': this.dataForm.roleName,
						'remark': this.dataForm.remark,
						'menuIdList': this.menuCheckedList
					})
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.$message({
							message: '操作成功',
							type: 'success',
							duration: 1500,
							onClose: () => {
								this.closeDialog();
								this.queryRoleList();
							}
						})
					} else {
						this.$message.error(data.msg)
					}
				})
			},
			menuListAddChecked(list){
				for (var i = 0; i < list.length; i++) {
					list[i]['isChecked'] = false;
					list[i]['indeterminate'] = false;
					if(list[i]['children'] && list[i]['children'].length > 0){
						this.menuListAddChecked(list[i]['children']);
					}
				}
			},
			changeMenuListChecked(list){
				for (var i = 0; i < list.length; i++) {
					if(this.menuCheckedList.indexOf(list[i]['menuId']) !== -1){
						list[i]['isChecked'] = true;
					}
					if(list[i]['children'] && list[i]['children'].length > 0){
						this.changeMenuListChecked(list[i]['children']);
					}
				}
			},
			changeCheckbox_f(index, topId, e){
				index = parseInt(index);
				topId = parseInt(topId);
				if(e.target.checked){
					// 全选
					this.menuCheckedList.push(topId);
					var doms = document.getElementsByName("checkbox-f-" + topId);
					for(var i = 0; i < doms.length; i++){
						doms[i].checked = true;
						var sonMenuId = doms[i].getAttribute('data-menuId');
						if(this.menuCheckedList.indexOf(sonMenuId) === -1){
							this.menuCheckedList.push(sonMenuId);
						}
					}
				}else{
					// 全反选
					this.menuCheckedList.splice(this.menuCheckedList.indexOf(topId), 1);
					var doms = document.getElementsByName("checkbox-f-" + topId);
					for(var i = 0; i < doms.length; i++){
						doms[i].checked = false;
						var sonMenuId = doms[i].getAttribute('data-menuId');
						if(this.menuCheckedList.indexOf(sonMenuId) !== -1){
							this.menuCheckedList.splice(this.menuCheckedList.indexOf(sonMenuId), 1);
						}
					}
				}
			},
			changeCheckbox_s(topIndex, sonId, topId, e){
				topIndex = parseInt(topIndex);
				sonId = parseInt(sonId);
				topId = parseInt(topId);
				if(e.target.checked){
					this.menuCheckedList.push(sonId);
					var dom = document.getElementById("checkbox-f-" + topId);
					dom.checked = true;
					if(this.menuCheckedList.indexOf(topId) === -1){
						this.menuCheckedList.push(topId);
					}
				}else{
					this.menuCheckedList.splice(this.menuCheckedList.indexOf(sonId), 1);
					var tempFlag = true;
					var doms = document.getElementsByName("checkbox-f-" + topId);
					for(var i = 0; i < doms.length; i++){
						if(doms[i].checked){
							tempFlag = false;
						}
					}
					if(tempFlag){
						var dom = document.getElementById("checkbox-f-" + topId);
						dom.checked = false;
						this.menuCheckedList.splice(this.menuCheckedList.indexOf(topId), 1);
					}
				}
			},
			closeDialog(){
				this.editJurisdictionDialogShow = false;
				this.visible = false,
				this.menuList = [],
				this.menuListLast = [],
				this.menuCheckedList = [],
				this.dataForm = {
					id: 0,
					roleName: '',
					remark: ''
				}
			}
		},
		components: {
			
		}
	}
</script>

<style lang="scss">
	.page_checkbox{
		width: 100%;
		height: 60px;
		display: flex;
		display: -webkit-flex;
		align-items:center;
		padding-left: 20px;
		input[type="checkbox"], label{
			cursor: pointer;
		}
	}
</style>