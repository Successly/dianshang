<template>
	<div class="block">
		<div class="search_area">
			<el-form :inline="true" :model="formInline" class="demo-form-inline">
				<el-form-item label="用户名：">
					<el-input v-model="formInline.userName" placeholder="请输入"></el-input>
				</el-form-item>
				<el-form-item label="账号：">
					<el-input v-model="formInline.account" placeholder="请输入"></el-input>
				</el-form-item>
				<el-form-item label="归属角色：">
					<el-select v-model="formInline.roleId" placeholder="请选择">
						<el-option
						  v-for="item in roleSelectData"
						  :key="item.value"
						  :label="item.label"
						  :value="item.value">
						</el-option>
					</el-select>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="searchUserList">查询</el-button>
					<el-button type="primary" @click="addOrUpdateHandle()">创建账号</el-button>
				</el-form-item>
			</el-form>
		</div>
		
		<div class="search_result">
			<el-table
			  :data="userListData"
			  v-loading="dataListLoading"
			  border
			  stripe
			  style="width: 100%">
				<el-table-column
				  prop="username"
				  label="用户名"
				  align="center">
				</el-table-column>
				<el-table-column
				  prop="email"
				  label="账号"
				  align="center">
				</el-table-column>
				<el-table-column
				  prop=""
				  label="归属角色"
				  align="center"
				  width="100">
				</el-table-column>
				<el-table-column
				  prop="createTime"
				  label="创建时间"
				  align="center"
				  width="160">
				</el-table-column>
				<el-table-column
				  prop=""
				  label="最后登录"
				  align="center"
				  width="160">
				</el-table-column>
				<el-table-column
				  prop="status"
				  label="状态"
				  align="center"
				  width="100">
					<template slot-scope="scope">
						<el-tag v-if="scope.row.status === 0" size="small" type="danger">已停用</el-tag>
						<el-tag v-else size="small">启用中</el-tag>
					</template>
				</el-table-column>
				<el-table-column
				  label="操作"
				  align="center"
				  width="250">
					<template slot-scope="scope">
						<el-button
						  @click.native.prevent="addOrUpdateHandle(scope.row.userId)"
						  type="text"
						  size="small">
						  详情
						</el-button>
						<el-button
						  @click.native.prevent="contectHotel(scope.$index, userListData)"
						  type="text"
						  size="small">
						  关联酒店
						</el-button>
						<el-button
						  @click.native.prevent="deleteThisUserInfo(scope.row.userId)"
						  type="text"
						  size="small">
						  删除
						</el-button>
						<el-button
						  @click.native.prevent="enableOrUnable(scope.row)"
						  type="text"
						  size="small">
						  {{scope.row.status === 0 ? '启用' : '停用'}}
						</el-button>
					</template>
				</el-table-column>
			</el-table>
			
			<div class='block'>
				<el-pagination
				  @size-change='handleSizeChange' 
				  @current-change='handleCurrentChange' 
			      :current-page='paginationData.pageNumber' 
				  :page-sizes='[10, 20, 30, 50, 100]' 
				  :page-size='paginationData.pageSize' 
				  :total='paginationData.totalPage'
				  layout='total, sizes, prev, pager, next, jumper' 
				>
				</el-pagination>
			</div>
		</div>
		
		<!-- 弹窗, 新增 / 修改 -->
		<AddOrUpdate v-if="addOrUpdateVisible" ref="addOrUpdate" @refreshDataList="searchUserList"></AddOrUpdate>
	</div>
</template>

<script>

	import AddOrUpdate from './user-add-or-update'

	export default {
		data () {
			return {
				formInline: {
					userName: '',
					account: '',
					roleId: 0
				},
				roleSelectData: [{
					label: '全部',
					value: 0
				}, {
					label: 'admin',
					value: 1
				}, {
					label: '酒店账号',
					value: 2
				}, {
					label: '酒店BD',
					value: 3
				}, {
					label: '运营',
					value: 4
				}],
				userListData: [],
				paginationData: {
					pageNumber: 1,
					pageSize: 20,
					totalPage: 0
				},
				dataListLoading: false,
				addOrUpdateVisible: false
			}
		},
		created () {
			
		},
		activated () {
			this.searchUserList();
		},
		methods: {
			searchUserList(){
				this.dataListLoading = true;
				this.$http({
					url: this.$http.adornUrl('/sys/user/list'),
					method: 'get',
					params: this.$http.adornParams({
						'page': this.paginationData.pageNumber,
						'limit': this.paginationData.pageSize,
						'username': this.formInline.userName
					})
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.userListData = data.page.list;
						this.paginationData.totalPage = data.page.totalCount;
					} else {
						this.userListData = [];
						this.paginationData.totalPage = 0;
					}
					this.dataListLoading = false;
				})
			},
			// 新增 / 修改
			addOrUpdateHandle (id) {
				this.addOrUpdateVisible = true;
				this.$nextTick(() => {
					this.$refs.addOrUpdate.init(id);
				})
			},
			deleteThisUserInfo(id){
				var userIds = [id];
				this.$confirm('确定对该用户进行删除操作?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
					this.$http({
						url: this.$http.adornUrl('/sys/user/delete'),
						method: 'post',
						data: this.$http.adornData(userIds, false)
					}).then(({data}) => {
						if (data && data.code === 0) {
							this.$message({
								message: '操作成功',
								type: 'success',
								duration: 1500,
								onClose: () => {
									this.searchUserList()
								}
							})
						} else {
							this.$message.error(data.msg)
						}
					})
				}).catch(() => {})
			},
			enableOrUnable(rowData){
				if(rowData.status === 0){
					// 启用
					this.updateStatus(rowData.userId, 1);
				}else{
					// 停用
					this.$confirm('确定对该用户进行停用操作?', '提示', {
						confirmButtonText: '确定',
						cancelButtonText: '取消',
						type: 'warning'
					}).then(() => {
						this.updateStatus(rowData.userId, 0);
					}).catch(() => {})
				}
			},
			updateStatus(id, status){
				this.$http({
					url: this.$http.adornUrl('/sys/user/update'),
					method: 'post',
					data: this.$http.adornData({
						'userId': id,
						'status': status
					})
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.$message({
							message: '操作成功',
							type: 'success',
							duration: 1500,
							onClose: () => {
								this.searchUserList();
							}
						})
					} else {
						this.$message.error(data.msg);
					}
				})
			},
			contectHotel(index, data){
				// 关联酒店
			},
			handleSizeChange(val){
				this.paginationData.pageSize = val;
				this.paginationData.pageNumber = 1;
				this.searchUserList();
			},
			handleCurrentChange(val){
				this.paginationData.pageNumber = val;
				this.searchUserList();
			}
		},
		components: {
			AddOrUpdate
		}
	}
</script>

<style lang="scss">

</style>