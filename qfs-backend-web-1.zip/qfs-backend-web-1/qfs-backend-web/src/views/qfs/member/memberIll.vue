<template>
	<div class="block">
		<h3>会员计划说明</h3>
		<img src="../../../assets/img/login_bg.jpg" />
		<h3>酒店会员计划</h3>
		<p>
			该计划旨在为解决传统酒店会员管理系统较为薄弱、缺乏有效的营销及推广工具的问题；通过在趣分时内建立酒店专属的会员体系，
			基于趣分时的渠道推广及酒店门店散客，帮助酒店建立集品牌推广、会员管理、营销活动、统计报表于一体的会员管理平台。清晰
			记录酒店用户的消费行为并进行数据分析；还可根据用户特征进行精细分类，从而实现各种模式的精准营销。
		</p>
		<h3>会员机制详情</h3>
		<p>
			1.会员等级设置：平台统一提供酒店会员等级；共分为5个等级：白银会员、
			黄金会员、铂金会员、钻石会员、至尊会员；各等级分别对应积分区间段。
		</p>
		<p>
			2.会员等级权益：各等级会员享有产异性的等级政策，平台提供参考设置，
			酒店可根据实际情况进行修改。
		</p>
		<p>
			3.酒店专属会员为免费开通或储值卡充值送会员，酒店可根据实际情况通过设置会员等级折扣来平衡会员权益；
			酒店储值卡为统一设置，分为500元和1000元两种储值方式，后期将开放更多储值权限。
		</p>
		<p>
			4.用户积分获取渠道主要包括：购买储蓄卡以及日常任务（预订房源且无退款、订单反馈、
			关注酒店、分享好友、酒店每日签到）建立酒店真正具有实际效益、成长性的会员体系。
		</p>
		<el-row style="margin-top: 30px;text-align: center;">
			<el-button type="primary" v-if="isJoin" @click="joinMember">已加入</el-button>
			<el-button type="primary" v-else @click="joinMember">加入酒店专属会员计划</el-button>
		</el-row>
	</div>
</template>

<script>
	export default {
		data () {
			return {
				isJoin: false
			}
		},
		created () {

		},
		activated () {
			this.getIsJoin();
		},
		methods: {
			getIsJoin(){
				// 获取是否已经加入计划

			},
			joinMember(){
				if(this.isJoin){
					// 已经加入，进入会员列表
					this.$router.push({name: 'qfs-member/memberList'});
				}else{
					// 未加入，进入会员设置
					this.$router.push({name: 'qfs-member/memberManage'});
				}
			}
		},
		components: {

		}
	}
</script>

<style lang="scss">
	p{
		line-height: 24px;
		font-size: 14px;
	}
</style>
