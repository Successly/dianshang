<template>
	<div class="block">
		<el-steps :active="active" finish-status="success" style="width: 30%;">
			<el-step title="会员基本信息"></el-step>
			<el-step title="会员权益信息"></el-step>
		</el-steps>

		<el-form :model="formInline" label-width="300px" style="margin-top: 20px;">
			<div class="block" v-if="active == 0">
				<el-row>
					<el-col :span="6">
						<div class="block form_title">基本信息</div>
					</el-col>
					<el-col :span="18">
						<el-row style="margin-bottom: 20px;">
							<hotel-select @changeSelectFunc="changeSelectFunc"></hotel-select>
						</el-row>
						<el-row class="baseInfo">
							<span class="baseInfo_lv">白银等级</span>
							<span class="baseInfo_num">成长值0-300</span>
							<span class="baseInfo_input">
								享受折扣<el-input v-model="byzk" placeholder="请输入享受折扣" style="width: 200px;margin: 0 10px;"></el-input>折
							</span>
						</el-row>
						<el-row class="baseInfo">
							<span class="baseInfo_lv">黄金等级</span>
							<span class="baseInfo_num">成长值301-1000</span>
							<span class="baseInfo_input">
								享受折扣<el-input v-model="hjzk" placeholder="请输入享受折扣" style="width: 200px;margin: 0 10px;"></el-input>折
							</span>
						</el-row>
						<el-row class="baseInfo">
							<span class="baseInfo_lv">铂金等级</span>
							<span class="baseInfo_num">成长值1001-3000</span>
							<span class="baseInfo_input">
								享受折扣<el-input v-model="bjzk" placeholder="请输入享受折扣" style="width: 200px;margin: 0 10px;"></el-input>折
							</span>
						</el-row>
						<el-row class="baseInfo">
							<span class="baseInfo_lv">钻石等级</span>
							<span class="baseInfo_num">成长值3001-6000</span>
							<span class="baseInfo_input">
								享受折扣<el-input v-model="zszk" placeholder="请输入享受折扣" style="width: 200px;margin: 0 10px;"></el-input>折
							</span>
						</el-row>
						<el-row class="baseInfo">
							<span class="baseInfo_lv">至尊等级</span>
							<span class="baseInfo_num">成长值6001以上</span>
							<span class="baseInfo_input">
								享受折扣<el-input v-model="zzzk" placeholder="请输入享受折扣" style="width: 200px;margin: 0 10px;"></el-input>折
							</span>
						</el-row>
					</el-col>
				</el-row>
				<el-row class="line"></el-row>
				<el-row>
					<el-col :span="6">
						<div class="block form_title">会员积分</div>
					</el-col>
					<el-col :span="18">
						<el-row :gutter="12">
							<el-col :span="4">
								<el-card shadow="always" style="text-align: center;border-color: #333;">
									<p>预订酒店</p>
									<p style="font-size: 12px;">1元=1成长值</p>
								</el-card>
							</el-col>
							<el-col :span="6">
								<el-card shadow="always" style="text-align: center;border-color: #333;">
									<p>关注酒店</p>
									<p style="font-size: 12px;">获得50成长值每人限一次</p>
								</el-card>
							</el-col>
							<el-col :span="4">
								<el-card shadow="always" style="text-align: center;border-color: #333;">
									<p>购储值卡</p>
									<p style="font-size: 12px;">储值获相应积分</p>
								</el-card>
							</el-col>
							<el-col :span="4">
								<el-card shadow="always" style="text-align: center;border-color: #333;" class="tip">
									<p>每日签到</p>
									<p style="font-size: 12px;">递增机制</p>
									<span>敬请期待</span>
								</el-card>
							</el-col>
							<el-col :span="4">
								<el-card shadow="always" style="text-align: center;border-color: #333;" class="tip">
									<p>订单反馈</p>
									<p style="font-size: 12px;">每单50成长值</p>
									<span>敬请期待</span>
								</el-card>
							</el-col>
						</el-row>
						<el-row>
							<p>预订酒店：预订房源且无退款，可获得订单金额对等成长值。</p>
							<p>关注酒店：成为酒店会员后首次关注酒店可获得50成长值，每位用户仅限一次。</p>
							<p>购储值卡：购买储值卡可获得相应积分，目前储值卡分为500元获得400成长值、1000元获得1000成长值、2000元获得2400成长值。</p>
						</el-row>
					</el-col>
				</el-row>
				<el-row class="line"></el-row>
				<el-row>
					<el-col :span="6">
						<div class="block form_title">储值设置</div>
					</el-col>
					<el-col :span="18">
						<el-row :gutter="12">
							<el-col :span="8">
								<el-card shadow="always" style="text-align: center;border-color: #333;">
									<p>储值卡 500元</p>
									<p style="font-size: 12px;">
										赠送金额<el-input v-model="money_500" placeholder="请输入赠送金额" style="width: 150px;margin: 0 10px;"></el-input>元
									</p>
								</el-card>
							</el-col>
							<el-col :span="8">
								<el-card shadow="always" style="text-align: center;border-color: #333;">
									<p>储值卡 1000元</p>
									<p style="font-size: 12px;">
										赠送金额<el-input v-model="money_1000" placeholder="请输入赠送金额" style="width: 150px;margin: 0 10px;"></el-input>元
									</p>
								</el-card>
							</el-col>
						</el-row>
					</el-col>
				</el-row>
			</div>
			<div class="block" v-if="active == 1">
				<el-row>
					<el-col :span="6">
						<div class="block form_title" style="font-size: 18px;">会员权益信息</div>
					</el-col>
					<el-col :span="18">
						<el-row>
							<h4>等级权益</h4>
						</el-row>
						<div class="lv-set block">
							<el-row>
								<el-col :span="4" style="text-align: center;">白银会员</el-col>
								<el-col :span="20" class="btn-r" style="padding-left: 20px;">
									享受预订订单折扣{{byzk}}折；会员勋章；会员营销优惠券权益
									<el-button type="primary" icon="el-icon-plus" style="width: 20px; height: 20px;padding: 0;" circle @click="openQyDialog(1)"></el-button>
								</el-col>
							</el-row>
							<el-row v-for="item in byqyList">
								<el-col :span="4" style="text-align: center;height: 40px;"></el-col>
								<el-col :span="20" class="btn-r" style="padding-left: 20px;">
									{{item.value=='freeDeposit'?'免押金':(item.value=='freeFindRoom'?'免查房':(item.value=='delayQuitRoom'?('整日租赁延迟退房至'+item.time+':00'):'升级大礼包'))}}
									<el-button type="text" icon="el-icon-edit" style="width: 20px; height: 20px;padding: 0;right: 50px;" circle @click="openQyDialog(1)"></el-button>
									<el-button type="text" icon="el-icon-delete" style="width: 20px; height: 20px;padding: 0;" circle @click="deleteThisQy(1, item)"></el-button>
								</el-col>
							</el-row>
						</div>
						<div class="lv-set block">
							<el-row>
								<el-col :span="4" style="text-align: center;">黄金会员</el-col>
								<el-col :span="20" class="btn-r" style="padding-left: 20px;">
									享受预订订单折扣{{hjzk}}折；会员勋章；会员营销优惠券权益
									<el-button type="primary" icon="el-icon-plus" style="width: 20px; height: 20px;padding: 0;" circle @click="openQyDialog(2)"></el-button>
								</el-col>
							</el-row>
							<el-row v-for="item in hjqyList">
								<el-col :span="4" style="text-align: center;height: 40px;"></el-col>
								<el-col :span="20" class="btn-r" style="padding-left: 20px;">
									{{item.value=='freeDeposit'?'免押金':(item.value=='freeFindRoom'?'免查房':(item.value=='delayQuitRoom'?('整日租赁延迟退房至'+item.time+':00'):'升级大礼包'))}}
									<el-button type="text" icon="el-icon-edit" style="width: 20px; height: 20px;padding: 0;right: 50px;" circle @click="openQyDialog(2)"></el-button>
									<el-button type="text" icon="el-icon-delete" style="width: 20px; height: 20px;padding: 0;" circle @click="deleteThisQy(2, item)"></el-button>
								</el-col>
							</el-row>
						</div>
						<div class="lv-set block">
							<el-row>
								<el-col :span="4" style="text-align: center;">铂金会员</el-col>
								<el-col :span="20" class="btn-r" style="padding-left: 20px;">
									享受预订订单折扣{{bjzk}}折；会员勋章；会员营销优惠券权益
									<el-button type="primary" icon="el-icon-plus" style="width: 20px; height: 20px;padding: 0;" circle @click="openQyDialog(3)"></el-button>
								</el-col>
							</el-row>
							<el-row v-for="item in bjqyList">
								<el-col :span="4" style="text-align: center;height: 40px;"></el-col>
								<el-col :span="20" class="btn-r" style="padding-left: 20px;">
									{{item.value=='freeDeposit'?'免押金':(item.value=='freeFindRoom'?'免查房':(item.value=='delayQuitRoom'?('整日租赁延迟退房至'+item.time+':00'):'升级大礼包'))}}
									<el-button type="text" icon="el-icon-edit" style="width: 20px; height: 20px;padding: 0;right: 50px;" circle @click="openQyDialog(3)"></el-button>
									<el-button type="text" icon="el-icon-delete" style="width: 20px; height: 20px;padding: 0;" circle @click="deleteThisQy(3, item)"></el-button>
								</el-col>
							</el-row>
						</div>
						<div class="lv-set block">
							<el-row>
								<el-col :span="4" style="text-align: center;">钻石会员</el-col>
								<el-col :span="20" class="btn-r" style="padding-left: 20px;">
									享受预订订单折扣{{zszk}}折；会员勋章；会员营销优惠券权益
									<el-button type="primary" icon="el-icon-plus" style="width: 20px; height: 20px;padding: 0;" circle @click="openQyDialog(4)"></el-button>
								</el-col>
							</el-row>
							<el-row v-for="item in zsqyList">
								<el-col :span="4" style="text-align: center;height: 40px;"></el-col>
								<el-col :span="20" class="btn-r" style="padding-left: 20px;">
									{{item.value=='freeDeposit'?'免押金':(item.value=='freeFindRoom'?'免查房':(item.value=='delayQuitRoom'?('整日租赁延迟退房至'+item.time+':00'):'升级大礼包'))}}
									<el-button type="text" icon="el-icon-edit" style="width: 20px; height: 20px;padding: 0;right: 50px;" circle @click="openQyDialog(4)"></el-button>
									<el-button type="text" icon="el-icon-delete" style="width: 20px; height: 20px;padding: 0;" circle @click="deleteThisQy(4, item)"></el-button>
								</el-col>
							</el-row>
						</div>
						<div class="lv-set block">
							<el-row>
								<el-col :span="4" style="text-align: center;">至尊会员</el-col>
								<el-col :span="20" class="btn-r" style="padding-left: 20px;">
									享受预订订单折扣{{zzzk}}折；会员勋章；会员营销优惠券权益
									<el-button type="primary" icon="el-icon-plus" style="width: 20px; height: 20px;padding: 0;" circle @click="openQyDialog(5)"></el-button>
								</el-col>
							</el-row>
							<el-row v-for="item in zzqyList">
								<el-col :span="4" style="text-align: center;height: 40px;"></el-col>
								<el-col :span="20" class="btn-r" style="padding-left: 20px;">
									{{item.value=='freeDeposit'?'免押金':(item.value=='freeFindRoom'?'免查房':(item.value=='delayQuitRoom'?('整日租赁延迟退房至'+item.time+':00'):'升级大礼包'))}}
									<el-button type="text" icon="el-icon-edit" style="width: 20px; height: 20px;padding: 0;right: 50px;" circle @click="openQyDialog(5)"></el-button>
									<el-button type="text" icon="el-icon-delete" style="width: 20px; height: 20px;padding: 0;" circle @click="deleteThisQy(5, item)"></el-button>
								</el-col>
							</el-row>
						</div>
						<el-row>
							<h4>更多权益功能敬请期待！</h4>
						</el-row>
					</el-col>
				</el-row>
			</div>
			<el-row style="margin-top: 30px;text-align: center;">
				<el-button type="primary" v-if="active == 0" @click="next">下一步，填写权益信息</el-button>
				<el-button type="primary" v-if="active == 1" @click="prev">上一步，填写基本信息</el-button>
				<el-button type="primary" v-if="active == 1" @click="save" v-loading.fullscreen.lock="fullscreenLoading">保存</el-button>
			</el-row>
		</el-form>

		<!-- 设置会员权益 -->
		<el-dialog
		  v-if="dialogShow"
		  :title="dialogTitle"
		  :close-on-click-modal="false"
		  :before-close="closeDialog"
		  :visible.sync="visible"
		  width="600px">
			<div class="block" style="width: 100%; line-height: 40px; fint-size: 16px;">
				<el-checkbox-group v-model="qyCheckInfo.qyCheckList">
					<el-row>
						<el-checkbox label="freeDeposit">免押金</el-checkbox>免押金
					</el-row>
					<el-row>
						<el-checkbox label="freeFindRoom">免查房</el-checkbox>
					</el-row>
					<el-row>
						<el-checkbox label="delayQuitRoom">
							整日租赁延迟退房至
              <el-input v-enterNumber v-rangeNumber v-model="qyCheckInfo.time"  placeholder="请输入整点（24小时制）" style="margin: 0 10px; max-width: 12rem;"></el-input>
							点
						</el-checkbox>
					</el-row>
					<el-row>
						<el-checkbox label="upgradeGift">升级大礼包</el-checkbox>
					</el-row>
				</el-checkbox-group>
			</div>
			<span slot="footer" class="dialog-footer">
				<el-button @click="closeDialog">取消</el-button>
				<el-button type="primary" @click="submitQy()">确定</el-button>
			</span>
		</el-dialog>
	</div>
</template>

<script>

	import HotelSelect from '../../../plugin/hotelSelect'

	export default {
		data () {
			return {
				active: 0,
        fullscreenLoading: false,
				formInline: {
					hotelId: '',
					hotelGrades: [],
					hoteCards: ''
				},
				levelList: ["白银会员", "黄金会员", "铂金会员", "钻石会员", "至尊会员"],
				qyList: [
					{ label: '免押金', value: 'freeDeposit' },
					{ label: '免查房', value: 'freeFindRoom' },
					{ label: '整日租赁延迟退房', value: 'delayQuitRoom' },
					{ label: '升级大礼包', value: 'upgradeGift' }
				],
				byzk: '',
				hjzk: '',
				bjzk: '',
				zszk: '',
				zzzk: '',
				byqyList: [],
				hjqyList: [],
				bjqyList: [],
				zsqyList: [],
				zzqyList: [],
				dialogShow: false,
				dialogTitle: '',
				visible: false,
				dialogType: 0,
				qyCheckInfo: {
					qyCheckList: [],
					time: ''
				},
				money_500: 0,
        money_500_id: '',
				money_1000: 0,
				money_1000_id: '',
				caozuoType: 'add'
			}
		},
		created () {

		},
		activated () {

		},
		methods: {
			changeSelectFunc(value){
				this.formInline.hotelId = value;
				this.queryInfo();
			},
			next(){
				this.active = 1;
			},
			prev(){
				this.active = 0;
			},
			queryInfo(){
				this.$http({
					url: this.$http.adornUrl_qfs('/hotel/grade/' + this.formInline.hotelId),
					method: 'get',
					params: this.$http.adornParams()
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.formInline = data.data;
						if(data.data.hotelGrades || data.data.hoteCards){
							this.caozuoType = 'update';
							for(var i = 0; i < data.data.hoteCards.length; i++){
								if(data.data.hoteCards[i].money == 500){
									this.money_500 = data.data.hoteCards[i].giveMoney;
									this.money_500_id = data.data.hoteCards[i].id;
								} else if(data.data.hoteCards[i].money == 1000){
									this.money_1000 = data.data.hoteCards[i].giveMoney;
									this.money_1000_id = data.data.hoteCards[i].id;
								}
							}
							for(var i = 0; i < data.data.hotelGrades.length; i++){
								if(data.data.hotelGrades[i].name == '白银会员'){
									this.byzk = data.data.hotelGrades[i].discount;
									this.byqyList = [];
									if(data.data.hotelGrades[i].hotelGradeRquity.rquitys){
                    for(var j = 0; j < data.data.hotelGrades[i].hotelGradeRquity.rquitys.length; j++){
                      this.byqyList.push({
                        value: data.data.hotelGrades[i].hotelGradeRquity.rquitys[j],
                        time: data.data.hotelGrades[i].hotelGradeRquity.rquitys[j] == 'delayQuitRoom' ? data.data.hotelGrades[i].hotelGradeRquity.delayQuitRoomHour : ''
                      })
                    }
                  }
								}else if(data.data.hotelGrades[i].name == '黄金会员'){
									this.hjzk = data.data.hotelGrades[i].discount;
									this.hjqyList = [];
									if(data.data.hotelGrades[i].hotelGradeRquity.rquitys){
                    for(var j = 0; j < data.data.hotelGrades[i].hotelGradeRquity.rquitys.length; j++){
                      this.hjqyList.push({
                        value: data.data.hotelGrades[i].hotelGradeRquity.rquitys[j],
                        time: data.data.hotelGrades[i].hotelGradeRquity.rquitys[j] == 'delayQuitRoom' ? data.data.hotelGrades[i].hotelGradeRquity.delayQuitRoomHour : ''
                      })
                    }
                  }
								}else if(data.data.hotelGrades[i].name == '铂金会员'){
									this.bjzk = data.data.hotelGrades[i].discount;
									this.bjqyList = [];
									if(data.data.hotelGrades[i].hotelGradeRquity.rquitys){
                    for(var j = 0; j < data.data.hotelGrades[i].hotelGradeRquity.rquitys.length; j++){
                      this.bjqyList.push({
                        value: data.data.hotelGrades[i].hotelGradeRquity.rquitys[j],
                        time: data.data.hotelGrades[i].hotelGradeRquity.rquitys[j] == 'delayQuitRoom' ? data.data.hotelGrades[i].hotelGradeRquity.delayQuitRoomHour : ''
                      })
                    }
                  }
								}else if(data.data.hotelGrades[i].name == '钻石会员'){
									this.zszk = data.data.hotelGrades[i].discount;
									this.zsqyList = [];
									if(data.data.hotelGrades[i].hotelGradeRquity.rquitys){
                    for(var j = 0; j < data.data.hotelGrades[i].hotelGradeRquity.rquitys.length; j++){
                      this.zsqyList.push({
                        value: data.data.hotelGrades[i].hotelGradeRquity.rquitys[j],
                        time: data.data.hotelGrades[i].hotelGradeRquity.rquitys[j] == 'delayQuitRoom' ? data.data.hotelGrades[i].hotelGradeRquity.delayQuitRoomHour : ''
                      })
                    }
                  }
								}else if(data.data.hotelGrades[i].name == '至尊会员'){
									this.zzzk = data.data.hotelGrades[i].discount;
									this.zzqyList = [];
									if(data.data.hotelGrades[i].hotelGradeRquity.rquitys){
                    for(var j = 0; j < data.data.hotelGrades[i].hotelGradeRquity.rquitys.length; j++){
                      this.zzqyList.push({
                        value: data.data.hotelGrades[i].hotelGradeRquity.rquitys[j],
                        time: data.data.hotelGrades[i].hotelGradeRquity.rquitys[j] == 'delayQuitRoom' ? data.data.hotelGrades[i].hotelGradeRquity.delayQuitRoomHour : ''
                      })
                    }
                  }
								}
							}
						} else {
              this.formInline = {
                hotelId: this.formInline.hotelId,
                hotelGrades: [],
                hoteCards: ''
              };
              this.byzk = '';
              this.hjzk = '';
              this.bjzk = '';
              this.zszk = '';
              this.zzzk = '';
              this.byqyList = [];
              this.hjqyList = [];
              this.bjqyList = [];
              this.zsqyList = [];
              this.zzqyList = [];
              this.money_500 = '';
              this.money_1000 = '';
              this.caozuoType = 'add';
            }
					} else {
						this.formInline = {
							hotelId: this.formInline.hotelId,
							hotelGrades: [],
							hoteCards: ''
						};
						this.byzk = '';
						this.hjzk = '';
						this.bjzk = '';
						this.zszk = '';
						this.zzzk = '';
						this.byqyList = [];
						this.hjqyList = [];
						this.bjqyList = [];
						this.zsqyList = [];
						this.zzqyList = [];
						this.money_500 = '';
						this.money_1000 = '';
						this.caozuoType = 'add';
					}
				})
			},
			handelQyList(list){
				var result = {}, qyArr = [];
				for(var i = 0; i < list.length; i++){
					qyArr.push(list[i].value);
					if(list[i].value == 'delayQuitRoom'){
						result['delayQuitRoomHour'] = list[i].time;
					}
				}
				if(qyArr.length > 0){
					result['rquitys'] = qyArr;
				}
				return result;
			},
			save(){
				// 保存
				var param = {
					'hotelId': this.formInline.hotelId,
					'hotelGrades': [{
						grade: 1,
						name: '白银会员',
						growthValue: 0,
						discount: this.byzk,
						hotelGradeRquity: this.handelQyList(this.byqyList)
					}, {
						grade: 2,
						name: '黄金会员',
						growthValue: 301,
						discount: this.hjzk,
						hotelGradeRquity: this.handelQyList(this.hjqyList)
					}, {
						grade: 3,
						name: '铂金会员',
						growthValue: 1001,
						discount: this.bjzk,
						hotelGradeRquity: this.handelQyList(this.bjqyList)
					}, {
						grade: 4,
						name: '钻石会员',
						growthValue: 3001,
						discount: this.zszk,
						hotelGradeRquity: this.handelQyList(this.zsqyList)
					}, {
						grade: 5,
						name: '至尊会员',
						growthValue: 6001,
						discount: this.zzzk,
						hotelGradeRquity: this.handelQyList(this.zzqyList)
					}],
					'hoteCards': [{
						'money': 500,
						'giveMoney': this.money_500,
            'id': this.money_500_id
					}, {
						'money': 1000,
						'giveMoney': this.money_1000,
            'id': this.money_1000_id
					}]
				};
				if(this.caozuoType == 'update'){
					for(var i = 0; i < param.hotelGrades.length; i++){
						/*for(var j = 0; j < this.formInline.hotelGrades.length; j++){
							if(param.hotelGrades[i].name == this.formInline.hotelGrades.name){
								param.hotelGrades[i]['id'] = this.formInline.hotelGrades.id
							}
						}*/
						this.formInline.hotelGrades.forEach((item) => {
               if(param.hotelGrades[i].name == item.name){
                 param.hotelGrades[i]['id'] = item.id;
               }
            })
					}
				}
				this.fullscreenLoading = true;
				this.$http({
					url: this.$http.adornUrl_qfs('/hotel/grade/addOrUpdate'),
					method: 'post',
					data: this.$http.adornData(param)
				}).then(({data}) => {
          this.fullscreenLoading = false;
					if (data && data.code === 0) {
            this.setSuccessDialogVisible = true;
            this.formInline = {
              hotelId: '',
              hotelGrades: [],
              hoteCards: ''
            };
            this.byzk = '';
            this.hjzk = '';
            this.bjzk = '';
            this.zszk = '';
            this.zzzk = '';
            this.byqyList = [];
            this.hjqyList = [];
            this.bjqyList = [];
            this.zsqyList = [];
            this.zzqyList = [];
            this.money_500 = '';
            this.money_1000 = '';
            this.caozuoType = 'add';
            this.active = 0;
            this.$router.push({name: "qfs-member/memberList",params: { gotoAddCouponVisiable: true }});
					} else {
						this.$message.error(data.msg);
					}
				}).catch(function(error) {
          console.log('发生错误！', error);
          this.$message.error("网络故障，请稍后再试");
          this.fullscreenLoading = false;
        });
			},
			openQyDialog(type){
				this.dialogShow = true;
				this.visible = true;
				type = parseInt(type);
				this.dialogType = type;
				this.dialogTitle = this.levelList[type - 1];
				var listArr = [this.byqyList, this.hjqyList, this.bjqyList, this.zsqyList, this.zzqyList];
				for(var i = 0; i < listArr[type - 1].length; i++){
					var item = listArr[type - 1][i];
					this.qyCheckInfo.qyCheckList.push(item.value);
					if(item.value == 'delayQuitRoom'){
						this.qyCheckInfo.time = item.time;
					}
				}
			},
			closeDialog(){
				this.dialogShow = false;
				this.dialogTitle = '';
				this.visible = false;
				this.dialogType = 0;
				this.qyCheckInfo = {
					qyCheckList: [],
					time: ''
				};
			},
			submitQy(){
				console.log(this.qyCheckInfo);
				if(this.dialogType == 1){
					this.byqyList = [];
					for(var i = 0; i < this.qyCheckInfo.qyCheckList.length; i++){
						var obj = {};
						obj['value'] = this.qyCheckInfo.qyCheckList[i];
						if(this.qyCheckInfo.qyCheckList[i] == 'delayQuitRoom'){
							obj['time'] = this.qyCheckInfo.time;
						}else{
							obj['time'] = '';
						}
						this.byqyList.push(obj);
					}
				}else if(this.dialogType == 2){
					this.hjqyList = [];
					for(var i = 0; i < this.qyCheckInfo.qyCheckList.length; i++){
						var obj = {};
						obj['value'] = this.qyCheckInfo.qyCheckList[i];
						if(this.qyCheckInfo.qyCheckList[i] == 'delayQuitRoom'){
							obj['time'] = this.qyCheckInfo.time;
						}else{
							obj['time'] = '';
						}
						this.hjqyList.push(obj);
					}
				}else if(this.dialogType == 3){
					this.bjqyList = [];
					for(var i = 0; i < this.qyCheckInfo.qyCheckList.length; i++){
						var obj = {};
						obj['value'] = this.qyCheckInfo.qyCheckList[i];
						if(this.qyCheckInfo.qyCheckList[i] == 'delayQuitRoom'){
							obj['time'] = this.qyCheckInfo.time;
						}else{
							obj['time'] = '';
						}
						this.bjqyList.push(obj);
					}
				}else if(this.dialogType == 4){
					this.zsqyList = [];
					for(var i = 0; i < this.qyCheckInfo.qyCheckList.length; i++){
						var obj = {};
						obj['value'] = this.qyCheckInfo.qyCheckList[i];
						if(this.qyCheckInfo.qyCheckList[i] == 'delayQuitRoom'){
							obj['time'] = this.qyCheckInfo.time;
						}else{
							obj['time'] = '';
						}
						this.zsqyList.push(obj);
					}
				}else if(this.dialogType == 5){
					this.zzqyList = [];
					for(var i = 0; i < this.qyCheckInfo.qyCheckList.length; i++){
						var obj = {};
						obj['value'] = this.qyCheckInfo.qyCheckList[i];
						if(this.qyCheckInfo.qyCheckList[i] == 'delayQuitRoom'){
							obj['time'] = this.qyCheckInfo.time;
						}else{
							obj['time'] = '';
						}
						this.zzqyList.push(obj);
					}
				}
				this.closeDialog();
			},
			deleteThisQy(type, data){
				if(type == 1){
					this.byqyList.splice(this.byqyList.indexOf(data), 1);
				}else if(type == 2){
					this.hjqyList.splice(this.hjqyList.indexOf(data), 1);
				}else if(type == 3){
					this.bjqyList.splice(this.bjqyList.indexOf(data), 1);
				}else if(type == 4){
					this.zsqyList.splice(this.zsqyList.indexOf(data), 1);
				}else if(type == 5){
					this.zzqyList.splice(this.zzqyList.indexOf(data), 1);
				}
			},
		},
    directives: {
      enterNumber: {
        // 指令的定义
        inserted: function (el) {
          el.addEventListener("keypress",function(e){
            e = e || window.event;
            let charcode = typeof e.charCode == 'number' ? e.charCode : e.keyCode;
            let re = /\d/;
            if(!re.test(String.fromCharCode(charcode)) && charcode > 9 && !e.ctrlKey){
              if(e.preventDefault){
                e.preventDefault();
              }else{
                e.returnValue = false;
              }
            }
          });
        }
      },
      rangeNumber: {
        bind: function(el,binding,vnode){
          el.addEventListener("keyup",function(e){
            console.log(vnode.context)
            let that = vnode.context;
            if(that.qyCheckInfo.time < 0 || that.qyCheckInfo.time > 24){
              that.qyCheckInfo.time = 1;
            }
          });
        }
      }
    },
		components: {
			HotelSelect
		}
	}
</script>

<style lang="scss">
	.line{
		height: 1px;
		width: 100%;
		margin: 10px auto;
		background: #c1c1c1;
	}
	.form_title{
		line-height: 40px;
		font-size: 24px;
		width: 150px;
		background: #f1f1f1;
		margin: 20px auto;
		padding: 20px;
		text-align: center;
		border-radius: 6px;
	}
	.baseInfo{
		line-height: 40px;
		font-size: 14px;
		span{
			display: inline-block;
		}
		.baseInfo_lv{
			width: 80px;
		}
		.baseInfo_num{
			width: 150px;
		}
	}
	.tip{
		position: relative;
		span{
			position: absolute;
			display: inline-block;
			color: #f00;
			top: 10px;
			right: 10px;
			font-size: 12px;
		}
	}
	.lv-set{
		margin-bottom: 20px;
		line-height: 40px;
		font-size: 14px;
		border-top: 1px solid #333;
		border-left: 1px solid #333;
		.el-row{
			border-bottom: 1px solid #333;
			.el-col{
				border-right: 1px solid #333;
			}
		}
	}
	.btn-r{
		position: relative;
		.el-button{
			position: absolute;
			top: 0;
			bottom: 0;
			right: 20px;
			margin: auto;
		}
	}
</style>
