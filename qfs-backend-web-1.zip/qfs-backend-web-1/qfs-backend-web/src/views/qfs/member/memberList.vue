<template>
	<div class="block">
		<el-row :gutter="40">
			<el-col :span="6">
				<el-card shadow="always" class="data-show">
					<span class="data-show-title">昨日新增会员</span>
					<span>{{dataInfo.yesterdayAddMember}}</span>
				</el-card>
			</el-col>
			<el-col :span="6">
				<el-card shadow="always" class="data-show">
					<span class="data-show-title">酒店会员总数</span>
					<span>{{dataInfo.hotelMemberTotal}}</span>
				</el-card>
			</el-col>
			<el-col :span="6">
				<el-card shadow="always" class="data-show">
					<span class="data-show-title">昨日会员消费</span>
					<span>{{dataInfo.yesterdayMemberConsume}}</span>
				</el-card>
			</el-col>
			<el-col :span="6">
				<el-card shadow="always" class="data-show">
					<span class="data-show-title">会员总消费</span>
					<span>{{dataInfo.memberTotalConsume}}</span>
				</el-card>
			</el-col>
		</el-row>

		<div class="search_area" style="margin-top: 30px;">
			<el-form :inline="true" :model="formInline" class="demo-form-inline" label-width="100px">
				<el-form-item label="酒店名称">
					<hotel-select :addressCode="formInline.addressCode" @changeSelectFunc="changeHotelSelectFunc"></hotel-select>
				</el-form-item>
				<el-form-item label="省市区">
					<ssq-select :ssqValuesArr="ssqValuesArr" @changeFunc="ssqChange"></ssq-select>
				</el-form-item>
				<el-form-item label="开通时间">
					<el-date-picker
					  v-model="memberTime"
					  type="daterange"
					  :editable="false"
					  align="center"
					  start-placeholder="开始日期"
					  end-placeholder="结束日期"
					  style="width: 400px;">
					</el-date-picker>
				</el-form-item>
				<br />
				<el-form-item label="用户账号">
					<el-input v-model="formInline.mobile" placeholder="请输入" style="width: 200px;"></el-input>
				</el-form-item>
				<el-form-item label="会员等级">
					<el-select v-model="formInline.level" placeholder="请选择" style="width: 200px;">
						<el-option
						  v-for="item in memberLevelList"
						  :key="item.value"
						  :label="item.label"
						  :value="item.value">
						</el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="累计消费金额">
          <el-select v-model="formInline.consumeType" placeholder="请选择" style="width: 200px;">
            <el-option
              v-for="item in consumeTypeList"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
				</el-form-item>
				<el-form-item label="最近一次消费">
					<el-date-picker
					  v-model="consumeTime"
					  type="daterange"
					  :editable="false"
					  align="center"
					  start-placeholder="开始日期"
					  end-placeholder="结束日期"
					  style="width: 400px;">
					</el-date-picker>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="queryListAndInfo">查询</el-button>
					<el-dropdown>
						<el-button type="primary">
							导出数据<i class="el-icon-arrow-down el-icon--right"></i>
						</el-button>
						<el-dropdown-menu slot="dropdown">
							<el-dropdown-item @click.native="downloadData(1)">选中用户</el-dropdown-item>
							<el-dropdown-item @click.native="downloadData(2)">全部用户</el-dropdown-item>
						</el-dropdown-menu>
					</el-dropdown>
					<el-dropdown>
						<el-button type="primary">
							批量操作<i class="el-icon-arrow-down el-icon--right"></i>
						</el-button>
						<el-dropdown-menu slot="dropdown">
							<el-dropdown-item @click.native="enableMember">启用</el-dropdown-item>
							<el-dropdown-item @click.native="unableMember">停用</el-dropdown-item>
							<el-dropdown-item @click.native="deleteMember">删除</el-dropdown-item>
						</el-dropdown-menu>
					</el-dropdown>
				</el-form-item>
			</el-form>
		</div>

		<div class="search_result">
			<el-table
			  :data="memberList"
			  border
			  stripe
			  @selection-change="selectionChangeHandle"
			  :v-loading="dataListLoading"
			  style="width: 100%">
				<el-table-column
				  type="selection"
				  header-align="center"
				  align="center"
				  width="50">
				</el-table-column>
        <el-table-column
          prop="id"
          label="用户ID"
          align="center"
          width="100">
        </el-table-column>
				<el-table-column
				  prop="hotelName"
				  label="归属酒店"
				  align="center"
				  width="100">
				</el-table-column>
				<el-table-column
				  prop="mobile"
				  label="用户账号"
				  align="center">
				</el-table-column>
				<el-table-column
				  label="开通时间"
				  align="center"
				  width="150">
					<template slot-scope="scope">
						{{ scope.row.registerMemberTime.substr(0, 10) }}
					</template>
				</el-table-column>
				<el-table-column
				  prop="levelName"
				  label="会员等级"
				  align="center"
				  width="150">
				</el-table-column>
				<el-table-column
				  prop="totalConsume"
				  label="累计消费"
				  align="center"
				  width="80">
				</el-table-column>
				<el-table-column
				  label="最近消费"
				  align="center">
					<template slot-scope="scope">
						{{ scope.row.lastConsumeTime.substr(0, 20).replace(/-/g,  "/").replace(/T/g,  " ") }}
					</template>
				</el-table-column>
				<el-table-column
				  prop="orderNumber"
				  label="订单量"
				  align="center">
				</el-table-column>
				<el-table-column
				  prop="balance"
				  label="储值详情"
				  align="center">
				</el-table-column>
				<el-table-column
				  label="操作"
				  align="center"
				  width="100">
					<template slot-scope="scope">
						<el-button
						  @click.native.prevent="openDialog_member(scope.row)"
						  type="text"
						  size="small">
						  查看详情
						</el-button>
					</template>
				</el-table-column>
			</el-table>

			<div class='block'>
				<el-pagination
				  @size-change='handleSizeChange'
				  @current-change='handleCurrentChange'
			      :current-page='paginationData.pageNumber'
				  :page-sizes='[10, 20, 30, 50, 100]'
				  :page-size='paginationData.pageSize'
				  :total='paginationData.totalPage'
				  layout='total, sizes, prev, pager, next, jumper'
				>
				</el-pagination>
			</div>
		</div>

		<!--详情弹窗-->
		<el-dialog
		  v-if="memberDialogShow"
		  title="会员详情"
		  :close-on-click-modal="false"
		  :before-close="closeMemberDialog"
		  :visible.sync="visible_1"
		  :fullscreen="true">
			<div class="block" style="width: 100%; line-height: 30px; fint-size: 14px;">
				<el-row style="text-align: center;">
					<el-col :span="4">
						<div style="width: 100%;"><img :src="memberInfo.avatar" style="width: 50px;margin: auto;height: 50px;" /></div>
						<el-tag style="margin-top: 10px;">{{memberInfo.levelName}}</el-tag>
					</el-col>
					<el-col :span="20" class="page_table_1">
						<el-row>
							<el-col :span="4">用户ID</el-col>
							<el-col :span="8">{{memberInfo.memberId}}</el-col>
							<el-col :span="4">性别</el-col>
							<el-col :span="8">{{memberInfo.sex == 1 ? '男' : (memberInfo.sex == 2 ? '女' : '未设置')}}</el-col>
						</el-row>
						<el-row>
							<el-col :span="4">手机号</el-col>
							<el-col :span="8">{{memberInfo.mobile}}</el-col>
							<el-col :span="4">生日</el-col>
							<el-col :span="8" v-if="!memberInfo.birthday">未设置</el-col>
							<el-col :span="8" v-if="memberInfo.birthday">{{memberInfo.birthday | formatDateByDate}}</el-col>
						</el-row>
						<el-row>
							<el-col :span="4">开通时间</el-col>
							<el-col :span="8">{{memberInfo.registerMemberTime | formatDateByDate}}</el-col>
							<el-col :span="4"></el-col>
							<el-col :span="8"></el-col>
						</el-row>
					</el-col>
				</el-row>
				<el-row>
					<h4>统计信息</h4>
				</el-row>
				<el-row style="width: 100%;text-align: center;" class="page_table_1">
					<el-col style="width: 20%;">消费金额</el-col>
					<el-col style="width: 20%;">订单数量</el-col>
					<el-col style="width: 20%;">成长值</el-col>
					<el-col style="width: 20%;">储值总额</el-col>
					<el-col style="width: 20%;">储值余额</el-col>
				</el-row>
				<el-row style="width: 100%;text-align: center;border-top: 0;" class="page_table_1">
					<el-col style="width: 20%;">¥{{memberInfo.memberCountInfoBean.consumeMoney | moneyToY}}</el-col>
					<el-col style="width: 20%;">{{memberInfo.memberCountInfoBean.orderNumber}}</el-col>
					<el-col style="width: 20%;">{{memberInfo.memberCountInfoBean.growthValue}}</el-col>
					<el-col style="width: 20%;">¥{{memberInfo.memberCountInfoBean.payMoney | moneyToY}}</el-col>
					<el-col style="width: 20%;">¥{{memberInfo.memberCountInfoBean.balance | moneyToY}}</el-col>
				</el-row>
				<el-row>
					<h4>储值记录</h4>
				</el-row>
				<el-table
				  :data="memberInfo.memberPayRecordBean"
				  style="width: 400px;">
					<el-table-column
					  label="储值金额">
						<template slot-scope="scope">
							¥{{scope.row.moeny | moneyToY}}
						</template>
					</el-table-column>
					<el-table-column
					  label="储值时间">
						<template slot-scope="scope">
							{{scope.row.time | formatDateByDate}}
						</template>
					</el-table-column>
				</el-table>
				<el-row>
					<h4>订单记录</h4>
				</el-row>

				<el-row class="page_table">
					<el-col :span="3">房型</el-col>
					<el-col :span="3">下单时间</el-col>
					<el-col :span="6">入离时间</el-col>
					<el-col :span="3">价格</el-col>
					<el-col :span="3">入住人</el-col>
					<el-col :span="2">状态</el-col>
					<el-col :span="4">操作</el-col>
				</el-row>
				<el-row class="page_body" v-for="item in orderListData">
					<el-row style="line-height: 20px;padding: 10px 0 10px 10px;border-right: 1px solid #666;">
						<span style="margin-right: 20px;">订单号：{{item.orderCode}}</span>
						<span style="margin-right: 20px;">酒店：{{item.hotelName}}</span>
						<el-tag type="warning">会员{{item.memberDiscount}}折</el-tag>
					</el-row>
					<el-row>
						<el-col :span="3">
							<p class="lh20">{{item.roomTypeName}}</p>
							<p class="lh20">共{{item.roomNumber}}间</p>
						</el-col>
						<el-col :span="3">
							<p class="lh40">{{item.orderTime | formatDate}}</p>
						</el-col>
						<el-col :span="6">
							<p class="lh20">{{item.startTime | formatDateByDate}}--{{item.endTime | formatDateByDate}}</p>
							<p class="lh20">共{{item.duration}}{{item.type == 0 ? '小时' : '天'}}</p>
						</el-col>
						<el-col :span="3">
							<p class="lh20">订单价 ¥{{item.roomFee | moneyToY}}</p>
							<p class="lh20">支付价 ¥{{item.payAmount | moneyToY}}</p>
						</el-col>
						<el-col :span="3">
							<p class="lh40">{{item.name + '  ' + item.mobile}}</p>
						</el-col>
						<el-col :span="2">
							<p class="lh40">{{item.status | statusFilter}}</p>
						</el-col>
						<el-col :span="4">
							<p class="lh40">
								<el-button type="text" @click="openOrderDialig(item)">查看详情</el-button>
							</p>
						</el-col>
					</el-row>
				</el-row>

				<div class='block'>
					<el-pagination
					  @size-change='handleSizeChange'
					  @current-change='handleCurrentChange'
					  :current-page='paginationData.pageNumber'
					  :page-sizes='[10, 20, 30, 50, 100]'
					  :page-size='paginationData.pageSize'
					  :total='paginationData.totalPage'
					  layout='total, sizes, prev, pager, next, jumper'
					>
					</el-pagination>
				</div>

			</div>
		</el-dialog>

    <!--会员入会红包弹框-->
    <el-dialog
      title="恭喜您成功开启了酒店专属会员计划"
      :visible.sync="goAddCouponDialogVisible"
      width="30%">
      <p style="font-weight: 700;">入会红包</p>
      <p style="color: #c1c1c1;">加入会员即送一张【入会优惠券】点击按钮前往设置</p>
      <span slot="footer" class="dialog-footer">
        <el-button @click="goAddCouponDialogVisible = false">稍后设置</el-button>
        <el-button type="primary" @click="gotoAddCoupon">设置入会优惠券</el-button>
      </span>
    </el-dialog>
		<!--详情弹窗-->
		<el-dialog
		  v-if="orderInfoDialogShow"
		  title="订单详情"
		  :close-on-click-modal="false"
		  :before-close="closeDialog"
		  :visible.sync="visible"
		  width="600px">
			<div class="block" style="width: 100%; line-height: 30px; fint-size: 14px;">
				<el-row>
					{{orderInfo.hotelName}}
				</el-row>
				<el-row>
					<span>订单状态：{{orderInfo.status | statusFilter}}</span>
					<span>订单号：{{orderInfo.orderCode}}</span>
				</el-row>
				<div class="dialog_line"></div>
				<el-row>
					入住房间：{{orderInfo.roomName}}
				</el-row>
				<el-row>
					订单类型：{{orderInfo.type == 0 ? '分时租赁 ' : '整日租赁 '}}{{orderInfo.duration}}{{orderInfo.type == 0 ? '小时' : '天'}}小时
				</el-row>
				<el-row>
					下单时间：{{orderInfo.orderTime | formatDateByDate}}
				</el-row>
				<el-row>
					入离时间：{{orderInfo.startTime | formatDateByDate}}-{{orderInfo.endTime | formatDateByDate}}
				</el-row>
				<div class="dialog_line"></div>
				<el-row>
					入住人：{{orderInfo.name}}
				</el-row>
				<el-row>
					入住人手机号：{{orderInfo.mobile}}
				</el-row>
				<div class="dialog_line"></div>
				<el-row>
					订单总额：{{orderInfo.roomFee | moneyToY}}元
				</el-row>
				<el-row>
					优惠券：{{orderInfo.couponName}}
				</el-row>
				<el-row>
					酒店会员：会员折扣{{orderInfo.memberDiscount}}折
				</el-row>
				<el-row>
					平台佣金：0元
				</el-row>
				<el-row>
					储值卡抵扣：{{orderInfo.cardDeduction}}元
				</el-row>
				<el-row>
					在线支付：{{orderInfo.payAmount}}元
				</el-row>
			</div>
		</el-dialog>
	</div>
</template>

<script>

	import HotelSelect from '@/plugin/hotelSelect'
	import SsqSelect from '@/plugin/ssqSelect'
	import {formatDate} from '@/utils'

	export default {
		data () {
			return {
				memberLevelList: [
					{ label: '全部', value: ''},
					{ label: '白银会员', value: 1},
					{ label: '黄金会员', value: 2},
					{ label: '铂金会员', value: 3},
					{ label: '钻石会员', value: 4},
					{ label: '至尊会员', value: 5}
				],
        goAddCouponDialogVisible: false,
				dataInfo: {
					yesterdayAddMember: '',
					hotelMemberTotal: '',
					yesterdayMemberConsume: '',
					memberTotalConsume: ''
				},
        consumeTypeList: [
          {min:0, max:500, label: '0 - 500', value: 0},
          {min:500, max:1000, label: '500 - 1000', value: 1},
          {min:1000, max:2000, label: '1000 - 2000', value: 2},
          {min:2000, max:4000, label: '2000 - 4000', value: 3},
          {min:4000, max: null, label: '4000以上', value: 4}
        ],
				formInline: {
					hotelId: '',
					mobile: '',
					addressCode: '',
					memberStartTime: '',
					memberEndTime: '',
					consumeStartTime: '',
					consumeEndTime: '',
          consumeType: 0,
					level: '',
					consumeMin: '',
					consumeMax: ''
				},
				ssqValuesArr: [],
				memberTime: [],
				consumeTime: [],
				dataListLoading: false,
				memberList: [],
				paginationData: {
					pageNumber: 1,
					pageSize: 20,
					totalPage: 0
				},
				dataListSelections: [],
				firstIn: true,
				memberDialogShow: false,
				visible_1: false,
				memberInfo: {},
				orderListData: [],
				paginationData: {
					pageNumber: 1,
					pageSize: 20,
					totalPage: 0
				},
				orderInfoDialogShow: false,
				visible: false,
				orderInfo: {}
			}
		},
		created () {

		},
		activated () {
      if(this.$route.params.gotoAddCouponVisiable == true){
        this.goAddCouponDialogVisible = true;
      }
		},
		methods: {
			closeDialog(){
				this.orderInfoDialogShow = false;
				this.visible = false;
				this.orderInfo = {};
			},
			openOrderDialig(obj){
				this.orderInfo = obj;
				this.orderInfoDialogShow = true;
				this.visible = true;
			},
			openDialog_member(item){
				this.$http({
					url: this.$http.adornUrl_qfs('/member/detail'),
					method: 'get',
					params: this.$http.adornParams({
						hotelId: item.hotelId,
						memberId: item.memberId
					})
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.memberInfo = data.data;
						this.memberInfo['levelName'] = item.levelName;
						this.memberDialogShow = true;
						this.visible_1 = true;

						this.$http({
							url: this.$http.adornUrl_qfs('/roomOrder/member'),
							method: 'get',
							params: this.$http.adornParams({
								hotelId: item.hotelId,
								memberId: item.memberId,
								pageNum: this.paginationData.pageNumber,
								pageSize: this.paginationData.pageSize
							})
						}).then(({data}) => {
							if (data && data.code === 0) {
								this.orderListData = data.data.list ? data.data.list : [];
								this.paginationData.totalPage = data.data.totalCount;
							} else {
								this.orderListData = [];
								this.paginationData.totalPage = 0;
							}
						})

					}
				})
			},
      gotoAddCoupon(){
			  this.goAddCouponDialogVisible = false;
        this.$router.push({name: 'qfs-market/addCoupon' });
      },
			closeMemberDialog(){
				this.memberDialogShow = false;
				this.visible_1 = false;
			},
			queryListAndInfo(){
				this.queryList();
				this.queryInfo();
			},
			ssqChange(result){
				if(result.length == 0){
					this.formInline.addressCode = '';
					this.ssqValuesArr = [];
				}else{
					this.formInline.addressCode = result[2].key;
					this.ssqValuesArr = [result[0].value, result[1].value, result[2].value];
				}
			},
			changeHotelSelectFunc(value){
				this.formInline.hotelId = value;
				if(this.firstIn){
					this.firstIn = false;
					this.queryList();
					this.queryInfo();
				}
			},
			queryInfo(){
				this.$http({
					url: this.$http.adornUrl_qfs('/member/list/count'),
					method: 'get',
					params: this.$http.adornParams({
						hotelId: this.formInline.hotelId
					})
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.dataInfo = data.data;
					}
				})
			},
			queryList(){
				this.dataListLoading = true;
				if(this.memberTime.length == 2){
					this.formInline.memberStartTime = this.memberTime[0];
					this.formInline.memberEndTime = this.memberTime[1];
				}
				if(this.consumeTime.length == 2){
					this.formInline.consumeStartTime = this.consumeTime[0];
					this.formInline.consumeEndTime = this.consumeTime[1];
				}
        this.formInline.consumeMin = this.consumeTypeList[this.formInline.consumeType].min
        this.formInline.consumeMax = this.consumeTypeList[this.formInline.consumeType].max
				this.$http({
					url: this.$http.adornUrl_qfs('/member/list'),
					method: 'get',
					params: this.$http.adornParams(Object.assign({
						'pageNum': this.paginationData.pageNumber,
						'pageSize': this.paginationData.pageSize,
					}, this.formInline))
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.memberList = data.data.list;
						this.paginationData.totalPage = data.data.totalCount;
					} else {
						this.memberList = [];
						this.paginationData.totalPage = 0;
					}
					this.dataListLoading = false;
				})
			},
			handleSizeChange(val){
				this.paginationData.pageSize = val;
				this.paginationData.pageNumber = 1;
				this.queryList();
			},
			handleCurrentChange(val){
				this.paginationData.pageNumber = val;
				this.queryList();
			},
			selectionChangeHandle (val) {
				// 多选
				this.dataListSelections = val;
			},
			downloadData(type){
				if(type == 1){
					if(this.dataListSelections.length == 0){
						this.$message.error('请先选择要操作的会员数据');

					}else{
            let ids = [];
            this.dataListSelections.forEach((item) => {
              ids.push(item.id);
            });
            this.exportHandler(ids);
					}
				}else if(type == 2){
          let ids = [];
          this.memberList.forEach((item) => {
            ids.push(item.id);
          });
          this.exportHandler(ids);
				}
			},
      exportHandler(ids){
        let idsParam = ids.join("&ids=");
        window.open(this.$http.adornUrl_qfs('/member/export?ids='+idsParam));
      },
			enableMember(){
				if(this.dataListSelections.length == 0){
					this.$message.error('请先选择要操作的会员数据');
				}else{
          this.$message.info('敬请期待');
				}
			},
			unableMember(){
				if(this.dataListSelections.length == 0){
					this.$message.error('请先选择要操作的会员数据');
				}else{
          this.$message.info('敬请期待');
				}
			},
			deleteMember(){
				if(this.dataListSelections.length == 0){
					this.$message.error('请先选择要操作的会员数据');
				}else{
          this.$message.info('敬请期待');
				}
			}
		},
		components: {
			HotelSelect,
			SsqSelect
		},
		filters: {
			formatDate(time){
				if(!time){
					return '';
				}
				let date = new Date(time * 1000);
				return formatDate(date, 'yyyy-MM-dd');
			},
			formatDateByDate(time){
        let date= new Date(time);
        return formatDate(date, 'yyyy-MM-dd');
			},
			moneyToY(money){
				return money / 100;
			},
			statusFilter(status){
				var result = '';
				switch(status){
					case 0:
						result = '待支付';
						break;
					case 1:
						result = '待入住';
						break;
					case 2:
						result = '待反馈';
						break;
					case 3:
						result = '已取消';
						break;
					case 4:
						result = '退款中';
						break;
					case 5:
						result = '已退款';
						break;
					case 6:
						result = '已完成';
						break;
					case 7:
						result = '待确认';
						break;
					default:
						result = '未知状态';
				}
				return result;
			}
		}
	}
</script>

<style lang="scss">
	.data-show{
		background: #3ebbff;
		span{
			display: inline-block;
			width: 100%;
			line-height: 32px;
			font-size: 24px;
			text-align: center;
			color: #fff;
		}
		span.data-show-title{
			font-size: 18px;
		}
	}
	.page_table_1{
		border-left: 1px solid #666;
		border-top: 1px solid #666;
		.el-col{
			border-right: 1px solid #666;
			border-bottom: 1px solid #666;
			min-height: 30px;
		}
	}
	.page_table{
		font-size: 16px;
		font-weight: bold;
		line-height: 30px;
		border-bottom: 1px solid #666;
		border-left: 1px solid #666;
		border-top: 1px solid #666;
		.el-col{
			padding: 10px 0 10px 10px;
			border-right: 1px solid #666;
		}
	}
	.page_body{
		border-left: 1px solid #666;
		.el-row{
			border-bottom: 1px solid #666;
			.el-col{
				padding: 10px 0 10px 10px;
				border-right: 1px solid #666;
			}
		}
		p{
			margin: 0;
			font-size: 14px;
		}
		p.lh20{
			line-height: 20px;
		}
		p.lh40{
			line-height: 40px;
		}
	}
</style>
