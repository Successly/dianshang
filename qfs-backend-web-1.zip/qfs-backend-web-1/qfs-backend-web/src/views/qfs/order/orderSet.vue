<template>
	<div class="block">
		<el-form :model="formInline" label-width="100px">
			<el-form-item label="酒店名称">
				<hotel-select @changeSelectFunc="changeSelectFunc"></hotel-select>
			</el-form-item>
			<el-row>
				分时租赁退款政策
			</el-row>
			<el-form-item label="是否允许退款">
				<el-radio v-model="formInline.timeRefundSwitch" label="1">是</el-radio>
				<el-radio v-model="formInline.timeRefundSwitch" label="0">否</el-radio>
				<span>（允许即为全款退款）</span>
			</el-form-item>
			<el-form-item label="退款时间限制">
				<el-row style="margin-bottom: 0.6rem;">
          <el-radio v-model="formInline.timeHourSwitch" label="1">
            入住前<el-input v-model="formInline.timeHourValue" placeholder="请输入" style="width: 100px; margin: 0 1rem;"></el-input>小时允许退款
          </el-radio>
				</el-row>
				<el-row>
          <el-radio v-model="formInline.timeHourSwitch" label="0">
            入住前<el-input v-model="formInline.timeDayValue" placeholder="请输入" style="width: 100px; margin: 0 1rem;"></el-input>天允许退款
          </el-radio>
				</el-row>
			</el-form-item>
			<el-row>
				整日租赁退款政策
			</el-row>
			<el-form-item label="是否允许退款">
				<el-radio v-model="formInline.dayRefundSwitch" label="1">是</el-radio>
				<el-radio v-model="formInline.dayRefundSwitch" label="0">否</el-radio>
				<span>（允许即为全款退款）</span>
			</el-form-item>
			<el-form-item label="退款时间限制">
				<el-row style="margin-bottom: 0.6rem;">
          <el-radio v-model="formInline.daySpotSwitch" label="1">
            入住当天<el-input v-model="formInline.daySpotValue" placeholder="请输入" style="width: 100px; margin: 0 1rem;"></el-input>:00前允许退款
          </el-radio>
				</el-row>
				<el-row>
          <el-radio v-model="formInline.daySpotSwitch" label="0">
            入住前<el-input v-model="formInline.dayValue" placeholder="请输入" style="width: 100px; margin: 0 1rem;"></el-input>天允许退款
          </el-radio>
				</el-row>
			</el-form-item>
			<el-row>
				订单提醒【试运营3个月（2019.03-2019.05），试运营期间不收取费用】
			</el-row>
			<el-form-item label="入住订单">
				<el-row>
					<el-checkbox v-model="checkSmsFlag" @change="changeFlag(1)">
						短信提醒
						<el-input v-model="formInline.checkSmsMobile" placeholder="请输入" style="width: 150px;margin-left: 20px;" :disable="!checkSmsFlag"></el-input>
					</el-checkbox>
				</el-row>
				<el-row>
					<el-checkbox v-model="checkVoiceFlag" @change="changeFlag(2)">
						语音提醒
						<el-input v-model="formInline.checkVoiceMobile" placeholder="请输入" style="width: 150px;margin-left: 20px;" :disable="!checkVoiceFlag"></el-input>
					</el-checkbox>
				</el-row>
			</el-form-item>
			<el-form-item label="取消订单">
				<el-row>
					<el-checkbox v-model="cancelSmsFlag" @change="changeFlag(3)">
						短信提醒
						<el-input v-model="formInline.cancelSmsMobile" placeholder="请输入" style="width: 150px;margin-left: 20px;" :disable="!cancelSmsFlag"></el-input>
					</el-checkbox>
				</el-row>
				<el-row>
					<el-checkbox v-model="cancelVoiceFlag" @change="changeFlag(4)">
						语音提醒
						<el-input v-model="formInline.cancelVoiceMobile" placeholder="请输入" style="width: 150px;margin-left: 20px;" :disable="!cancelVoiceFlag"></el-input>
					</el-checkbox>
				</el-row>
			</el-form-item>
		</el-form>
		<el-row style="margin-top: 30px;text-align: center;">
			<el-button type="primary" @click="save">保存</el-button>
		</el-row>
	</div>
</template>

<script>

	import HotelSelect from '@/plugin/hotelSelect'

	export default {
		data () {
			return {
				formInline: {
					hotelId: '',
					timeRefundSwitch: '0',
					timeHourSwitch: '1',
					timeHourValue: '',
					timeDaySwitch: '0',
					timeDayValue: '',
					dayRefundSwitch: '1',
					daySpotSwitch: '1',
					daySpotValue: '',
					daySwitch: '0',
					dayValue: '',
					checkSmsMobile: '',
					checkVoiceMobile: '',
					cancelSmsMobile: '',
					cancelVoiceMobile: ''
				},
				timeHourSwitchFlag: true,
				timeDaySwitchFlag: true,
				daySpotSwitchFlag: true,
				daySwitchFlag: true,
				checkSmsFlag: false,
				checkVoiceFlag: false,
				cancelSmsFlag: false,
				cancelVoiceFlag: false,
				caozuoType: 'add'
			}
		},
		created () {
			// 查询房型列表
		},
		activated () {

		},
		methods: {
			changeSelectFunc(value){
				this.formInline.hotelId = value;
				this.queryInfo();
			},
			changeFlag(type){
				if(type == 1){
					if(!this.checkSmsFlag){
						this.formInline.checkSmsMobile = '';
					}
				}else if(type == 2){
					if(!this.checkVoiceFlag){
						this.formInline.checkVoiceMobile = '';
					}
				}else if(type == 3){
					if(!this.cancelSmsFlag){
						this.formInline.cancelSmsMobile = '';
					}
				}else if(type == 4){
					if(!this.cancelVoiceFlag){
						this.formInline.cancelVoiceMobile = '';
					}
				}
			},
			queryInfo(){
				this.$http({
					url: this.$http.adornUrl_qfs('/hotelOrderSetup/info'),
					method: 'get',
					params: this.$http.adornParams({
						hotelId: this.formInline.hotelId
					})
				}).then(({data}) => {
					if (data && data.code === 0) {

						if(data.data != null){
              this.caozuoType = 'update';
              this.formInline = data.data;
              this.formInline.timeHourSwitch = data.data.timeHourSwitch.toString();
              this.formInline.daySpotSwitch = data.data.daySpotSwitch.toString();
              this.timeHourSwitchFlag = data.data.timeHourSwitch == 1 ? true : false;
              this.timeDaySwitchFlag = data.data.timeDaySwitch == 1;
              this.daySpotSwitchFlag = data.data.daySpotSwitch == 1 ? true :false;
              this.daySwitchFlag = data.data.daySwitch == 1;

              this.checkSmsFlag = data.data.checkSmsMobile != '';
              this.checkVoiceFlag = data.data.checkVoiceMobile != '';
              this.cancelSmsFlag = data.data.cancelSmsMobile != '';
              this.cancelVoiceFlag = data.data.cancelVoiceMobile != '';
              this.formInline.timeRefundSwitch = this.formInline.timeRefundSwitch + '';
              this.formInline.dayRefundSwitch = this.formInline.dayRefundSwitch + '';
            }else{
              this.caozuoType = 'add';
              console.log("formInline",this.formInline);

                this.formInline.timeRefundSwitch = '0';
                this.formInline.timeHourSwitch = '1';
                this.formInline.timeHourValue = '';
                this.formInline.timeDaySwitch = '0';
                this.formInline.timeDayValue = '';
                this.formInline.dayRefundSwitch = '1';
                this.formInline.daySpotSwitch = '1';
                this.formInline.daySpotValue = '';
                this.formInline.daySwitch = '0';
                this.formInline.dayValue = '';
                this.formInline.checkSmsMobile = '';
                this.formInline.checkVoiceMobile = '';
                this.formInline.cancelSmsMobile = '';
                this.formInline.cancelVoiceMobile = '';
              this.timeHourSwitchFlag = true;
              this.timeDaySwitchFlag = false;
              this.daySpotSwitchFlag = true;
              this.daySwitchFlag = false;
              this.checkSmsFlag = false;
              this.checkVoiceFlag = false;
              this.cancelSmsFlag = false;
              this.cancelVoiceFlag = false
            }




					}else{
						this.caozuoType = 'add';

            this.formInline.timeRefundSwitch = '0';
            this.formInline.timeHourSwitch = '1';
            this.formInline.timeHourValue = '';
            this.formInline.timeDaySwitch = '0';
            this.formInline.timeDayValue = '';
            this.formInline.dayRefundSwitch = '1';
            this.formInline.daySpotSwitch = '1';
            this.formInline.daySpotValue = '';
            this.formInline.daySwitch = '0';
            this.formInline.dayValue = '';
            this.formInline.checkSmsMobile = '';
            this.formInline.checkVoiceMobile = '';
            this.formInline.cancelSmsMobile = '';
            this.formInline.cancelVoiceMobile = '';
						this.timeHourSwitchFlag = true;
						this.timeDaySwitchFlag = false;
						this.daySpotSwitchFlag = true;
						this.daySwitchFlag = false;
						this.checkSmsFlag = false;
						this.checkVoiceFlag = false;
						this.cancelSmsFlag = false;
						this.cancelVoiceFlag = false
					}
				})
			},
			save(){
        this.formInline.timeHourSwitch = this.formInline.timeHourSwitch == 1 ? 1 : 0;
        this.formInline.timeDaySwitch = this.formInline.timeHourSwitch == 1 ? 0 : 1;
        this.formInline.daySpotSwitch = this.formInline.daySpotSwitch == 1 ? 1 : 0;
        this.formInline.daySwitch = this.formInline.daySpotSwitch == 1 ? 0 : 1;
				this.$http({
					url: this.$http.adornUrl_qfs(this.caozuoType == 'add' ? '/hotelOrderSetup/save' : '/hotelOrderSetup/update'),
					method: 'post',
					data: this.$http.adornData(this.formInline)
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.$message({
							message: '操作成功',
							type: 'success',
							duration: 1500,
							onClose: () => {
								this.queryInfo();
							}
						})
					}else{
						this.$message.error(data.msg);
					}
				})
			}
		},
		components: {
			HotelSelect
		}
	}
</script>

<style lang="scss">

</style>
