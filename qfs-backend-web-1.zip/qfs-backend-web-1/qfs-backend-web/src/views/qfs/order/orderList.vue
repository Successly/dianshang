<template>
	<div class="block">
		<el-tabs v-model="formInline.status" @tab-click="handleClick">
			<el-tab-pane label="待确认" name="7"></el-tab-pane>
			<el-tab-pane label="待入住" name="1"></el-tab-pane>
			<el-tab-pane label="已完成" name="6"></el-tab-pane>
			<el-tab-pane label="已取消" name="3"></el-tab-pane>
		</el-tabs>

		<el-form :inline="true" :model="formInline" class="demo-form-inline" label-width="80px">
			<el-form-item label="酒店名称">
				<hotel-select :addressCode="formInline.addressCode" @changeSelectFunc="changeSelectFunc"></hotel-select>
			</el-form-item>
			<el-form-item label="省市区">
				<ssq-select :ssqValuesArr="ssqCheckedArr" @changeFunc="ssqChange"></ssq-select>
			</el-form-item>
			<el-form-item label="房型">
        <el-input v-model="formInline.roomShap" placeholder="请输入" style="width: 200px;"></el-input>
			</el-form-item>
			<el-form-item label="入住人">
				<el-input v-model="formInline.name" placeholder="请输入" style="width: 200px;"></el-input>
			</el-form-item>
			<el-form-item label="手机号">
				<el-input v-model="formInline.mobile" placeholder="请输入" style="width: 200px;"></el-input>
			</el-form-item>
			<el-form-item label="订单号">
				<el-input v-model="formInline.orderCode" placeholder="请输入" style="width: 200px;"></el-input>
			</el-form-item>
			<el-form-item label="下单时间">
				<el-radio v-model="formInline.type" label="">全部</el-radio>
				<el-radio v-model="formInline.type" label="1">今天</el-radio>
				<el-radio v-model="formInline.type" label="2">昨天</el-radio>
				<el-radio v-model="formInline.type" label="3">最近7天</el-radio>
			</el-form-item>
			<el-form-item>
				<el-button type="primary" @click="queryList">查询</el-button>
			</el-form-item>
		</el-form>

		<el-row class="page_table">
			<el-col :span="3">房型</el-col>
			<el-col :span="3">下单时间</el-col>
			<el-col :span="6">入离时间</el-col>
			<el-col :span="3">价格</el-col>
			<el-col :span="3">入住人</el-col>
			<el-col :span="2">状态</el-col>
			<el-col :span="4">操作</el-col>
		</el-row>
		<el-row class="page_body" v-for="item in orderListData">
			<el-row style="line-height: 20px;padding: 10px 0 10px 10px;border-right: 1px solid #666;">
				<span style="margin-right: 20px;">订单号：{{item.orderCode}}</span>
				<span style="margin-right: 20px;">酒店：{{item.hotelName}}</span>
				<el-tag type="warning">会员{{item.memberDiscount}}折</el-tag>
			</el-row>
			<el-row>
				<el-col :span="3">
					<p class="lh20">{{item.roomName}}</p>
					<p class="lh20">共{{item.roomNumber}}间</p>
				</el-col>
				<el-col :span="3">
					<p class="lh40">{{item.createTime | formatDate}}</p>
				</el-col>
				<el-col :span="6">
					<p class="lh20">{{item.startTime | formatDate}}--{{item.endTime | formatDate}}</p>
					<p class="lh20">共{{item.duration}}{{item.type == 0 ? '小时' : '天'}}</p>
				</el-col>
				<el-col :span="3">
					<p class="lh20">订单价 ¥{{item.roomFee | moneyToY}}</p>
					<p class="lh20">支付价 ¥{{item.payAmount | moneyToY}}</p>
				</el-col>
				<el-col :span="3">
					<p class="lh40">{{item.name + '  ' + item.mobile}}</p>
				</el-col>
				<el-col :span="2">
					<p class="lh40">{{item.status | statusFilter}}</p>
				</el-col>
				<el-col :span="4">
					<p class="lh40">
						<el-button type="text" @click="openDialig(item)">查看详情</el-button>
						<el-button type="text" v-if="item.status == 7 || item.status == 1" @click="updateOrderStatus(item.id, item.status)">确认</el-button>
					</p>
				</el-col>
			</el-row>
		</el-row>

		<div class='block'>
			<el-pagination
			  @size-change='handleSizeChange'
			  @current-change='handleCurrentChange'
			  :current-page='paginationData.pageNumber'
			  :page-sizes='[10, 20, 30, 50, 100]'
			  :page-size='paginationData.pageSize'
			  :total='paginationData.totalPage'
			  layout='total, sizes, prev, pager, next, jumper'
			>
			</el-pagination>
		</div>

		<!--详情弹窗-->
		<el-dialog
		  v-if="orderInfoDialogShow"
		  title="订单详情"
		  :close-on-click-modal="false"
		  :before-close="closeDialog"
		  :visible.sync="visible"
		  width="600px">
			<div class="block" style="width: 100%; line-height: 30px; fint-size: 14px;">
				<el-row>
					{{orderInfo.hotelName}}
				</el-row>
				<el-row>
					<span>订单状态：{{orderInfo.status | statusFilter}}</span>
					<span>订单号：{{orderInfo.orderCode}}</span>
				</el-row>
				<div class="dialog_line"></div>
				<el-row>
					入住房间：{{orderInfo.roomName}}
				</el-row>
				<el-row>
					订单类型：{{orderInfo.type == 0 ? '分时租赁 ' : '整日租赁 '}}{{orderInfo.duration}}{{orderInfo.type == 0 ? '小时' : '天'}}
				</el-row>
				<el-row>
					下单时间：{{orderInfo.createTime | formatDate}}
				</el-row>
				<el-row>
					入离时间：{{orderInfo.startTime | formatDate}}-{{orderInfo.endTime | formatDate}}
				</el-row>
				<div class="dialog_line"></div>
				<el-row>
					入住人：{{orderInfo.name}}
				</el-row>
				<el-row>
					入住人手机号：{{orderInfo.mobile}}
				</el-row>
				<div class="dialog_line"></div>
				<el-row>
					订单总额：{{orderInfo.roomFee | moneyToY}}元
				</el-row>
				<el-row>
					优惠券：{{orderInfo.couponAmount | moneyToY}}元
				</el-row>
				<el-row>
					酒店会员：会员折扣
          {{orderInfo.memberDiscount}}折
				</el-row>
				<el-row>
					平台佣金：0元
				</el-row>
				<el-row>
					储值卡抵扣：{{orderInfo.cardDeduction | moneyToY}}元
				</el-row>
				<el-row>
					在线支付：{{orderInfo.payAmount | moneyToY}}元
				</el-row>
			</div>
		</el-dialog>
	</div>
</template>

<script>

	import HotelSelect from '@/plugin/hotelSelect'
	import SsqSelect from '@/plugin/ssqSelect'
	import {formatDate} from '@/utils'

	export default {
		data () {
			return {
				formInline: {
					status: '7',
					hotelId: '',
					roomShap: '',
					name: '',
					mobile: '',
					orderCode: '',
					province: '',
					city: '',
					district: '',
					type: '',
          addressCode: ''
				},
				ssqCheckedArr: [],
				// roomShapeList: [{label: '全部', value: ''}],
				firstIn: true,
				orderListData: [],
				paginationData: {
					pageNumber: 1,
					pageSize: 20,
					totalPage: 0
				},
				orderInfoDialogShow: false,
				visible: false,
				orderInfo: {}
			}
		},
		created () {
			// 查询房型列表
		},
		activated () {
			this.formInline.status = this.$route.params.activeTab == undefined ? '7' : this.$route.params.activeTab;
		},
		methods: {
			ssqChange(result){
				if(result.length == 0){
					this.formInline.province = '';
					this.formInline.city = '';
					this.formInline.district = '';
					this.ssqCheckedArr = [];
          this.formInline.addressCode = '';
				}else{
					this.formInline.province = result[0].value;
					this.formInline.city = result[1].value;
					this.formInline.district = result[2].value;
					this.ssqCheckedArr = [result[0].value, result[1].value, result[2].value];
          this.formInline.addressCode = result[2].key;
				}
			},
			changeSelectFunc(value){
				this.formInline.hotelId = value;
				if(this.firstIn){
					this.firstIn = false;
					this.queryList();
				}
			},
			queryList(){
				// 查询列表
				this.$http({
					url: this.$http.adornUrl_qfs('/roomOrder/adminList'),
					method: 'post',
					data: this.$http.adornData(Object.assign({
						'pageNum': this.paginationData.pageNumber,
						'pageSize': this.paginationData.pageSize
					}, this.formInline))
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.orderListData = data.data.list ? data.data.list : [];
						this.paginationData.totalPage = data.data.totalCount;
					} else {
						this.orderListData = [];
						this.paginationData.totalPage = 0;
					}
				})
			},
			handleClick(){
				this.queryList();
			},
			handleSizeChange(val){
				this.paginationData.pageSize = val;
				this.paginationData.pageNumber = 1;
				this.queryList();
			},
			handleCurrentChange(val){
				this.paginationData.pageNumber = val;
				this.queryList();
			},
			closeDialog(){
				this.orderInfoDialogShow = false;
				this.visible = false;
				this.orderInfo = {};
			},
			openDialig(obj){
				this.orderInfo = obj;
				this.orderInfoDialogShow = true;
				this.visible = true;
			},
			updateOrderStatus(orderId, oldStatus){
				var param = {
					id: orderId
				};
				if(oldStatus == 7){
					param['status'] = 1;
				} else if(oldStatus == 1) {
					param['status'] = 3;
				}
				if(oldStatus == 7 || oldStatus == 1){
					this.$http({
						url: this.$http.adornUrl_qfs('/roomOrder/update'),
						method: 'get',
						params: this.$http.adornParams(param)
					}).then(({data}) => {
						if (data && data.code === 0) {
							this.$message({
								message: '操作成功',
								type: 'success',
								duration: 1500,
								onClose: () => {
									this.queryList();
								}
							})
						} else {
							this.$message.error(data.msg);
						}
					})
				}
			}
		},
		components: {
			HotelSelect,
			SsqSelect
		},
		filters: {
			moneyToY(money){// 分转元
				return money*1/100;
			},
			formatDate(time){
				let date = new Date(time * 1000);
				return formatDate(date, 'yyyy-MM-dd hh:mm');
			},
			statusFilter(status){
				var result = '';
				switch(status){
					case 0:
						result = '待支付';
						break;
					case 1:
						result = '待入住';
						break;
					case 2:
						result = '待反馈';
						break;
					case 3:
						result = '已取消';
						break;
					case 4:
						result = '退款中';
						break;
					case 5:
						result = '已退款';
						break;
					case 6:
						result = '已完成';
						break;
					case 7:
						result = '待确认';
						break;
					default:
						result = '未知状态';
				}
				return result;
			}
		}
	}
</script>

<style lang="scss">
	.page_table{
		font-size: 16px;
		font-weight: bold;
		line-height: 30px;
		border-bottom: 1px solid #666;
		border-left: 1px solid #666;
		border-top: 1px solid #666;
		.el-col{
			padding: 10px 0 10px 10px;
			border-right: 1px solid #666;
		}
	}
	.page_body{
		border-left: 1px solid #666;
		.el-row{
      display: flex;
			border-bottom: 1px solid #666;
			.el-col{
				padding: 10px 0 10px 10px;
				border-right: 1px solid #666;
			}
		}
		p{
			margin: 0;
			font-size: 14px;
		}
		p.lh20{
			line-height: 20px;
		}
		p.lh40{
			line-height: 40px;
		}
	}
</style>
