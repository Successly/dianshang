<template>
	<div class="block">
		<el-form :model="formInline" :rules="formRules" ref="formInline" label-width="100px">
			<el-form-item label="酒店名称">
				<hotel-select @changeSelectFunc="changeHotelSelectFunc"></hotel-select>
			</el-form-item>
			<el-form-item label="优惠券类型" prop="type">
				<el-select v-model="formInline.type" placeholder="请选择" style="width: 200px;">
					<el-option
					  v-for="item in couponTypeSelectData"
					  :key="item.value"
					  :label="item.label"
					  :value="item.value">
					</el-option>
				</el-select>
			</el-form-item>
			<el-form-item label="优惠券名称" prop="name">
				<el-input v-model="formInline.name" placeholder="请输入" style="width: 200px;"></el-input>
			</el-form-item>
			<el-form-item label="总发行量" prop="num">
				<el-input type="number" v-model.number="formInline.num" placeholder="只能输入整数，输入-1为无限制" min="-1" style="width:16rem; min-width: 16rem;"></el-input>
			</el-form-item>
			<el-form-item label="面额" prop="money">
				<el-input type="number" v-model.number="formInline.money" placeholder="面值只能是数值，1-10000" min="1" max="10000" style="width: 200px;">
					<template slot="append">元</template>
				</el-input>
			</el-form-item>
			<el-form-item label="每人限领">
				<el-input value="1" :disabled="true" style="width: 200px;">
					<template slot="append">张</template>
				</el-input>
			</el-form-item>
			<el-form-item label="领取限制" prop="getCondition">
				<el-radio v-model="getCondition" label="1" @change="changeGetCondition">不限</el-radio>
				<el-radio v-model="getCondition" label="2" @change="changeGetCondition">会员领取</el-radio>
				<el-checkbox-group v-model="getConditionArray" :min="1" v-if="getCondition == 2">
					<el-checkbox label="1">白银会员</el-checkbox>
					<el-checkbox label="2">黄金会员</el-checkbox>
					<el-checkbox label="3">铂金会员</el-checkbox>
					<el-checkbox label="4">钻石会员</el-checkbox>
					<el-checkbox label="5">至尊会员</el-checkbox>
				</el-checkbox-group>
			</el-form-item>
			<el-form-item label="使用有效期" prop="issueWay">
				<div class="block">
					<el-radio v-model="formInline.issueWay" label="0" @change="changeEffectiveTime" style="margin-right: 20px;">日期范围</el-radio>
					<el-date-picker
					  v-model="effectiveTime_timeArr"
					  type="daterange"
					  start-placeholder="开始日期"
					  end-placeholder="结束日期"
            :picker-options="pickerOptions1"
					  :disabled="formInline.issueWay != 0"
					  style="width: 400px;">
					</el-date-picker>
				</div>
				<div class="block" style="margin-top: 10px;">
					<el-radio v-model="formInline.issueWay" label="1" @change="changeEffectiveTime" style="margin-right: 20px;">固定天数</el-radio>
					<el-input type="number" v-model="effectiveTime_time" placeholder="领取后到期天数" min="1" :disabled="formInline.issueWay != 1" style="width: 200px;">
						<template slot="append">天</template>
					</el-input>
				</div>
			</el-form-item>
			<el-form-item label="使用门槛" prop="threshold">
				<el-radio v-model="threshold" label="1" @change="changeThreshold">无限制</el-radio>
				<el-radio v-model="threshold" label="2" @change="changeThreshold">
					满<el-input type="number" v-model="threshold_num" :disabled="threshold != 2" style="width: 100px;margin: 0 10px;"></el-input>元可用
				</el-radio>
			</el-form-item>
			<el-form-item label="可使用房型">
				<el-row>
					<div class="block">分时租赁房型：</div>
					<div class="block">
						<el-checkbox :indeterminate="isIndeterminateHour" v-model="checkAllHour" @change="handleCheckAllChangeHour">全选</el-checkbox>
						<el-checkbox-group v-model="checkedHour" @change="handleCheckedHourChange">
							<el-checkbox v-for="item in hourRooms" :label="item.id" :key="item.id">{{item.name}}</el-checkbox>
						</el-checkbox-group>
					</div>
				</el-row>
				<el-row>
					<div class="block">整日租赁房型：</div>
					<div class="block">
						<el-checkbox :indeterminate="isIndeterminateDay" v-model="checkAllDay" @change="handleCheckAllChangeDay">全选</el-checkbox>
						<el-checkbox-group v-model="checkedDay" @change="handleCheckedDayChange">
							<el-checkbox v-for="item in dayRooms" :label="item.id" :key="item.id">{{item.name}}</el-checkbox>
						</el-checkbox-group>
					</div>
				</el-row>
			</el-form-item>
			<el-row style="text-align: center;">
				<el-button type="success" @click="save('formInline')">保存并确认</el-button>
			</el-row>
		</el-form>
	</div>
</template>

<script>

	import HotelSelect from '@/plugin/hotelSelect'
	import {formatDate} from '@/utils'

	export default {
		data () {
      var validatePositiveInteger = (rule, value, callback) => {
        //验证密码
        if (!/^[0-9]+$/.test(value)) {
          callback(new Error('内容只能为自然数'));
        } else {
          callback();
        }
      };
			return {
				formInline: {
					hotelId: '',
					type: '',
					name: '',
					num: '',
					money: '',
					limit: [],
					useType: 0,
					issueWay: '0',
					startTime: '',
					endTime: '',
					expireDay: '',
					barriers: -1,
					timeSharing: [],
					wholeDay: []
				},
        formRules: {
          type: [
            { required: true, message: '请选择优惠券类型', trigger: 'change' }
          ],
          name: [
            { required: true, message: '请填写优惠券名称', trigger: 'blur' }
          ],
          num: [
            { required: true, message: '请输入总发行量', trigger: 'blur' },
            { type: 'number', message: '总发行量只能为整数'},
           /* { validator: validatePositiveInteger, trigger: 'blur'}*/
          ],
          money: [
            { required: true, message: '请输入面值', trigger: 'blur' },
            { type: 'number', message: '面值只能是数值'},
          ],
        },
				couponTypeSelectData: [
					{ label: '营销优惠券', value: 1 },
					{ label: '入会优惠券', value: 2 },
					{ label: '消费优惠券', value: 3 }
				],
				getCondition: '1',
				getConditionArray: ['1', '2', '3', '4', '5'],
				effectiveTime_timeArr: [],
				effectiveTime_time: '',
				threshold: '1',
				threshold_num: '',
				dayRooms: [],
				hourRooms: [],
				checkAllHour: false,
				checkAllDay: false,
				isIndeterminateHour: false,
				isIndeterminateDay: false,
				checkedHour: [],
				checkedDay: [],
				allHourList: [],
				allDayList: [],
        pickerOptions1: {
          disabledDate(time) {
            return time.getTime() < Date.now();
          },
        },
			}
		},
		created () {

		},
		activated () {

		},
		methods: {
			changeHotelSelectFunc(value){
				this.formInline.hotelId = value;
				// 查询房型列表
				this.$http({
					url: this.$http.adornUrl_qfs('/hotel/rooms/collect/simpleRoomType'),
					method: 'get',
					params: this.$http.adornParams({
						hotelId: this.formInline.hotelId
					})
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.hourRooms = [];
						for(var i = 0; i < data.data.length; i++){
							if(data.data[i].timeshare == 1){
								this.hourRooms.push(data.data[i]);
							}
						}
						this.dayRooms = data.data;
						this.checkAllHour = false;
						this.checkAllDay = false;
						this.isIndeterminateHour = false;
						this.isIndeterminateDay = false;
						this.checkedHour = [];
						this.checkedDay = [];
						this.allHourList = [];
						this.allDayList = [];
						for(var i = 0; i < this.hourRooms.length; i++){
							this.allHourList.push(this.hourRooms[i].id);
						}
						for(var i = 0; i < this.dayRooms.length; i++){
							this.allDayList.push(this.dayRooms[i].id);
						}
					} else {
						this.hourRooms = [];
						this.dayRooms = [];
						this.checkAllHour = false;
						this.checkAllDay = false;
						this.isIndeterminateHour = false;
						this.isIndeterminateDay = false;
						this.checkedHour = [];
						this.checkedDay = [];
						this.allHourList = [];
						this.allDayList = [];
					}
				})
			},
			changeGetCondition(){
				if(this.getCondition == 2){
					this.getConditionArray = ['1', '2', '3', '4', '5'];
				}
			},
			changeEffectiveTime(){
				if(this.effectiveTime == 1){
					this.effectiveTime_time = '';
				}else{
					this.effectiveTime_timeArr = [];
				}
			},
			changeThreshold(){
				if(this.threshold == 1){
					this.threshold_num = '';
				}
			},
			handleCheckedHourChange(value){
				let checkedCount = value.length;
				this.checkAllHour = checkedCount === this.dayRooms.length;
				this.isIndeterminateHour = checkedCount > 0 && checkedCount < this.dayRooms.length;
			},
			handleCheckedDayChange(value){
				let checkedCount = value.length;
				this.checkAllDay = checkedCount === this.hourRooms.length;
				this.isIndeterminateDay = checkedCount > 0 && checkedCount < this.hourRooms.length;
			},
			handleCheckAllChangeHour(val){
				this.checkedHour = val ? this.allHourList : [];
				this.isIndeterminateHour = false;
			},
			handleCheckAllChangeDay(val){
				this.checkedDay = val ? this.allDayList : [];
				this.isIndeterminateDay = false;
			},
			save(formName){
        if (this.formInline.issueWay == '0' && this.effectiveTime_timeArr.length == 0) {
          this.$message.error('请选择时间范围');
        }else if(this.formInline.issueWay == '1' && this.effectiveTime_time == ''){
          this.$message.error('请填写领取后到期天数');
        }else if(this.checkedHour.length == 0 && this.checkedDay.length == 0){
          this.$message.error('请选择可使用房型');
        } else {
          this.$refs[formName].validate((valid) => {
            if (valid) {
              if(this.threshold == 2){
                this.formInline.barriers = this.threshold_num*1;
              }
              if(this.formInline.issueWay == 0){
                this.formInline.startTime = formatDate(new Date(this.effectiveTime_timeArr[0]), 'yyyy-MM-dd');
                this.formInline.endTime = formatDate(new Date(this.effectiveTime_timeArr[1]), 'yyyy-MM-dd');
              }else if(this.formInline.issueWay == 1){
                this.formInline.expireDay = this.effectiveTime_time;
              }
              if(this.getCondition == 2){
                this.formInline.limit = this.getConditionArray;
              }
              this.formInline.wholeDay = this.checkedDay;
              this.formInline.timeSharing = this.checkedHour;
              this.$http({
                url: this.$http.adornUrl_qfs('/coupon/add'),
                method: 'post',
                data: this.$http.adornData(this.formInline)
              }).then(({data}) => {
                if (data && data.code === 0) {
                  this.$message({
                    message: '操作成功',
                    type: 'success',
                    duration: 1500,
                    onClose: () => {
                      this.formInline = {
                        hotelId: this.formInline.hotelId,
                        type: '',
                        name: '',
                        num: '',
                        money: '',
                        limit: [],
                        useType: 0,
                        issueWay: '0',
                        startTime: '',
                        endTime: '',
                        expireDay: '',
                        barriers: -1,
                        timeSharing: [],
                        wholeDay: []
                      }
                      /*this.getCondition = '1',
                        this.getConditionArray = ['1', '2', '3', '4', '5'],
                        this.effectiveTime_timeArr = [],
                        this.effectiveTime_time = '',
                        this.threshold = '1',
                        this.threshold_num = '',
                        this.dayRooms = [],
                        this.hourRooms = [],
                        this.checkAllHour = false,
                        this.checkAllDay = false,
                        this.isIndeterminateHour = false,
                        this.isIndeterminateDay = false,
                        this.checkedHour = [],
                        this.checkedDay = [],
                        this.allHourList = [],
                        this.allDayList = []*/
                      this.changeHotelSelectFunc(this.formInline.hotelId);
                    }
                  })
                } else {
                  this.$message.error(data.msg);
                }
              })
            } else {
              console.log('error submit!!');
              return false;
            }
          });
        }


			}
		},
		components: {
			HotelSelect
		}
	}
</script>

<style lang="scss">

</style>
