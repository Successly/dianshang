<template>
	<div class="block">
		<div class="search_area">
			<el-form :inline="true" :model="formInline" class="demo-form-inline" label-width="100px">
				<el-form-item label="酒店名称">
					<hotel-select @changeSelectFunc="changeHotelSelectFunc"></hotel-select>
				</el-form-item>
				<br />
				<el-form-item label="优惠券名称">
					<el-input v-model="formInline.couponName" placeholder="请输入" style="width: 200px;"></el-input>
				</el-form-item>
				<el-form-item label="优惠券类型">
					<el-select v-model="formInline.type" placeholder="请选择" style="width: 200px;">
						<el-option
						  v-for="item in couponTypeSelectData"
						  :key="item.value"
						  :label="item.label"
						  :value="item.value">
						</el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="优惠券状态">
					<el-select v-model="formInline.exceed" placeholder="请选择" style="width: 200px;">
						<el-option
						  v-for="item in couponStatusSelectData"
						  :key="item.value"
						  :label="item.label"
						  :value="item.value">
						</el-option>
					</el-select>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="searchCouponInfo">查询</el-button>
					<el-button type="primary" @click="addCoupon">新建优惠券</el-button>
				</el-form-item>
			</el-form>
		</div>

		<div class="search_result">
			<el-table
			  :data="couponList"
			  v-loading="dataListLoading"
			  border
			  stripe
			  style="width: 100%">
				<el-table-column
				  prop="id"
				  label="编号"
				  align="center"
				  width="80">
				</el-table-column>
				<el-table-column
				  prop="name"
				  label="优惠劵名称"
				  align="center"
				  width="150">
				</el-table-column>
				<el-table-column
				  label="优惠券类型"
				  align="center"
				  width="100">
					<template slot-scope="scope">
						{{ scope.row.type == 1 ? '营销优惠券' : (scope.row.type == 2 ? '入会优惠券' : (scope.row.type == 3 ? '消费优惠券' : '未知类型')) }}
					</template>
				</el-table-column>
				<el-table-column
				  label="领取限制"
				  align="center"
				  width="100">
					<template slot-scope="scope">{{ !scope.row.limit || scope.row.limit.length == 0 ? '不限制' : '限制' }}</template>
				</el-table-column>
				<el-table-column
				  prop=""
				  label="使用门槛"
				  align="center"
				  width="150">
					<template slot-scope="scope">
						{{ scope.row.barriers == -1 ? '无门槛' : '满减券【满' + scope.row.barriers + '】' }}
					</template>
				</el-table-column>
				<el-table-column
				  prop="money"
				  label="面额"
				  align="center"
				  width="120">
					<template slot-scope="scope">
						{{ scope.row.money + '元' }}
					</template>
				</el-table-column>
				<el-table-column
				  label="有效期"
				  align="center">
					<template slot-scope="scope">
						<span v-if="scope.row.issueWay == 0">{{ scope.row.startTime | formatDate }}至{{ scope.row.endTime | formatDate }}</span>
						<span v-if="scope.row.issueWay == 1">领取后{{ scope.row.expireDay }}天结束</span>
					</template>
				</el-table-column>
				<el-table-column
				  label="状态"
				  align="center"
				  width="100">
					<template slot-scope="scope">
						{{ scope.row.exceed == 0 ? '未过期' : '已过期' }}
					</template>
				</el-table-column>
				<el-table-column
				  label="操作"
				  align="center"
				  width="150">
					<template slot-scope="scope">
						<el-button
						  @click.native.prevent="queryInfo(scope.row)"
						  type="text"
						  size="small">
						  详情
						</el-button>
						<el-button
						  @click.native.prevent="unableCoupon(scope.row.id)"
						  type="text"
						  size="small"
						  v-if="scope.row.exceed == 0">
						  下架
						</el-button>
					</template>
				</el-table-column>
			</el-table>

			<div class='block'>
				<el-pagination
				  @size-change='handleSizeChange'
				  @current-change='handleCurrentChange'
			      :current-page='paginationData.pageNumber'
				  :page-sizes='[10, 20, 30, 50, 100]'
				  :page-size='paginationData.pageSize'
				  :total='paginationData.totalPage'
				  layout='total, sizes, prev, pager, next, jumper'
				>
				</el-pagination>
			</div>
		</div>

		<!--详情弹窗-->
		<el-dialog
		  v-if="couponInfoDialogShow"
		  :title="couponInfo.dialogTitle"
		  :close-on-click-modal="false"
		  :before-close="closeDialog"
		  :visible.sync="visible"
		  width="600px">
			<div class="block" style="width: 100%; line-height: 40px; fint-size: 16px;">
				<el-row :gutter="20">
					<el-col :span="6">发行数量</el-col>
					<el-col :span="18">{{couponInfo.num >= 0 ? couponInfo.num+'张' : '无限'}}</el-col>
				</el-row>
				<el-row :gutter="20">
					<el-col :span="6">面额</el-col>
					<el-col :span="18">{{couponInfo.money}}元</el-col>
				</el-row>
				<el-row :gutter="20">
					<el-col :span="6">使用门槛</el-col>
					<el-col :span="18">{{couponInfo.barriers | barriersFilter}}</el-col>
				</el-row>
				<el-row :gutter="20">
					<el-col :span="6">使用有效期</el-col>
					<el-col :span="18" v-if="couponInfo.issueWay == 0">{{couponInfo.startTime | formatDate}}至{{couponInfo.endTime | formatDate}}</el-col>
					<el-col :span="18" v-if="couponInfo.issueWay == 1">领取后{{ couponInfo.expireDay }}天结束</el-col>
				</el-row>
				<el-row :gutter="20">
					<el-col :span="6">领取限制</el-col>
					<el-col :span="18">{{couponInfo.limit | limitFilter}}</el-col>
				</el-row>
				<el-row :gutter="20">
					<el-col :span="6">使用房型限制</el-col>
					<el-col :span="18">
						<el-row>
							<div class="block">分时租赁房型：</div>
							<div class="block">
								{{couponInfo.timeSharing | roomNameFilter}}
							</div>
						</el-row>
						<el-row>
							<div class="block">整日租赁房型：</div>
							<div class="block">
								{{couponInfo.wholeDay | roomNameFilter}}
							</div>
						</el-row>
					</el-col>
				</el-row>
			</div>
		</el-dialog>
	</div>
</template>

<script>

	import HotelSelect from '@/plugin/hotelSelect'
	import {formatDate} from '@/utils'

	export default {
		data () {
			return {
				formInline: {
					hotelId: '',
					couponName: '',
					type: '',
					exceed: ''
				},
				dataListLoading: false,
				couponList: [],
				paginationData: {
					pageNumber: 1,
					pageSize: 20,
					totalPage: 0
				},
				couponTypeSelectData: [
					{ label: '全部', value: '' },
					{ label: '营销优惠券', value: 1 },
					{ label: '入会优惠券', value: 2 },
					{ label: '消费优惠券', value: 3 }
				],
				couponStatusSelectData: [
					{ label: '全部', value: '' },
					{ label: '未过期', value: 0 },
					{ label: '已过期', value: 1 }
				],
				couponInfoDialogShow: false,
				visible: false,
				couponInfo: {
					hotelId: '',
					dialogTitle: '',
					num: '',
					money: '',
					barriers: '',
					startTime: '',
					endTime: '',
					limit: [],
					timeSharing: [],
					wholeDay: [],
					issueWay: '',
					expireDay: ''
				},
				firstIn: true
			}
		},
		created () {

		},
		activated () {

		},
		methods: {
			changeHotelSelectFunc(value){
				this.formInline.hotelId = value;
				if(this.firstIn){
					this.firstIn = false;
					this.searchCouponInfo();
				}
			},
			searchCouponInfo(){
				this.dataListLoading = true;
				this.$http({
					url: this.$http.adornUrl_qfs('/coupon/list'),
					method: 'get',
					params: this.$http.adornParams(Object.assign({
						'pageNum': this.paginationData.pageNumber,
						'pageSize': this.paginationData.pageSize
					}, this.formInline))
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.couponList = data.data.list;
						this.paginationData.totalPage = data.data.totalCount;
					} else {
						this.couponList = [];
						this.paginationData.totalPage = 0;
					}
					this.dataListLoading = false;
				})
			},
			handleSizeChange(val){
				this.paginationData.pageSize = val;
				this.paginationData.pageNumber = 1;
				this.searchCouponInfo();
			},
			handleCurrentChange(val){
				this.paginationData.pageNumber = val;
				this.searchCouponInfo();
			},
			addCoupon(){
				// 新建优惠券
				this.$router.push({name: 'qfs-market/addCoupon'});
			},
			queryInfo(row){
				this.couponInfoDialogShow = true;
				var typeName = row.type == 1 ? '营销优惠券' : (row.type == 2 ? '入会优惠券' : (row.type == 3 ? '消费优惠券' : '未知类型'));
				this.couponInfo = {
					hotelId: row.hotelId,
					dialogTitle: row.name + '-' + typeName,
					num: row.num,
					money: row.money,
					barriers: row.barriers,
					startTime: row.startTime,
					endTime: row.endTime,
					limit: row.limit,
					timeSharing: row.timeSharings,
					wholeDay: row.wholeDays,
					issueWay: row.issueWay,
					expireDay: row.expireDay
				};

				this.visible = true;
			},
			unableCoupon(id){
				this.$confirm('确定对该优惠券进行下架操作?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
					// 下架
					this.$http({
						url: this.$http.adornUrl_qfs('/coupon/close/' + id),
						method: 'post',
						params: this.$http.adornParams()
					}).then(({data}) => {
						if (data && data.code === 0) {
							this.$message({
								message: '操作成功',
								type: 'success',
								duration: 1500,
								onClose: () => {
									this.searchCouponInfo();
								}
							})
						} else {
							this.$message.error(data.msg);
						}
					})
				}).catch(() => {})
			},
			closeDialog(){
				this.couponInfoDialogShow = false;
				this.visible = false;
				this.couponInfo = {
					dialogTitle: '',
					num: '',
					money: '',
					barriers: '',
					startTime: '',
					endTime: '',
					limit: [],
					timeSharing: [],
					wholeDay: [],
					issueWay: '',
					expireDay: ''
				};
			}
		},
		components: {
			HotelSelect
		},
		filters: {
			formatDate(time){
				let date = new Date(time);
				return formatDate(date, 'yyyy-MM-dd');
			},
			barriersFilter(barriers){
				return barriers == -1 ? '无限制' : '满减券【满' + barriers + '】';
			},
			limitFilter(limit){
				var lv_arr = ['白银会员', '黄金会员', '铂金会员', '钻石会员', '至尊会员'];
				if(!limit || limit.length == 0){
					return '无限制';
				}else{
					var result_str = '';
					for(var i = 0; i < limit.length; i++){
						if(i != 0){
							result_str += ' | ';
						}
						result_str += lv_arr[limit[i] - 1];
					}
					return result_str;
				}
			},
			roomNameFilter(arrStr){
			  let text = '';
			  if(arrStr != null && arrStr.length > 0){
			    text = arrStr.join('、');
        }
			  return text;
			}
		}
	}
</script>

<style lang="scss">

</style>
