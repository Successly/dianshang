<template>
	<div class="block">
		<div class="search_area">
			<el-form :inline="true" :model="formInline" class="demo-form-inline" label-width="80px">
				<el-form-item label="酒店名称">
					<el-input v-model="formInline.name" placeholder="请输入" style="width: 200px;"></el-input>
				</el-form-item>
				<el-form-item label="省市区">
					<ssq-select :ssqValuesArr="ssqCheckedArr" @changeFunc="ssqChange"></ssq-select>
				</el-form-item>
				<el-form-item label="酒店状态">
					<el-select v-model="formInline.status" placeholder="请选择" style="width: 200px;">
						<el-option
						  v-for="item in hotelStateList"
						  :key="item.value"
						  :label="item.label"
						  :value="item.value">
						</el-option>
					</el-select>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="searchHotelInfo">查询</el-button>
				</el-form-item>
			</el-form>
		</div>

		<div class="search_result">
			<el-table
			  :data="hotelListData"
			  border
			  stripe
			  :v-loading="dataListLoading"
			  style="width: 100%">
				<el-table-column
				  prop="id"
				  label="编号"
				  align="center"
				  width="100">
				</el-table-column>
				<el-table-column
				  prop="name"
				  label="酒店名称"
				  align="center">
				</el-table-column>
				<el-table-column
				  prop="phone"
				  label="前台座机"
				  align="center"
				  width="150">
				</el-table-column>
				<el-table-column
				  prop="mobile"
				  label="联系人"
				  align="center"
				  width="150">
				</el-table-column>
				<el-table-column
				  label="酒店状态"
				  align="center"
				  width="80">
					<template slot-scope="scope">
						<span style="color:#1ABC9C">{{ scope.row.status == 0 ? '正常营业' : (scope.row.status == 1 ? '暂停营业' : (scope.row.status == -1 ? '已倒闭' : '未知状态')) }}</span>
					</template>
				</el-table-column>
				<el-table-column
				  label="省 / 市 / 区"
				  align="center">
					<template slot-scope="scope">{{ scope.row.province + ' / ' + scope.row.city + ' / ' + scope.row.district }}</template>
				</el-table-column>
				<el-table-column
				  prop="addressDetail"
				  label="详细地址"
				  align="center">
				</el-table-column>
				<el-table-column
				  label="操作"
				  align="center"
				  width="100">
					<template slot-scope="scope">
						<el-button
						  @click.native.prevent="editThisHotelInfo(scope.row.id)"
						  type="text"
						  size="small">
						  编辑
						</el-button>
					</template>
				</el-table-column>
			</el-table>

			<div class='block'>
				<el-pagination
				  @size-change='handleSizeChange'
				  @current-change='handleCurrentChange'
			      :current-page='paginationData.pageNumber'
				  :page-sizes='[10, 20, 30, 50, 100]'
				  :page-size='paginationData.pageSize'
				  :total='paginationData.totalPage'
				  layout='total, sizes, prev, pager, next, jumper'
				>
				</el-pagination>
			</div>
		</div>
	</div>
</template>

<script>

	import HotelSelect from '@/plugin/hotelSelect'
	import SsqSelect from '@/plugin/ssqSelect'

	export default {
		data () {
			return {
				formInline: {
					name: '',
					province: '',
					city: '',
					district: '',
					status: ''
				},
				ssqCheckedArr: [],
				hotelStateList: [
					{ label: '全部', value: '' },
					{ label: '正常营业', value: 0},
					{ label: '暂停营业', value: 1},
					{ label: '已倒闭', value: -1}
				],
				dataListLoading: false,
				hotelListData: [],
				paginationData: {
					pageNumber: 1,
					pageSize: 20,
					totalPage: 0
				}
			}
		},
		created () {

		},
		activated () {
			this.ssqCheckedArr = [this.formInline.province, this.formInline.city, this.formInline.district];
			this.searchHotelInfo();
		},
		methods: {
			ssqChange(result){
				if(result.length == 0){
					this.formInline.province = '';
					this.formInline.city = '';
					this.formInline.district = '';
					this.ssqCheckedArr = [];
				}else{
					this.formInline.province = result[0].value;
					this.formInline.city = result[1].value;
					this.formInline.district = result[2].value;
					this.ssqCheckedArr = [result[0].value, result[1].value, result[2].value];
				}
			},
			searchHotelInfo(){
				// 查询酒店信息列表
				this.dataListLoading = true;
				this.$http({
					url: this.$http.adornUrl_qfs('/hotel/hotels'),
					method: 'get',
					params: this.$http.adornParams(Object.assign({
						'pageNum': this.paginationData.pageNumber,
						'pageSize': this.paginationData.pageSize
					}, this.formInline))
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.hotelListData = data.data.list;
						this.paginationData.totalPage = data.data.totalCount;
					} else {
						this.hotelListData = [];
						this.paginationData.totalPage = 0;
					}
					this.dataListLoading = false;
				})
			},
			editThisHotelInfo(id){
				// this.$router.push({name: 'qfs-hotel/addHotel', params: {'id': id}});
				this.$router.push({
					name: 'qfs-hotel/addHotel',
					params: {
						'id': id
					}
				});
			},
			handleSizeChange(val){
				this.paginationData.pageSize = val;
				this.paginationData.pageNumber = 1;
				this.searchHotelInfo();
			},
			handleCurrentChange(val){
				this.paginationData.pageNumber = val;
				this.searchHotelInfo();
			}
		},
		components: {
			HotelSelect,
			SsqSelect
		}
	}
</script>

<style lang="scss">

</style>

