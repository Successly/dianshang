<template>
	<el-dialog
      :title="!dataForm.id ? '新增' : '修改'"
      :close-on-click-modal="false"
      :visible.sync="visible">
		<el-steps :active="active" finish-status="success" style="width: 400px;">
			<el-step title="房型基本信息"></el-step>
			<el-step title="房型基础价格"></el-step>
		</el-steps>
		<el-form :model="dataForm" :rules="formRules" ref="dataForm" label-width="80px" style="margin-top: 20px;">
			<div v-if="active == 0">
				<el-form-item label="酒店名称">
					<hotel-select @changeSelectFunc="changeHotelSelectFunc" ref="child" :default-hotel-id="defaultHotelId"></hotel-select>
				</el-form-item>
				<el-form-item label="房型名称" prop="name">
					<el-input v-model="dataForm.name" placeholder="请输入" style="width: 200px;"></el-input>
				</el-form-item>
				<el-form-item label="房型类型" prop="type">
					<el-select v-model="dataForm.type" placeholder="请选择" style="width: 200px;">
						<el-option
						  v-for="item in roomTypeList"
						  :key="item.code"
						  :label="item.name"
						  :value="item.code">
						</el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="房型面积" prop="area">
          <el-input-number v-model.number="dataForm.area" v-enterNumber :precision="0" :min="1" placeholder="请输入"></el-input-number>
				</el-form-item>
				<el-form-item label="房间床型" prop="bedTypeName">
					<el-input v-model="dataForm.bedTypeName" placeholder="请输入" style="width: 200px;"></el-input>
				</el-form-item>
				<el-form-item label="可住人数" prop="capacity">
					<el-input v-model.number="dataForm.capacity" placeholder="请输入" style="width: 200px;"></el-input>
				</el-form-item>
				<el-form-item label="是否有窗" prop="bedCount">
					<el-radio v-model="dataForm.bedCount" label="1">有</el-radio>
					<el-radio v-model="dataForm.bedCount" label="0">没有</el-radio>
				</el-form-item>
				<el-form-item label="是否独卫" prop="indieToilet">
					<el-radio v-model="dataForm.indieToilet" label="1">是</el-radio>
					<el-radio v-model="dataForm.indieToilet" label="0">不是</el-radio>
				</el-form-item>
				<el-form-item label="吸烟政策" prop="allowSmoking">
					<el-radio v-model="dataForm.allowSmoking" label="1">允许</el-radio>
					<el-radio v-model="dataForm.allowSmoking" label="0">不允许</el-radio>
				</el-form-item>
				<el-form-item label="早餐政策" prop="breakfast">
					<el-select v-model="dataForm.breakfast" placeholder="请选择" style="width: 200px;">
						<el-option
						  v-for="item in breakfastList"
						  :key="item.code"
						  :label="item.name"
						  :value="item.name">
						</el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="房间宽带" prop="wifi">
					<el-select v-model="dataForm.wifi" placeholder="请选择" style="width: 200px;">
						<el-option
						  v-for="item in wifiList"
						  :key="item.code"
						  :label="item.name"
						  :value="item.name">
						</el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="房间设施" prop="utilities">
					<el-input v-model="dataForm.utilities" placeholder="请输入" style="width: 400px;"></el-input>
				</el-form-item>
				<el-form-item label="房型图片">
					<el-row :gutter="20" type="flex" align="bottom">
						<el-col v-for="item in dataForm.images" :span="4">
							<el-card :body-style="{ padding: '0px' }" class="uploadPicCard">
								<img :src="item" style="width: 100%;">
								<div class="block" style="text-align: center;">
									<el-button type="text" @click="deletePic(item)">删除图片</el-button>
								</div>
							</el-card>
						</el-col>
					</el-row>
					<el-row>
						<el-upload
						  :action="uploadUrl"
						  :show-file-list="false"
						  :before-upload="handleBeforeUpload"
						  :on-success="handleSuccess">
							<el-button size="small" type="primary" style="margin: 20px 20px 20px 0;">点击上传</el-button>
							<div slot="tip" style="display: inline-block;font-size: 12px;">建议尺寸800*800px，大小200kb内。</div>
						</el-upload>
					</el-row>
				</el-form-item>
			</div>
			<div v-if="active == 1">
        <div>
          <el-form-item label="整日租赁基础数量" prop="dayCount" label-width="150px">
            <el-input v-model.number="dataForm.dayCount" placeholder="请输入" style="width: 200px;"></el-input>
          </el-form-item>
          <el-form-item label="分时租赁基础数量" prop="hourCount" label-width="150px">
            <el-input v-model.number="dataForm.hourCount" placeholder="请输入" style="width: 200px;"></el-input>
          </el-form-item>
          <el-row>平时-基础价格信息</el-row>
          <el-form-item label="平时日期定义" prop="wkDefaultArr" label-width="150px" class="elcm0">
            <el-checkbox-group v-model="wkDefaultArr" :min="1" :max="6" @change="handleCheckedCitiesChange">
              <el-checkbox label="1">星期一</el-checkbox>
              <el-checkbox label="2">星期二</el-checkbox>
              <el-checkbox label="3">星期三</el-checkbox>
              <el-checkbox label="4">星期四</el-checkbox>
              <el-checkbox label="5">星期五</el-checkbox>
              <el-checkbox label="6">星期六</el-checkbox>
              <el-checkbox label="7">星期日</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
          <el-form-item label="全天房价" prop="normalDayPrice_yuan" label-width="150px">
            <el-input v-model.number="normalDayPrice_yuan" placeholder="请输入" style="width: 200px;"></el-input>
          </el-form-item>
          <el-form-item label="是否开放分时" prop="normalHourSwitch" label-width="150px">
            <el-radio v-model="dataForm.normalHourSwitch" label="1">开放</el-radio>
            <el-radio v-model="dataForm.normalHourSwitch" label="0">不开放</el-radio>
          </el-form-item>
          <el-form-item label="分时时段" prop="normalHourPrice_yuan" label-width="150px" v-if="dataForm.normalHourSwitch == 1">
            <el-time-select
              placeholder="起始时间"
              v-model="dataForm.normalHourStart"
              :picker-options="{
            start: '00:00',
            step: '01:00',
            end: '24:00'
            }">
            </el-time-select>
            至
            <el-time-select
              placeholder="结束时间"
              v-model="dataForm.normalHourEnd"
              :picker-options="{
            start: '00:00',
            step: '01:00',
            end: '24:00',
            minTime: dataForm.normalHourStart
    }">
            </el-time-select>
            <el-input v-model="normalHourPrice_yuan" placeholder="" style="width: 80px; margin-top: 20px"></el-input>元 / 每小时
          </el-form-item>
          <el-form-item label="特殊价格时段" prop="normalHourSpecialSwitch" label-width="150px" v-if="dataForm.normalHourSwitch == 1 && dataForm.normalHourSwitch == 1" >
            <el-radio v-model="dataForm.normalHourSpecialSwitch" label="1">设置</el-radio>
            <el-radio v-model="dataForm.normalHourSpecialSwitch" label="0">不设置</el-radio>
          </el-form-item>
          <el-form-item label="特殊时段" prop="normalHourSpecialPrice_yuan" label-width="150px" v-if="dataForm.normalHourSwitch == 1 && dataForm.normalHourSpecialSwitch == 1">
            <el-time-select
              placeholder="起始时间"
              v-model="dataForm.normalHourSpecialStart"
              :picker-options="{
            start: '00:00',
            step: '01:00',
            end: '24:00',
            minTime: normalSpecialMin,
            maxTime: dataForm.normalHourEnd
            }">
            </el-time-select>
            至
            <el-time-select
              placeholder="结束时间"
              v-model="dataForm.normalHourSpecialEnd"
              :picker-options="{
            start: '00:00',
            step: '01:00',
            end: '24:00',
            minTime: dataForm.normalHourSpecialStart,
            maxTime: normalSpecialMax
          }">
            </el-time-select>
            <el-input v-model="normalHourSpecialPrice_yuan" placeholder="" style="width: 80px; margin-top: 20px"></el-input>元 / 每小时
          </el-form-item>
          <el-row>周末-基础价格信息</el-row>
          <el-form-item label="周末日期定义" prop="wkArr" label-width="150px">
            {{wkArr | wkArrFilter}}
          </el-form-item>
          <el-form-item label="全天房价" prop="wkDayPrice_yuan" label-width="150px">
            <el-input v-model="wkDayPrice_yuan" placeholder="请输入" style="width: 200px;"></el-input>
          </el-form-item>
          <el-form-item label="是否开放分时" prop="wkHourSwitch" label-width="150px">
            <el-radio v-model="dataForm.wkHourSwitch" label="1">开放</el-radio>
            <el-radio v-model="dataForm.wkHourSwitch" label="0">不开放</el-radio>
          </el-form-item>
          <el-form-item label="分时时段" prop="wkHourPrice_yuan" label-width="150px" v-if="dataForm.wkHourSwitch == 1">
            <el-time-select
              placeholder="起始时间"
              v-model="dataForm.wkHourStart"
              :picker-options="{
            start: '00:00',
            step: '01:00',
            end: '24:00'
            }">
            </el-time-select>
            至
            <el-time-select
              placeholder="结束时间"
              v-model="dataForm.wkHourEnd"
              :picker-options="{
            start: '00:00',
            step: '01:00',
            end: '24:00',
            minTime: dataForm.wkHourStart,
          }">
            </el-time-select>
            <el-input :disabled="dataForm.wkHourSwitch == 0" v-model="wkHourPrice_yuan" placeholder="" style="width: 80px; margin-top: 20px;"></el-input>元 / 每小时
          </el-form-item>
          <el-form-item label="特殊价格时段" prop="wkHourSpecialSwitch" label-width="150px" v-if="dataForm.wkHourSwitch == 1">
            <el-radio v-model="dataForm.wkHourSpecialSwitch" label="1">设置</el-radio>
            <el-radio v-model="dataForm.wkHourSpecialSwitch" label="0">不设置</el-radio>
          </el-form-item>
          <el-form-item label="特殊时段" prop="wkHourSpecialPrice_yuan" label-width="150px" v-if="dataForm.wkHourSwitch == 1 && dataForm.wkHourSpecialSwitch == 1">
            <el-time-select
              placeholder="起始时间"
              v-model="dataForm.wkHourSpecialStart"
              :picker-options="{
            start: '00:00',
            step: '01:00',
            end: '24:00',
            minTime:wkSpecialMin,
            maxTime: dataForm.wkHourEnd
            }">
            </el-time-select>
            至
            <el-time-select
              placeholder="结束时间"
              v-model="dataForm.wkHourSpecialEnd"
              :picker-options="{
            start: '00:00',
            step: '01:00',
            end: '24:00',
            minTime: dataForm.wkHourSpecialStart,
            maxTime: wkSpecialMax
          }">
            </el-time-select>
            <el-input v-model="wkHourSpecialPrice_yuan" placeholder="" style="width: 80px; margin-top: 20px;"></el-input>元 / 每小时
          </el-form-item>
        </div>

			</div>
		</el-form>
		<span slot="footer" class="dialog-footer">
			<el-button type="primary" @click="next()" v-if="active == 0">下一步</el-button>
			<el-button type="primary" @click="prev()" v-if="active == 1">上一步</el-button>
			<el-button type="primary" @click="dataFormSubmit('dataForm')" v-if="active == 1" v-loading.fullscreen.lock="fullscreenLoading">确定</el-button>
		</span>
	</el-dialog>
</template>

<script>

	import HotelSelect from '@/plugin/hotelSelect'
	import Upload from '@/plugin/oneFileUpload_form'
	import {formatDate} from '@/utils'

	export default {
		data () {
      var validatePositiveInteger = (rule, value, callback) => {
        //验证密码
        if (!/^[0-9]+$/.test(value)) {
          callback(new Error('内容只能为自然数'));
        } else {
          callback();
        }
      };
      var validatewkDayPrice_yuan = (rule, value, callback) => {
        //验证密码
        if(this.wkDayPrice_yuan == ''){
          callback(new Error('该参数为必填项'));
        }else if (!/^[0-9]+$/.test(this.wkDayPrice_yuan)) {
          callback(new Error('内容只能为自然数'));
        } else {
          callback();
        }
      };
      var validatenormalDayPrice_yuan = (rule, value, callback) => {
        //验证密码
        if(this.normalDayPrice_yuan == ''){
          callback(new Error('该参数为必填项'));
        }else if (!/^[0-9]+$/.test(this.normalDayPrice_yuan)) {
          callback(new Error('内容只能为自然数'));
        } else {
          callback();
        }
      };
      var validateNormalHourTime = (rule, value, callback) => {
        //验证密码
        if (this.dataForm.normalHourStart == '' || this.dataForm.normalHourEnd == '') {
          callback(new Error('请选择分时时间段'));
        } else if(this.normalHourPrice_yuan == ''){
          callback(new Error('请输入分时的每小时单价'));
        }else{
          callback();
        }
      };
      var validateNormalHourSpecialTime = (rule, value, callback) => {
        //验证密码
        if (this.dataForm.normalHourSpecialStart == '' || this.dataForm.normalHourSpecialStart == '') {
          callback(new Error('请选择特殊时段'));
        } else if(this.normalHourSpecialPrice_yuan == ''){
          callback(new Error('请输入特殊时段的每小时单价'));
        }else{
          callback();
        }
      };
      var validatewkHourPriceTime = (rule, value, callback) => {
        //验证密码
        if (this.dataForm.wkHourStart == '' || this.dataForm.wkHourEnd == '') {
          callback(new Error('请选择分时时间段'));
        } else if(this.wkHourPrice_yuan == ''){
          callback(new Error('请输入分时的每小时单价'));
        }else{
          callback();
        }
      };
      var validatewkHourSpecialPriceTime = (rule, value, callback) => {
        //验证密码
        if (this.dataForm.wkHourSpecialStart == '' || this.dataForm.wkHourSpecialEnd == '') {
          callback(new Error('请选择特殊时段'));
        } else if(this.wkHourSpecialPrice_yuan == ''){
          callback(new Error('请输入特殊时段的每小时单价'));
        }else{
          callback();
        }
      };
			return {
        fullscreenLoading: false,
				visible: false,
				dataForm: {
					id: 0,
					hotelId: '',
					name: '',
					type: '',
					status: '0',
					capacity: '',
					dayCount: '',
					hourCount: '',
					area: '',
					bedTypeName: '',
					bedCount: '',
					windowCount: '',
					indieToilet: '',
					allowSmoking: '',
					breakfast: '',
					wifi: '',
					utilities: '',
					images: [],
					weekendDef: [],
					normalHourSwitch: '1',
					normalDayPrice: '',
					normalHourPrice: '',
					normalHourStart: '',
					normalHourEnd: '',
					normalHourSpecialPrice: '',
					normalHourSpecialStart: '',
					normalHourSpecialEnd: '',
					normalHourSpecialSwitch: '1',
					wkHourSwitch: '1',
					wkDayPrice: '',
					wkHourPrice: '',
					wkHourStart: '',
					wkHourEnd: '',
					wkHourSpecialPrice: '',
					wkHourSpecialStart: '',
					wkHourSpecialEnd: '',
					wkHourSpecialSwitch: '1'
				},
        formRules: {
          name: [
            { required: true, message: '请输入房型名称', trigger: 'blur' },
            { max: 50, message: '酒店名称最多50个字符', trigger: 'blur' }
          ],
          type: [
            { required: true, message: '请选择房型类型', trigger: 'change' }
          ],
          area: [
            { required: true, message: '请输入房型面积', trigger: 'blur' },
            { type: 'number', required: true, message: '房型面积只能为整数', trigger: 'blur' },
          ],
          bedTypeName: [
            { required: true, message: '请输入房间床型', trigger: 'blur' },
          ],
          capacity: [
            { required: true, message: '请输入可住人数', trigger: 'blur' },
            { type: 'number', message: '可住人数只能为整数'},
            { validator: validatePositiveInteger, trigger: 'blur'}
          ],
          bedCount: [
            { required: true, message: '请选择是否有窗', trigger: 'change' }
          ],
          indieToilet: [
            { required: true, message: '请选择是否独卫', trigger: 'change' }
          ],
          allowSmoking: [
            { required: true, message: '请选择酒店吸烟政策', trigger: 'change' }
          ],
          breakfast: [
            { required: true, message: '请选择早餐政策', trigger: 'change' }
          ],
          wifi: [
            { required: true, message: '请选择房间的宽带情况', trigger: 'change' }
          ],
          utilities: [
            { required: true, message: '请输入房间设施', trigger: 'blur' },
          ],
          dayCount: [
            { required: true, message: '请输入整日租赁基础数量', trigger: 'blur' },
            { type: 'number', message: '整日租赁基础数量只能为整数'},
            { validator: validatePositiveInteger, trigger: 'blur'}
          ],
          hourCount: [
            { required: true, message: '请输入分时租赁基础数量', trigger: 'blur' },
            { type: 'number', message: '分时租赁基础数量只能为整数'},
            { validator: validatePositiveInteger, trigger: 'blur'}
          ],
          normalDayPrice_yuan: [
            { validator: validatenormalDayPrice_yuan, trigger: 'blur'}
          ],
          normalHourPrice_yuan: [
            {required: true, validator: validateNormalHourTime, trigger: 'blur'}
          ],
          normalHourSpecialPrice_yuan: [
            {required: true, validator: validateNormalHourSpecialTime, trigger: 'blur'}
          ],
          wkDayPrice_yuan: [
            { validator: validatewkDayPrice_yuan, trigger: 'blur'}
          ],
          wkHourPrice_yuan: [
            {required: true, validator: validatewkHourPriceTime, trigger: 'blur'}
          ],
          wkHourSpecialPrice_yuan: [
            {required: true, validator: validatewkHourSpecialPriceTime, trigger: 'blur'}
          ]
        },
				active: 0,
				roomTypeList: [],
				breakfastList: [],
				wifiList: [],
				wkDefaultArr: ['1', '2', '3', '4', '7'],
				wkArr: ['5','6'],
				normalDayPrice_yuan: '',
				normalHourPrice_yuan: '',
				normalHourSpecialPrice_yuan: '',
				wkDayPrice_yuan: '',
				wkHourPrice_yuan: '',
				wkHourSpecialPrice_yuan: '',
				firstIn: true,
				defaultHotelId: -1,
				uploadUrl: this.$http.adornUrl(`/sys/oss/upload?token=${this.$cookie.get('token')}`)
			}
		},
    computed: {
      normalSpecialMin: function () {
        return parseInt(this.dataForm.normalHourStart.toString().substring(0,2))-1 < 0 ? '' : parseInt(this.dataForm.normalHourStart.toString().substring(0,2))-1 < 10 ? '0'+(parseInt(this.dataForm.normalHourStart.toString().substring(0,2))-1)+':00' : (parseInt(this.dataForm.normalHourStart.toString().substring(0,2))-1)+':00';
      },
      normalSpecialMax: function () {
        return parseInt(this.dataForm.normalHourEnd.toString().substring(0,2))+1 < 10 ? '0'+(parseInt(this.dataForm.normalHourEnd.toString().substring(0,2))+1)+':00' : (parseInt(this.dataForm.normalHourEnd.toString().substring(0,2))+1)+':00';

      },
      wkSpecialMin: function () {
        return parseInt(this.dataForm.wkHourStart.toString().substring(0,2))-1 < 0 ? '' : parseInt(this.dataForm.wkHourStart.toString().substring(0,2))-1 < 10 ? '0'+(parseInt(this.dataForm.wkHourStart.toString().substring(0,2))-1)+':00' : (parseInt(this.dataForm.wkHourStart.toString().substring(0,2))-1)+':00';
      },
      wkSpecialMax: function () {
        return parseInt(this.dataForm.wkHourEnd.toString().substring(0,2))+1 < 10 ? '0'+(parseInt(this.dataForm.wkHourEnd.toString().substring(0,2))+1)+':00' : (parseInt(this.dataForm.wkHourEnd.toString().substring(0,2))+1)+':00';
      }
    },
    directives: {
      enterNumber: {
        // 指令的定义
        inserted: function (el) {
          el.addEventListener("keypress",function(e){
            e = e || window.event;
            let charcode = typeof e.charCode == 'number' ? e.charCode : e.keyCode;
            let re = /\d/;
            if(!re.test(String.fromCharCode(charcode)) && charcode > 9 && !e.ctrlKey){
              if(e.preventDefault){
                e.preventDefault();
              }else{
                e.returnValue = false;
              }
            }
          });
        }
      }
    },
		methods: {
			next(){
				this.active = 1;
			},
			prev(){
				this.active = 0;
			},
			handleCheckedCitiesChange(value){
				this.wkArr = [];
				var t_arr = [1,2,3,4,5,6,7];
				for(var i = 0; i < value.length; i++){
					var index = t_arr.indexOf(parseInt(value[i]));
					if(index > -1){
						t_arr.splice(index, 1);
					}
				}
				this.wkArr = t_arr;
			},

			initSelect(){
				// 查询房型类型列表
				this.$http({
					url: this.$http.adornUrl_qfs('/setup/setups/collect/hotel_room_type'),
					method: 'get',
					params: this.$http.adornParams()
				}).then(({data}) => {
					this.roomTypeList = [];
					for(var i = 0; i < data.length; i++){
						var t_obj = data[i];
						var t_json = eval('(' + t_obj.data + ')');
						this.roomTypeList.push(t_json);
					}
				})
				// 查询早餐政策列表
				this.$http({
					url: this.$http.adornUrl_qfs('/setup/setups/collect/hotel_breakfast_rule'),
					method: 'get',
					params: this.$http.adornParams()
				}).then(({data}) => {
					this.breakfastList = [];
					for(var i = 0; i < data.length; i++){
						var t_obj = data[i];
						var t_json = eval('(' + t_obj.data + ')');
						this.breakfastList.push(t_json);
					}
				})

				// 查询房间宽带列表
				this.$http({
					url: this.$http.adornUrl_qfs('/setup/setups/collect/hotel_room_wifi'),
					method: 'get',
					params: this.$http.adornParams()
				}).then(({data}) => {
					this.wifiList = [];
					for(var i = 0; i < data.length; i++){
						var t_obj = data[i];
						var t_json = eval('(' + t_obj.data + ')');
						this.wifiList.push(t_json);
					}
				})

			},
			changeHotelSelectFunc(value){
				if(this.firstIn){
					this.firstIn = false;
					if(this.defaultHotelId == -1){// 新增
						this.dataForm.hotelId = value;
					}
				}else{
					this.dataForm.hotelId = value;
				}
			},
			handelWeek(arr){
				this.wkDefaultArr = [];
				// var t_arr = [1,2,3,4,5,6,7];
				var t_arr = ['1','2','3','4','5','6','7'];
				for(var i = 0; i < arr.length; i++){
					var index = t_arr.indexOf(arr[i]);
					if(index > -1){
						t_arr.splice(index, 1);
					}
				}
				this.wkDefaultArr = t_arr;
			},
			init (hotelDefaultId,row) {
				this.visible = false;
				this.dataForm = {
					id: 0,
					hotelId: '',
					name: '',
					type: '',
					status: '0',
					capacity: '',
					dayCount: '',
					hourCount: '',
					area: '',
					bedTypeName: '',
					bedCount: '',
					windowCount: '',
					indieToilet: '',
					allowSmoking: '',
					breakfast: '',
					wifi: '',
					utilities: '',
					images: [],
					weekendDef: [],
					normalHourSwitch: '1',
					normalDayPrice: '',
					normalHourPrice: '',
					normalHourStart: '',
					normalHourEnd: '',
					normalHourSpecialPrice: '',
					normalHourSpecialStart: '',
					normalHourSpecialEnd: '',
					normalHourSpecialSwitch: '1',
					wkHourSwitch: '1',
					wkDayPrice: '',
					wkHourPrice: '',
					wkHourStart: '',
					wkHourEnd: '',
					wkHourSpecialPrice: '',
					wkHourSpecialStart: '',
					wkHourSpecialEnd: '',
					wkHourSpecialSwitch: '1'
				};
				this.active = 0;
				this.roomTypeList = [];
				this.breakfastList = [];
				this.wifiList = [];
				this.wkDefaultArr = ['1','2','3','4','7'];
				this.wkArr = ['5','6'];
				this.normalDayPrice_yuan = '';
				this.normalHourPrice_yuan = '';
				this.normalHourSpecialPrice_yuan = '';
				this.wkDayPrice_yuan = '';
				this.wkHourPrice_yuan = '';
				this.wkHourSpecialPrice_yuan = '';
				this.firstIn = true;
				this.defaultHotelId = -1;

				this.initSelect();

        if(row != undefined){
          this.defaultHotelId = row.hotelId;
          this.dataForm = row;

          this.dataForm.normalHourStart = this.parseDate(row.normalHourStart);
          this.dataForm.normalHourEnd = this.parseDate(row.normalHourEnd);
          this.dataForm.normalHourSpecialStart = this.parseDate(row.normalHourSpecialStart);
          this.dataForm.normalHourSpecialEnd = this.parseDate(row.normalHourSpecialEnd);
          this.dataForm.wkHourStart = this.parseDate(row.wkHourStart);
          this.dataForm.wkHourEnd = this.parseDate(row.wkHourEnd);
          this.dataForm.wkHourSpecialStart = this.parseDate(row.wkHourSpecialStart);
          this.dataForm.wkHourSpecialEnd = this.parseDate(row.wkHourSpecialEnd);

          this.dataForm.type = row.type+'';
          this.dataForm.bedCount = row.bedCount+'';
          this.dataForm.indieToilet = row.indieToilet+'';
          this.dataForm.allowSmoking = row.allowSmoking+'';
          this.dataForm.normalHourSwitch = row.normalHourSwitch+'';
          this.dataForm.normalHourSpecialSwitch = row.normalHourSpecialSwitch+'';
          this.dataForm.wkHourSwitch = row.wkHourSwitch+'';
          this.dataForm.wkHourSpecialSwitch = row.wkHourSpecialSwitch+'';
          this.wkArr = row.weekendDef.replace('[', '').replace(']', '').split(',');
          this.handelWeek(this.wkArr);
          this.normalDayPrice_yuan = row.normalDayPrice / 100;
          this.normalHourPrice_yuan = row.normalHourPrice / 100;
          this.normalHourSpecialPrice_yuan = row.normalHourSpecialPrice / 100;
          this.wkDayPrice_yuan = row.wkDayPrice / 100;
          this.wkHourPrice_yuan = row.wkHourPrice / 100;
          this.wkHourSpecialPrice_yuan = row.wkHourSpecialPrice / 100;
        }

        this.defaultHotelId = hotelDefaultId;

				this.visible = true;
				this.$nextTick(() => {
					this.$refs['child'].queryAllHotelList();
					this.$refs['dataForm'].resetFields();
				})
			},
			handleBeforeUpload(file){
				if (file.type !== 'image/jpg' && file.type !== 'image/jpeg' && file.type !== 'image/png' && file.type !== 'image/gif') {
					this.$message.error('只支持jpg、jpeg、png、gif格式的图片！');
					return false;
				}
				if (file.size > 1024 * 200) {
					this.$message.error('最大支持200kb的图片！');
					return false;
				}
				return true;
			},
			handleSuccess(response, file){
				if (response && response.code === 0) {
					this.dataForm.images.push(response.url)
				} else {
					this.$message.error(response.msg)
				}
			},
			deletePic(obj){
				this.dataForm.images.splice(this.dataForm.images.indexOf(obj), 1);
			},
			dataFormSubmit (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.fullscreenLoading = true;
            this.dataForm['normalDayPrice'] = this.normalDayPrice_yuan *100;
            this.dataForm['wkDayPrice'] = this.wkDayPrice_yuan * 100;
            if(this.dataForm['normalHourSwitch'] == 0){
              this.dataForm['normalHourPrice'] = '';
              this.dataForm['normalHourStart'] = '';
              this.dataForm['normalHourEnd'] = '';
              this.dataForm['normalHourSpecialPrice'] = '';
              this.dataForm['normalHourSpecialStart'] = '';
              this.dataForm['normalHourSpecialEnd'] = '';
              this.dataForm['normalHourSpecialSwitch'] = '';
            }else{
              this.dataForm['normalHourStart'] = this.dataForm['normalHourStart'].toString().substring(0,2);
              this.dataForm['normalHourEnd'] = this.dataForm['normalHourEnd'].toString().substring(0,2);
              this.dataForm['normalHourPrice'] = this.normalHourPrice_yuan * 100;
              if(this.dataForm['normalHourSpecialSwitch'] == 0){
                this.dataForm['normalHourSpecialPrice'] = '';
                this.dataForm['normalHourSpecialStart'] = '';
                this.dataForm['normalHourSpecialEnd'] = '';
              }else{
                this.dataForm['normalHourSpecialStart'] = this.dataForm['normalHourSpecialStart'].toString().substring(0,2);
                this.dataForm['normalHourSpecialEnd'] = this.dataForm['normalHourSpecialEnd'].toString().substring(0,2);
                this.dataForm['normalHourSpecialPrice'] = this.normalHourSpecialPrice_yuan * 100;
              }
            }
            if(this.dataForm['wkHourSwitch'] == 0){
              this.dataForm['wkHourPrice'] = '';
              this.dataForm['wkHourStart'] = '';
              this.dataForm['wkHourEnd'] = '';
              this.dataForm['wkHourSpecialPrice'] = '';
              this.dataForm['wkHourSpecialStart'] = '';
              this.dataForm['wkHourSpecialEnd'] = '';
              this.dataForm['wkHourSpecialSwitch'] = '';
            }else{
              this.dataForm['wkHourStart'] = this.dataForm['wkHourStart'].toString().substring(0,2);
              this.dataForm['wkHourEnd'] = this.dataForm['wkHourEnd'].toString().substring(0,2);
              this.dataForm['wkHourPrice'] = this.wkHourPrice_yuan * 100;
              if(this.dataForm['wkHourSpecialSwitch'] == 0){
                this.dataForm['wkHourSpecialPrice'] = '';
                this.dataForm['wkHourSpecialStart'] = '';
                this.dataForm['wkHourSpecialEnd'] = '';
              }else{
                this.dataForm['wkHourSpecialStart'] = this.dataForm['wkHourSpecialStart'].toString().substring(0,2);
                this.dataForm['wkHourSpecialEnd'] = this.dataForm['wkHourSpecialEnd'].toString().substring(0,2);
                this.dataForm['wkHourSpecialPrice'] = this.wkHourSpecialPrice_yuan * 100;
              }
            }
            this.dataForm['weekendDef'] = this.wkArr;
            this.$http({
              url: this.$http.adornUrl_qfs(`/hotel/rooms/${!this.dataForm.id ? 'add' : this.dataForm.id + '/update'}`),
              method: 'post',
              data: this.$http.adornData(this.dataForm)
            }).then(({data}) => {
              this.fullscreenLoading = false;
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false;
                    this.$emit('refreshDataList');
                  }
                })
              } else {
                this.$message.error(data.msg);
              }
            })
          } else {
            this.$message.error("表单未通过校验，请检查您的内容后重试！");
            return false;
          }
        });

			},
      parseDate(time){
			  let rTime;
			  if(time < 10){
			    rTime = '0' + time + ':00';
        }else{
          rTime = time+':00';
        }
        return rTime.substring(0,5)
      }
		},
		components: {
			Upload,
			HotelSelect
		},
		filters: {
			wkArrFilter(arr) {
				var t_arr = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日'];
				var result = '';
				for(var i = 0; i < arr.length; i++){
					result += '#' + t_arr[arr[i] - 1] + '#';
				}
				return result;
			}
		}
	}
</script>

<style lang="scss">
	.elcm0{
		font-size: 12px;
		.el-checkbox+.el-checkbox{
			margin-left: 5px;
		}
	}
</style>
