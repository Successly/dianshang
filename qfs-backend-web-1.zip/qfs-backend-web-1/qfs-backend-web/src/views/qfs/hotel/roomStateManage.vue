<template>
	<div class="block">
		<div class="search_area">
			<el-form :inline="true" :model="formInline" class="demo-form-inline" label-width="100px">
				<el-form-item label="酒店名称">
        <hotel-select @changeSelectFunc="changeHotelSelectFunc"></hotel-select>
      </el-form-item>
				<el-form-item>
					<el-button type="primary" @click="queryResult">查询</el-button>
				</el-form-item>
			</el-form>
		</div>
		<div class="search_result" v-if="isResultShow">
			<el-tabs v-model="formInline.type" @tab-click="handleClick">
				<el-tab-pane label="整日租赁" name="day">
					<div class="date_select">
						<div><el-button type="text" :disabled="dateSelectClickNum == 1" @click="changeDateSelect(1)"><<前7天</el-button></div>
						<div class="date_select_day">{{formInline.dayStart}}</div>
						<div><el-button type="text" :disabled="!canClick" @click="changeDateSelect(2)">后7天>></el-button></div>
					</div>
					<div class="block page_table">
						<el-row class="page_table_head">
							<el-col :span="3" style="line-height: 48px;">房型</el-col>
							<el-col :span="3" v-for="item in tableHeadList">
								{{item}}<br/>{{item | getWeek}}
							</el-col>
						</el-row>
						<el-row class="page_table_body" v-for="item in tableDataList" style="height: 120px;">
							<el-col :span="3">
								<p style="margin-top: 24px;">{{item.name}}</p>
								<el-checkbox v-model="item.isShowPrice">价格</el-checkbox>
							</el-col>
							<el-col :span="3" v-for="obj in item.statusDetail">
								<p v-if="obj.status == 0">{{obj.remain + '间'}}<el-button icon="el-icon-edit" circle size="mini" style="width: 20px;" @click="updateRoom(item.id, obj.day, item.dayCount, obj.status)"></el-button></p>
								<el-button type="success" v-if="obj.status == 0" size="mini" @click="roomFull(item.id, obj.day)">有房</el-button>
								<el-button type="info" v-if="obj.status == 1" size="mini" @click="updateRoom(item.id, obj.day, item.dayCount, obj.status)">满房</el-button>
								<p v-if="item.isShowPrice && !!obj.todayPrice">{{obj.todayPrice | moneyToY}}每晚</p>
							</el-col>
						</el-row>
					</div>
				</el-tab-pane>
				<el-tab-pane label="分时租赁" name="hour">
					<div class="date_select">
						<div><el-button type="text" :disabled="dateSelectClickNum == 1" @click="changeDateSelect(1)"><<前7天</el-button></div>
						<div class="date_select_day">{{formInline.dayStart}}</div>
						<div><el-button type="text" :disabled="!canClick" @click="changeDateSelect(2)">后7天>></el-button></div>
					</div>
					<div class="block page_table">
						<el-row class="page_table_head">
							<el-col :span="3" style="line-height: 48px;">房型</el-col>
							<el-col :span="3" v-for="item in tableHeadList">
								{{item}}<br/>{{item | getWeek}}
							</el-col>
						</el-row>
						<el-row class="page_table_body" v-for="item in tableDataList" style="height: 160px;">
							<el-col :span="3">
								<p>{{item.name}}</p>
								<div class="page_table_head_tip">
									<span>开放时间</span>
									<span>平时 {{item.normalHourStart}}：00至{{item.normalHourEnd}}：00</span>
									<span>周末 {{item.wkHourStart}}：00至{{item.wkHourEnd}}：00</span>
								</div>
							</el-col>
							<el-col :span="3" v-for="obj in item.statusDetail" style="padding-top: 20px;">
								<p v-if="obj.status == 0">{{obj.remain + '间'}}<el-button icon="el-icon-edit" circle size="mini" style="width: 20px;" @click="updateRoom(item.id, obj.day, item.hourCount,obj.status)"></el-button></p>
								<el-button type="success" v-if="obj.status == 0" size="mini" @click="roomFull(item.id, obj.day)">有房</el-button>
								<el-button type="info" v-if="obj.status == 1" size="mini" @click="updateRoom(item.id, obj.day, item.hourCount, obj.status)">满房</el-button>
							</el-col>
						</el-row>
					</div>
				</el-tab-pane>
			</el-tabs>
		</div>

		<!--弹窗-->
		<el-dialog
		  v-if="dialogShow"
		  title="修改房态房量"
		  :close-on-click-modal="false"
		  :before-close="closeDialog"
		  :visible.sync="visible"
		  width="600px">
			<el-form :model="dialogData" label-width="100px">
				<el-form-item label="房态设置">
					<el-radio v-model="dialogData.status" label="0">开房</el-radio>
					<el-radio v-model="dialogData.status" label="1">关房</el-radio>
				</el-form-item>
				<el-form-item label="房量设置" v-if="dialogData.status == 0">
					<el-radio v-model="dialogData.isLimit" label="0">无限量</el-radio>
					<el-radio v-model="dialogData.isLimit" label="1">限量</el-radio>
				</el-form-item>
				<el-form-item label="剩余房量" v-if="dialogData.status == 0 && dialogData.isLimit == 1">
					<el-input-number v-model="dialogData.remain" :min="1" :max="roomCount" label="剩余房量"></el-input-number>
				</el-form-item>
			</el-form>
			<span slot="footer" class="dialog-footer">
				<el-button @click="closeDialog">取 消</el-button>
				<el-button type="primary" @click="saveInfo">确 定</el-button>
			</span>
		</el-dialog>
	</div>
</template>

<script>

	import HotelSelect from '@/plugin/hotelSelect'
	import {formatDate, datePlus, dateSubtract, formatDateToWeek} from '@/utils'

	export default {
		data () {
			return {
				formInline: {
					hotelId: '',
					type: 'day',
					dayStart: formatDate(new Date(), 'yyyy-MM-dd'),
					dayEnd: formatDate(datePlus(new Date(), 6), 'yyyy-MM-dd')
				},
				isResultShow: false,
				dateSelectClickNum: 1,
				tableHeadList: [
					formatDate(new Date(), 'yyyy-MM-dd'),
					formatDate(datePlus(new Date(), 1), 'yyyy-MM-dd'),
					formatDate(datePlus(new Date(), 2), 'yyyy-MM-dd'),
					formatDate(datePlus(new Date(), 3), 'yyyy-MM-dd'),
					formatDate(datePlus(new Date(), 4), 'yyyy-MM-dd'),
					formatDate(datePlus(new Date(), 5), 'yyyy-MM-dd'),
					formatDate(datePlus(new Date(), 6), 'yyyy-MM-dd')
				],
				tableDataList: [],
				firstIn: true,
				nowHid: '',
				dialogShow: false,
				visible: false,
				dialogData: {
					roomId: '',
					day: '',
					status: '0',
					isLimit: '0',
					remain: 1,
          originalStatus: '0' //dang
				},
				roomCount: 10,
				canClick: true
			}
		},
		created () {

		},
		activated () {

		},
		methods: {
			changeHotelSelectFunc(value){
				this.formInline.hotelId = value;
				if(this.firstIn){
					this.firstIn = false;
					this.queryResult();
				}
			},
			queryResult(){
				this.$http({
					url: this.$http.adornUrl_qfs('/hotel/rooms/status'),
					method: 'get',
					params: this.$http.adornParams(this.formInline)
				}).then(({data}) => {
					if (data && data.code === 0) {
						for(var i = 0; i < data.data; i++){
							data.data[i]['isShowPrice'] = false;
						}
						var flag = false;
						for(var i = 0; i < data.data.length; i++){
							var list = data.data[i].statusDetail;
							if(list.length != 7){
								var len = 7 - list.length;
								for(var j = 0; j < len; j++){
									list.push({});
								}
							}else{
								flag = true;
							}
						}
						this.canClick = flag;
						this.tableDataList = data.data;
						this.isResultShow = true;
						this.nowHid = this.formInline.hotelId;
					} else {
						this.tableDataList = [];
					}
				})
			},
			handleClick(){
				this.queryResult();
			},
			changeDateSelect(type){
				if(type == 1){
					this.dateSelectClickNum++;
					this.formInline.dayStart = formatDate(dateSubtract(new Date(this.formInline.dayStart), 7), 'yyyy-MM-dd');
					this.formInline.dayEnd = formatDate(dateSubtract(new Date(this.formInline.dayEnd), 7), 'yyyy-MM-dd');
					this.tableHeadList = [
						formatDate(new Date(this.formInline.dayStart), 'yyyy-MM-dd'),
						formatDate(datePlus(new Date(this.formInline.dayStart), 1), 'yyyy-MM-dd'),
						formatDate(datePlus(new Date(this.formInline.dayStart), 2), 'yyyy-MM-dd'),
						formatDate(datePlus(new Date(this.formInline.dayStart), 3), 'yyyy-MM-dd'),
						formatDate(datePlus(new Date(this.formInline.dayStart), 4), 'yyyy-MM-dd'),
						formatDate(datePlus(new Date(this.formInline.dayStart), 5), 'yyyy-MM-dd'),
						formatDate(datePlus(new Date(this.formInline.dayStart), 6), 'yyyy-MM-dd')
					]
				}else{
					this.dateSelectClickNum--;
					this.formInline.dayStart = formatDate(datePlus(new Date(this.formInline.dayStart), 7), 'yyyy-MM-dd');
					this.formInline.dayEnd = formatDate(datePlus(new Date(this.formInline.dayEnd), 7), 'yyyy-MM-dd');
					this.tableHeadList = [
						formatDate(new Date(this.formInline.dayStart), 'yyyy-MM-dd'),
						formatDate(datePlus(new Date(this.formInline.dayStart), 1), 'yyyy-MM-dd'),
						formatDate(datePlus(new Date(this.formInline.dayStart), 2), 'yyyy-MM-dd'),
						formatDate(datePlus(new Date(this.formInline.dayStart), 3), 'yyyy-MM-dd'),
						formatDate(datePlus(new Date(this.formInline.dayStart), 4), 'yyyy-MM-dd'),
						formatDate(datePlus(new Date(this.formInline.dayStart), 5), 'yyyy-MM-dd'),
						formatDate(datePlus(new Date(this.formInline.dayStart), 6), 'yyyy-MM-dd')
					]
				}
				this.queryResult();
			},
			roomFull(roomId, day){
				this.$http({
					url: this.$http.adornUrl_qfs('/hotel/rooms/status/update'),
					method: 'post',
					data: this.$http.adornData({
						hotelId: this.nowHid,
						roomId: roomId,
						type: this.formInline.type,
						day: day,
						status: 1
					})
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.queryResult();
					} else {
						this.$message.error(data.msg);
					}
				})
			},
			updateRoom(roomId, day, maxNum, originalStatus){
				this.roomCount = maxNum;
				this.dialogData.roomId = roomId;
				this.dialogData.day = day;
        this.dialogData.originalStatus = originalStatus;
				this.dialogShow = true;
				this.visible = true;
			},
			closeDialog(){
				this.dialogShow = false;
				this.visible = false;
				this.dialogData = {
					roomId: '',
					day: '',
					status: '0',
					isLimit: '0',
					remain: 1
				};
				this.roomCount = 10;
			},
			saveInfo(){
				var param = {
					hotelId: this.nowHid,
					roomId: this.dialogData.roomId,
					type: this.formInline.type,
					day: this.dialogData.day,
					status: this.dialogData.status
				}
				if(this.dialogData.status == 0){
					param['remain'] = this.dialogData.isLimit == 0 ? this.roomCount : this.dialogData.remain;
				}else if(this.dialogData.status == 1 && this.dialogData.originalStatus == 1){
          this.closeDialog();
          this.queryResult();
          return;
        }
				this.$http({
					url: this.$http.adornUrl_qfs('/hotel/rooms/status/update'),
					method: 'post',
					data: this.$http.adornData(param)
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.closeDialog();
						this.queryResult();
					} else {
						this.$message.error(data.msg);
					}
				})
			}
		},
		components: {
			HotelSelect
		},
		filters: {
			getWeek(dataStr){
				return formatDateToWeek(new Date(dataStr));
			},
      moneyToY(money){// 分转元
        return parseInt(money / 100);
      }
		}
	}
</script>

<style lang="scss">
	.date_select{
		line-height: 30px;
		font-size: 14px;
		border: 1px solid #666;
		width: 320px;
		div{
			display: inline-block;
			width: 80px;
			text-align: center;
		}
		div.date_select_day{
			width: 150px;
			border-left: 1px solid #666;
			border-right: 1px solid #666;
		}
	}

	.page_table{
		margin-top: 20px;
		border-left: 1px solid #666;
    .el-col{
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 0;
      border-right: 1px solid #666;
    }
		.page_table_head{
			line-height: 24px;
			font-size: 14px;
			text-align: center;
			border-top: 1px solid #666;
			border-bottom: 1px solid #666;
			.el-col{
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 0;
				border-right: 1px solid #666;
			}
		}
		.page_table_body{
			line-height: 24px;
			font-size: 14px;
			text-align: center;
			height: 90px;
			display: -webkit-flex;
			display: flex;
			justify-content: center;
			align-items: center;
			border-bottom: 1px solid #666;
			.el-col{
				border-right: 1px solid #666;
				height: 100%;
			}
			p{
				margin: 0;
			}
			.page_table_head_tip{
				font-size: 10px;
				line-height: 18px;
				border: 1px solid #3BB19C;
				color: #3BB19C;
				border-radius: 4px;
				width: 110px;
				margin: auto;
				span{
					display: inline-block;
					width: 100%;
				}
			}
			.el-button{
				width: 40px;
				height: 20px;
				padding: 0;
				margin-bottom: 5px;
				margin-left: 5px;
			}
		}
	}
</style>
