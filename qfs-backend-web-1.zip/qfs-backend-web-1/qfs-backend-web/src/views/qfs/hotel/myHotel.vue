<template>
  <div>
    <div class="search_area">
		<hotel-select @changeSelectFunc="changeSelectFunc"></hotel-select>
	</div>

	<div class="hotel-info" v-if="infoShow">
		<el-row>
			<h4>酒店信息</h4>
		</el-row>
		<div class="hotel-info-block">
			<el-row>
				<el-col :span="6">
					<div class="block form_title">基本信息</div>
				</el-col>
				<el-col :span="18">
					<el-row>
						<el-col :span="24">酒店名称：{{hotelInfo.name}}</el-col>
					</el-row>
					<el-row>
						<el-col :span="16">
							<el-row>
								<el-col :span="24">酒店状态：{{hotelInfo.status == 0 ? '正常营业' : (hotelInfo.status == 1 ? '暂停营业' : (hotelInfo.status == -1 ? '已倒闭' : '未知状态'))}}</el-col>
							</el-row>
							<el-row>
								<el-col :span="24">酒店类型：{{hotelTypeName}}</el-col>
							</el-row>
							<el-row>
								<el-col :span="24">前台电话：{{hotelInfo.phone}}</el-col>
							</el-row>
							<el-row>
								<el-col :span="24">酒店联系人：{{hotelInfo.mobile}}</el-col>
							</el-row>
						</el-col>
						<el-col :span="8">
							<div id="mapContainer" style="width: 90%;height: 160px;margin: auto;"></div>
						</el-col>
					</el-row>
					<el-row>
						<el-col :span="24">所属地区：{{hotelInfo.province + ' / ' + hotelInfo.city + ' / ' + hotelInfo.district}}</el-col>
					</el-row>
					<el-row>
						<el-col :span="24">详细地址：{{hotelInfo.addressDetail}}</el-col>
					</el-row>
					<el-row>
						<el-col :span="12">是否允许携带宠物：{{hotelInfo.pets == 0 ? '不允许' : '允许'}}</el-col>
						<el-col :span="12">是否接待外宾：{{hotelInfo.foreign == 0 ? '不接待' : '接待'}}</el-col>
					</el-row>
					<el-row>
						<el-col :span="12">膳食餐饮：{{hotelInfo.foodService}}</el-col>
						<el-col :span="12">停车政策：{{hotelInfo.parkService}}</el-col>
					</el-row>
					<el-row>
						<el-col :span="24">酒店标签：
							<span v-for="item in hotelInfo.tags" style="margin-right: 10px;">#{{item}}#</span>
						</el-col>
					</el-row>
				</el-col>
			</el-row>
		</div>
		<div class="hotel-info-block">
			<el-row>
				<el-col :span="6">
					<div class="block form_title">政策信息</div>
				</el-col>
				<el-col :span="18">
					<el-row>
						<el-col :span="12"><span class="hotel-info-block-title">分时租赁退款政策</span></el-col>
						<el-col :span="12"><span class="hotel-info-block-title">整日租赁退款政策</span></el-col>
					</el-row>
					<el-row>
						<el-col :span="12">是否允许退款：允许退款（全款退款）</el-col>
						<el-col :span="12">是否允许退款：允许退款（全款退款）</el-col>
					</el-row>
					<el-row>
						<el-col :span="12">退款时间限制：入住当天18：00前允许退款</el-col>
						<el-col :span="12">退款时间限制：入住当天18：00前允许退款</el-col>
					</el-row>
					<el-row>
						<el-col :span="24"><span class="hotel-info-block-title">订单提醒<span class="tips_grey">[试运营3个月（2019.03-2019.05），试运营期间不收取费用]</span></span></el-col>
					</el-row>
					<el-row>
						<el-col :span="24">入住订单：短信提醒 15005150872；语音提醒：025-88882222</el-col>
					</el-row>
					<el-row>
						<el-col :span="24">取消订单：短信提醒 15005150872；语音提醒：未设置</el-col>
					</el-row>
					<el-row>
						<el-col :span="24"><span style="color: #3bb19c;">[退款政策、订单提醒修改请联系BD]</span></el-col>
					</el-row>
				</el-col>
			</el-row>
		</div>
		<div class="hotel-info-block">
			<el-row>
				<el-col :span="6">
					<div class="block form_title">财务信息</div>
				</el-col>
				<el-col :span="18">
					<el-row>
						<el-col :span="24"><span class="hotel-info-block-title">打款账号</span></el-col>
					</el-row>
					<el-row>
						<el-col :span="24">开户行：{{hotelInfo.bank+' | '+hotelInfo.branchBank+' | '+hotelInfo.subBaranchBank}}</el-col>
					</el-row>
					<el-row>
						<el-col :span="24">开户名：{{hotelInfo.accountName}}</el-col>
					</el-row>
					<el-row>
						<el-col :span="24">账号信息：{{hotelInfo.account}}</el-col>
					</el-row>
					<el-row>
						<el-col :span="24"><span style="color: #3bb19c;">[财务信息修改请联系BD]</span></el-col>
					</el-row>
				</el-col>
			</el-row>
		</div>
	</div>
  </div>
</template>

<script>

	import HotelSelect from '../../../plugin/hotelSelect'
	import { TMap } from '@/TMap/TMap'

	export default {
		data () {
			return {
				hotelId: '',
				hotelInfo: {},
				qqKey: 'IRGBZ-U36WV-UDXPC-UOIJ2-24G5T-A5BT2',
				geocoder: {},
				infoShow: false,
				hotelTypeList: [],
				firstIn: true
			}
		},
		computed: {
			hotelTypeName: function(){
				for(var i = 0; i < this.hotelTypeList.length; i++){
					if(this.hotelTypeList[i].code == this.hotelInfo.type){
						return this.hotelTypeList[i].name;
					}
				}
				return '未知类型';
			}
		},
		created () {
			TMap(this.qqKey).then(qq => {
				this.geocoder = new qq.maps.Geocoder({
					complete:function(result){
						var map = map = new qq.maps.Map(document.getElementById("mapContainer"), {
							center: result.detail.location,
							zoom: 17
						})
						var marker = new qq.maps.Marker({
							map:map,
							position: result.detail.location
						});
					}
				});
			});
			// 查询酒店类型列表
			this.$http({
				url: this.$http.adornUrl_qfs('/setup/setups/collect/hotel_type'),
				method: 'get',
				params: this.$http.adornParams()
			}).then(({data}) => {
				this.hotelTypeList = [];
				for(var i = 0; i < data.length; i++){
					var t_obj = data[i];
					var t_json = eval('(' + t_obj.data + ')');
					this.hotelTypeList.push(t_json);
				}
			})
		},
		activated () {

		},
		methods: {
			changeSelectFunc(value){
				this.hotelId = value;
				this.queryHotelInfo();
			},
			getAddress(addr){
				this.geocoder.getLocation(addr);
			},
			queryHotelInfo(){
				this.$http({
					url: this.$http.adornUrl_qfs('/hotel/hotels/detail/' + this.hotelId),
					method: 'get',
					params: this.$http.adornParams({
						'id': this.hotelId
					})
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.hotelInfo = data.data;
						this.geocoder.getLocation(this.hotelInfo.province+this.hotelInfo.city+this.hotelInfo.district+this.hotelInfo.addressDetail);
						this.infoShow = true;
					} else {
						this.hotelInfo = {};
						this.infoShow = false;
					}
				})
			}
		},
		components: {
			HotelSelect
		}
	}
</script>

<style lang="scss">
	.hotel-info-block{
		font-size: 14px;
		line-height: 40px;
		color: #666666;
		background: #f0f0f0;
		margin-bottom: 20px;
		.hotel-info-block-title{
			font-weight: bold;
			font-size: 16px;
			color: #000;
			.tips_grey{
				margin-left: 20px;
				color: #ccc;
			}
		}
	}
	.form_title{
    line-height: 40px;
    font-size: 24px;
    width: 150px;
    background: #9ea7b4;
    margin: 10px auto;
    padding: 8px;
    text-align: center;
    border-radius: 6px;
    color: #fff;
	}
</style>

