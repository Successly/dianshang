<template>
	<div class="block">
		<el-form :model="formInline" :rules="formRules" ref="formInline" label-width="140px">
			<el-row>
				<el-col :span="6">
					<div class="block form_title">基本信息</div>
				</el-col>
				<el-col :span="18">
					<el-row>
						<el-form-item prop="name" label="酒店名称">
							<el-input v-model="formInline.name" placeholder="请输入" style="width: 200px;"></el-input>
						</el-form-item>
					</el-row>
					<el-row>
						<el-form-item prop="type" label="酒店类型">
							<el-select v-model="formInline.type" placeholder="请选择" style="width: 200px;">
								<el-option
								  v-for="item in hotelTypeList"
								  :key="item.code"
								  :label="item.name"
								  :value="item.code">
								</el-option>
							</el-select>
						</el-form-item>
					</el-row>
					<el-row>
						<el-form-item prop="status" label="酒店状态">
							<el-radio v-for="item in hotelStateList" v-model="formInline.status" :label="item.value">{{item.label}}</el-radio>
						</el-form-item>
					</el-row>
					<el-row>
						<el-form-item prop="phone" label="前台电话">
							<el-input v-model="formInline.phone" placeholder="请输入" style="width: 200px;"></el-input>
						</el-form-item>
					</el-row>
					<el-row>
						<el-form-item prop="mobile" label="酒店联系人">
							<el-input v-model="formInline.mobile" placeholder="请输入" style="width: 200px;"></el-input>
						</el-form-item>
					</el-row>
					<el-row>
						<el-form-item label="所属地区">
							<ssq-select ref="ssq" :ssqValuesArr="ssqValuesArr" @changeFunc="changeSSQFunc"></ssq-select>
						</el-form-item>
					</el-row>
					<el-row>
						<el-form-item prop="addressDetail" label="详细地址">
							<el-input v-model="formInline.addressDetail" placeholder="请输入" style="width: 400px;"></el-input>
						</el-form-item>
					</el-row>
          <el-row>
            <el-form-item prop="lng" label="经度">
              <el-input v-model="formInline.lng" placeholder="请输入经度" style="width: 400px;"></el-input>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item prop="lat" label="纬度">
              <el-input v-model="formInline.lat" placeholder="请输入纬度" style="width: 400px;"></el-input>
            </el-form-item>
          </el-row>
					<el-row>
						<el-form-item prop="summary" label="酒店描述">
							<el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4 }" v-model="formInline.summary" placeholder="请输入" style="width: 400px;"></el-input>
						</el-form-item>
					</el-row>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="6">
					<div class="block form_title">服务特色</div>
				</el-col>
				<el-col :span="18">
					<el-row>
						<el-form-item prop="pets" label="是否允许携带宠物">
							<el-radio v-model="formInline.pets" :label="1">允许</el-radio>
							<el-radio v-model="formInline.pets" :label="0">不允许</el-radio>
						</el-form-item>
					</el-row>
					<el-row>
						<el-form-item prop="foreign" label="是否接待外宾">
							<el-radio v-model="formInline.foreign" :label="1">接待</el-radio>
							<el-radio v-model="formInline.foreign" :label="0">不接待</el-radio>
						</el-form-item>
					</el-row>
					<el-row>
						<el-form-item prop="foodService" label="膳食餐饮">
							<el-select v-model="formInline.foodService" placeholder="请选择" style="width: 200px;">
								<el-option
								  v-for="item in hotelFoodList"
								  :key="item.code"
								  :label="item.name"
								  :value="item.name">
								</el-option>
							</el-select>
						</el-form-item>
					</el-row>
					<el-row>
						<el-form-item prop="parkService" label="停车政策">
							<el-select v-model="formInline.parkService" placeholder="请选择" style="width: 200px;">
								<el-option
								  v-for="item in hotelParkList"
								  :key="item.code"
								  :label="item.name"
								  :value="item.name">
								</el-option>
							</el-select>
						</el-form-item>
					</el-row>
					<el-row>
						<el-form-item prop="tags" label="酒店标签">
							<el-select v-model="formInline.tags" multiple placeholder="请选择" style="width: 400px;">
								<el-option
								  v-for="item in hotelTagsList"
								  :key="item.code"
								  :label="item.name"
								  :value="item.name">
								</el-option>
							</el-select>
						</el-form-item>
					</el-row>
					<el-row>
						<el-form-item label="酒店特色">
							<el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4 }" v-model="hotelDesc" placeholder="请输入" style="width: 400px;" maxlength="200"></el-input>
							<el-row style="margin-top: 10px;">
								<el-button type="success" @click="saveHotelDesc" :disabled="formInline.features.length == 3">保存</el-button>
								<span>（最多可以添加3条酒店特色，每条最多200字符）</span>
							</el-row>
							<el-row v-for="item in formInline.features" :gutter="30">
								<el-col :span="16">
									<p style="margin: 0;word-wrap: break-word;word-break: break-all;overflow: hidden;">{{item}}</p>
								</el-col>
								<el-col :span="4">
									<el-button type="text" @click="deleteHotelDesc(item)">删除</el-button>
								</el-col>
							</el-row>
						</el-form-item>
					</el-row>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="6">
					<div class="block form_title">酒店图片</div>
				</el-col>
				<el-col :span="18">
					<el-row :gutter="20" type="flex" align="bottom">
						<el-col v-for="item in uploadPicList" :span="4">
							<el-card :body-style="{ padding: '0px' }" class="uploadPicCard">
								<img :src="item.url">
								<div class="block" style="text-align: center;">
									<el-button type="text" @click="deletePic(item)">删除图片</el-button>
								</div>
							</el-card>
						</el-col>
					</el-row>
					<el-row>
						<el-upload
						  :action="uploadUrl"
						  :show-file-list="false"
						  :before-upload="handleBeforeUpload"
						  :on-success="handleSuccess">
							<el-button size="small" type="primary" style="margin: 20px 20px 20px 0;">点击上传</el-button>
							<div slot="tip" style="display: inline-block;font-size: 12px;">建议尺寸800*800px，大小200kb内。</div>
						</el-upload>
					</el-row>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="6">
					<div class="block form_title">财务信息</div>
				</el-col>
				<el-col :span="18">
					<el-row>
						<el-form-item prop="bank" label="开户行">
							<el-select v-model="formInline.bank" placeholder="请选择" style="width: 200px;">
								<el-option
								  v-for="item in bankList"
								  :key="item.code"
								  :label="item.name"
								  :value="item.name">
								</el-option>
							</el-select>
							<el-input v-model="formInline.branchBank" placeholder="请输入开户所属分行" style="width: 200px;"></el-input>
							<el-input v-model="formInline.subBaranchBank" placeholder="请输入开户所属支行" style="width: 200px;"></el-input>
						</el-form-item>
					</el-row>
					<el-row>
						<el-form-item prop="accountName" label="开户名">
							<el-input v-model="formInline.accountName" placeholder="请输入" style="width: 200px;"></el-input>
						</el-form-item>
					</el-row>
					<el-row>
						<el-form-item prop="account" label="账号信息">
							<el-input v-model="formInline.account" placeholder="请输入" style="width: 200px;"></el-input>
						</el-form-item>
					</el-row>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="6">
					<div class="block form_title">签约信息</div>
				</el-col>
				<el-col :span="18">
					<!--<el-row>
						<el-form-item prop="signBdId" label="签约BD">
							<el-input v-model="formInline.signBdId" placeholder="请输入" style="width: 200px;"></el-input>
						</el-form-item>
					</el-row>-->
					<el-row>
						<el-form-item prop="signTime" label="签约时间">
							<el-date-picker
							  v-model="formInline.signTime"
							  type="date"
							  placeholder="选择日期"
							  style="width: 200px;">
							</el-date-picker>
						</el-form-item>
					</el-row>
					<el-row>
						<el-form-item prop="sharePercent" label="服务费比例">
							<el-input-number v-model="formInline.sharePercent" :step="1" :min="0" :max="100"></el-input-number>（0≤服务费比例≤100）
						</el-form-item>
					</el-row>
				</el-col>
			</el-row>
			<el-row style="text-align: center;">
				<el-button type="success" @click="saveHote('formInline')">保存并确认</el-button>
			</el-row>
		</el-form>
	</div>
</template>

<script>

	import SsqSelect from '@/plugin/ssqSelect'
	import {formatDate} from '@/utils'

	export default {
		data () {
      var validateBankInfo = (rule, value, callback) => {
        //验证密码
        if (value === ''|| this.formInline.branchBank == '' || this.formInline.subBaranchBank == '') {
          callback(new Error('请完善开户行信息'));
        } else {
          callback();
        }
      };
      var validateTagLength = (rule, value, callback) => {
        //验证标签长度
        if (value.length > 5 ) {
          callback(new Error('最多支持5个标签'));
        } else {
          callback();
        }
      };
      var validatePhoneAndTel = (rule, value, callback) => {
        //验证标签长度
        if (!/^((0[0-9]{2,3}\-)?([2-9][0-9]{6,7})+(\-[0-9]{1,4})?)$|^(0?[1][34578][0-9]{9})$|^(400[0-9]{7})$/.test(value) ) {
          callback(new Error('请填写正确的电话号码'));
        } else {
          callback();
        }
      };
			return {
				formInline: {
					name: '',
					phone: '',
					mobile: '',
					type: '',
					status: '',
					province: '',
					city: '',
					district: '',
					addressCode: '',
					addressDetail: '',
					summary: '',
					pets: '',
					foreign: '',
					foodService: '',
					parkService: '',
					tags: [],
					features: [],
					bank: '',
          lat: '',
          lng: '',
					branchBank: '',
					subBaranchBank: '',
					accountName: '',
					account: '',
					// signBdId: '',
					signTime: '',
					sharePercent: '',
					images: []
				},
        formRules: {
          name: [
            { required: true, message: '请输入酒店名称', trigger: 'blur' },
            { max: 50, message: '酒店名称最多50个字符', trigger: 'blur' }
          ],
          type: [
            { required: true, message: '请选择酒店类型', trigger: 'change' }
          ],
          status: [
            { required: true, message: '请选择酒店状态', trigger: 'change' }
          ],
          phone: [
            { required: true, message: '请填写前台电话', trigger: 'blur' },
            { validator: validatePhoneAndTel, trigger: 'blur'}
          ],
          mobile: [
            { required: true, message: '请填写酒店联系人', trigger: 'blur' }
          ],
          addressDetail: [
            { required: true, message: '请填写详细地址', trigger: 'blur' }
          ],
          lng: [
            { required: true, message: '请填写经度', trigger: 'blur' }
          ],
          lat: [
            { required: true, message: '请填写纬度', trigger: 'blur' }
          ],
          summary: [
            { required: true, message: '请填写酒店描述', trigger: 'blur' },
            { max: 50, message: '酒店描述最多50个字符', trigger: 'blur' }
          ],
          pets: [
            { required: true, message: '请确认是否允许携带宠物', trigger: 'change' }
          ],
          foreign: [
            { required: true, message: '请确认是否接待外宾', trigger: 'change' }
          ],
          foodService: [
            { required: true, message: '请选择膳食餐饮方式', trigger: 'change' }
          ],
          parkService: [
            { required: true, message: '请选择停车政策', trigger: 'change' }
          ],
          tags: [
            { required: true, message: '请选择酒店标签', trigger: 'change' },
            {validator: validateTagLength, trigger: 'change'}
          ],
          bank: [
            { required: true, message: '请选择开户行', trigger: 'change' },
            {validator: validateBankInfo, trigger: 'blur'}
          ],
          accountName: [
            { required: true, message: '请输入开户名', trigger: 'blur' }
          ],
          account: [
            { required: true, message: '请输入账号信息', trigger: 'blur' }
          ],
        /*  signBdId: [
            { required: true, message: '请输入签约BD', trigger: 'blur' }
          ],*/
          signTime: [
            { type: 'date', required: true, message: '请选择签约时间', trigger: 'change' }
          ],
          sharePercent: [
            { required: true, message: '请输入服务费比例', trigger: 'blur' }
          ],
        },
				hotelTypeList: [],
				hotelStateList: [
					{ label: '正常营业', value: 0},
					{ label: '暂停营业', value: 1},
					{ label: '已倒闭', value: -1}
				],
				hotelFoodList: [],
				hotelParkList: [],
				hotelTagsList: [],
				bankList: [],
				ssqValuesArr: [],
				hotelDesc: '',
				uploadUrl: this.$http.adornUrl(`/sys/oss/upload?token=${this.$cookie.get('token')}`),
				uploadPicList: [],
				updateHotelId: ''
			}
		},
		created () {
			// 查询酒店类型列表
			this.$http({
				url: this.$http.adornUrl_qfs('/setup/setups/collect/hotel_type'),
				method: 'get',
				params: this.$http.adornParams()
			}).then(({data}) => {
				this.hotelTypeList = [];
				for(var i = 0; i < data.length; i++){
					var t_obj = data[i];
					var t_json = eval('(' + t_obj.data + ')');
					this.hotelTypeList.push(t_json);
				}
			})
			// 查询膳食餐饮列表
			this.$http({
				url: this.$http.adornUrl_qfs('/setup/setups/collect/hotel_food_rule'),
				method: 'get',
				params: this.$http.adornParams()
			}).then(({data}) => {
				this.hotelFoodList = [];
				for(var i = 0; i < data.length; i++){
					var t_obj = data[i];
					var t_json = eval('(' + t_obj.data + ')');
					this.hotelFoodList.push(t_json);
				}
			})
			// 查询停车政策列表
			this.$http({
				url: this.$http.adornUrl_qfs('/setup/setups/collect/hotel_park_rule'),
				method: 'get',
				params: this.$http.adornParams()
			}).then(({data}) => {
				this.hotelParkList = [];
				for(var i = 0; i < data.length; i++){
					var t_obj = data[i];
					var t_json = eval('(' + t_obj.data + ')');
					this.hotelParkList.push(t_json);
				}
			})
			// 查询酒店标签列表
			this.$http({
				url: this.$http.adornUrl_qfs('/setup/setups/collect/hotel_tags'),
				method: 'get',
				params: this.$http.adornParams()
			}).then(({data}) => {
				this.hotelTagsList = [];
				for(var i = 0; i < data.length; i++){
					var t_obj = data[i];
					var t_json = eval('(' + t_obj.data + ')');
					this.hotelTagsList.push(t_json);
				}
			})
			// 查询开户行银行列表
			this.$http({
				url: this.$http.adornUrl_qfs('/setup/setups/collect/account_bank'),
				method: 'get',
				params: this.$http.adornParams()
			}).then(({data}) => {
				this.bankList = [];
				for(var i = 0; i < data.length; i++){
					var t_obj = data[i];
					var t_json = eval('(' + t_obj.data + ')');
					this.bankList.push(t_json);
				}
			})
		},
		activated () {
			this.updateHotelId = '';
			// 判断是否修改
			if(!!this.$route.params.id){
				this.updateHotelId = this.$route.params.id;
				this.$http({
					url: this.$http.adornUrl_qfs('/hotel/hotels/detail/' + this.updateHotelId),
					method: 'get',
					params: this.$http.adornParams({
						'id': this.updateHotelId
					})
				}).then(({data}) => {
					if (data && data.code === 0) {
						for(var key in this.formInline){
							if(key == 'signTime'){
								this.formInline[key] = new Date(data.data[key]);
							}else if(key == 'type'){
								this.formInline[key] = data.data[key] + '';
							}else{
								this.formInline[key] = data.data[key];
							}
						}
						this.ssqValuesArr = [this.formInline['province'], this.formInline['city'], this.formInline['district']];
						for(var i = 0; i < this.formInline['images'].length; i++){
							this.uploadPicList.push({
								url: this.formInline['images'][i].image
							})
						}
						/*this.$nextTick(() => {
              this.$refs.ssq.refresh();
						})*/
					}
				})
			}
		},
		methods: {
			changeSSQFunc(result){
				if(result.length == 0){
					this.formInline.province = '';
					this.formInline.city = '';
					this.formInline.district = '';
					this.formInline.addressCode = '';
					this.ssqValuesArr = [];
				}else{
					this.formInline.province = result[0].value;
					this.formInline.city = result[1].value;
					this.formInline.district = result[2].value;
					this.formInline.addressCode = result[2].key;
					this.ssqValuesArr = [result[0].value, result[1].value, result[2].value];
				}
			},
			saveHotelDesc(){
				if(this.hotelDesc == ''){
					return;
				}
				this.formInline.features.push(this.hotelDesc);
				this.hotelDesc = '';
			},
			deleteHotelDesc(item){
				this.formInline.features.splice(this.formInline.features.indexOf(item), 1);
			},
			handleBeforeUpload(file){
				if (file.type !== 'image/jpg' && file.type !== 'image/jpeg' && file.type !== 'image/png' && file.type !== 'image/gif') {
					this.$message.error('只支持jpg、jpeg、png、gif格式的图片！');
					return false;
				}
				if (file.size > 1024 * 200) {
					this.$message.error('最大支持200kb的图片！');
					return false;
				}
				return true;
			},
			handleSuccess(response, file){
				if (response && response.code === 0) {
					this.uploadPicList.push({
						url: response.url
					})
				} else {
					this.$message.error(response.msg)
				}
			},
			deletePic(obj){
				this.uploadPicList.splice(this.uploadPicList.indexOf(obj), 1);
			},
			saveHote(formName){
				// 新增酒店，成功重置参数
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.formInline.images = [];
            for(var i = 0; i < this.uploadPicList.length; i++){
              this.formInline.images.push({
                id: '',
                name: '',
                image: this.uploadPicList[i].url,
                link: ''
              })
            }
            var param = this.formInline;
            param['signTime'] = formatDate(new Date(this.formInline.signTime), 'yyyy-MM-dd');
            this.$http({
              url: !!this.$route.params.id ? this.$http.adornUrl_qfs('/hotel/hotels/'+this.$route.params.id+'/update') : this.$http.adornUrl_qfs('/hotel/hotels/add'),
              method: 'post',
              data: this.$http.adornData(param)
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.formInline = {
                      name: '',
                      phone: '',
                      mobile: '',
                      type: '',
                      status: '',
                      province: '',
                      city: '',
                      district: '',
                      addressCode: '',
                      addressDetail: '',
                      summary: '',
                      pets: '',
                      foreign: '',
                      foodService: '',
                      parkService: '',
                      tags: [],
                      features: [],
                      bank: '',
                      branchBank: '',
                      subBaranchBank: '',
                      accountName: '',
                      account: '',
                    /*  signBdId: '',*/
                      signTime: '',
                      sharePercent: '',
                      images: []
                    };
                    this.ssqValuesArr = [];
                    this.hotelDesc = '';
                    this.uploadPicList = [];
                    this.$router.push({name: 'qfs-hotel/hotelList'});
                  }
                })
              } else {
                this.$message.error(data.msg);
              }
            })
          } else {
            console.log('error submit!!');
            return false;
          }
        });

			}
		},
		components: {
			SsqSelect
		}
	}
</script>

<style lang="scss">
  .form_title{
    line-height: 40px;
    font-size: 24px;
    width: 150px;
    background: #9ea7b4;
    margin: 10px auto;
    padding: 8px;
    text-align: center;
    border-radius: 6px;
    color: #fff;
  }
	.uploadPicCard{
		font-size: 12px;
		line-height: 40px;
		img{
			width: 100%;
			display: block;
		}
	}
</style>
