<template>
	<div class="block">
		<div class="block day_search">
			<el-form :inline="true" :model="formInline" class="demo-form-inline" label-width="80px">
				<el-form-item label="酒店名称">
					<hotel-select @changeSelectFunc="changeSelectFunc"></hotel-select>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="queryList">查询</el-button>
				</el-form-item>
			</el-form>
		</div>
		<div class="block day_list">
			<el-tabs v-model="formInline.type" @tab-click="handleClick">
				<el-tab-pane label="整日租赁" name="day">
					<el-row v-for="item in roomPricelist" style="padding-top: 10px;">
						<el-row class="table_title">
							<el-col :span="8">
								<span class="table_title_head">{{item.roomName}}【今日房价{{item.todayPrice | moneyToY}}】</span>
							</el-col>
							<el-col :span="10">
								<p class="table_title_body">基础价格【平时价格：{{item.normalDayPrice | moneyToY}} 周末价格：{{item.wkDayPrice | moneyToY}}】</p>
								<span class="table_title_tip">基础价格修改请联系BD商务</span>
							</el-col>
							<el-col :span="6" style="text-align: center;">
								<el-button type="primary" plain style="margin-top: 10px;" @click="openDialog(item)">修改价格</el-button>
								<el-button type="primary" plain style="margin-top: 10px;" @click="changeIsShow(item)">价格日历</el-button>
							</el-col>
						</el-row>

						<el-carousel :autoplay="false" arrow="always" :loop="false" height="560px" v-if="item.isShow" @change="changeCarousel">
							<el-carousel-item style="padding: 10px;" v-for="o in t_index">
								<div class="block">
									<el-row style="border-left: 1px solid #666;text-align: center;">
										<el-col class="calendar_field" style="border-top: 1px solid #666;" v-for="week in weekArr">{{week}}</el-col>
									</el-row>
									<el-row style="border-left: 1px solid #666;text-align: center;">
										<el-col class="calendar_field" v-for="obj in roomCalendarList">
											<p>{{obj.day}}</p>
											<p v-if="obj.isWeekend == 0" style="color: #1ABC9C; font-size: 1.6rem;">{{obj.normalDayPrice | moneyToY}}</p>
											<p v-if="obj.isWeekend == 1" style="color: #1ABC9C; font-size: 1.6rem;">{{obj.wkDayPrice | moneyToY}}</p>
										</el-col>
									</el-row>
								</div>
							</el-carousel-item>
						</el-carousel>
					</el-row>
				</el-tab-pane>
				<el-tab-pane label="分时租赁" name="hour">
					<el-row v-for="item in roomPricelist" style="padding-top: 10px;">
						<el-row class="table_title">
							<el-col :span="4">
								<span class="table_title_head">{{item.roomName}}</span>
							</el-col>
							<el-col :span="4">
								<p class="table_title_body" style="text-align: right;">基础价格</p>
								<p style="text-align: right;font-size: 12px;color: #666;line-height: 30px;margin: 0;">基础价格修改请联系BD商务</p>
							</el-col>
							<el-col :span="10" style="padding-left: 20px;">
								<el-row :gutter="15">
									<el-col :span="12">
										<p class="s_p">平时开放{{item.normalHourStart}}：00至{{item.normalHourEnd}}：00 价格：{{item.normalHourPrice | moneyToY}}元每小时</p>
									</el-col>
									<el-col :span="12">
										<p class="s_p">周末开放{{item.wkHourStart}}：00至{{item.wkHourEnd}}：00 价格：{{item.wkHourPrice | moneyToY}}元每小时</p>
									</el-col>
								</el-row>
								<el-row :gutter="15">
									<el-col :span="12">
										<p class="s_p" v-if="item.normalHourSpecialSwitch == 1">平时特殊{{item.normalHourSpecialStart}}：00至{{item.normalHourSpecialEnd}}：00 价格：{{item.normalHourSpecialPrice | moneyToY}}元每小时</p>
									</el-col>
									<el-col :span="12">
										<p class="s_p" v-if="item.wkHourSpecialSwitch == 1">周末特殊{{item.wkHourSpecialStart}}：00至{{item.wkHourSpecialEnd}}：00 价格：{{item.wkHourSpecialPrice | moneyToY}}元每小时</p>
									</el-col>
								</el-row>
							</el-col>
							<el-col :span="6" style="text-align: center;">
								<el-button type="primary" plain style="margin-top: 10px;" v-if="item.normalHourSwitch == 1 || item.wkHourSwitch == 1" @click="openDialog(item)">修改价格</el-button>
								<el-button type="primary" plain style="margin-top: 10px;" @click="changeIsShow(item)">价格日历</el-button>
							</el-col>
						</el-row>

						<el-carousel :autoplay="false" arrow="always" :loop="false" height="560px" v-if="item.isShow" @change="changeCarousel">
							<el-carousel-item style="padding: 10px;" v-for="o in t_index">
								<div class="block">
									<el-row style="border-left: 1px solid #666;text-align: center;">
										<el-col :span="3" class="calendar_field" style="border-top: 1px solid #666;" v-for="week in weekArr">{{week}}</el-col>
									</el-row>
									<el-row style="border-left: 1px solid #666;text-align: center;">
										<el-col :span="3" class="calendar_field" v-for="obj in roomCalendarList">
											<p>{{obj.day}}</p>
											<p style="color: #1ABC9C;" v-if="obj.normalHourSwitch == 1 && obj.isWeekend == 0">{{obj.normalHourStart + '点-' + obj.normalHourEnd + '点  '}}{{obj.normalHourPrice | moneyToY}}元/小时</p>
											<p style="color: #1ABC9C;" v-if="obj.wkHourSwitch == 1 && obj.isWeekend == 1">{{obj.wkHourStart + '点-' + obj.wkHourEnd + '点  '}}{{obj.wkHourPrice | moneyToY}}元/小时</p>
											<p style="color: #1ABC9C;" v-if="obj.normalHourSwitch == 1 && obj.normalHourSpecialSwitch == 1 && obj.isWeekend == 0">{{obj.normalHourSpecialStart + '点-' + obj.normalHourSpecialEnd + '点  '}}{{obj.normalHourSpecialPrice | moneyToY}}元/小时</p>
											<p style="color: #1ABC9C;" v-if="obj.wkHourSwitch == 1 && obj.wkHourSpecialSwitch == 1 && obj.isWeekend == 1">{{obj.wkHourSpecialStart + '点-' + obj.wkHourSpecialEnd + '点  '}}{{obj.wkHourSpecialPrice | moneyToY}}元/小时</p>
										</el-col>
									</el-row>
								</div>
							</el-carousel-item>
						</el-carousel>
					</el-row>
				</el-tab-pane>
			</el-tabs>
		</div>

		<!--详情弹窗-->
		<el-dialog
		  v-if="dialogShow"
		  title="修改价格"
		  :close-on-click-modal="false"
		  :before-close="closeDialog"
		  :visible.sync="visible"
		  width="600px">
			<div class="block" style="width: 100%; line-height: 40px; fint-size: 16px;">
				<el-form :model="dialogInfo" label-width="100px">
					<el-form-item label="房型名称">
						<el-row>
							{{dialogInfo.roomName}}
						</el-row>
					</el-form-item>
					<el-form-item label="时间段">
						<el-date-picker
						  v-model="dialogInfo.timeArr"
						  type="daterange"
						  :editable="false"
						  align="center"
						  start-placeholder="开始日期"
						  end-placeholder="结束日期"
						  style="width: 400px;">
						</el-date-picker>
					</el-form-item>
					<el-form-item label="佣金率">
						<el-row>
							{{dialogInfo.sharePercent}}
						</el-row>
					</el-form-item>
					<el-form-item label="价格">
						<div v-if="dialogInfo.timeshare == 0">
							<el-row class="p20">
								<el-radio v-model="radio_type_1" label="1" @click="changeRadio">平时、周末统一价</el-radio>
								<el-radio v-model="radio_type_1" label="2" @click="changeRadio">平时、周末不同价</el-radio>
							</el-row>
							<el-row style="fint-size: 12px;color: #666;line-height: 18px;" class="p20">
                周末价会在所选日期生效【修改周末所属日期请联系BD】
							</el-row>
							<el-row class="p20">
								平时价格：
								<el-input v-model="dialogInfo.normalDayPrice_yuan" placeholder="请输入" style="width: 100px;margin-right: 10px;margin-left: 10px;"></el-input>
								元/每晚
							</el-row>
							<el-row v-if="radio_type_1 == 2" class="p20">
								周末价格：
								<el-input v-model="dialogInfo.wkDayPrice_yuan" placeholder="请输入" style="width: 100px;margin-right: 10px;margin-left: 10px;"></el-input>
								元/每晚
							</el-row>
						</div>
						<div v-if="dialogInfo.timeshare == 1">
							<el-row style="fint-size: 12px;color: #666;line-height: 18px;" class="p20">
                周末价会在所选日期生效【修改周末所属日期请联系BD]
							</el-row>
							<el-row class="p20" v-if="dialogInfo.normalHourSwitch == 1">
								平时价格：
							</el-row>
							<el-row class="p20" v-if="dialogInfo.normalHourSwitch == 1">
								开放时段{{dialogInfo.normalHourStart}}：00-{{dialogInfo.normalHourEnd}}：00
								<el-input v-model="dialogInfo.normalHourPrice_yuan" placeholder="请输入" style="width: 100px;margin-right: 10px;margin-left: 10px;"></el-input>
								元/小时
							</el-row>
							<el-row class="p20" v-if="dialogInfo.normalHourSwitch == 1 && dialogInfo.normalHourSpecialSwitch">
								特殊时段{{dialogInfo.normalHourSpecialStart}}：00-{{dialogInfo.normalHourSpecialEnd}}：00
								<el-input v-model="dialogInfo.normalHourSpecialPrice_yuan" placeholder="请输入" style="width: 100px;margin-right: 10px;margin-left: 10px;"></el-input>
								元/小时
							</el-row>
							<el-row class="p20" v-if="dialogInfo.wkHourSwitch == 1">
								周末价格：
							</el-row>
							<el-row class="p20" v-if="dialogInfo.wkHourSwitch == 1">
								开放时段{{dialogInfo.wkHourStart}}：00-{{dialogInfo.wkHourEnd}}：00
								<el-input v-model="dialogInfo.wkHourPrice_yuan" placeholder="请输入" style="width: 100px;margin-right: 10px;margin-left: 10px;"></el-input>
								元/小时
							</el-row>
							<el-row class="p20" v-if="dialogInfo.wkHourSwitch == 1 && dialogInfo.wkHourSpecialSwitch == 1">
								特殊时段{{dialogInfo.wkHourSpecialStart}}：00-{{dialogInfo.wkHourSpecialEnd}}：00
								<el-input v-model="dialogInfo.wkHourSpecialPrice_yuan" placeholder="请输入" style="width: 100px;margin-right: 10px;margin-left: 10px;"></el-input>
								元/小时
							</el-row>
						</div>
					</el-form-item>
				</el-form>
				<div style="text-align: center;width: 100%;">
					<span slot="footer" class="dialog-footer">
						<el-button @click="visible = false">取消</el-button>
						<el-button type="primary" @click="dataFormSubmit()">确定</el-button>
					</span>
				</div>
			</div>
		</el-dialog>
	</div>
</template>

<script>

	import HotelSelect from '@/plugin/hotelSelect'
	import {formatDate} from '@/utils'

	export default {
		data () {
			return {
				formInline: {
					hotelId: '',
					type: 'day'
				},
				roomPricelist: [],
				firstIn: true,
				dialogShow: false,
				visible: false,
				radio_type_1: '1',
				dialogInfo: {},
				roomCalendarList: [],
				t_index: [0, 1, 2],
				t_obj: {},
				weekArr: [],
			}
		},
		created () {

		},
		activated () {

		},
		methods: {
			changeSelectFunc(value){
				this.formInline.hotelId = value;
				if(this.firstIn){
					this.firstIn = false;
					this.queryList();
				}
			},
			queryList(){
				this.$http({
					url: this.$http.adornUrl_qfs('/hotel/rooms/prices'),
					method: 'get',
					params: this.$http.adornParams(this.formInline)
				}).then(({data}) => {
					if (data && data.code === 0) {
						for(var i = 0; i < data.data.length; i++){
							data.data[i]['isShow'] = false;
						}
						this.roomPricelist = data.data;
					} else {
						this.roomPricelist = [];
					}
				})
			},
			handleClick(){
				this.queryList();
			},
			getMonthFirstDayWeek(type){
				var nowdays = new Date();
				var year = nowdays.getFullYear();
				var month = nowdays.getMonth() + 1;

				month = month + type;
				if(month > 12){
					year = year + 1;
					month = month - 12;
				}

				if (month < 10) {
					month = "0" + month;
				}
				return new Date(year + '-' + month + '-' + '01').getDay();
			},
			getWeekArr(week){
				var result = [], w_a = ['日', '一', '二', '三', '四', '五', '六'];
				for(var i = 0; i < 7; i++){
					result.push('星期' + w_a[week]);
					week = week + 1;
					if(week == 7){
						week = 0;
					}
				}
				return result;
			},
			changeIsShow(item){
				if(item.isShow){
					item.isShow = false;
					this.t_obj = {};
				}else{
					this.roomCalendarList = [];
					this.t_obj = {
						hotelId: item.hotelId,
						roomId: item.roomId,
						normalHourSwitch: item.normalHourSwitch,
						wkHourSwitch: item.wkHourSwitch
					};
					this.$http({
						url: this.$http.adornUrl_qfs('/hotel/rooms/prices/calendar'),
						method: 'get',
						params: this.$http.adornParams({
							hotelId: item.hotelId,
							roomId: item.roomId,
							type: this.formInline.type,
							offset: 0
						})
					}).then(({data}) => {
						if (data && data.code === 0) {
							var week = this.getMonthFirstDayWeek(0);
							this.weekArr = this.getWeekArr(week);
							for(var i = 0; i < data.data.length; i++){
								data.data[i]['normalHourSwitch'] = this.t_obj.normalHourSwitch;
								data.data[i]['wkHourSwitch'] = this.t_obj.wkHourSwitch;
							}
							this.roomCalendarList = data.data;

							for(var i = 0; i < this.roomPricelist.length; i++){
								this.roomPricelist[i].isShow = false;
							}
							item.isShow = true;
						} else {
							this.roomCalendarList = [];
						}
					})
				}
			},
			changeCarousel(index, oldIndex){
				this.roomCalendarList = [];
				this.$http({
					url: this.$http.adornUrl_qfs('/hotel/rooms/prices/calendar'),
					method: 'get',
					params: this.$http.adornParams({
						hotelId: this.t_obj.hotelId,
						roomId: this.t_obj.roomId,
						type: this.formInline.type,
						offset: this.t_index[index]
					})
				}).then(({data}) => {
					if (data && data.code === 0) {
						var week = this.getMonthFirstDayWeek(this.t_index[index]);
						this.weekArr = this.getWeekArr(week);
						for(var i = 0; i < data.data.length; i++){
							data.data[i]['normalHourSwitch'] = this.t_obj.normalHourSwitch;
							data.data[i]['wkHourSwitch'] = this.t_obj.wkHourSwitch;
						}
						this.roomCalendarList = data.data;
					} else {
						this.roomCalendarList = [];
					}
				})
			},
			openDialog(obj){
				if(obj.timeshare == 0){
					this.dialogInfo = {
						hotelId: obj.hotelId,
						roomId: obj.roomId,
						roomName: obj.roomName,
						timeArr: [],
						timeshare: obj.timeshare,
						normalDayPrice_yuan: '',
						wkDayPrice_yuan: '',
						sharePercent: obj.sharePercent,
						normalHourPrice: obj.normalHourPrice,
						normalHourSpecialPrice: obj.normalHourSpecialPrice,
						wkHourPrice: obj.wkHourPrice,
						wkHourSpecialPrice: obj.wkHourSpecialPrice
					}
					this.radio_type_1 = obj.normalDayPrice == obj.wkDayPrice ? '1': '2';
				}else{
					this.dialogInfo = {
						hotelId: obj.hotelId,
						roomId: obj.roomId,
						roomName: obj.roomName,
						timeArr: [],
						timeshare: obj.timeshare,
						normalDayPrice: obj.normalDayPrice,
						wkDayPrice: obj.wkDayPrice,
						sharePercent: obj.sharePercent,
						normalHourPrice_yuan: '',
						normalHourSpecialPrice_yuan: '',
						wkHourPrice_yuan: '',
						wkHourSpecialPrice_yuan: '',
						normalHourStart: obj.normalHourStart,
						normalHourEnd: obj.normalHourEnd,
						normalHourSpecialStart: obj.normalHourSpecialStart,
						normalHourSpecialEnd: obj.normalHourSpecialEnd,
						wkHourStart: obj.wkHourStart,
						wkHourEnd: obj.wkHourEnd,
						wkHourSpecialStart: obj.wkHourSpecialStart,
						wkHourSpecialEnd: obj.wkHourSpecialEnd,
						normalHourSpecialSwitch: obj.normalHourSpecialSwitch,
						wkHourSpecialSwitch: obj.wkHourSpecialSwitch,
						normalHourSwitch: obj.normalHourSwitch,
						wkHourSwitch: obj.wkHourSwitch
					}
				}
				this.dialogShow = true;
				this.visible = true;
			},
			closeDialog(){
				this.dialogInfo = {};
				this.dialogShow = false;
				this.visible = false;
			},
			dataFormSubmit(){
				var param = {};
				if(this.dialogInfo.timeshare == 0){
					param = {
						hotelId: this.dialogInfo.hotelId,
						roomId: this.dialogInfo.roomId,
						type: this.formInline.type,
						dayStart: formatDate(new Date(this.dialogInfo.timeArr[0]), 'yyyy-MM-dd'),
						dayEnd: formatDate(new Date(this.dialogInfo.timeArr[1]), 'yyyy-MM-dd'),
						normalDayPrice: parseInt(this.dialogInfo.normalDayPrice_yuan) * 100,
						wkDayPrice: this.radio_type_1 == 1 ? parseInt(this.dialogInfo.normalDayPrice_yuan) * 100 : parseInt(this.dialogInfo.wkDayPrice_yuan) * 100,
						normalHourPrice: this.dialogInfo.normalHourPrice,
						normalHourSpecialPrice: this.dialogInfo.normalHourSpecialPrice,
						wkHourPrice: this.dialogInfo.wkHourPrice,
						wkHourSpecialPrice: this.dialogInfo.wkHourSpecialPrice
					}
				}else{
					param = {
						hotelId: this.dialogInfo.hotelId,
						roomId: this.dialogInfo.roomId,
						type: this.formInline.type,
						dayStart: formatDate(new Date(this.dialogInfo.timeArr[0]), 'yyyy-MM-dd'),
						dayEnd: formatDate(new Date(this.dialogInfo.timeArr[1]), 'yyyy-MM-dd'),
						normalDayPrice: this.dialogInfo.normalDayPrice,
						wkDayPrice: this.dialogInfo.wkDayPrice,
						normalHourPrice: parseInt(this.dialogInfo.normalHourPrice_yuan) * 100,
						normalHourSpecialPrice: parseInt(this.dialogInfo.normalHourSpecialPrice_yuan) * 100,
						wkHourPrice: parseInt(this.dialogInfo.wkHourPrice_yuan) * 100,
						wkHourSpecialPrice: parseInt(this.dialogInfo.wkHourSpecialPrice_yuan) * 100
					}
				}
				this.$http({
					url: this.$http.adornUrl_qfs('/hotel/rooms/prices/update'),
					method: 'post',
					data: this.$http.adornData(param)
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.$message({
							message: '操作成功',
							type: 'success',
							duration: 1500,
							onClose: () => {
								this.closeDialog();
							}
						})
					} else {
						this.$message.error(data.msg);
					}
				})
			},
			changeRadio(){
				if(this.radio_type_1 == 1){
					this.dialogInfo.wkDayPrice_fen = '';
				}
			}
		},
		components: {
			HotelSelect
		},
		filters: {
			moneyToY(money){// 分转元
				return parseInt(money / 100);
			}
		}
	}
</script>

<style lang="scss">
	.table_title{
		border-bottom: 1px solid #000;
		line-height: 40px;
		.table_title_head{
			line-height: 60px;
			font-size: 22px;
		}
		.table_title_body{
			line-height: 30px;
			font-size: 16px;
			margin: 0;
		}
		.table_title_tip{
			line-height: 30px;
			font-size: 12px;
			color: #666;
		}
	}
	.calendar_field{
		height: 90px;
		line-height: 90px;
		border-bottom: 1px solid #666;
		border-right: 1px solid #666;
		width: 14%;
		p{
			line-height: 30px;
			margin: 0;
		}
	}
	p.s_p{
		font-size: 12px;
		line-height: 30px;
		margin: 0;
	}
	p20{
		padding: 10px 0;
	}
</style>
