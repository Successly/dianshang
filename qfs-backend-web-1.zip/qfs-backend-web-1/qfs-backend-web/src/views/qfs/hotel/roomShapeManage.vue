<template>
	<div class="block">
		<div class="search_area">
			<el-form :inline="true" :model="formInline" class="demo-form-inline">
				<el-form-item label="酒店名称">
					<hotel-select @changeSelectFunc="changeSelectFunc"></hotel-select>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="queryList">搜索</el-button>
					<el-button type="primary" @click="addOrUpdateRoom(formInline.hotelId)">添加房型</el-button>
				</el-form-item>
			</el-form>
		</div>

		<div class="search_result">
			<el-table
			  :data="roomListData"
			  border
			  stripe
			  :v-loading="dataListLoading"
			  style="width: 100%">
				<el-table-column
				  prop="name"
				  label="房型名称"
				  align="center"
				  width="150">
				</el-table-column>
				<el-table-column
				  prop="typeName"
				  label="房型类型"
				  align="center"
				  width="100">
				</el-table-column>
				<el-table-column
				  prop="hotelName"
				  label="所属酒店"
				  align="center">
				</el-table-column>
				<el-table-column
				  prop="dayCount"
				  label="整日房数"
				  align="center"
				  width="100">
				</el-table-column>
				<el-table-column
				  prop="hourCount"
				  label="分时房数"
				  align="center"
				  width="100">
				</el-table-column>
				<el-table-column
				  label="房型状态"
				  align="center"
				  width="100">
					<template slot-scope="scope">
						{{scope.row.status == 0 ? '已上架' : '已下架'}}
					</template>
				</el-table-column>
				<el-table-column
				  label="操作"
				  align="center"
				  width="200">
					<template slot-scope="scope">
						<el-button
						  @click.native.prevent="addOrUpdateRoom(formInline.hotelId,scope.row)"
						  type="text"
						  size="small">
						  编辑
						</el-button>
						<el-button
						  @click.native.prevent="updateStatusConfirm(scope.row);"
						  type="text"
						  size="small">
						  {{scope.row.status == 0 ? '下架' : '上架'}}
						</el-button>
					</template>
				</el-table-column>
			</el-table>
		</div>

		<!-- 弹窗, 新增 / 修改 -->
		<AddOrUpdate v-if="addOrUpdateVisible" ref="addOrUpdate" @refreshDataList="queryList"></AddOrUpdate>
	</div>
</template>

<script>

	import HotelSelect from '@/plugin/hotelSelect'
	import AddOrUpdate from './roomShape-add-or-update'

	export default {
		data () {
			return {
				formInline: {
					hotelId: ''
				},
				firstIn: true,
				roomListData: [],
				dataListLoading: false,
				addOrUpdateVisible: false
			}
		},
		created () {

		},
		activated () {

		},
		methods: {
			changeSelectFunc(value){
				this.formInline.hotelId = value;
				if(this.firstIn){
					this.firstIn = false;
					this.queryList();
				}
			},
			queryList(){
				this.dataListLoading = true;
				// 查询列表
				this.$http({
					url: this.$http.adornUrl_qfs('/hotel/rooms/collect/roomType'),
					method: 'get',
					params: this.$http.adornParams(this.formInline)
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.roomListData = data.data;
					}
					this.dataListLoading = false;
				})
			},
			addOrUpdateRoom(defaultHotelId,row){
        // 新建/修改活动
        this.addOrUpdateVisible = true;
        this.$nextTick(() => {
          this.$refs.addOrUpdate.init(defaultHotelId,row);
        })
      },
      updateStatusConfirm(row){
			  let desc = row.status == 0 ? "下架" : "上架";
        this.$confirm('确定要'+ desc +'【'+row.name+'】？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$http({
            url: this.$http.adornUrl_qfs('/hotel/rooms/'+row.id+'/puton'),
            method: 'get',
            params: this.$http.adornParams({
              'id': row.id,
              'type': row.status == 0 ? 0 : 1

            })
          }).then(({data}) => {
            if (data && data.code === 0) {
              this.queryList();
            }

          })
        })
      },
		},
		components: {
			HotelSelect,
			AddOrUpdate
		}
	}
</script>

<style lang="scss">

</style>
