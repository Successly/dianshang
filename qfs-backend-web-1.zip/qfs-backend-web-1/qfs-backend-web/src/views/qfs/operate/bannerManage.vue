<template>
	<div class="block">
		<div class="search_area">
			<el-form :inline="true" :model="formInline" class="demo-form-inline">
				<el-form-item label="酒店名称">
					<hotel-select @changeSelectFunc="changeHotelSelectFunc"></hotel-select>
				</el-form-item>
				<el-form-item label="活动状态">
					<el-select v-model="formInline.status" placeholder="请选择" style="width: 200px;">
						<el-option
						  v-for="item in activityStateList"
						  :key="item.value"
						  :label="item.label"
						  :value="item.value">
						</el-option>
					</el-select>
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="searchActivityList">查询</el-button>
					<el-button type="primary" @click="addOrUpdateActivity()">新增</el-button>
					<el-button type="primary" @click="deleteActivity()">批量删除</el-button>
				</el-form-item>
			</el-form>
		</div>
		
		<div class="search_result">
			<el-table
			  :data="activityListData"
			  border
			  stripe
			  @selection-change="selectionChangeHandle"
			  :v-loading="dataListLoading"
			  style="width: 100%">
				<el-table-column
				  type="selection"
				  header-align="center"
				  align="center"
				  width="50">
				</el-table-column>
				<el-table-column
				  prop="hotelName"
				  label="酒店"
				  align="center"
				  width="250">
				</el-table-column>
				<el-table-column
				  prop="name"
				  label="活动名称"
				  align="center">
				</el-table-column>
				<el-table-column
				  prop="time"
				  label="起始时间"
				  align="center"
				  width="250">
					<template slot-scope="scope">
						<span>{{ scope.row.startTime | formatDate }}至{{ scope.row.endTime | formatDate }}</span>
					</template>
				</el-table-column>
				<el-table-column
				  prop="state"
				  label="活动状态"
				  align="center"
				  width="150">
					<template slot-scope="scope">
						{{ scope.row.status == 3 ? '已过期' : '进行中' }}
					</template>
				</el-table-column>
				<el-table-column
				  label="操作"
				  align="center"
				  width="200">
					<template slot-scope="scope">
						<el-button
						  @click.native.prevent="addOrUpdateActivity(scope.row)"
						  type="text"
						  size="small">
						  查看详情
						</el-button>
						<el-button
						  @click.native.prevent="deleteActivity(scope.row.id)"
						  type="text"
						  size="small">
						  删除
						</el-button>
					</template>
				</el-table-column>
			</el-table>
			
			<div class='block'>
				<el-pagination
				  @size-change='handleSizeChange' 
				  @current-change='handleCurrentChange' 
			      :current-page='paginationData.pageNumber' 
				  :page-sizes='[10, 20, 30, 50, 100]' 
				  :page-size='paginationData.pageSize' 
				  :total='paginationData.totalPage'
				  layout='total, sizes, prev, pager, next, jumper' 
				>
				</el-pagination>
			</div>
		</div>
		
		<!-- 弹窗, 新增 / 修改 -->
		<AddOrUpdate v-if="addOrUpdateVisible" ref="addOrUpdate" @refreshDataList="searchActivityList"></AddOrUpdate>
	</div>
</template>

<script>

	import HotelSelect from '@/plugin/hotelSelect'
	import AddOrUpdate from './banner-add-or-update'
	import {formatDate} from '@/utils'

	export default {
		data () {
			return {
				formInline: {
					hotelId: '',
					status: ''
				},
				activityStateList: [
					{ label: '全部', value: '' },
					{ label: '进行中', value: 1 },
					{ label: '已过期', value: 3 }
				],
				dataListLoading: false,
				activityListData: [],
				paginationData: {
					pageNumber: 1,
					pageSize: 20,
					totalPage: 0
				},
				dataListSelections: [],
				addOrUpdateVisible: false,
				firstIn: true
			}
		},
		created () {
			
		},
		activated () {
			
		},
		methods: {
			changeHotelSelectFunc(value){
				this.formInline.hotelId = value;
				if(this.firstIn){
					this.firstIn = false;
					this.searchActivityList();
				}
			},
			selectionChangeHandle (val) {
				// 多选
				this.dataListSelections = val;
			},
			searchActivityList(){
				this.dataListLoading = true;
				this.$http({
					url: this.$http.adornUrl_qfs('/banner/adminList'),
					method: 'post',
					data: this.$http.adornData(Object.assign({
						'pageNum': this.paginationData.pageNumber,
						'pageSize': this.paginationData.pageSize
					}, this.formInline))
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.activityListData = data.data.list;
						this.paginationData.totalPage = data.data.totalCount;
					} else {
						this.activityListData = [];
						this.paginationData.totalPage = 0;
					}
					this.dataListLoading = false;
				})
			},
			handleSizeChange(val){
				this.paginationData.pageSize = val;
				this.paginationData.pageNumber = 1;
				this.searchActivityList();
			},
			handleCurrentChange(val){
				this.paginationData.pageNumber = val;
				this.searchActivityList();
			},
			addOrUpdateActivity(row){
				// 新建/修改活动
				this.addOrUpdateVisible = true;
				this.$nextTick(() => {
					this.$refs.addOrUpdate.init(row);
				})
			},
			deleteActivity(id){
				// 删除活动
				var ids = id ? [id] : this.dataListSelections.map(item => {
					return item.id;
				});
				this.$confirm(`确定进行[${id ? '删除' : '批量删除'}]操作?`, '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
					this.$http({
						url: this.$http.adornUrl_qfs('/banner/delete'),
						method: 'post',
						data: this.$http.adornData({
							'ids': ids
						})
					}).then(({data}) => {
						if (data && data.code === 0) {
							this.$message({
								message: '操作成功',
								type: 'success',
								duration: 1500,
								onClose: () => {
									this.searchActivityList();
								}
							})
						} else {
							this.$message.error(data.msg);
						}
					})
				}).catch(() => {})
			}
		},
		components: {
			HotelSelect,
			AddOrUpdate
		},
		filters: {
			formatDate(time){
				let date = new Date(time);
				return formatDate(date, 'yyyy-MM-dd');
			}
		}
	}
</script>

<style lang="scss">

</style>