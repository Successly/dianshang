<template>
	<el-dialog
      :title="!dataForm.id ? '新增' : '修改'"
      :close-on-click-modal="false"
      :visible.sync="visible">
		<el-form :model="dataForm" ref="dataForm" label-width="80px">
			<el-form-item label="酒店名称">
				<hotel-select @changeSelectFunc="changeHotelSelectFunc" ref="child" :default-hotel-id="defaultHotelId"></hotel-select>
			</el-form-item>
			<el-form-item label="活动名称">
				<el-input v-model="dataForm.name" placeholder="活动名称" style="width: 200px;"></el-input>
			</el-form-item>
			<el-form-item label="链接地址">
				<el-input v-model="dataForm.link" placeholder="链接地址" style="width: 200px;"></el-input>
			</el-form-item>
			<el-form-item label="起始时间">
				<el-date-picker
				  v-model="time"
				  type="daterange"
				  start-placeholder="开始日期"
				  end-placeholder="结束日期"
				  style="width: 400px;">
				</el-date-picker>
			</el-form-item>
			<el-form-item label="活动状态">
				<el-radio v-model="dataForm.status" v-for="item in stateList" :label="item.value">{{item.label}}</el-radio>
			</el-form-item>
			<el-form-item label="轮播位置">
				<el-input-number v-model="dataForm.order" :step="1" :min="0" :max="100" style="width: 200px;"></el-input-number>
			</el-form-item>
			<el-form-item label="轮播图片">
				<Upload ref="pic" :uploadUrl="uploadUrl" :imgUrl="dataForm.image" @changeFileListFunc="changeFileListFunc" :imgWidth="150" :imgHeight="150"></Upload>
			</el-form-item>
		</el-form>
		<span slot="footer" class="dialog-footer">
			<el-button @click="visible = false">取消</el-button>
			<el-button type="primary" @click="dataFormSubmit()">确定</el-button>
		</span>
	</el-dialog>
</template>

<script>

	import HotelSelect from '@/plugin/hotelSelect'
	import Upload from '@/plugin/oneFileUpload_form'
	import {formatDate} from '@/utils'

	export default {
		data () {
			return {
				visible: false,
				stateList: [
					{ label: '进行中', value: 1 },
					{ label: '已过期', value: 3 }
				],
				dataForm: {
					id: 0,
					name: '',
					link: '',
					startTime: '',
					endTime: '',
					status: 1,
					hotelId: '',
					order: '',
					image: ''
				},
				time: [],
				uploadUrl: this.$http.adornUrl(`/sys/oss/upload?token=${this.$cookie.get('token')}`),
				defaultHotelId: -1,
				firstIn: true
			}
		},
		methods: {
			changeHotelSelectFunc(value){
				if(this.firstIn){
					this.firstIn = false;
					if(this.defaultHotelId == -1){// 新增
						this.dataForm.hotelId = value;
					}
				}else{
					this.dataForm.hotelId = value;
				}
			},
			init (row) {
				this.defaultHotelId = -1;
				this.dataForm = {
					id: 0,
					name: '',
					link: '',
					startTime: '',
					endTime: '',
					status: 1,
					hotelId: '',
					order: '',
					image: ''
				};
				this.time = [];
				if(row != undefined){
					this.defaultHotelId = row.hotelId;
					this.dataForm = {
						id: row.id,
						name: row.name,
						link: row.link,
						startTime: row.startTime,
						endTime: row.endTime,
						status: row.status,
						hotelId: row.hotelId,
						order: row.order,
						image: row.image
					};
					this.time = [formatDate(new Date(this.dataForm.startTime), 'yyyy-MM-dd'), formatDate(new Date(this.dataForm.endTime), 'yyyy-MM-dd')];
				}
				this.visible = true;
				this.$nextTick(() => {
					this.$refs['child'].queryAllHotelList();
				/*	this.$refs['pic'].refresh();*/
					this.$refs['dataForm'].resetFields();
				})
			},
			dataFormSubmit () {
				this.dataForm['startTime'] = formatDate(new Date(this.time[0]), 'yyyy-MM-dd');
				this.dataForm['endTime'] = formatDate(new Date(this.time[1]), 'yyyy-MM-dd');
				this.$http({
					url: this.$http.adornUrl_qfs(`/banner/${!this.dataForm.id ? 'save' : 'update'}`),
					method: 'post',
					data: this.$http.adornData(this.dataForm)
				}).then(({data}) => {
					if (data && data.code === 0) {
						this.$message({
							message: '操作成功',
							type: 'success',
							duration: 1500,
							onClose: () => {
								this.visible = false;
								this.$emit('refreshDataList');
							}
						})
					} else {
						this.$message.error(data.msg);
					}
				})
			},
			changeFileListFunc(imgUrl){
				this.dataForm.image = imgUrl;
			}
		},
		components: {
			Upload,
			HotelSelect
		}
	}
</script>
