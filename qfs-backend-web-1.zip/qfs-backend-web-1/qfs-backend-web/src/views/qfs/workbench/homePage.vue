<template>
	<div class="block">
		<el-row :gutter="40">
			<el-col :span="6">
				<el-card shadow="always" class="data-show icon-1" :body-style="elCardStyle">
					<span class="data-show-title">昨日订单总数</span>
					<span>200</span>
				</el-card>
			</el-col>
			<el-col :span="6">
				<el-card shadow="always" class="data-show icon-2" :body-style="elCardStyle">
					<span class="data-show-title">昨日销售总额</span>
					<span>200</span>
				</el-card>
			</el-col>
			<el-col :span="6">
				<el-card shadow="always" class="data-show icon-3" :body-style="elCardStyle">
					<span class="data-show-title">昨日新增会员</span>
					<span>200</span>
				</el-card>
			</el-col>
			<el-col :span="6">
				<el-card shadow="always" class="data-show icon-4" :body-style="elCardStyle">
					<span class="data-show-title">会员总数</span>
					<span>200</span>
				</el-card>
			</el-col>
		</el-row>
		<el-row>
			<el-col :span="24" style="padding-left: 20px;"><h4>运营快捷入口</h4></el-col>
		</el-row>
		<el-row>
			<el-button type="text"
			  v-for="item in entrance"
			  :class="'page-btn ' + item.icon"
			  @click="gotoPage(item)">
			  {{item.name}}
			</el-button>
		</el-row>
	</div>
</template>

<script>
	export default {
		data () {
			return {
				elCardStyle: {
					padding: '20px 20px 20px 100px'
				},
				entrance: [
					{ routerName: 'qfs-order/orderList', param: '7', name: '订单管理', url: 'qfs-order/orderList', icon: 'btn-1' },
					{ routerName: 'qfs-order/orderList', param: '1', name: '待入住订单', url: 'qfs-order/orderList', icon: 'btn-2' },
					{ routerName: 'qfs-hotel/roomPriceManage', name: '预订改价', url: 'qfs-hotel/roomPriceManage', icon: 'btn-3' },
					{ routerName: 'qfs-hotel/roomStateManage', name: '房态管理', url: 'qfs-hotel/roomStateManage', icon: 'btn-4' },
					{ routerName: 'qfs-market/couponList', name: '营销中心', url: 'qfs-market/couponList', icon: 'btn-5' },
					{ routerName: 'qfs-member/memberList', name: '会员管理', url: 'qfs-member/memberList', icon: 'btn-6' }
				],
			}
		},
		created () {

		},
		activated () {

		},
		methods: {
			gotoPage(item){
				console.log(item);
				if(item.param){
          this.$router.push({ name: item.routerName, params: { activeTab: item.param }})
        }else{
          this.$router.push({ name: item.routerName })

        }
			}
		},
		components: {

		}
	}
</script>

<style lang="scss">
	.data-show{
		span{
			display: inline-block;
			width: 100%;
			line-height: 32px;
			font-size: 24px;
		}
		span.data-show-title{
			font-size: 20px;
		}
	}
	.icon-1{
		background-image: url(~@/assets/qfs/icons/icon-1.png);
		background-repeat: no-repeat;
		background-position: 18px center;
	}
	.icon-2{
		background-image: url(~@/assets/qfs/icons/icon-2.png);
		background-repeat: no-repeat;
		background-position: 18px center;
	}
	.icon-3{
		background-image: url(~@/assets/qfs/icons/icon-3.png);
		background-repeat: no-repeat;
		background-position: 18px center;
	}
	.icon-4{
		background-image: url(~@/assets/qfs/icons/icon-4.png);
		background-repeat: no-repeat;
		background-position: 18px center;
	}
	.page-btn{
		color: #333333;
		width: 100px;
		padding-top: 100px;
		text-align: center;
		border-radius: 6px;

		&:hover{
			color: #3ebbff;
			border: 1px solid #3ebbff;
		}
	}
	.btn-1{
		background-image: url(~@/assets/qfs/icons/btn-1.png);
		background-repeat: no-repeat;
		background-position: center 18px;
		&:hover{
			background-image: url(~@/assets/qfs/icons/btn-1-h.png);
		}
	}
	.btn-2{
		background-image: url(~@/assets/qfs/icons/btn-2.png);
		background-repeat: no-repeat;
		background-position: center 18px;
		&:hover{
			background-image: url(~@/assets/qfs/icons/btn-2-h.png);
		}
	}
	.btn-3{
		background-image: url(~@/assets/qfs/icons/btn-3.png);
		background-repeat: no-repeat;
		background-position: center 18px;
		&:hover{
			background-image: url(~@/assets/qfs/icons/btn-3-h.png);
		}
	}
	.btn-4{
		background-image: url(~@/assets/qfs/icons/btn-4.png);
		background-repeat: no-repeat;
		background-position: center 18px;
		&:hover{
			background-image: url(~@/assets/qfs/icons/btn-4-h.png);
		}
	}
	.btn-5{
		background-image: url(~@/assets/qfs/icons/btn-5.png);
		background-repeat: no-repeat;
		background-position: center 18px;
		&:hover{
			background-image: url(~@/assets/qfs/icons/btn-5-h.png);
		}
	}
	.btn-6{
		background-image: url(~@/assets/qfs/icons/btn-6.png);
		background-repeat: no-repeat;
		background-position: center 18px;
		&:hover{
			background-image: url(~@/assets/qfs/icons/btn-6-h.png);
		}
	}
</style>
