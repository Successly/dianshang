<template>
	<div class="block page-div">
		<el-row>
			<el-col :span="4" class="page-title">服务器操作系统</el-col>
			<el-col :span="8">{{systemInfo.os}}</el-col>
			<el-col :span="4" class="page-title">Web 服务器</el-col>
			<el-col :span="8">{{systemInfo.web}}</el-col>
		</el-row>
		<el-row>
			<el-col :span="4" class="page-title">PHP 版本</el-col>
			<el-col :span="8">{{systemInfo.php}}</el-col>
			<el-col :span="4" class="page-title">MySQL 版本</el-col>
			<el-col :span="8">{{systemInfo.mysql}}</el-col>
		</el-row>
		<el-row>
			<el-col :span="4" class="page-title">安全模式</el-col>
			<el-col :span="8">{{systemInfo.safe}}</el-col>
			<el-col :span="4" class="page-title">安全模式GID</el-col>
			<el-col :span="8">{{systemInfo.safeGid}}</el-col>
		</el-row>
		<el-row>
			<el-col :span="4" class="page-title">Socket 支持</el-col>
			<el-col :span="8">{{systemInfo.socket}}</el-col>
			<el-col :span="4" class="page-title">时区设置</el-col>
			<el-col :span="8">{{systemInfo.timeZone}}</el-col>
		</el-row>
		<el-row>
			<el-col :span="4" class="page-title">GD 版本</el-col>
			<el-col :span="8">{{systemInfo.gd}}</el-col>
			<el-col :span="4" class="page-title">Zlib 支持</el-col>
			<el-col :span="8">{{systemInfo.zlib}}</el-col>
		</el-row>
		<el-row>
			<el-col :span="4" class="page-title">IP 库版本</el-col>
			<el-col :span="8">{{systemInfo.ip}}</el-col>
			<el-col :span="4" class="page-title">文件上传的最大大小</el-col>
			<el-col :span="8">{{systemInfo.fileSize}}</el-col>
		</el-row>
		<el-row>
			<el-col :span="4" class="page-title">程序版本</el-col>
			<el-col :span="8">{{systemInfo.version}}</el-col>
			<el-col :span="4" class="page-title">安装日期</el-col>
			<el-col :span="8">{{systemInfo.installDate}}</el-col>
		</el-row>
		<el-row>
			<el-col :span="4" class="page-title">编码</el-col>
			<el-col :span="8">{{systemInfo.code}}</el-col>
			<el-col :span="4" class="page-title"></el-col>
			<el-col :span="8"></el-col>
		</el-row>
	</div>
</template>

<script>
	export default {
		data () {
			return {
				systemInfo: {
					os: '',
					web: '',
					php: '',
					mysql: '',
					safe: '',
					safeGid: '',
					socket: '',
					timeZone: '',
					gd: '',
					zlib: '',
					ip: '',
					fileSize: '',
					version: '',
					installDate: '',
					code: ''
				}
			}
		},
		created () {
			
		},
		activated () {
			this.querySysInfo();
		},
		methods: {
			querySysInfo(){
				this.systemInfo = {
					os: 'asd',
					web: 'asd',
					php: 'asd',
					mysql: 'asd',
					safe: 'asd',
					safeGid: '',
					socket: '',
					timeZone: '',
					gd: '',
					zlib: '',
					ip: '',
					fileSize: '',
					version: '',
					installDate: '',
					code: ''
				}
			}
		},
		components: {
			
		}
	}
</script>

<style lang="scss">
	.page-div{
		line-height: 50px;
		width: 100%;
		text-align: center;
		border-left: 1px solid #e1e1e1;
		border-top: 1px solid #e1e1e1;
		.el-col{
			height: 50px;
			border-right: 1px solid #e1e1e1;
			border-bottom: 1px solid #e1e1e1;
		}
		.page-title{
			background: #f1f1f1;
		}
	}
</style>