<template>
	<div class="block">
		<el-table
		  :data="loginLogList"
		  border
		  stripe
		  v-loading="dataListLoading"
		  style="width: 100%">
			<el-table-column
			  prop="time"
			  label="时间"
			  align="center"
			  style="width: 25%;">
			</el-table-column>
			<el-table-column
			  prop="ip"
			  label="IP"
			  align="center"
			  style="width: 25%;">
			</el-table-column>
			<el-table-column
			  prop="addr"
			  label="地址"
			  align="center"
			  style="width: 25%;">
			</el-table-column>
			<el-table-column
			  prop="browser"
			  label="浏览器"
			  align="center"
			  style="width: 25%;">
			</el-table-column>
		</el-table>

		<div class='block'>
			<el-pagination
			  @size-change='handleSizeChange'
			  @current-change='handleCurrentChange'
			  :current-page='paginationData.pageNumber'
			  :page-sizes='[10, 20, 30, 50, 100]'
			  :page-size='paginationData.pageSize'
			  :total='paginationData.totalPage'
			  layout='total, sizes, prev, pager, next, jumper'
			>
			</el-pagination>
		</div>
	</div>
</template>

<script>
	export default {
		data () {
			return {
				loginLogList: [],
				dataListLoading: false,
				paginationData: {
					pageNumber: 1,
					pageSize: 20,
					totalPage: 0
				}
			}
		},
		created () {

		},
		activated () {
			this.queryLoginLogList();
		},
		methods: {
			queryLoginLogList(){
				this.paginationData.totalPage = 1;
				this.loginLogList = [{
					time: '2019-02-12',
					ip: '192.156.12.1',
					addr: '江苏省南京市',
					browser: 'Chrome'
				}]
			},
      handleSizeChange(val){
        this.paginationData.pageSize = val;
        this.paginationData.pageNumber = 1;
        this.queryLoginLogList();
      },
      handleCurrentChange(val){
        this.paginationData.pageNumber = val;
        this.queryLoginLogList();
      },
		},
		components: {

		}
	}
</script>

<style lang="scss">

</style>
