<template>
	<div class="block" style="width: 40%; margin: auto;">
		<el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
			<!--<div style="width: 80px; margin: auto; margin-bottom: 20px;">
				<Upload :uploadUrl="uploadUrl" :imgUrl="dataForm.fileUrl" @changeFileListFunc="changeFileListFunc" :imgWidth="80" :imgHeight="80"></Upload>
			</div>-->
			<!--<el-form-item label="用户名" prop="name">
				<el-input v-model="dataForm.name" placeholder="用户名"></el-input>
			</el-form-item>-->
			<el-form-item label="Email" prop="email">
				<el-input v-model="dataForm.email" placeholder="Email"></el-input>
			</el-form-item>
			<el-form-item label="旧密码" prop="oldPsw">
				<el-input type="password" v-model="dataForm.oldPsw" placeholder="旧密码"></el-input>
			</el-form-item>
			<el-form-item label="新密码" prop="newPsw">
				<el-input type="password" v-model="dataForm.newPsw" placeholder="新密码"></el-input>
			</el-form-item>
			<el-form-item label="确认密码" prop="rePsw">
				<el-input type="password" v-model="dataForm.rePsw" placeholder="确认密码"></el-input>
			</el-form-item>
		</el-form>
		<div class="block" style="text-align: center;">
			<el-button type="primary" @click="dataFormSubmit()">提交</el-button>
		</div>
	</div>
</template>

<script>

	import Upload from '@/plugin/oneFileUpload_form'
  import { clearLoginInfo } from '@/utils'

	export default {
		data () {
      var validatePass = (rule, value, callback) => {
        //验证密码
        if (value === '') {
          callback(new Error('请再次输入密码'));
        } else if (value !== this.dataForm.newPsw) {
          callback(new Error('两次输入密码不一致!'));
        } else {
          callback();
        }
      };
			return {
				dataForm: {
					name: '',
					email: '',
					oldPsw: '',
					newPsw: '',
					rePsw: '',
					fileUrl: ''
				},
				dataRule: {
				/*	name: [
						{ required: true, message: '用户名不能为空', trigger: 'blur' }
					],*/
					email: [
						{ required: true, message: 'Email不能为空', trigger: 'blur' }
					],
					oldPsw: [
						{ required: true, message: '旧密码不能为空', trigger: 'blur' }
					],
					newPsw: [
						{ required: true, message: '新密码不能为空', trigger: 'blur' }
					],
					rePsw: [
						{ required: true, message: '确认密码不能为空', trigger: 'blur' },
            {validator: validatePass, trigger: 'blur'}
					]
				},
				uploadUrl: this.$http.adornUrl(`/sys/oss/upload?token=${this.$cookie.get('token')}`)
			}
		},
		created () {

		},
		activated () {
			this.queryUserInfo();
		},
		methods: {
			queryUserInfo(){

			},
			dataFormSubmit(){
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl('/sys/user/modifyInfo'),
              method: 'post',
              data: this.$http.adornData({
                'name': this.dataForm.name,
                'email': this.dataForm.email,
                'password': this.dataForm.oldPsw,
                'newPassword': this.dataForm.newPsw
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$nextTick(() => {
                      this.mainTabs = []
                      clearLoginInfo()
                      this.$router.replace({ name: 'login' })
                    })
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
			},
			changeFileListFunc(imgUrl){
				console.log(imgUrl);
			}
		},
		components: {
			Upload
		}
	}
</script>

<style lang="scss">

</style>
