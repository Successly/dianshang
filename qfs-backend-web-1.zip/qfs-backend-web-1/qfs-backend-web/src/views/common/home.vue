<template>
  <div>
	  <div class="number_show">
		<div class="number_show_body">
		  <p>昨日订单总数</p>
		  <p class="ft3">{{numberShowData.yestOrderTotalCount}}</p>
		</div>
		<div class="number_show_body">
		  <p>昨日销售总额</p>
		  <p class="ft3">¥{{numberShowData.yestSaleTotalCount}}</p>
		</div>
		<div class="number_show_body">
		  <p>昨日新增会员</p>
		  <p class="ft3">{{numberShowData.yestMemberAddNumber}}</p>
		</div>
		<div class="number_show_body">
		  <p>会员总数</p>
		  <p class="ft3">{{numberShowData.memberTotalNumber}}</p>
		</div>
	  </div>
	  <div class="shortcutEntry">
		<h4>运营快捷入口</h4>
		<ul>
		  <li @click="gotoUrl('1')"><span>订单管理</span></li>
		  <li @click="gotoUrl('2')"><span>待入住订单</span></li>
		  <li @click="gotoUrl('3')"><span>预定改价</span></li>
		  <li @click="gotoUrl('4')"><span>房态管理</span></li>
		  <li @click="gotoUrl('5')"><span>营销中心</span></li>
		  <li @click="gotoUrl('4asd')"><span>会员管理</span></li>
		</ul>
	  </div>
  </div>
</template>

<script>
  export default {
    data () {
      return {
		numberShowData: {
		  yestOrderTotalCount: 0,
		  yestSaleTotalCount: 0.00,
		  yestMemberAddNumber: 0,
		  memberTotalNumber: 0
		}
      }
    },
	created () {
      this.getNumberShowData();
    },
	methods: {
	  gotoUrl (url) {
	    console.log(url);
	  },
	  getNumberShowData () {
	    this.numberShowData = {
		  yestOrderTotalCount: 200,
		  yestSaleTotalCount: 500.00,
		  yestMemberAddNumber: 230,
		  memberTotalNumber: 1200
		};
	  }
	}
  }
</script>

<style lang="scss">
  ul, li {
    list-style:none;
	margin: 0;
  }
  .number_show {
    line-height: 1.5;
	font-size: 18px;
	display: flex;
	.number_show_body {
	  flex: 1;
	  padding-left: 70px;
	  border: 1px solid #efefef;
	  p {
	    width: 100%;
		text-align: center;
	  }
	  p.ft3 {
	    font-size: 25px;
	  }
	}
	.number_show_body + .number_show_body {
	  margin-left: 25px;
	}
  }
  .shortcutEntry {
    line-height: 1.5;
	font-size: 14px;
	&:after {
	  clear: both;
	  overflow: hidden;
	}
	h4 {
	  font-size: 18px;
	  line-height: 2;
	  padding-left: 20px;
	}
	ul li {
	  float: left;
	  padding: 70px 10px 10px 10px;
	  width: 150px;
	  line-height: 20px;
	  text-align: center;
	  font-size: 14px;
	  &:hover {
	    cursor: pointer;
	    color: #3ebbff;
		border: 1px solid #3ebbff;
	  }
	  span {
	    display: inline-block;
		height: 20px;
	  }
	}
  }
</style>

