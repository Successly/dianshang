import axios from 'axios'

const baseURL = 'http://192.168.0.113:8000/renren-fast'
axios.defaults.baseURL = baseURL

// 商品分类 - 删除分类
export const deleteCateWork = (id) => {
  return axios({
    method: 'delete',
    url: '/category/delete',
    data: {
      'id': id
    }
  }).then(res => res)
}

// get请求
this.$http({
  url: this.$http.adornUrl(''),
  method: 'get',
  params: this.$http.adornParams({
    'page': this.pageIndex,
    'limit': this.pageSize,
    'username': this.dataForm.userName
  })
}).then(({data}) => {
  console.log('数据格式：', this.dataSource)
  console.log('-----分类列表 成功-----: ', data.data)
  // 正常
  if (data && data.code === 0) {
    this.loading = false
    // 获取列表
    this.dataSource = data.data
  } else if (data.code === 1) {
    console.log('-----/category/list-----', data.msg)
  } else {
    console.log('-----/category/list 服务器异常-----', data.msg)
  }
}).catch((e) => {
  console.log('获取分类列表失败', e)
})

// post请求
this.$http({
  url: this.$http.adornUrl(''),
  method: 'post',
  data: this.$http.adornData({
    'name': value
  })
}).then(({data}) => {
  console.log('-------添加 子分类--------', data)
  // 正常
  if (data && data.code === 0) {
    // 添加分类 成功提示
    this.$message({
      type: 'success',
      message: data.msg
    })
    // 重新刷新一次
    this.initList()
  } else if (data.code === 1) {
    console.log('-----/category/add 请求参数错误-----')
  } else {
    console.log('-----/category/add 服务器异常-----')
  }
}).catch((e) => {
  console.log(e)
})

// delete请求
// 调用删除接口
// get类似删除 参数: 字符
// var ids = id ? [id] : (this.dataListSelections.map(item => { return item.id })).join(',')
this.$http({
  url: this.$http.adornUrl('/merchant/delete'),
  method: 'delete',
  params: this.$http.adornParams({ // ids=10&ids=11
    'ids': ids
  })
}).then(({data}) => {
  // console.log('-------删除--------', data)
  if (data.code === 0 && data.msg === 'success') {
    this.getDataList()
  }
}).catch((e) => {
  console.log(e)
})

// post类似删除
// var ids = id ? [id] : this.dataListSelections.map(item => {
//   return item.id
// })
this.$http({
  url: this.$http.adornUrl('/merchant/delete'),
  method: 'delete',
  data: this.$http.adornData({ // ids=10&ids=11
    'ids': ids
  })
}).then(({data}) => {
  // console.log('-------删除--------', data)
  if (data.code === 0 && data.msg === 'success') {
    this.getDataList()
  }
}).catch((e) => {
  console.log(e)
})